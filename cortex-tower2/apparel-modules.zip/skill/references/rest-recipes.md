# REST recipes for building a Frappe app's metadata on a live site

All examples assume `api` from `scripts/portlib.py` (a `requests.Session` carrying the site token, plus
`api.get/post/put/exists/list/insert`). Names with spaces are URL-quoted.

## Credentials

The workspace gateway knows which apps are installed and hands out the keys:

```
query { getWorkspaceInstalledApps(workspace_id: $w) { app_id name app_type sso_provider } }
query { getKogoSasApiKeys(app_id: $a, workspace_id: $w) { api_base api_key api_secret token } }
```

`Authorization: token <key>:<secret>`. Nothing is stored.

## Module Def

```json
POST /api/resource/Module Def
{"doctype": "Module Def", "module_name": "Arinox Apparel", "app_name": "frappe", "custom": 1}
```

## DocType (from the app's exported JSON)

Keep `name, fields, permissions, autoname, naming_rule, istable, issingle, is_submittable, engine,
sort_field, sort_order, quick_entry, track_changes, description, title_field, search_fields,
allow_rename, editable_grid`; drop `owner/creation/modified/modified_by/field_order/actions/links/states`;
set `custom: 1` and `module`.

```json
POST /api/resource/DocType
{"doctype": "DocType", "name": "Tech Pack", "custom": 1, "module": "...", "fields": [...], "permissions": [...]}
```

Frappe creates the table immediately. Failures seen in practice:

| Error | Cause | Fix |
|---|---|---|
| `LinkValidationError: Role X` | permission names a role that does not exist | create roles first |
| `WrongOptionsDoctypeLinkError: Options must be a valid DocType` | Link/Table target absent | children first; park circular/self Links as `Data`, write back later |
| `Cannot set Submit, Cancel, Amend without Write` | inconsistent permission row | give that row `write: 1` |
| `Only one rule allowed with the same Role, Level and If Owner` | duplicate permission rows | merge, OR-ing the flags |

Writing a parked Link back:

```python
st, cur = api.get(f"/api/resource/DocType/{name}")
rows = cur["data"]["fields"]
for row in rows:
    if row["fieldname"] in parked:            # {"fieldtype": "Link", "options": "Sample Approval"}
        row["fieldtype"] = "Link"
        row["options"] = parked[row["fieldname"]]["options"]
api.put(f"/api/resource/DocType/{name}", {"fields": rows})
```

## Custom Field on a standard doctype

```json
POST /api/resource/Custom Field
{"doctype": "Custom Field", "dt": "Sales Order Item", "fieldname": "apparel_colour",
 "fieldtype": "Data", "label": "Colour", "insert_after": "delivery_date", "read_only": 1}
```

`insert_after` must be an existing field on the target. The column is added at once.

## Single: read and write

```
GET /api/method/frappe.client.get?doctype=Apparel Settings&name=Apparel Settings
PUT /api/resource/Apparel Settings/Apparel Settings        # body = fields to set
```
`/api/resource/Apparel Settings` returns 500 — a Single has no table.

## Child rows

Not listable. Read them off the parent: `frappe.client.get` → `message["sample_rules"]`. Use that for
every existence check, otherwise rows get duplicated on the next run.

## Submit / cancel / delete a test document

```python
api.put(f"/api/resource/{dt}/{name}", {"docstatus": 1})   # submit
api.put(f"/api/resource/{dt}/{name}", {"docstatus": 2})   # cancel
api.s.delete(f"{base}/api/resource/{dt}/{name}")          # delete
```
`frappe.client.submit` can raise `TimestampMismatchError` on a fresh document; the PUT works.

## Workspace (the page)

```json
POST /api/resource/Workspace
{"doctype": "Workspace", "name": "Apparel", "label": "Apparel", "title": "Apparel",
 "module": "Custom", "app": "erpnext", "icon": "organization", "public": 1, "is_hidden": 0,
 "sequence_id": 3, "for_user": "",
 "content": "[{\"id\":\"a1\",\"type\":\"shortcut\",\"data\":{\"shortcut_name\":\"Tech Pack\",\"col\":3}}]",
 "shortcuts": [{"type": "DocType", "link_to": "Tech Pack", "label": "Tech Pack", "color": "Blue",
                "doc_view": "List", "stats_filter": "[]"}],
 "links": [{"type": "Card Break", "label": "Pre-Sales", "link_count": 1},
           {"type": "Link", "label": "Tech Pack", "link_to": "Tech Pack", "link_type": "DocType"}],
 "number_cards": [{"number_card_name": "Open Inquiries", "label": "Open Inquiries"}],
 "charts": [{"chart_name": "Apparel Inquiries", "label": "Apparel Inquiries"}],
 "quick_lists": [], "custom_blocks": [], "roles": []}
```

`module` must resolve to a path (`get_module_path`), so a module no app ships is rejected — use
`Custom` and put the page in the working app's group with `app`.

Content block types: `header`(text), `paragraph`(text), `shortcut`(shortcut_name), `card`(card_name),
`number_card`(number_card_name), `chart`(chart_name), `spacer`. `card_name` must equal a Card Break
label; `shortcut_name` a shortcut label.

## Desktop Icon (the tile on /desk)

```json
POST /api/resource/Desktop Icon
{"doctype": "Desktop Icon", "name": "Apparel", "label": "Apparel", "icon_type": "Link",
 "link_type": "Workspace Sidebar", "link_to": "Apparel", "icon": "shirt", "app": "erpnext",
 "parent_icon": "", "standard": 0, "hidden": 0, "restrict_removal": 0, "roles": []}
```
Drawn only if the sidebar named `link_to` is in boot with a permitted item. `standard: 0` shows it to its
owner (the API user).

## Workspace Sidebar (the rail)

```json
POST /api/resource/Workspace Sidebar
{"doctype": "Workspace Sidebar", "name": "Apparel", "title": "Apparel", "header_icon": "shirt",
 "module": "Arinox Apparel", "app": "erpnext", "standard": 0,
 "items": [
  {"type": "Link", "link_type": "Workspace", "link_to": "Apparel", "label": "Home", "icon": "home",
   "child": 0, "collapsible": 0, "indent": 0, "keep_closed": 0, "show_arrow": 0},
  {"type": "Section Break", "label": "Production", "link_type": "DocType", "icon": "getting-started",
   "child": 0, "collapsible": 1, "indent": 1, "keep_closed": 0, "show_arrow": 0},
  {"type": "Link", "link_type": "DocType", "link_to": "Production Card", "label": "Production Card",
   "icon": "clipboard-check", "child": 0, "collapsible": 0, "indent": 0, "keep_closed": 0, "show_arrow": 0}
 ]}
```
Every Link item needs an `icon`; pick names already used by another sidebar on the site (read every
`Workspace Sidebar`) so the desk is known to draw them.

## Number Card that must not call app Python

```json
POST /api/resource/Report
{"doctype": "Report", "report_name": "Apparel Fabric Overdue Lots", "ref_doctype": "Fabric Requisition",
 "report_type": "Query Report", "query": "select count(*) as value from ...",
 "is_standard": "No", "module": "...", "roles": [{"role": "System Manager"}]}

PUT /api/resource/Number Card/Fabric Overdue
{"type": "Report", "report_name": "Apparel Fabric Overdue Lots", "report_field": "value",
 "report_function": "Sum", "function": "Sum", "method": null, "document_type": null}
```

## Verification calls

```
GET  /api/method/frappe.desk.form.load.getdoctype?doctype=<DocType>       # fields, for link checks
GET  /api/method/frappe.desk.desktop.get_workspaces                      # pages the user may see
POST /api/method/frappe.desk.desktop.get_desktop_page  {"page": <page json>}
POST /api/method/frappe.desk.query_report.run          {"report_name": ..., "filters": "{}"}
POST /api/method/frappe.desk.doctype.number_card.number_card.get_result {"doc": <card>, "filters": "[]"}
GET  /api/method/frappe.utils.change_log.get_versions                    # frappe + erpnext versions
GET  /api/method/frappe.core.doctype.server_script.server_script.enabled # are server scripts on?
```
Note the exact names: on Frappe 16.33 the sidebar call is `frappe.desk.desktop.get_workspaces` (not
`get_workspace_sidebar_items`, which returns null), and each built widget group is `{"items": [...]}`.
