"""Shared plumbing for porting the Arinox Apparel app metadata into the KOGO ERP site.

The site is reached through the workspace app connector (credentials discovered, never hardcoded).
Everything here is read/write over the REST API only - there is no bench access.
"""

import json
import os
import time

import requests

HERE = os.path.dirname(os.path.abspath(__file__))
STATE = os.path.join(HERE, "state")
os.makedirs(STATE, exist_ok=True)

MODULE = os.environ.get("APP_MODULE", "Arinox Apparel")  # <- change for another app


def _gql(query, variables):
    api_path = os.environ.get("API_PATH", "")
    if api_path and not api_path.endswith("/gateway"):
        api_path += "/gateway"
    r = requests.post(
        api_path,
        json={"query": query, "variables": variables},
        headers={
            "Authorization": f"Bearer {os.environ.get('USER_JWT_TOKEN', '')}",
            "Content-Type": "application/json",
        },
        timeout=60,
    )
    body = r.json()
    if body.get("errors"):
        raise SystemExit("gateway error: " + str(body["errors"])[:400])
    return body["data"]


def session():
    apps = _gql(
        "query G($w: ID!){ getWorkspaceInstalledApps(workspace_id:$w){ app_id name } }",
        {"w": os.environ["SWARM_ID"]},
    )["getWorkspaceInstalledApps"]
    erp = [a for a in apps if "ERP" in (a.get("name") or "").upper()]
    if not erp:
        raise SystemExit("no ERP app installed in this workspace")
    keys = _gql(
        """query K($a: String!, $w: ID!){ getKogoSasApiKeys(app_id:$a, workspace_id:$w){
             api_base api_key api_secret token } }""",
        {"a": erp[0]["app_id"], "w": os.environ["SWARM_ID"]},
    )["getKogoSasApiKeys"]
    s = requests.Session()
    if keys.get("token"):
        s.headers.update({"Authorization": f"Bearer {keys['token']}"})
    else:
        s.headers.update({"Authorization": f"token {keys['api_key']}:{keys['api_secret']}"})
    s.headers.update({"Accept": "application/json", "Content-Type": "application/json"})
    s.base_url = keys["api_base"].rstrip("/")
    return s


class Api:
    def __init__(self):
        self.s = session()

    def get(self, path, **params):
        r = self.s.get(self.s.base_url + path, params=params or None, timeout=120)
        try:
            return r.status_code, r.json()
        except Exception:
            return r.status_code, {"text": r.text[:600]}

    def post(self, path, payload, retries=3):
        last = None
        for i in range(retries):
            try:
                r = self.s.post(self.s.base_url + path, json=payload, timeout=180)
                try:
                    return r.status_code, r.json()
                except Exception:
                    return r.status_code, {"text": r.text[:600]}
            except Exception as exc:  # transient socket / 502
                last = str(exc)
                time.sleep(2 + 2 * i)
        return 0, {"exception": f"request failed: {last}"}

    def put(self, path, payload):
        r = self.s.put(self.s.base_url + path, json=payload, timeout=180)
        try:
            return r.status_code, r.json()
        except Exception:
            return r.status_code, {"text": r.text[:600]}

    def exists(self, doctype, name):
        st, r = self.get(f"/api/resource/{requests.utils.quote(doctype)}/{requests.utils.quote(name)}")
        return st == 200

    def list(self, doctype, fields="[\"name\"]", filters=None, limit=0):
        params = {"fields": fields, "limit_page_length": limit}
        if filters:
            params["filters"] = filters
        st, r = self.get(f"/api/resource/{requests.utils.quote(doctype)}", **params)
        if st != 200:
            return []
        return r.get("data") or []

    def insert(self, doctype, doc):
        return self.post(f"/api/resource/{requests.utils.quote(doctype)}", doc)


def err(resp):
    """Short, readable error from a Frappe response."""
    if isinstance(resp, dict):
        for key in ("exception", "_server_messages", "exc_type", "text"):
            if resp.get(key):
                msg = resp[key]
                if key == "_server_messages":
                    try:
                        msgs = json.loads(msg)
                        msg = " | ".join(json.loads(m).get("message", "") for m in msgs)
                    except Exception:
                        pass
                msg = str(msg)
                if len(msg) > 500:
                    msg = msg[:500] + "..."
                return f"{resp.get('exc_type', '')}: {msg}".strip(": ")
    return str(resp)[:500]


def save(name, data):
    with open(os.path.join(STATE, f"{name}.json"), "w") as fh:
        json.dump(data, fh, indent=1)


def load(name):
    p = os.path.join(STATE, f"{name}.json")
    if os.path.exists(p):
        with open(p) as fh:
            return json.load(fh)
    return None
