---
name: frappe-metadata-ingest
description: Copy a Frappe/ERPNext app's document types, fields, master data and desk navigation into a KOGO ERP site over its REST API, when the server has no shell and `bench install-app` is impossible. Use when someone points at a GitHub app repo (or any app source tree) and asks to add its modules, doctypes or features to the ERP in the workspace, or asks what has already been ingested and what a newer version of the app would add.
---

# Ingesting a Frappe app's metadata into a live site

A Frappe app normally travels by `bench get-app` / `install-app` / `migrate`. A KOGO ERP site is
reachable only through its REST API, so an app **cannot be installed**. What can be done is to recreate
the app's **records**: document types, custom fields, masters, print formats, cards, and the desk
navigation. Say that difference out loud before starting — the forms, fields and masters arrive, the
Python business logic does not.

## Phase 0 — decide, and say so

`GET /api/method/frappe.utils.change_log.get_versions` gives the target's Frappe and ERPNext versions;
the app's `pyproject.toml` / `README` gives what it targets. Different major.minor is a reason to stop
and ask.

Then tell the user what does and does not cross:

- **crosses**: doctypes, fields, child tables, permissions, links, numbering, custom fields on standard
  documents, master data, print formats, number cards, charts, workspace page, desk tile and rail
- **does not**: doctype controllers (validation, ledger posting, gates), `hooks.py` (`doc_events`,
  `override_doctype_class`, `doctype_js`, schedulers), script reports, desk pages (JS), patches

## Phase 1 — order of work (every step idempotent)

1. **Module Def** — `POST /api/resource/Module Def` with `module_name`, `app_name`, `custom: 1`.
2. **Roles** — every role named in any doctype's `permissions` plus the app's own list. A permission
   naming a missing Role makes the doctype insert fail.
3. **Child tables first, then parents, in passes** (`v2/loader/kogo_load.py`, group 03). Frappe refuses a Link or
   Table whose target is absent, and such apps link in circles (Production Card → its child → Sample
   Approval → PP Meeting → back) and to themselves (`Amended From`). Park those Link fields as `Data` for
   the insert, PUT the Link back once every target exists (`v2/loader/kogo_load.py`, two-pass loop).
4. **Custom fields** on standard doctypes — read them out of the app source (`setup/install.py`,
   `setup/materials.py`), never retype (`v2/loader/kogo_load.py`, group 04).
5. **Master data** — run the app's own seed functions against a recording stand-in for `frappe`, so field
   names come from the app and cannot drift, then push what it captured (`v2/loader/kogo_load.py`, group 06).
6. **Settings** — a Single stores nothing until saved; write defaults, and dedupe its child rows
   (`v2/loader/kogo_load.py`, group 07).
7. **UI records** — print formats, number cards, dashboard charts (`v2/loader/kogo_load.py`, groups 08-11).
8. **Desk navigation** — decides whether the user ever finds the work:
   - `Workspace` = the page. Its `module` must map to a real app folder or the insert fails with
     "Module X not found" (use the framework's `Custom`); its `app` field decides which app group the
     desk lists it under — set it to the working app (`erpnext`), not `frappe`.
   - `Desktop Icon` = the tile on `/desk`: `icon_type: Link`, `link_type: Workspace Sidebar`,
     `link_to` = the sidebar's **name**, `parent_icon: ""` for top level. It is only drawn when that
     sidebar exists in boot *and* has an item the user may open.
   - `Workspace Sidebar` = the rail, one `Workspace Sidebar Item` per line; every Link item needs an
     `icon` or it renders as bare text. A sidebar named exactly like a module suppresses the
     auto-generated one.
   - Then **touch the Desktop Icon** (`PUT` an unchanged field): that clears the per-user
     `desktop_icons` and `bootinfo` caches. `frappe.clear_cache` is not whitelisted. The browser still
     needs a reload.
9. **No record may call app Python.** A Number Card with `type: Custom` and `method: <app>.<mod>.<fn>`
   throws "App <app> is not installed" as the page loads. Rebuild those as `type: Report` over a small
   `Query Report` holding the app's own SQL (`v2/loader/kogo_load.py`, groups 10-11), then sweep
   `Number Card.method`, `Report.query`, `Dashboard Chart`, `Print Format.html`, `Workspace.content` for
   `<app>.` — zero hits is the goal.
10. **Manifest** — `v2/loader/make_inventory_md.py` writes `v2/INVENTORY.md`, one row per record with
    its live presence, so the next pull is a diff instead of a re-run.

## Phase 2 — verify the way the desk does

Never report success from an HTTP 200.

- every doctype answers a list query (`GET /api/resource/<Doctype>?limit_page_length=1`)
- no Link/Table points at a missing doctype (walk `frappe.desk.form.load.getdoctype` for all of them)
- create a parent record with child rows, then delete it
- replay the desk: `frappe.desk.desktop.get_workspaces` → find the page → `POST`
  `frappe.desk.desktop.get_desktop_page` with **that page's JSON** (it takes the page, not its name) →
  `cards`, `shortcuts`, `charts`, `number_cards` must each come back as `{"items": [...]}`
- run every card: `frappe.desk.query_report.run` for Report cards,
  `frappe.desk.doctype.number_card.number_card.get_result` for Document Type cards
- leave no test records behind

## Traps that cost time

- **Child doctypes cannot be listed** over the API (403 even for System Manager). Read them through
  `frappe.client.get` on the parent, or every idempotency check says "empty" and you duplicate rows.
- **Singles have no table**: `/api/resource/<Single>` 500s on the list route. Use `frappe.client.get`
  and `PUT /api/resource/<Single>/<Single>`.
- `naming_series:` doctypes need the series on insert; a doctype with no `autoname` gets a hash name —
  that is the app's own behaviour.
- A pre-existing broken Link on a standard doctype blocks **any** custom field added to it. Park it, or
  create the missing doctype.
- Report cards need `report_name`, `report_field`, `report_function`; `get_result` only understands
  Document Type cards — Report cards resolve client-side through `query_report.run`.
- The platform **re-provisions `userfiles/CORE_AGENT_SKILLS/`** and deletes skills added there. Keep the
  canonical copy in the project folder (`apparel-modules/skill/`) and copy it in when needed.

## Scripts

The working implementation for the Arinox Apparel app is `../v2/loader/` (bundle-driven, one command):

| script | job |
|---|---|
| `kogo_load.py` | load the 17 bundle groups, upsert by name, two-pass doctypes |
| `post_fix.py` | workspace `app`/`module`, icon cache, desk page proof |
| `script_switch.py` | `--probe` the site's `server_script_enabled`, then `--on` / `--off [--type=...]` |
| `verify_after_load.py` | group-by-group proof against the live site, runs every report |
| `make_inventory_md.py` | regenerate `v2/INVENTORY.md` |
| `validate_bundle.py` | offline pre-flight: links, fields, scripts, reports, seeds |

An app that ships its own hosted bundle needs nothing else. Without one, build the same 17 groups
from the app source (export doctypes, custom fields, seeds, settings, prints, reports, cards,
workspaces, sidebars, icons, client and server scripts) and load them with the same loader.
Credentials come from `scripts/portlib.py` (workspace gateway, nothing stored); set `APP_MODULE` for
another app.

`references/rest-recipes.md` has the exact request bodies for each record type.
