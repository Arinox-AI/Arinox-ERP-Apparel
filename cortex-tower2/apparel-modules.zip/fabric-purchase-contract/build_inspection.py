#!/usr/bin/env python3
"""Put the Cortex FABRIC INSPECTION REPORT into the KOGO ERP.

Home is the existing `Fabric Inspection` doctype (Arinox Apparel): it already holds the rolls,
the defect log, the shrinkage readings, the width checks and the result this sheet reports.
No new doctype. One custom field is added for the contract number the sheet prints.

The sheet is 4 rolls wide, like the paper form; a lot with more rolls prints one sheet per 4 rolls.

Run:  python3 build_inspection.py [--dry-run] [--with-font]
"""
import base64
import os
import sys

from build import Site, why

HERE = os.path.dirname(os.path.abspath(__file__))
DOC = "Fabric Inspection"
PF = "Fabric Inspection Report"


def template_html(with_font=False):
    html = open(os.path.join(HERE, "print_format_inspection.html"), encoding="utf-8").read()
    # the ruler is a PNG on purpose: the ERP's PDF engine (wkhtmltopdf/QtWebKit) renders data-URI
    # images fine but drops inline SVG, so the sheet came out with empty measuring columns.
    png = open(os.path.join(HERE, "fabric_ruler.png"), "rb").read()
    html = html.replace("__RULER_PNG__", "data:image/png;base64," + base64.b64encode(png).decode())
    font = ""
    if with_font:
        path = os.path.join(HERE, "font_css.txt")
        font = open(path, encoding="utf-8").read() if os.path.exists(path) else ""
    return html.replace("/*__CJK_FONT_CSS__*/", font)


def main(argv):
    dry = "--dry-run" in argv
    site = Site()
    if site.get("/api/method/frappe.auth.get_logged_user")[0] != 200:
        raise SystemExit("cannot reach the ERP")
    if not site.exists("DocType", DOC):
        raise SystemExit("doctype %s is missing on this site" % DOC)

    # 1. contract number (the sheet prints CTSC合同号; the doctype only has the receipt link)
    cf = "%s-custom_contract_no" % DOC
    if site.exists("Custom Field", cf):
        print("custom field exists:", cf)
    elif dry:
        print("[dry] custom field", cf)
    else:
        st, r = site.create("Custom Field", {
            "doctype": "Custom Field", "name": cf, "dt": DOC, "fieldname": "custom_contract_no",
            "label": "Contract No. 合同号", "fieldtype": "Data", "insert_after": "purchase_order"})
        print("custom field custom_contract_no            -> %s %s" % (st, "" if st == 200 else why(r)))

    # 2. print format
    html = template_html(with_font="--with-font" in argv)
    print("print format html: %d bytes (ruler inlined)" % len(html))
    if site.exists("Print Format", PF):
        if dry:
            print("[dry] update print format", PF)
        else:
            st, r = site.put("Print Format", PF, {"html": html, "custom_format": 1,
                                                 "print_format_type": "Jinja", "doc_type": DOC})
            print("update print format %-24s -> %s %s" % (PF, st, "" if st == 200 else why(r)))
    else:
        body = {"doctype": "Print Format", "name": PF, "doc_type": DOC, "module": "Arinox Apparel",
                "custom_format": 1, "print_format_type": "Jinja", "standard": "No", "disabled": 0,
                "html": html, "margin_top": 8, "margin_bottom": 8, "margin_left": 8, "margin_right": 8,
                "font_size": 7, "page_number": "Hide", "print_format_builder": 0,
                "print_format_builder_beta": 0, "raw_printing": 0, "align_labels_right": 0,
                "absolute_value": 0, "show_section_headings": 0, "line_breaks": 0}
        if dry:
            print("[dry] create print format", PF)
        else:
            st, r = site.create("Print Format", body)
            print("create print format %-24s -> %s %s" % (PF, st, "" if st == 200 else why(r)))
            if st != 200:
                return 1

    if not dry:
        st, r = site.put("DocType", DOC, {"default_print_format": PF})
        print("set %s default print format -> %s %s" % (DOC, st, "" if st == 200 else why(r)))

    print("\ndone.")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
