#!/usr/bin/env python3
"""Put the Cortex FINAL INSPECTION REPORT into the KOGO ERP.

Second format on the stock `Quality Inspection` doctype (the first is `Fabric Testing Report`,
which stays the doctype default - this one is chosen in the Print dropdown).

Adds the header fields the sheet prints that the doctype does not carry.

Run:  python3 build_final.py [--dry-run] [--with-font]
"""
import base64
import os
import sys

from build import Site, why

HERE = os.path.dirname(os.path.abspath(__file__))
DOC = "Quality Inspection"
PF = "Final Inspection Report (Cortex)"  # named so the bundle's own
                                      # "Final Inspection Report" on doctype Final Inspection is untouched

CUSTOM_FIELDS = [
    ("custom_season", "Season", "item_name"),
    ("custom_po_no", "PO No. 客人合同号", "custom_season"),
    ("custom_buyer_code", "Buyer Code", "custom_po_no"),
    ("custom_country_of_origin", "Country of Origin", "custom_buyer_code"),
    ("custom_supplier_rep", "Supplier Rep", "custom_country_of_origin"),
    ("custom_po_qty", "PO Quantity", "custom_supplier_rep"),
    ("custom_offered_qty", "Offered Quantity", "custom_po_qty"),
]


def template_html(with_font=False):
    html = open(os.path.join(HERE, "print_format_final.html"), encoding="utf-8").read()
    png = open(os.path.join(HERE, "final_inspection_logo.png"), "rb").read()
    html = html.replace("__FI_LOGO__", "data:image/png;base64," + base64.b64encode(png).decode())
    font = ""
    if with_font:
        path = os.path.join(HERE, "font_css.txt")
        font = open(path, encoding="utf-8").read() if os.path.exists(path) else ""
    return html.replace("/*__CJK_FONT_CSS__*/", font)


def main(argv):
    dry = "--dry-run" in argv
    site = Site()
    if site.get("/api/method/frappe.auth.get_logged_user")[0] != 200:
        raise SystemExit("cannot reach the ERP")
    if not site.exists("DocType", DOC):
        raise SystemExit("doctype %s is missing on this site" % DOC)

    for fieldname, label, after in CUSTOM_FIELDS:
        name = "%s-%s" % (DOC, fieldname)
        if site.exists("Custom Field", name):
            continue
        if dry:
            print("[dry] custom field", fieldname)
            continue
        st, r = site.create("Custom Field", {
            "doctype": "Custom Field", "name": name, "dt": DOC, "fieldname": fieldname,
            "label": label, "fieldtype": "Data", "insert_after": after})
        print("custom field %-26s -> %s %s" % (fieldname, st, "" if st == 200 else why(r)))

    html = template_html(with_font="--with-font" in argv)
    print("print format html: %d bytes (logo inlined)" % len(html))
    # never touch a format of the same name that belongs to another doctype
    st, existing = site.get("/api/resource/Print%20Format", filters='[["name","=","%s"]]' % PF,
                            fields='["name","doc_type"]')
    clash = [r for r in (existing.get("data") or []) if r.get("doc_type") != DOC]
    if clash:
        raise SystemExit("a print format called %r already exists on %r - refusing to overwrite"
                         % (PF, clash[0]["doc_type"]))
    if site.exists("Print Format", PF):
        if dry:
            print("[dry] update print format", PF)
        else:
            st, r = site.put("Print Format", PF, {"html": html, "custom_format": 1,
                                                 "print_format_type": "Jinja", "doc_type": DOC})
            print("update print format %-24s -> %s %s" % (PF, st, "" if st == 200 else why(r)))
    else:
        body = {"doctype": "Print Format", "name": PF, "doc_type": DOC, "module": "Stock",
                "custom_format": 1, "print_format_type": "Jinja", "standard": "No", "disabled": 0,
                "html": html, "margin_top": 8, "margin_bottom": 8, "margin_left": 8, "margin_right": 8,
                "font_size": 9, "page_number": "Hide", "print_format_builder": 0,
                "print_format_builder_beta": 0, "raw_printing": 0, "align_labels_right": 0,
                "absolute_value": 0, "show_section_headings": 0, "line_breaks": 0}
        if dry:
            print("[dry] create print format", PF)
        else:
            st, r = site.create("Print Format", body)
            print("create print format %-24s -> %s %s" % (PF, st, "" if st == 200 else why(r)))
            if st != 200:
                return 1

    print("\nQuality Inspection default print format stays 'Fabric Testing Report';")
    print("this one is picked in the Print dropdown.")
    print("\ndone.")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
