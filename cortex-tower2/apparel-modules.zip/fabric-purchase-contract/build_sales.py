#!/usr/bin/env python3
"""Put the Cortex fabric SALES CONTRACT print format into the KOGO ERP.

Target is the existing `Sales Contract` doctype of the apparel module, not Sales Order:
the doctype already carries the contract fields (contract_date, buyer_po_no, revision_date,
revised_for, buyer_contact, customer_address, item style_no/colour/qty/rate/ex_factory_date).

What it does, idempotently:
  1. adds two custom fields to Sales Contract Item: print_type and surcharge
     (Custom Field records, so the doctype's own field list is never rewritten)
  2. creates/updates Print Format `Fabric Sales Contract`
  3. makes it the default print format of Sales Contract

Run:  python3 build_sales.py [--dry-run] [--with-font]
"""
import json
import os
import sys

from build import Site, why

HERE = os.path.dirname(os.path.abspath(__file__))
DOC = "Sales Contract"
ITEM = "Sales Contract Item"
PF = "Fabric Sales Contract"

CUSTOM_FIELDS = [
    {"dt": ITEM, "fieldname": "print_type", "label": "Print / Solid / Y/D 印花/素色/色织",
     "fieldtype": "Data", "insert_after": "colour", "in_list_view": 0},
    {"dt": ITEM, "fieldname": "surcharge", "label": "Surcharge 附加费",
     "fieldtype": "Currency", "insert_after": "rate", "in_list_view": 0},
]


def template_html(with_font=False):
    html = open(os.path.join(HERE, "print_format_sales.html"), encoding="utf-8").read()
    font = ""
    if with_font:
        path = os.path.join(HERE, "font_css.txt")
        font = open(path, encoding="utf-8").read() if os.path.exists(path) else ""
    return html.replace("/*__CJK_FONT_CSS__*/", font)


def main(argv):
    dry = "--dry-run" in argv
    site = Site()
    if site.get("/api/method/frappe.auth.get_logged_user")[0] != 200:
        raise SystemExit("cannot reach the ERP")

    for dt in (DOC, ITEM):
        if not site.exists("DocType", dt):
            raise SystemExit("doctype %s is missing on this site" % dt)

    # 1. custom fields (a Custom Field record never touches the doctype's own field list)
    for cf in CUSTOM_FIELDS:
        name = "%s-%s" % (cf["dt"], cf["fieldname"])
        if site.exists("Custom Field", name):
            print("custom field exists:", name)
            continue
        body = dict(cf, doctype="Custom Field", name=name)
        if dry:
            print("[dry] create custom field", name)
        else:
            st, r = site.create("Custom Field", body)
            print("create custom field %-42s -> %s %s" % (name, st, "" if st == 200 else why(r)))

    # 2. print format
    html = template_html(with_font="--with-font" in argv)
    print("print format html: %d bytes" % len(html))
    if site.exists("Print Format", PF):
        if dry:
            print("[dry] update print format", PF)
        else:
            st, r = site.put("Print Format", PF, {"html": html, "custom_format": 1,
                                                  "print_format_type": "Jinja", "doc_type": DOC})
            print("update print format %-26s -> %s %s" % (PF, st, "" if st == 200 else why(r)))
    else:
        body = {"doctype": "Print Format", "name": PF, "doc_type": DOC, "module": "Arinox Apparel",
                "custom_format": 1, "print_format_type": "Jinja", "standard": "No", "disabled": 0,
                "html": html, "margin_top": 8, "margin_bottom": 8, "margin_left": 8, "margin_right": 8,
                "font_size": 10, "page_number": "Hide", "print_format_builder": 0,
                "print_format_builder_beta": 0, "raw_printing": 0, "align_labels_right": 0,
                "absolute_value": 0, "show_section_headings": 0, "line_breaks": 0}
        if dry:
            print("[dry] create print format", PF)
        else:
            st, r = site.create("Print Format", body)
            print("create print format %-26s -> %s %s" % (PF, st, "" if st == 200 else why(r)))
            if st != 200:
                return 1

    # 3. default print format
    if not dry:
        st, r = site.put("DocType", DOC, {"default_print_format": PF})
        print("set %s default print format -> %s %s" % (DOC, st, "" if st == 200 else why(r)))

    print("\ndone.")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
