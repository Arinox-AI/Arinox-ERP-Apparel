#!/usr/bin/env python3
"""Build font_css.txt: a tiny embedded CJK font for the print format.

Why: the ERP renders PDFs on the server, and the server has no Chinese font, so
张家港卡泰克斯纺织有限公司 and every Chinese label came out as blank boxes. The
browser on the user's machine has fonts, so only the server PDF was broken.

Fix: subset Noto Sans SC down to the few hundred characters this contract actually
uses (plus 400 and 700 weights) and inline it as base64 @font-face. Self contained,
no network at print time, ~1-2 % of the original font.

Run: python3 make_font_subset.py     -> writes font_css.txt
"""
import base64
import io
import os
import re
import sys

import requests
from fontTools.subset import Options, Subsetter
from fontTools.ttLib import TTFont

HERE = os.path.dirname(os.path.abspath(__file__))
BASE = "https://cdn.jsdelivr.net/npm/@fontsource/noto-sans-sc@5.0.0/files/noto-sans-sc-chinese-simplified-%d-normal.woff2"
WEIGHTS = (400, 700)
EXTRA = "　、。，．：；（）《》“”‘’—…·¥￥"


def chars():
    text = open(os.path.join(HERE, "print_format.html"), encoding="utf-8").read()
    used = {c for c in text if ord(c) > 0x2000}
    used.update(EXTRA)
    return "".join(sorted(used))


def subset(data: bytes, text: str) -> bytes:
    font = TTFont(io.BytesIO(data))
    opts = Options()
    opts.flavor = None  # plain TTF: wkhtmltopdf / QtWebKit cannot read woff2
    opts.desubroutinize = True
    opts.layout_features = ["*"]
    opts.notdef_outline = True
    opts.drop_tables += ["DSIG"]
    sub = Subsetter(options=opts)
    sub.populate(text=text)
    sub.subset(font)
    out = io.BytesIO()
    font.save(out)
    return out.getvalue()


def main():
    text = chars()
    cjk = [c for c in text if ord(c) > 0x2E00]
    print("characters to keep: %d (CJK: %d)" % (len(text), len(cjk)))
    css = []
    total = 0
    for w in WEIGHTS:
        r = requests.get(BASE % w, timeout=180)
        r.raise_for_status()
        small = subset(r.content, text)
        total += len(small)
        print("  weight %d: %d KB -> %d KB" % (w, len(r.content) // 1024, len(small) // 1024))
        b64 = base64.b64encode(small).decode()
        css.append("@font-face{font-family:'CortexCJK';font-style:normal;font-weight:%d;"
                   "src:url(data:font/otf;base64,%s) format('opentype');}" % (w, b64))
    out = os.path.join(HERE, "font_css.txt")
    open(out, "w", encoding="utf-8").write("\n".join(css))
    print("wrote %s (%d KB of css, %d KB of font)" % (out, os.path.getsize(out) // 1024, total // 1024))
    return 0


if __name__ == "__main__":
    sys.exit(main())
