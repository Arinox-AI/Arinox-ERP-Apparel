#!/usr/bin/env python3
"""Render print_format.html with sample data, the way the ERP renders it.

No ERP write, no record created. Produces preview.html + preview.png in /tmp
(and a copy of the png next to this script when --save is passed).
"""
import base64 as _b64_mod
import datetime
import os
import subprocess
import sys

from jinja2 import Environment

HERE = os.path.dirname(os.path.abspath(__file__))


class Row:
    """Stand-in for a Frappe child row: attribute access + get_formatted()."""

    def __init__(self, **kw):
        self.__dict__.update(kw)

    def __getattr__(self, k):
        return ""

    def get(self, k, default=None):
        v = self.__dict__.get(k, default)
        return default if v is None else v

    def get_formatted(self, f):
        v = getattr(self, f, None)
        if not v:
            return ""
        if isinstance(v, (datetime.date, datetime.datetime)):
            return v.strftime("%d-%m-%Y")
        return str(v)


class Doc(Row):
    pass


class Frappe:
    """Just enough of the frappe namespace for a template that touches frappe.utils / frappe.db."""
    class utils:
        @staticmethod
        def formatdate(v, fmt="dd-MMM-yyyy"):
            if not v:
                return ""
            months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
            return "%02d-%s-%d" % (v.day, months[v.month - 1], v.year)

    class db:
        @staticmethod
        def get_value(doctype, name, fields=None, as_dict=False):
            if as_dict:
                return None
            if fields == "customer_name":
                return "HARBOR & LANE APPAREL LLC"
            if fields == "delivery_date":
                return datetime.date(2026, 12, 28)
            if fields == "supplier":
                return "Go Go Garment Unit, Tirupur"
            return None


SAMPLE_SALES = Doc(
    name="ZZ-SAMPLE-SC-001",
    arinox_name="SC-CTX-2026-0114",
    customer="HARBOR & LANE APPAREL LLC",
    customer_name="HARBOR & LANE APPAREL LLC",
    brand="HARBOR & LANE APPAREL LLC",
    customer_address="",
    buyer_contact="Ms. Dana Ruiz / +1 415 555 0134 / dana@harborlane.com",
    contract_date=datetime.date(2026, 11, 7),
    revision_date=datetime.date(2026, 11, 7),
    revised_for="Delivery dates on lines 2 updated after buyer request",
    buyer_po_no="PO-CTX-88421",
    currency="USD",
    signed_by_buyer="",
    signed_by_company="",
    buyer_signed_on=None,
    company_signed_on=None,
    items=[
        Row(style_no="C9043-U70-629", fabric_description='100% COTTON POPLIN 40X40/133X72 57/58"',
            print_type="Solid 素色", colour="OPTIC WHITE", qty=4200, rate=9.8, surcharge=0,
            ex_factory_date=datetime.date(2026, 12, 20)),
        Row(style_no="C2027-S84-304", fabric_description="COTTON SPANDEX TWILL 32X16+70D/130X56",
            print_type="Y/D 色织", colour="INDIGO BLUE", qty=3100, rate=12.4, surcharge=120,
            ex_factory_date=datetime.date(2026, 12, 28)),
        Row(style_no="C8009-R43-304", fabric_description='LINEN 100% 14X14/54X54 53/54"',
            print_type="Solid 素色", colour="NATURAL FLAX", qty=1850, rate=21.5, surcharge=0,
            ex_factory_date=datetime.date(2027, 1, 12)),
    ],
)


import base64 as _b64

SAMPLE_PP = Doc(
    name="PPM-26-00003",
    meeting_type="PP Meeting",
    customer="HARBOR & LANE APPAREL LLC",
    style_no="C9043-U70-629",
    work_order_ref="WO-2026-0114",
    order_qty=7300,
    delivery_date=datetime.date(2026, 12, 28),
    line="",
    pp_sample="SMP-2026-0088",
    size_set_sample="SMP-2026-0091",
    line_setting_checklist=1,
    pp_corrections_for_cutting=1,
    size_set_corrections_for_cutting=0,
    participants=[Row(department=d, designation=d, participant_name=n) for d, n in [
        ("IE", "R. Selvam"), ("MERCHANTS", "P. Anand"), ("MECHANIC", "K. Muthu"),
        ("CUTTING SUPERVISOR & QC", "S. Devi"), ("LINE SUPERVISOR", "M. Ravi"),
        ("LINE QC", "A. Priya"), ("CAD INCHARGE", "J. Kumar"), ("FINISHING INCHARGE", "T. Bala")]],
    colours=[
        Row(colour="OPTIC WHITE", buyer_po="PO-CTX-88421", order_qty=4200, fabric_required_m=3960.5,
            fabric_received_m=3980, no_of_shades=2),
        Row(colour="INDIGO BLUE", buyer_po="PO-CTX-88421", order_qty=3100, fabric_required_m=2930,
            fabric_received_m=2900, no_of_shades=3)],
    actions=[
        Row(comment="Collar interlining too stiff on PP sample", action_taken="Switched to softer 220 gsm interlining"),
        Row(comment="Shade variation between rolls L-04 and L-05", action_taken="Cutting to follow grouping marker only"),
        Row(comment="Size set chest measurement +1 cm", action_taken="Pattern corrected")],
    sewing_trims="Available", packing_trims="Available", prewashed_trims="Yes", predyed_trims="No",
    critical_operations="Collar joining, sleeve placket, bottom hem stitch\nPlacket must be cut on grouping marker only",
    expected_problems="Shade variation on indigo\nNeedle marks on poplin",
    preventive_actions="Grouping marker mandatory\nUse SP needle, change every 8 hours",
    checkpoints="Inline after collar joining\nEnd of line 100% measurement\nFinal audit before packing",
    spi="14 SPI", needle_size="DBx1 11#", needle_type="Ball point",
    needle_change_frequency="Every 8 hours", marking_method="Magic pen",
    washing_method="Garment wash - soft, 40C, no bleach",
    finishing_instructions="Inline 100% check, measurement every 20 pcs",
    ironing="Steam press, 130C max", packing="1 pc per poly bag, 20 pcs per carton",
    special_requirements="Hangtag on left side seam",
)


SAMPLE_PILOT = Doc(
    name="PR-26-00004",
    production_card="PC-C9043-001",
    sales_order="SAL-ORD-2026-00083",
    style_no="C9043-U70-629",
    run_date=datetime.date(2026, 11, 7),
    status="Approved with Comments",
    line="",
    pilot_pp_meeting="PPM-26-00003",
    line_supervisor="apparelerp@gmail.com",
    line_qc="apparelerp@gmail.com",
    cutting_supervisor="apparelerp@gmail.com",
    cad_incharge="apparelerp@gmail.com",
    colours=[Row(colour="OPTIC WHITE", qty_planned=30), Row(colour="INDIGO BLUE", qty_planned=30)],
    checks=[
        Row(check_item="Construction", result="No",
            comment="Collar stand height 4.2 cm against 4.0 cm spec",
            action_taken="Pattern corrected, re-run on 10 pcs", responsible="CAD", location="Pattern room"),
        Row(check_item="Fit and measurements after wash", result="Yes",
            comment="Chest within tolerance after wash", responsible="QC", location="Wash plant"),
        Row(check_item="Wash result vs approved standard", result="No",
            comment="Shade slightly darker than approved swatch",
            action_taken="Re-wash trial with new recipe", responsible="QC", location="Wash plant")],
    pattern_cutting_supervisor_comment="Collar and cuff interlining changed to softer quality\nPlacket length ok after correction",
    pattern_cutting_qc_comment="Measurement chart updated on 7 Nov\nWash shade to be re-approved by buyer",
    participants=[Row(participant_name="P. Anand", designation="Merchant"),
                  Row(participant_name="R. Selvam", designation="IE")],
)


SAMPLE_TEST = Doc(
    name="MAT-QA-2026-00010",
    item_code="100% COTTON POPLIN 40X40",
    item_name="C9043-U70-629",
    description="Cotton poplin, piece dyed",
    report_date=datetime.date(2026, 11, 7),
    custom_customer="HARBOR & LANE APPAREL LLC",
    custom_contract_no="CTX-FAB-2026-0114",
    custom_finish_applied="Soft wash / silicone",
    custom_construction="40X40 / 133X72",
    custom_colour="OPTIC WHITE",
    inspected_by="apparelerp@gmail.com",
    verified_by="QA Manager",
    remarks="Shade band found on 2 rolls, re-checked and cleared.\nWidth on the lower side but within tolerance.",
    readings=[
        Row(specification="Width (Finished) 成品幅宽", reading_value="57.5", status="Accepted", manual_inspection=1),
        Row(specification="Weight 重量", reading_value="118", status="Accepted", manual_inspection=1),
        Row(specification="Finished Density Warp 成品密度 经向", reading_value="132", status="Accepted", manual_inspection=1),
        Row(specification="Finished Density Weft 成品密度 纬向", reading_value="70", status="Accepted", manual_inspection=1),
        Row(specification="Tensile Strength Warp 拉伸强力 经向", reading_value="52", status="Accepted", manual_inspection=1),
        Row(specification="Tensile Strength Weft 拉伸强力 纬向", reading_value="31", status="Rejected", manual_inspection=1),
        Row(specification="Tearing Strength Warp 撕破强力 经向", reading_value="3.1", status="Accepted", manual_inspection=1),
        Row(specification="Tearing Strength Weft 撕破强力 纬向", reading_value="2.4", status="Accepted", manual_inspection=1),
        Row(specification="Seam Strength Warp 缝线滑移 经向", reading_value="26", status="Accepted", manual_inspection=1),
        Row(specification="Seam Strength Weft 缝线滑移 纬向", reading_value="23", status="Accepted", manual_inspection=1),
        Row(specification="Shrinkage Warp 缩水率 经向", reading_value="-2.1", status="Accepted", manual_inspection=1),
        Row(specification="Shrinkage Weft 缩水率 纬向", reading_value="-1.4", status="Accepted", manual_inspection=1),
        Row(specification="Skewness Warp 纬斜 经向", reading_value="1.2", status="Accepted", manual_inspection=1),
        Row(specification="Skewness Weft 纬斜 纬向", reading_value="0.9", status="Accepted", manual_inspection=1),
        Row(specification="Washing Colour Change 水洗变色", reading_value="4", status="Accepted", manual_inspection=1),
        Row(specification="Rubbing Dry 干磨", reading_value="4", status="Accepted", manual_inspection=1),
        Row(specification="Rubbing Wet 湿磨", reading_value="3", status="Accepted", manual_inspection=1),
        Row(specification="pH Value 布身pH值", reading_value="6.4", status="Accepted", manual_inspection=1),
        Row(specification="Pilling 起毛起球", reading_value="3", status="Rejected", manual_inspection=1),
    ],
)


SAMPLE_INSP = Doc(
    name="FI-26-00005",
    fabric_item="100% COTTON POPLIN 40X40",
    style_nos="C9043-U70-629",
    description='100% COTTON POPLIN 40X40/133X72 57/58"',
    colour="OPTIC WHITE",
    customer="HARBOR & LANE APPAREL LLC",
    supplier="SHAOXING LISA TEXTILE CO., LTD",
    purchase_order="PO-CTX-88421",
    purchase_receipt="MAT-PRE-2026-00068",
    custom_contract_no="CTSC-2026-0114",
    inspection_date=datetime.date(2026, 11, 7),
    inspected_by="apparelerp@gmail.com",
    inspection_machine="MA-01",
    light_source="D65",
    required_width_cm=147,
    inspected_m=591,
    lot_result="Pass",
    remarks="One roll rejected for shade band. Rest accepted.",
    rolls=[
        Row(roll_no="R-%03d" % i, dye_lot="LOT-0%d" % (1 + i // 3), ticket_length=100.0,
            actual_length=98.5 - i, width_required_cm=147, width_start_cm=148.2, width_middle_cm=147.6,
            width_end_cm=147.1, csv_ok=(i % 2 == 0), bowing_skew_pct=1.2 + i / 10,
            face_side_marked=(i < 4), roll_result=("Accept" if i < 5 else "Reject"),
            points_per_100=11.0 + i)
        for i in range(6)],
    defects=[Row(defect_code="A", qty=4, roll_no="R-001"), Row(defect_code="I", qty=0, roll_no="R-005")],
    shrinkage=[Row(roll_no="R-001", shrink_warp_pct=-2.1, shrink_weft_pct=-1.4),
               Row(roll_no="R-002", shrink_warp_pct=-1.8, shrink_weft_pct=-1.1)],
)


SAMPLE_FINAL = Doc(
    name="MAT-QA-2026-00012",
    item_code="C9043-U70-629",
    item_name="C9043-U70-629",
    description="Ladies woven blouse, 100% cotton poplin",
    report_date=datetime.date(2026, 11, 7),
    sample_size=50,
    inspection_type="Outgoing",
    status="Accepted",
    inspected_by="apparelerp@gmail.com",
    verified_by="QA Manager",
    reference_type="Purchase Receipt",
    reference_name="MAT-PRE-2026-00068",
    custom_customer="HARBOR & LANE APPAREL LLC",
    custom_season="FW27",
    custom_po_no="PO-CTX-88421",
    custom_buyer_code="HL-88231",
    custom_country_of_origin="CHINA",
    custom_supplier_rep="Mr. Ravi",
    custom_po_qty="1,500 pcs",
    custom_offered_qty="1,500 pcs",
    remarks="Minor uncut threads on 2 pcs, corrected on the spot.",
)

SAMPLE = Doc(
    name="FPC-2026-00001",
    po_no="CTX-FAB-2026-0114",
    po_date=datetime.date(2026, 11, 7),
    revised_on=None,
    revision_reason="",
    pi_no="PI-CTX-4471",
    supplier="SHAOXING LISA TEXTILE CO., LTD",
    supplier_contact="Mr. Chen Wei",
    supplier_company="SHAOXING LISA TEXTILE CO., LTD",
    supplier_address="No. 88 Keqiao Avenue, Keqiao District, Shaoxing, Zhejiang, China",
    supplier_contact_details="+86 575 8412 6688  /  chenwei@lisatextile.cn",
    ship_to="Go Go International, Tirupur unit, India",
    mode_of_shipment="By Sea 海运",
    items=[
        Row(style_name="C9043-U70-629", fabric_description='100% COTTON POPLIN 40X40/133X72 57/58"',
            print_type="Solid 素色", color_name="OPTIC WHITE", upcharge_below_moq="+0.35",
            qty_y=4200, price_rmb=9.8, delivery_date=datetime.date(2026, 12, 20)),
        Row(style_name="C2027-S84-304", fabric_description="COTTON SPANDEX TWILL 32X16+70D/130X56",
            print_type="Y/D 色织", color_name="INDIGO BLUE", upcharge_below_moq="",
            qty_y=3100, price_rmb=12.4, delivery_date=datetime.date(2026, 12, 28)),
        Row(style_name="C8009-R43-304", fabric_description='LINEN 100% 14X14/54X54 53/54"',
            print_type="Solid 素色", color_name="NATURAL FLAX", upcharge_below_moq="+0.60",
            qty_y=1850, price_rmb=21.5, delivery_date=datetime.date(2027, 1, 12)),
    ],
)


def render(kind="purchase"):
    env = Environment(autoescape=False)
    template, sample, out_name = {
        "purchase": ("print_format.html", SAMPLE, "/tmp/fpc_preview.html"),
        "sales": ("print_format_sales.html", SAMPLE_SALES, "/tmp/sc_preview.html"),
        "pp": ("print_format_pp.html", SAMPLE_PP, "/tmp/pp_preview.html"),
        "pilot": ("print_format_pilot.html", SAMPLE_PILOT, "/tmp/pr_preview.html"),
        "testing": ("print_format_testing.html", SAMPLE_TEST, "/tmp/tr_preview.html"),
        "inspection": ("print_format_inspection.html", SAMPLE_INSP, "/tmp/fi_preview.html"),
        "final": ("print_format_final.html", SAMPLE_FINAL, "/tmp/fr_preview.html"),
    }[kind]
    html = open(os.path.join(HERE, template), encoding="utf-8").read()
    font_path = os.path.join(HERE, "font_css.txt")
    if os.path.exists(font_path):
        html = html.replace("/*__CJK_FONT_CSS__*/", open(font_path, encoding="utf-8").read())
    fi_logo = os.path.join(HERE, "final_inspection_logo.png")
    if os.path.exists(fi_logo):
        html = html.replace("__FI_LOGO__",
                            "data:image/png;base64," + _b64.b64encode(open(fi_logo, "rb").read()).decode())
    ruler = os.path.join(HERE, "fabric_ruler.png")
    if os.path.exists(ruler):
        html = html.replace("__RULER_PNG__",
                            "data:image/png;base64," + _b64.b64encode(open(ruler, "rb").read()).decode())
    logo = os.path.join(HERE, "cortex_logo.png")
    if os.path.exists(logo):
        html = html.replace("__CORTEX_LOGO__",
                            "data:image/png;base64," + _b64.b64encode(open(logo, "rb").read()).decode())
    tpl = env.from_string(html)
    body = tpl.render(doc=sample, frappe=Frappe)
    page = ("<!DOCTYPE html><html><head><meta charset='utf-8'><title>Fabric Purchase Contract</title>"
            "<style>body{margin:0;background:#e9e9e9;padding:16px;}"
            ".fpc{max-width:1100px;margin:0 auto;background:#fff;padding:28px 32px 36px;border:1px solid #bbb;}"
            "@media print{body{background:#fff;padding:0}.fpc{border:0;padding:0;max-width:none}}"
            "</style></head><body>" + body + "</body></html>")
    out = out_name
    open(out, "w", encoding="utf-8").write(page)
    return out


def shot(html, png="/tmp/fpc_preview.png"):
    script = """
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b = p.chromium.launch()
    for name, w in (("pdf", 1400),):
        pg = b.new_page(viewport={"width": w, "height": 1200}, device_scale_factor=2)
        pg.goto("file://%s")
        pg.wait_for_timeout(400)
        pg.screenshot(path="%s", full_page=True)
    b.close()
""" % (html, png)
    subprocess.run([sys.executable, "-c", script], check=True)
    return png


if __name__ == "__main__":
    kind = ("sales" if "--sales" in sys.argv else
            "pp" if "--pp" in sys.argv else
            "pilot" if "--pilot" in sys.argv else
            "testing" if "--testing" in sys.argv else
            "inspection" if "--inspection" in sys.argv else
            "final" if "--final" in sys.argv else "purchase")
    h = render(kind)
    p = shot(h, "/tmp/%s_preview.png" % {"sales": "sc", "pp": "pp", "pilot": "pr", "testing": "tr", "inspection": "fi", "final": "fr"}.get(kind, "fpc"))
    if "--save" in sys.argv:
        import shutil
        shutil.copy(p, os.path.join(HERE, {"sales": "preview_sales.png", "pp": "preview_pp.png", "pilot": "preview_pilot.png",
         "testing": "preview_testing.png", "inspection": "preview_inspection.png",
         "final": "preview_final.png"}.get(kind, "preview.png")))
    print(p, os.path.getsize(p), "bytes")
