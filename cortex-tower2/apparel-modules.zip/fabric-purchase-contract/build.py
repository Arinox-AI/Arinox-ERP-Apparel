#!/usr/bin/env python3
"""Put the Fabric Purchase Contract doctype + its print format into the KOGO ERP.

Idempotent: safe to run again after editing print_format.html. Nothing is deleted,
no business record is created, one doctype pair, one print format, one client script,
one workspace page.

Run:  python3 build.py [--dry-run]
"""
import json
import os
import sys

import requests

HERE = os.path.dirname(os.path.abspath(__file__))
MODULE = "Arinox Apparel"
DOC = "Fabric Purchase Contract"
ITEM = "Fabric Purchase Contract Item"
PF = "Fabric Purchase Contract"
SCRIPT = "Fabric Purchase Contract Totals"
WS = "Fabric Contracts"

READ_ONLY = dict(read=1, report=1, export=1, print=1, email=1, share=1)
FULL = dict(READ_ONLY, write=1, create=1, submit=1, cancel=1, amend=1)


# ---------------------------------------------------------------- credentials
def _gql(q, v):
    api = os.environ.get("API_PATH", "") or ""
    if api and not api.endswith("/gateway"):
        api += "/gateway"
    r = requests.post(api, json={"query": q, "variables": v}, timeout=60,
                      headers={"Authorization": "Bearer " + os.environ.get("USER_JWT_TOKEN", ""),
                               "Content-Type": "application/json"})
    body = r.json()
    if body.get("errors"):
        raise SystemExit("gateway: " + body["errors"][0].get("message", "error"))
    return body["data"]


class Site:
    def __init__(self):
        ws = os.environ.get("SWARM_ID", "") or ""
        if ws == "null":
            ws = ""
        apps = _gql("query($w:ID!){getWorkspaceInstalledApps(workspace_id:$w){app_id name app_type}}",
                    {"w": ws})["getWorkspaceInstalledApps"]
        app = next((a for a in apps if (a.get("app_type") or "").upper() == "KOGO_SAS"), None)
        if not app:
            raise SystemExit("no ERP app in this workspace")
        k = _gql("""query($a:String!,$w:ID!){getKogoSasApiKeys(app_id:$a,workspace_id:$w)
                   {api_base api_key api_secret auth_style token}}""", {"a": app["app_id"], "w": ws})["getKogoSasApiKeys"]
        self.base = (k.get("api_base") or "").rstrip("/")
        self.h = {"Authorization": "token %s:%s" % (k.get("api_key"), k.get("api_secret")),
                  "Content-Type": "application/json", "Accept": "application/json"}

    def get(self, path, **params):
        r = requests.get(self.base + path, headers=self.h, params=params, timeout=120)
        return r.status_code, _j(r)

    def create(self, dt, body):
        r = requests.post(self.base + "/api/resource/" + dt.replace(" ", "%20"),
                          headers=self.h, json=body, timeout=300)
        return r.status_code, _j(r)

    def put(self, dt, name, body):
        r = requests.put(self.base + "/api/resource/%s/%s" % (dt.replace(" ", "%20"), name.replace(" ", "%20")),
                         headers=self.h, json=body, timeout=300)
        return r.status_code, _j(r)

    def exists(self, dt, name):
        st, _ = self.get("/api/resource/%s/%s" % (dt.replace(" ", "%20"), name.replace(" ", "%20")))
        return st == 200


def _j(r):
    try:
        return r.json()
    except Exception:
        return {"raw": r.text[:400]}


def why(resp):
    r = resp or {}
    if r.get("exception"):
        return str(r.get("exception"))[:300]
    if r.get("_server_messages"):
        try:
            return "; ".join(json.loads(m).get("message", "") for m in json.loads(r["_server_messages"]))[:300]
        except Exception:
            return str(r["_server_messages"])[:300]
    return str(r)[:300]


def template_html(with_font=False):
    """print_format.html, optionally with the subset CJK font inlined (--with-font).

    Off by default: the ERP's server side PDF engine ignores web fonts entirely and has
    no CJK font of its own, so inlining only makes the print format 130 KB heavier.
    Browsers already have a Chinese font, and the print view prints from the browser.
    """
    html = open(os.path.join(HERE, "print_format.html"), encoding="utf-8").read()
    font = ""
    if with_font:
        font_path = os.path.join(HERE, "font_css.txt")
        font = open(font_path, encoding="utf-8").read() if os.path.exists(font_path) else ""
        if not font:
            print("WARNING: font_css.txt missing, run make_font_subset.py first.")
    return html.replace("/*__CJK_FONT_CSS__*/", font)


# ---------------------------------------------------------------- definitions
def item_fields():
    return [
        {"fieldname": "style_name", "fieldtype": "Data", "label": "Style Name 款号", "in_list_view": 1, "columns": 2},
        {"fieldname": "fabric_description", "fieldtype": "Data", "label": "Fabric Description 面料描述", "in_list_view": 1, "columns": 3},
        {"fieldname": "print_type", "fieldtype": "Data", "label": "Print / Solid / Y/D 印花/素色/色织", "in_list_view": 1, "columns": 2},
        {"fieldname": "color_name", "fieldtype": "Data", "label": "Color Name 颜色名", "in_list_view": 1, "columns": 2},
        {"fieldname": "upcharge_below_moq", "fieldtype": "Data", "label": "Upcharge below MOQ 低于起订量加价", "columns": 2},
        {"fieldname": "qty_y", "fieldtype": "Float", "label": "Qty Y 数量", "in_list_view": 1, "columns": 2},
        {"fieldname": "price_rmb", "fieldtype": "Currency", "label": "Price RMB ¥ per Y 单价", "in_list_view": 1, "columns": 2},
        {"fieldname": "amount", "fieldtype": "Currency", "label": "Total Amount RMB ¥ 总额", "read_only": 1, "in_list_view": 1, "columns": 2},
        {"fieldname": "delivery_date", "fieldtype": "Date", "label": "Delivery Date 交期", "columns": 2},
    ]


def parent_fields():
    return [
        {"fieldname": "naming_series", "fieldtype": "Select", "label": "Series", "reqd": 1,
         "options": "FPC-.YYYY.-.#####", "default": "FPC-.YYYY.-.#####", "hidden": 1},
        {"fieldname": "po_no", "fieldtype": "Data", "label": "P.O. No. 合同号", "reqd": 1,
         "in_list_view": 1, "unique": 1, "columns": 3},
        {"fieldname": "po_date", "fieldtype": "Date", "label": "Date 日期", "reqd": 1,
         "default": "Today", "in_list_view": 1, "columns": 2},
        {"fieldname": "revised_on", "fieldtype": "Date", "label": "Revised on 修改日期"},
        {"fieldname": "revision_reason", "fieldtype": "Data", "label": "Reason for revision 修改原因"},
        {"fieldname": "pi_no", "fieldtype": "Data", "label": "P.I (internal) 内部的PI号"},
        {"fieldname": "supplier", "fieldtype": "Link", "label": "Supplier (link, optional)", "options": "Supplier"},
        {"fieldname": "supplier_contact", "fieldtype": "Data", "label": "TO 供应商联系人"},
        {"fieldname": "supplier_company", "fieldtype": "Data", "label": "Company Name 公司名称",
         "in_list_view": 1, "columns": 3},
        {"fieldname": "supplier_address", "fieldtype": "Small Text", "label": "Address 地址"},
        {"fieldname": "supplier_contact_details", "fieldtype": "Small Text", "label": "Contact details 联系方式"},
        {"fieldname": "sb_ship", "fieldtype": "Section Break", "label": "Goods and shipment"},
        {"fieldname": "ship_to", "fieldtype": "Data", "label": "Shipped to 待运至"},
        {"fieldname": "mode_of_shipment", "fieldtype": "Select", "label": "Mode of Shipment 装运方式",
         "options": "By Road 陆运\nBy Sea 海运\nBy Air 空运", "default": "By Road 陆运"},
        {"fieldname": "items", "fieldtype": "Table", "label": "Items 货物明细",
         "options": ITEM, "reqd": 1},
        {"fieldname": "sb_tot", "fieldtype": "Section Break", "label": "Totals"},
        {"fieldname": "total_qty", "fieldtype": "Float", "label": "Total Qty (Y) 总数量", "read_only": 1},
        {"fieldname": "total_amount", "fieldtype": "Currency", "label": "Total Amount (RMB ¥) 总金额",
         "read_only": 1, "in_list_view": 1, "columns": 2},
    ]


def permissions():
    rows = [("System Manager", FULL), ("Purchase Manager", FULL), ("Purchase Master Manager", FULL),
            ("Purchase User", dict(READ_ONLY, write=1, create=1)),
            ("Accounts Manager", READ_ONLY), ("Accounts User", READ_ONLY),
            ("Stock Manager", READ_ONLY), ("Apparel Merchandising Manager", READ_ONLY),
            ("Apparel Merchandiser", READ_ONLY)]
    return [dict(role=r, **p) for r, p in rows]


CLIENT_SCRIPT = """
frappe.ui.form.on("%(item)s", {
    qty_y: function (frm, cdt, cdn) { cx_row(frm, cdt, cdn); },
    price_rmb: function (frm, cdt, cdn) { cx_row(frm, cdt, cdn); }
});

frappe.ui.form.on("%(doc)s", {
    refresh: function (frm) { cx_totals(frm); },
    validate: function (frm) { cx_totals(frm); }
});

function cx_row(frm, cdt, cdn) {
    var r = locals[cdt][cdn];
    frappe.model.set_value(cdt, cdn, "amount", (r.qty_y || 0) * (r.price_rmb || 0));
    cx_totals(frm);
}

function cx_totals(frm) {
    var q = 0, a = 0;
    (frm.doc.items || []).forEach(function (r) {
        q += r.qty_y || 0;
        a += r.amount || ((r.qty_y || 0) * (r.price_rmb || 0));
    });
    frm.set_value("total_qty", q);
    frm.set_value("total_amount", a);
}
""" % {"doc": DOC, "item": ITEM}


def workspace():
    content = [
        {"id": "fabric01", "type": "header", "data": {
            "text": '<span class="h4"><b>Fabric Purchase Contracts</b></span>', "col": 12}},
        {"id": "fabric02", "type": "shortcut", "data": {"shortcut_name": DOC, "col": 4}},
        {"id": "fabric03", "type": "spacer", "data": {"col": 12}},
        {"id": "fabric04", "type": "header", "data": {
            "text": '<span class="h4"><b>Related</b></span>', "col": 12}},
        {"id": "fabric05", "type": "shortcut", "data": {"shortcut_name": "Supplier", "col": 4}},
        {"id": "fabric06", "type": "shortcut", "data": {"shortcut_name": "Purchase Order", "col": 4}},
        {"id": "fabric07", "type": "shortcut", "data": {"shortcut_name": "Fabric Inspection", "col": 4}},
    ]
    shortcuts = [
        {"type": "DocType", "label": DOC, "link_to": DOC, "color": "Blue"},
        {"type": "DocType", "label": "Supplier", "link_to": "Supplier", "color": "Grey"},
        {"type": "DocType", "label": "Purchase Order", "link_to": "Purchase Order", "color": "Orange"},
        {"type": "DocType", "label": "Fabric Inspection", "link_to": "Fabric Inspection", "color": "Green"},
    ]
    links = [
        {"type": "Card Break", "label": "Fabric Contracts", "link_count": 2, "hidden": 0, "onboard": 0},
        {"type": "Link", "label": DOC, "link_to": DOC, "link_type": "DocType", "hidden": 0,
         "dependencies": "", "onboard": 0, "is_query_report": 0},
        {"type": "Link", "label": "Purchase Order", "link_to": "Purchase Order", "link_type": "DocType",
         "hidden": 0, "dependencies": "", "onboard": 0, "is_query_report": 0},
        {"type": "Card Break", "label": "Fabric", "link_count": 2, "hidden": 0, "onboard": 0},
        {"type": "Link", "label": "Fabric Inspection", "link_to": "Fabric Inspection", "link_type": "DocType",
         "hidden": 0, "dependencies": "", "onboard": 0, "is_query_report": 0},
        {"type": "Link", "label": "Fabric Requisition", "link_to": "Fabric Requisition", "link_type": "DocType",
         "hidden": 0, "dependencies": "", "onboard": 0, "is_query_report": 0},
    ]
    return {
        "doctype": "Workspace", "name": WS, "label": WS, "title": WS, "type": "Workspace",
        "app": "erpnext", "module": MODULE, "icon": "shopping-cart", "public": 1, "is_hidden": 0,
        "sequence_id": 22, "content": json.dumps(content), "custom_blocks": [], "quick_lists": [],
        "shortcuts": shortcuts, "links": links, "charts": [], "number_cards": [], "roles": [],
    }


# ---------------------------------------------------------------- steps
def main(argv):
    dry = "--dry-run" in argv
    site = Site()
    st, _ = site.get("/api/method/frappe.auth.get_logged_user")
    if st != 200:
        raise SystemExit("cannot reach the ERP (%s)" % st)

    html = template_html(with_font="--with-font" in argv)
    print("print format html: %d bytes" % len(html))

    # 1. child table
    if site.exists("DocType", ITEM):
        print("child doctype exists")
    else:
        body = {"doctype": "DocType", "name": ITEM, "module": MODULE, "custom": 1, "istable": 1,
                "editable_grid": 1, "engine": "InnoDB", "fields": item_fields(),
                "permissions": [{"role": "System Manager", "read": 1, "write": 1, "create": 1}]}
        if dry:
            print("[dry] create %s" % ITEM)
        else:
            st, r = site.create("DocType", body)
            print("create %s -> %s %s" % (ITEM, st, "" if st == 200 else why(r)))
            if st != 200:
                return 1

    # 2. parent doctype
    body = {"doctype": "DocType", "module": MODULE, "custom": 1, "engine": "InnoDB",
            "autoname": "naming_series:", "naming_rule": 'By "Naming Series" field',
            "is_submittable": 1, "track_changes": 1, "allow_rename": 0, "allow_copy": 1,
            "title_field": "po_no", "search_fields": "po_no,supplier_company"}
    if site.exists("DocType", DOC):
        st, r = site.put("DocType", DOC, {"fields": parent_fields(), "permissions": permissions()})
        print("update %s fields/permissions -> %s %s" % (DOC, st, "" if st == 200 else why(r)))
    else:
        body.update({"name": DOC, "fields": parent_fields(), "permissions": permissions()})
        if dry:
            print("[dry] create %s" % DOC)
        else:
            st, r = site.create("DocType", body)
            print("create %s -> %s %s" % (DOC, st, "" if st == 200 else why(r)))
            if st != 200:
                return 1

    # 3. print format
    pf = {"doctype": "Print Format", "doc_type": DOC, "module": MODULE, "custom_format": 1,
          "print_format_type": "Jinja", "standard": "No", "disabled": 0, "html": html,
          "margin_top": 8, "margin_bottom": 8, "margin_left": 8, "margin_right": 8,
          "font_size": 11, "page_number": "Hide", "print_format_builder": 0,
          "print_format_builder_beta": 0, "raw_printing": 0, "align_labels_right": 0,
          "absolute_value": 0, "show_section_headings": 0, "line_breaks": 0}
    if site.exists("Print Format", PF):
        if dry:
            print("[dry] update print format")
        else:
            st, r = site.put("Print Format", PF, {"html": html, "custom_format": 1,
                                                  "print_format_type": "Jinja", "module": MODULE,
                                                  "doc_type": DOC})
            print("update print format -> %s %s" % (st, "" if st == 200 else why(r)))
    else:
        pf["name"] = PF
        if dry:
            print("[dry] create print format")
        else:
            st, r = site.create("Print Format", pf)
            print("create print format -> %s %s" % (st, "" if st == 200 else why(r)))
            if st != 200:
                return 1

    # 4. make it the default print for the doctype
    if not dry:
        st, r = site.put("DocType", DOC, {"default_print_format": PF})
        print("set default print format -> %s %s" % (st, "" if st == 200 else why(r)))

    # 5. totals client script
    if site.exists("Client Script", SCRIPT):
        if not dry:
            st, r = site.put("Client Script", SCRIPT, {"script": CLIENT_SCRIPT, "enabled": 1})
            print("update client script -> %s %s" % (st, "" if st == 200 else why(r)))
    elif not dry:
        st, r = site.create("Client Script", {"doctype": "Client Script", "name": SCRIPT, "dt": DOC,
                                             "view": "Form", "enabled": 1, "script": CLIENT_SCRIPT})
        print("create client script -> %s %s" % (st, "" if st == 200 else why(r)))

    # 6. workspace page
    if site.exists("Workspace", WS):
        if not dry:
            w = workspace()
            st, r = site.put("Workspace", WS, {k: v for k, v in w.items()
                                                if k not in ("doctype", "name")})
            print("update workspace -> %s %s" % (st, "" if st == 200 else why(r)))
    elif not dry:
        st, r = site.create("Workspace", workspace())
        print("create workspace -> %s %s" % (st, "" if st == 200 else why(r)))

    print("\ndone.")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
