#!/usr/bin/env python3
"""Put the Cortex PILOT RUN COMMENTS format into the KOGO ERP.

Target is the existing `Pilot Run` doctype (Arinox Apparel): it already has participants,
checks (check / result / action / who / where), colours, operations, defects and the two
pattern-and-cutting comments this form is built around. No new doctype, no custom fields.

Run:  python3 build_pilot.py [--dry-run] [--with-font]
"""
import base64
import os
import sys

from build import Site, why

HERE = os.path.dirname(os.path.abspath(__file__))
DOC = "Pilot Run"
PF = "Pilot Run Format"


def template_html(with_font=False):
    html = open(os.path.join(HERE, "print_format_pilot.html"), encoding="utf-8").read()
    png = open(os.path.join(HERE, "cortex_logo.png"), "rb").read()
    html = html.replace("__CORTEX_LOGO__", "data:image/png;base64," + base64.b64encode(png).decode())
    font = ""
    if with_font:
        path = os.path.join(HERE, "font_css.txt")
        font = open(path, encoding="utf-8").read() if os.path.exists(path) else ""
    return html.replace("/*__CJK_FONT_CSS__*/", font)


def main(argv):
    dry = "--dry-run" in argv
    site = Site()
    if site.get("/api/method/frappe.auth.get_logged_user")[0] != 200:
        raise SystemExit("cannot reach the ERP")
    if not site.exists("DocType", DOC):
        raise SystemExit("doctype %s is missing on this site" % DOC)

    html = template_html(with_font="--with-font" in argv)
    print("print format html: %d bytes (logo inlined)" % len(html))

    if site.exists("Print Format", PF):
        if dry:
            print("[dry] update print format", PF)
        else:
            st, r = site.put("Print Format", PF, {"html": html, "custom_format": 1,
                                                 "print_format_type": "Jinja", "doc_type": DOC})
            print("update print format %-18s -> %s %s" % (PF, st, "" if st == 200 else why(r)))
    else:
        body = {"doctype": "Print Format", "name": PF, "doc_type": DOC, "module": "Arinox Apparel",
                "custom_format": 1, "print_format_type": "Jinja", "standard": "No", "disabled": 0,
                "html": html, "margin_top": 8, "margin_bottom": 8, "margin_left": 8, "margin_right": 8,
                "font_size": 9, "page_number": "Hide", "print_format_builder": 0,
                "print_format_builder_beta": 0, "raw_printing": 0, "align_labels_right": 0,
                "absolute_value": 0, "show_section_headings": 0, "line_breaks": 0}
        if dry:
            print("[dry] create print format", PF)
        else:
            st, r = site.create("Print Format", body)
            print("create print format %-18s -> %s %s" % (PF, st, "" if st == 200 else why(r)))
            if st != 200:
                return 1

    if not dry:
        st, r = site.put("DocType", DOC, {"default_print_format": PF})
        print("set %s default print format -> %s %s" % (DOC, st, "" if st == 200 else why(r)))

    print("\ndone.")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
