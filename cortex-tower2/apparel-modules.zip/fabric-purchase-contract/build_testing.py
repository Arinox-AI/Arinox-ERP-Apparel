#!/usr/bin/env python3
"""Put the Cortex FABRIC INHOUSE TEST CERTIFICATE into the KOGO ERP.

Home is the stock **Quality Inspection** doctype, which is what the apparel module already
links to for fabric lab tests (`Fabric Inspection.quality_inspection`). Nothing new is invented.

What it does, idempotently:
  1. 5 custom fields on Quality Inspection (customer, contract no, finish applied,
     construction, colour) - the header block of the certificate
  2. the 32 test parameters of the form as Quality Inspection Parameter records
  3. a Quality Inspection Template `Fabric Inhouse Test Report` with those 32 rows and the
     customer requirement text, so a new certificate pre-fills the whole sheet
  4. Print Format `Fabric Testing Report`, set as the Quality Inspection default

Run:  python3 build_testing.py [--dry-run] [--with-font]
"""
import os
import sys

from build import Site, why

HERE = os.path.dirname(os.path.abspath(__file__))
DOC = "Quality Inspection"
CLIENT_SCRIPT = "Fabric Testing Report - manual readings"
PF = "Fabric Testing Report"
TEMPLATE = "Fabric Inhouse Test Report"

# (parameter name used by the parameter master AND matched by the print format,
#  test method, customer requirement)
PARAMS = [
    ("Width (Finished) 成品幅宽", "", "AS CONTRACT"),
    ("Weight 重量", "ASTMD3776", "+/- 3%"),
    ("Finished Density Warp 成品密度 经向", "ASTMD3775", "+/- 3%"),
    ("Finished Density Weft 成品密度 纬向", "ASTMD3775", "+/- 3%"),
    ("Tensile Strength Warp 拉伸强力 经向", "ASTMD5034", "> 40 LBS"),
    ("Tensile Strength Weft 拉伸强力 纬向", "ASTMD5034", "> 35 LBS"),
    ("Tearing Strength Warp 撕破强力 经向", "ASTMD1424", "> 2 LBS"),
    ("Tearing Strength Weft 撕破强力 纬向", "ASTMD1424", "> 2 LBS"),
    ("Seam Strength Warp 缝线滑移 经向", "ASTMD1683", "> 20 LBS"),
    ("Seam Strength Weft 缝线滑移 纬向", "ASTMD1683", "> 20 LBS"),
    ("Shrinkage Warp 缩水率 经向", "AATCC135", "+/- 3%"),
    ("Shrinkage Weft 缩水率 纬向", "AATCC135", "+/- 3%"),
    ("Skewness Warp 纬斜 经向", "", "> 2%"),
    ("Skewness Weft 纬斜 纬向", "", "> 2%"),
    ("Washing Colour Change 水洗变色", "AATCC61(2A)", "4"),
    ("Washing Staining Acetate 水洗沾色 醋酸", "AATCC61(2A)", "3-4"),
    ("Washing Staining Cotton 水洗沾色 棉", "AATCC61(2A)", "3-4"),
    ("Washing Staining Nylon 水洗沾色 尼龙", "AATCC61(2A)", "3-4"),
    ("Washing Staining Polyester 水洗沾色 涤", "AATCC61(2A)", "3-4"),
    ("Washing Staining Acrylic 水洗沾色 晴纶", "AATCC61(2A)", "3-4"),
    ("Washing Staining Wool 水洗沾色 毛", "AATCC61(2A)", "3-4"),
    ("Water Colour Change 耐水变色", "", "4"),
    ("Water Staining Acetate 耐水沾色 醋酸", "", "3-4"),
    ("Water Staining Cotton 耐水沾色 棉", "", "3-4"),
    ("Water Staining Nylon 耐水沾色 尼龙", "", "3-4"),
    ("Water Staining Polyester 耐水沾色 涤", "", "3-4"),
    ("Water Staining Acrylic 耐水沾色 晴纶", "", "3-4"),
    ("Water Staining Wool 耐水沾色 毛", "", "3-4"),
    ("Rubbing Dry 干磨", "AATCC 8", "4"),
    ("Rubbing Wet 湿磨", "AATCC 8", "3"),
    ("pH Value 布身pH值", "AATCC 81", "5 - 7.5"),
    ("Pilling 起毛起球", "ASTMD3512", "3-4"),
]

CUSTOM_FIELDS = [
    ("custom_customer", "Customer 客户", "Data", "item_name"),
    ("custom_contract_no", "Contract No. 合同号", "Data", "custom_customer"),
    ("custom_finish_applied", "Finish Applied 后整理", "Data", "custom_contract_no"),
    ("custom_construction", "Construction 组织规格", "Data", "custom_finish_applied"),
    ("custom_colour", "Color 颜色", "Data", "custom_construction"),
]


def template_html(with_font=False):
    html = open(os.path.join(HERE, "print_format_testing.html"), encoding="utf-8").read()
    font = ""
    if with_font:
        path = os.path.join(HERE, "font_css.txt")
        font = open(path, encoding="utf-8").read() if os.path.exists(path) else ""
    return html.replace("/*__CJK_FONT_CSS__*/", font)


def main(argv):
    dry = "--dry-run" in argv
    site = Site()
    if site.get("/api/method/frappe.auth.get_logged_user")[0] != 200:
        raise SystemExit("cannot reach the ERP")
    if not site.exists("DocType", DOC):
        raise SystemExit("doctype %s is missing on this site" % DOC)

    # 1. header custom fields
    for fieldname, label, ftype, after in CUSTOM_FIELDS:
        name = "%s-%s" % (DOC, fieldname)
        if site.exists("Custom Field", name):
            continue
        if dry:
            print("[dry] custom field", name)
            continue
        st, r = site.create("Custom Field", {
            "doctype": "Custom Field", "name": name, "dt": DOC, "fieldname": fieldname,
            "label": label, "fieldtype": ftype, "insert_after": after})
        print("custom field %-34s -> %s %s" % (fieldname, st, "" if st == 200 else why(r)))

    # 2. test parameters
    made = 0
    for pname, method, req in PARAMS:
        if site.exists("Quality Inspection Parameter", pname):
            continue
        if dry:
            made += 1
            continue
        st, r = site.create("Quality Inspection Parameter", {
            "doctype": "Quality Inspection Parameter", "parameter": pname,
            "description": ("Test method: %s. Requirement: %s" % (method, req)) if method
                           else ("Requirement: %s" % req)})
        if st != 200:
            print("PARAM FAILED %-40s %s" % (pname, why(r)))
        else:
            made += 1
    print("test parameters: %d created of %d%s" % (made, len(PARAMS), " (dry run)" if dry else ""))

    # 3. template carrying the whole sheet
    if site.exists("Quality Inspection Template", TEMPLATE):
        if not dry:
            rows = [{"doctype": "Item Quality Inspection Parameter", "specification": p, "value": req,
                     "manual_inspection": 1} for p, _m, req in PARAMS]
            st, r = site.put("Quality Inspection Template", TEMPLATE,
                             {"item_quality_inspection_parameter": rows})
            print("template rows refreshed %-20s -> %s %s" % (TEMPLATE, st, "" if st == 200 else why(r)))
    elif dry:
        print("[dry] create template", TEMPLATE)
    else:
        # manual_inspection=1 on every row on purpose: without it the stock logic re-decides each
        # reading from numeric criteria and stamps them Rejected, so a fresh certificate would print
        # FAIL everywhere. Manual rows keep the lab's own Accepted/Rejected (blank until decided).
        rows = [{"doctype": "Item Quality Inspection Parameter", "specification": p, "value": req,
                 "manual_inspection": 1} for p, _m, req in PARAMS]
        st, r = site.create("Quality Inspection Template", {
            "doctype": "Quality Inspection Template", "quality_inspection_template_name": TEMPLATE,
            "item_quality_inspection_parameter": rows})
        print("template %-26s -> %s %s" % (TEMPLATE, st, "" if st == 200 else why(r)))

    # 4. print format
    html = template_html(with_font="--with-font" in argv)
    print("print format html: %d bytes" % len(html))
    if site.exists("Print Format", PF):
        if dry:
            print("[dry] update print format", PF)
        else:
            st, r = site.put("Print Format", PF, {"html": html, "custom_format": 1,
                                                 "print_format_type": "Jinja", "doc_type": DOC})
            print("update print format %-22s -> %s %s" % (PF, st, "" if st == 200 else why(r)))
    else:
        body = {"doctype": "Print Format", "name": PF, "doc_type": DOC, "module": "Stock",
                "custom_format": 1, "print_format_type": "Jinja", "standard": "No", "disabled": 0,
                "html": html, "margin_top": 8, "margin_bottom": 8, "margin_left": 8, "margin_right": 8,
                "font_size": 7, "page_number": "Hide", "print_format_builder": 0,
                "print_format_builder_beta": 0, "raw_printing": 0, "align_labels_right": 0,
                "absolute_value": 0, "show_section_headings": 0, "line_breaks": 0}
        if dry:
            print("[dry] create print format", PF)
        else:
            st, r = site.create("Print Format", body)
            print("create print format %-22s -> %s %s" % (PF, st, "" if st == 200 else why(r)))
            if st != 200:
                return 1

    # the stock doctype re-decides a reading from numeric criteria and stamps "Rejected" when there
    # are none, so a lab decision typed by hand would not stick. Tick manual inspection on every row
    # of THIS certificate only, so Accept/Reject is kept as entered.
    script = """
frappe.ui.form.on("Quality Inspection", {
    quality_inspection_template: function (frm) {
        if (frm.doc.quality_inspection_template === "Fabric Inhouse Test Report") {
            (frm.doc.readings || []).forEach(function (r) { r.manual_inspection = 1; });
            frm.refresh_field("readings");
        }
    }
});
"""
    if site.exists("Client Script", CLIENT_SCRIPT):
        print("client script exists:", CLIENT_SCRIPT)
    elif dry:
        print("[dry] client script", CLIENT_SCRIPT)
    else:
        st, r = site.create("Client Script", {"doctype": "Client Script", "name": CLIENT_SCRIPT,
                                             "dt": DOC, "view": "Form", "enabled": 1, "script": script})
        print("client script %-38s -> %s %s" % (CLIENT_SCRIPT, st, "" if st == 200 else why(r)))

    # Quality Inspection is a STANDARD doctype, so its own record cannot be written over REST
    # ("Not in Developer Mode"). A Property Setter is the supported way to make our format the
    # default; without it the user simply picks "Fabric Testing Report" in the Print menu.
    ps_name = "%s-main-default_print_format" % DOC
    if site.exists("Property Setter", ps_name):
        print("default print format already set by property setter")
    elif dry:
        print("[dry] property setter ->", ps_name)
    else:
        st, r = site.create("Property Setter", {
            "doctype": "Property Setter", "doctype_or_field": "DocType", "doc_type": DOC,
            "property": "default_print_format", "property_type": "Data", "value": PF})
        print("property setter %-42s -> %s %s" % (ps_name, st, "" if st == 200 else why(r)))

    print("\ndone.")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
