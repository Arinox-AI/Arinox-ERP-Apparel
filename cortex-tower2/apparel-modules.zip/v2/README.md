# Arinox Apparel -> KOGO ERP

The app's own hosted bundle, loaded into this workspace's ERP over REST. No bench, no app install.

Source: `github.com/Arinox-AI/Arinox-ERP-Apparel`, branch `apparel-app`, head `75ef036`
(6 Nov 2026). Current state of the site: **887 bundle records live, 34 verification checks passed,
0 failed**.

* **[INTEGRATION.md](INTEGRATION.md)** - what was loaded, how it was verified, the one limit
  (`server_script_enabled` is off on this site, so server scripts cannot execute), and what to do
  the day it is turned on.
* **[INVENTORY.md](INVENTORY.md)** - every record on the site, generated from the bundle: 131
  doctypes, 189 custom fields, 195 seeds, 20 reports, 29 cards, 4 workspaces, 30 client scripts,
  251 server scripts.

## Run it

```bash
./integrate.sh            # reachability -> load all groups -> desk fix -> script state -> verify -> inventory
./integrate.sh --demo     # the same, plus the 30-document demo order
```

or step by step:

```bash
python3 loader/validate_bundle.py      # offline pre-flight, no site needed
python3 loader/kogo_load.py            # all 17 groups, idempotent, ~90 s
python3 loader/post_fix.py             # workspace app/module, icon cache, desk page proof
python3 loader/script_switch.py        # show the script state (per type, enabled/disabled)
python3 loader/verify_after_load.py    # group-by-group proof, runs every report
python3 loader/make_inventory_md.py    # refresh INVENTORY.md
```

Everything is an upsert keyed on the record's own name, so a re-run updates and never duplicates.
Per-record results land in `loader/state/load_log.json`; each run also keeps its own log.

## The one thing this site will not do

`POST /api/method/arinox_engine` returns
`403 frappe.utils.safe_exec.ServerScriptNotEnabled`. The site's bench config needs
`server_script_enabled = 1`, and there is no REST route to it. Until somebody with bench access sets
it:

* the 166 DocType Event scripts are parked (`disabled = 1`) - otherwise the global guard rejects every
  save on the 47 doctypes that carry one, Sales Order and Purchase Order included;
* the 17 script reports and the 83 desk API endpoints stay inert.

When the flag is on:

```bash
python3 loader/script_switch.py --probe   # expect ENABLED
python3 loader/script_switch.py --on      # re-arms all 251
```

## Layout

```
hosted_bundle/    the app's export, 17 groups + index.json (source of truth for every load)
loader/           validate, load, post-fix, script switch, verify, inventory
demo/             make_demo_book.py - 30 documents, --dry-run / --clean (not run here)
docs/             the authors' own guides: HOSTED_BUILD_GUIDE, HANDOFF, DEPLOY, BUILD_PLAN, ...
```

`docs/HOSTED_BUILD_GUIDE.md` is the 75 KB answer to "what does a site without a bench support"; it is
where the server-script limit and the sandbox rules are documented.
