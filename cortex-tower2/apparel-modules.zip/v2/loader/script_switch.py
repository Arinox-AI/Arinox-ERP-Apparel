#!/usr/bin/env python3
"""Turn the Arinox Server Scripts on or off per script type, over REST only.

Why this exists
---------------
Frappe refuses to EXECUTE any Server Script unless the site config carries
`server_script_enabled = 1`, and that flag can only be set with
`bench --site <site> set-config server_script_enabled 1`. The KOGO ERP is a hosted
site with no bench, so the flag is off and cannot be flipped from here (proved
6 Nov 2026 with loader/probe_server_scripts.py: HTTP 403 ServerScriptNotEnabled).

The guard is global and fires BEFORE the script body, from the doc_event hook. So
while the scripts are enabled in the records, every save / submit / cancel on the
47 doctypes that carry a DocType Event script is rejected with HTTP 403 - that
includes Sales Order, Purchase Order, Quotation, Sales Invoice, Purchase Receipt,
Work Order, Supplier Quotation, Opportunity, Cost Head, TNA Template, plus the
whole apparel document set.

Therefore:
  * `--off --type="DocType Event"`  keeps the records but makes the desk usable
    (documents save, no automation). This is the safe state while the flag is off.
  * `--on`                            re-arms everything the moment the flag is on.

Usage
-----
    python3 script_switch.py                          # report the current state
    python3 script_switch.py --off --type="DocType Event"
    python3 script_switch.py --on
    python3 script_switch.py --off --only-department  # (none) kept for symmetry
    python3 script_switch.py --on --type=API --dry-run
"""
import json
import os
import sys
import urllib.parse

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "..", "skill", "scripts"))

FIELDS = ["name", "script_type", "reference_doctype", "doctype_event", "api_method", "disabled"]


def load(site):
    st, r = site.call("GET", "/api/resource/%s?limit_page_length=0&fields=%s"
                      % (urllib.parse.quote("Server Script"), urllib.parse.quote(json.dumps(FIELDS))))
    return (r.get("data") or []) if st == 200 else []


def main(argv):
    flags = {}
    for a in argv:
        k, _, v = a.partition("=")
        if k.startswith("--"):
            flags[k] = v or True

    from kogo_load import Site, session
    site = Site(session())
    if flags.get("--probe"):
        # prove whether the site will execute scripts at all, without writing anything
        st, r = site.call("POST", "/api/method/arinox_engine", {})
        print("script execution:", "ENABLED" if st != 403 else "DISABLED (bench flag off)", "HTTP", st)
        return 0

    rows = load(site)
    want = flags.get("--on") and 0 or (flags.get("--off") and 1 or None)
    types = flags.get("--type")
    types = set(types.split(",")) if types and types is not True else None
    dry = bool(flags.get("--dry-run"))

    by_type = {}
    for s in rows:
        by_type.setdefault(s["script_type"], []).append(s)
    print("server scripts: %d" % len(rows))
    for t, rs in sorted(by_type.items()):
        print("  %-16s %3d  enabled %3d / disabled %3d" % (
            t, len(rs), sum(1 for x in rs if not x["disabled"]), sum(1 for x in rs if x["disabled"])))
    if want is None:
        print("\nnothing to do - pass --on or --off")
        return 0

    todo = [s for s in rows if (types is None or s["script_type"] in types)
            and bool(s["disabled"]) != bool(want)]
    print("\n%s disabled=%d on %d record(s) of %s%s" % (
        "would set" if dry else "setting", want, len(todo),
        ",".join(sorted(types)) if types else "all types", " (dry run)" if dry else ""))
    changed = failed = 0
    for i, s in enumerate(todo, 1):
        if dry:
            continue
        st, r = site.call("PUT", "/api/resource/%s/%s" % (urllib.parse.quote("Server Script"),
                                                          urllib.parse.quote(s["name"])),
                          {"disabled": want})
        if st == 200:
            changed += 1
        else:
            failed += 1
            print("   FAILED %-46s %s" % (s["name"], str(r)[:160]))
        if i % 25 == 0:
            print("   ... %d/%d" % (i, len(todo)))
    if not dry:
        print("\nchanged %d, failed %d" % (changed, failed))
        rows = load(site)
        for t in sorted(by_type):
            rs = [x for x in rows if x["script_type"] == t]
            print("  %-16s enabled %3d / disabled %3d" % (
                t, sum(1 for x in rs if not x["disabled"]), sum(1 for x in rs if x["disabled"])))
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
