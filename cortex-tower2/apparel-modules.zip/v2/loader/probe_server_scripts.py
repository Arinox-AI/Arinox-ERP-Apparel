#!/usr/bin/env python3
"""Prove whether the ERP actually EXECUTES Server Scripts, without touching the 40 Arinox ones.

Two throw-away probes are created, run, and removed:

  1. API probe      - a new API-type Server Script `zz_probe_api_ping`, called over
                      /api/method/zz_probe_api_ping. If Server Script execution is off,
                      the endpoint is not registered at all and we get 404/417.
  2. Event probe    - a new DocType Event script on `ToDo` (Before Insert) that stamps a
                      marker into the note. ToDo carries no Arinox script, so nothing of
                      the 40 is involved. A ToDo is inserted, read back, deleted.

Nothing else in the site is written. Run:  python3 probe_server_scripts.py [--keep]
"""
import json
import os
import sys
import time
import urllib.parse

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "..", "skill", "scripts"))
import portlib  # noqa: E402

KEEP = "--keep" in sys.argv

API_NAME = "zz_probe_api_ping"
EVT_NAME = "zz_probe_todo_hook"
MARK = "ZZ-HOOK-RAN"
TODO_TEXT = "zz probe todo"


def q(s):
    return urllib.parse.quote(str(s), safe="")


class Api:
    def __init__(self):
        self.s = portlib.session()

    def req(self, method, path, body=None, timeout=180):
        for i in range(3):
            try:
                r = self.s.request(method, self.s.base_url + path, json=body, timeout=timeout)
                if r.status_code in (429, 502, 503, 504):
                    time.sleep(2 + 3 * i)
                    continue
                try:
                    return r.status_code, r.json()
                except Exception:
                    return r.status_code, {"raw": r.text[:400]}
            except Exception as e:
                time.sleep(3 + 3 * i)
                err = {"raw": "%s: %s" % (type(e).__name__, e)}
        return 0, err

    def get(self, dt, name=None, fields=None, filters=None, limit=20):
        if name:
            return self.req("GET", "/api/resource/%s/%s" % (q(dt), q(name)))
        p = ["/api/resource/%s?limit_page_length=%d" % (q(dt), limit)]
        if fields:
            p.append("fields=" + urllib.parse.quote(json.dumps(fields)))
        if filters:
            p.append("filters=" + urllib.parse.quote(json.dumps(filters)))
        return self.req("GET", "&".join(p))

    def create(self, dt, body):
        return self.req("POST", "/api/resource/%s" % q(dt), body)

    def delete(self, dt, name):
        return self.req("DELETE", "/api/resource/%s/%s" % (q(dt), q(name)))

    def method(self, m, body=None):
        st, b = self.req("POST", "/api/method/" + m, body or {})
        return st, b


def drop(api, dt, name):
    st, b = api.delete(dt, name)
    return st in (200, 202, 404)


def main():
    api = Api()
    print("site:", api.s.base_url)

    # 0 ---------------------------------------------------------------- read only
    st, body = api.get("Server Script", fields=["name", "script_type", "disabled"],
                       limit=500)
    existing = [r["name"] for r in (body.get("data") or [])]
    print("existing Server Scripts on site: %d (untouched)" % len(existing))
    st, body = api.get("System Settings", "System Settings")
    print("System Settings read: HTTP", st)

    # 1 ---------------------------------------------------------------- API probe
    print("\n[1] API-type probe")
    for n in (API_NAME, EVT_NAME):
        drop(api, "Server Script", n)
    drop(api, "ToDo", TODO_TEXT)

    api_script = (
        "n = 41\n"
        "frappe.response['probe'] = 'api-ok'\n"
        "frappe.response['sum'] = sum(range(n))\n"
        "frappe.response['user'] = frappe.session.user\n"
    )
    st, b = api.create("Server Script", {
        "doctype": "Server Script",
        "name": API_NAME,
        "script_type": "API",
        "api_method": API_NAME,
        "allow_guest": 0,
        "disabled": 0,
        "script": api_script,
    })
    print("  create via POST body   :", st, str(b)[:200])
    if st >= 400:
        # frappe needs name in the URL for autoname-by-field doctypes sometimes
        st, b = api.req("POST", "/api/resource/Server Script/" + q(API_NAME), {
            "doctype": "Server Script", "name": API_NAME, "script_type": "API",
            "api_method": API_NAME, "allow_guest": 0, "disabled": 0, "script": api_script})
        print("  create via PUT name    :", st, str(b)[:200])

    st, b = api.get("Server Script", API_NAME,
                    fields=["name", "script_type", "api_method", "disabled"])
    print("  stored                 :", st, str(b.get("data"))[:200] if st == 200 else str(b)[:200])

    time.sleep(1)
    st, b = api.method(API_NAME)
    print("  GET/POST /api/method/%s -> HTTP %s" % (API_NAME, st))
    print("  body                   :", json.dumps(b)[:400])
    api_ran = st == 200 and str(b.get("message") or b).find("api-ok") >= 0

    # 2 ---------------------------------------------------------------- event probe
    print("\n[2] DocType Event probe on ToDo (no Arinox script on that doctype)")
    evt = (
        "if doc.get('description'):\n"
        "    doc.description = doc.description + ' " + MARK + "'\n"
        "else:\n"
        "    doc.description = '" + MARK + "'\n"
    )
    st, b = api.create("Server Script", {
        "doctype": "Server Script", "name": EVT_NAME,
        "script_type": "DocType Event", "doctype_event": "Before Insert",
        "reference_doctype": "ToDo", "disabled": 0, "script": evt})
    print("  create event script    :", st, str(b)[:200])

    st, b = api.create("ToDo", {"doctype": "ToDo", "description": TODO_TEXT})
    print("  insert ToDo            :", st, str(b)[:250])
    st2, b2 = api.get("ToDo", TODO_TEXT, fields=["name", "description"])
    desc = ((b2.get("data") or {}).get("description") or "") if st2 == 200 else ""
    print("  read back              :", st2, repr(desc)[:200])
    evt_ran = MARK in desc

    # 3 ---------------------------------------------------------------- cleanup
    if not KEEP:
        print("\n[3] cleanup")
        print("  ToDo deleted           :", drop(api, "ToDo", TODO_TEXT))
        print("  probe api script gone  :", drop(api, "Server Script", API_NAME))
        print("  probe event script gone:", drop(api, "Server Script", EVT_NAME))
    else:
        print("\n[3] keeping probes on site (--keep)")

    # 4 ---------------------------------------------------------------- verdict
    print("\n" + "=" * 62)
    print("Server Script execution enabled :", "YES" if (api_ran or evt_ran) else "NO")
    print("  API script callable           :", "YES" if api_ran else "NO")
    print("  DocType Event script fired    :", "YES" if evt_ran else "NO")
    print("=" * 62)
    return 0 if (api_ran or evt_ran) else 1


if __name__ == "__main__":
    sys.exit(main())
