#!/usr/bin/env python3
"""Write INVENTORY.md - the full, human-readable list of everything the bundle puts on the site.

Reads the local bundle for the authoritative payload and, when the site answers, the live counts
and per-record presence. Safe to run any time:  python3 make_inventory_md.py [--offline]

Output: ../INVENTORY.md
"""
import json
import os
import sys
import time
import urllib.parse

HERE = os.path.dirname(os.path.abspath(__file__))
V2 = os.path.dirname(HERE)
BUNDLE = os.path.join(V2, "hosted_bundle")
OUT = os.path.join(V2, "INVENTORY.md")
sys.path.insert(0, os.path.join(V2, "..", "skill", "scripts"))


def b(name):
    return json.load(open(os.path.join(BUNDLE, name)))


def main(argv):
    offline = "--offline" in argv
    site = None
    if not offline:
        try:
            from kogo_load import Site, session
            site = Site(session())
        except Exception as e:
            print("site unreachable (%s) - writing the bundle side only" % type(e).__name__)

    def live(dt, fields=("name",)):
        if not site:
            return {}
        st, r = site.call("GET", "/api/resource/%s?fields=%s&limit_page_length=0"
                          % (urllib.parse.quote(dt), urllib.parse.quote(json.dumps(list(fields)))))
        return {x["name"]: x for x in ((r.get("data") or []) if st == 200 else [])}

    idx = b("index.json")
    total = sum(e["count"] for e in idx)
    L = []
    A = L.append
    A("# Arinox Apparel: what is on the KOGO ERP")
    A("")
    A("Generated %s UTC by `loader/make_inventory_md.py` from `hosted_bundle/`%s."
      % (time.strftime("%Y-%m-%d %H:%M"), "" if site else " (offline run)"))
    A("")
    A("Source: `github.com/Arinox-AI/Arinox-ERP-Apparel`, branch `apparel-app`, head `75ef036`.")
    A("")
    A("**%d records in %d groups.** Every row below is a record the loader upserts by name, so a"
      " re-run updates instead of duplicating." % (total, len(idx)))
    A("")
    A("| group | file | records | how it loads |")
    A("|---|---|---:|---|")
    mode_note = {
        "create": "upsert by name",
        "doctypes": "two-pass, links closed on the second pass",
        "single": "PUT on the singleton",
    }
    for e in idx:
        A("| %s | `%s` | %d | %s |" % (e["group"], e["file"], e["count"], mode_note.get(e["mode"], e["mode"])))
    A("")

    # ---- doctypes
    dts = b("03_doctypes.json")["records"]
    have = live("DocType", ["name", "issingle", "istable", "is_submittable", "module"])
    A("## DocTypes (%d)" % len(dts))
    A("")
    A("`S` = single (no table), `C` = child table, `sub` = submittable, `✓` = present on the site.")
    A("")
    A("| DocType | module | flags | on site |")
    A("|---|---|---|---:|")
    for rec in dts:
        d = rec["first"]
        flags = []
        if d.get("issingle"):
            flags.append("S")
        if d.get("istable"):
            flags.append("C")
        if d.get("is_submittable"):
            flags.append("sub")
        A("| %s | %s | %s | %s |" % (d["name"], d.get("module", ""), " ".join(flags),
                                     "✓" if d["name"] in have else "—" if site else "?"))
    A("")

    # ---- custom fields
    cfs = b("04_custom_fields.json")["records"]
    per = {}
    for c in cfs:
        per.setdefault(c["dt"], []).append(c)
    A("## Custom fields (%d on %d documents)" % (len(cfs), len(per)))
    A("")
    A("| document | fields | fieldnames |")
    A("|---|---:|---|")
    for dt in sorted(per, key=lambda k: -len(per[k])):
        names = ", ".join("`%s`" % c["fieldname"] for c in per[dt])
        A("| %s | %d | %s |" % (dt, len(per[dt]), names))
    A("")

    # ---- property setters
    pss = b("05_property_setters.json")["records"]
    A("## Property setters (%d)" % len(pss))
    A("")
    A("| doc type | field | property | value |")
    A("|---|---|---|---|")
    for p in pss:
        A("| %s | %s | %s | %s |" % (p.get("doc_type", ""), p.get("field_name", ""),
                                     p.get("property", ""), str(p.get("value"))[:60]))
    A("")

    # ---- seeds
    seeds = b("06_seeds.json")["records"]
    by = {}
    for s in seeds:
        by.setdefault(s["doctype"], []).append(s.get("name") or s.get("template_name") or "?")
    A("## Master data and seeds (%d rows in %d doctypes)" % (len(seeds), len(by)))
    A("")
    A("| doctype | rows | names |")
    A("|---|---:|---|")
    for dt in sorted(by):
        nm = by[dt]
        shown = ", ".join(nm[:14]) + (" …" if len(nm) > 14 else "")
        A("| %s | %d | %s |" % (dt, len(nm), shown))
    A("")

    # ---- settings
    st = b("07_apparel_settings.json")["records"][0]
    A("## Apparel Settings (singleton, %d fields)" % len([k for k in st if k != "doctype"]))
    A("")
    A("Keys the site now carries as defaults:")
    A("")
    A("```")
    A(", ".join(sorted(k for k in st if k != "doctype")))
    A("```")
    A("")

    # ---- print formats
    pfs = b("08_print_formats.json")["records"]
    A("## Print formats (%d)" % len(pfs))
    A("")
    for p in pfs:
        A("- **%s** (%s) %d bytes of HTML" % (p["name"], p.get("doc_type") or p.get("dt") or "",
                                              len(p.get("html") or "")))
    A("")

    # ---- reports
    reps = b("09_reports.json")["records"]
    A("## Reports (%d)" % len(reps))
    A("")
    A("| report | type | ref doctype | runs today |")
    A("|---|---|---|---|")
    run = {}
    if site:
        for r in reps:
            p = ("/api/method/frappe.desk.query_report.run?report_name=%s&ignore_prepared_report=1&filters=%s"
                 % (urllib.parse.quote(r["name"]), urllib.parse.quote("{}")))
            s_, resp = site.call("GET", p)
            if s_ == 200:
                run[r["name"]] = "%d rows" % len((resp.get("message") or {}).get("result") or [])
            else:
                why = json.dumps(resp)[:200]
                run[r["name"]] = ("parked: server scripts off" if "ServerScriptNotEnabled" in why
                                  else "needs a filter" if ("KeyError" in why or "mapping" in why)
                                  else "error")
    for r in reps:
        A("| %s | %s | %s | %s |" % (r["name"], r.get("report_type", ""),
                                     r.get("ref_doctype") or "", run.get(r["name"], "?")))
    A("")

    # ---- UI records
    ncs = b("10_number_cards.json")["records"]
    chs = b("11_dashboard_charts.json")["records"]
    dbs = b("12_dashboards.json")["records"]
    wss = b("13_workspaces.json")["records"]
    sbs = b("14_workspace_sidebars.json")["records"]
    ics = b("15_desktop_icons.json")["records"]
    A("## Desk UI records")
    A("")
    A("| group | count | names |")
    A("|---|---:|---|")
    for label, recs, key in (("number cards", ncs, "label"), ("dashboard charts", chs, "chart_name"),
                             ("dashboards", dbs, "dashboard_name"), ("workspaces", wss, "label"),
                             ("sidebars", sbs, "title"), ("desktop icons", ics, "label")):
        A("| %s | %d | %s |" % (label, len(recs), ", ".join(str(r.get(key) or r.get("name")) for r in recs)))
    A("")

    # ---- client scripts
    css = b("16_client_scripts.json")["records"]
    A("## Client scripts (%d)" % len(css))
    A("")
    A("| script | document |")
    A("|---|---|")
    for c in css:
        A("| %s | %s |" % (c.get("name"), c.get("dt") or c.get("reference_doctype") or ""))
    A("")

    # ---- server scripts
    sss = b("17_server_scripts.json")["records"]
    by_type = {}
    for s in sss:
        by_type.setdefault(s.get("script_type"), []).append(s)
    A("## Server scripts (%d)" % len(sss))
    A("")
    for t in sorted(by_type):
        A("### %s (%d)" % (t, len(by_type[t])))
        A("")
        if t == "API":
            A("| script | api method |")
            A("|---|---|")
            for s in sorted(by_type[t], key=lambda x: x.get("api_method") or ""):
                A("| %s | `%s` |" % (s["name"], s.get("api_method")))
        elif t == "DocType Event":
            A("| document | events | scripts |")
            A("|---|---|---|")
            per = {}
            for s in by_type[t]:
                per.setdefault(s.get("reference_doctype") or "?", []).append(s)
            for dt in sorted(per):
                evs = sorted({x.get("doctype_event") or "" for x in per[dt]})
                A("| %s | %s | %d |" % (dt, ", ".join(evs), len(per[dt])))
        else:
            A("| script | event |")
            A("|---|---|")
            for s in by_type[t]:
                A("| %s | %s |" % (s["name"], s.get("doctype_event") or ""))
        A("")

    open(OUT, "w").write("\n".join(L) + "\n")
    print("wrote %s (%d lines)" % (OUT, len(L)))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
