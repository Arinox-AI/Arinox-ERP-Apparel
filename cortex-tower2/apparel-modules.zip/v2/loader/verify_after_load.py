#!/usr/bin/env python3
"""Prove the port after the load, group by group, against the live site.

    python3 verify_after_load.py            # everything
    python3 verify_after_load.py --quick    # counts only, no report runs

Checks:
  * every one of the 131 doctypes exists and answers a list query
  * the 188 custom fields are on the documents they belong to
  * the 194 seeds, the settings, 10 print formats, 13 reports, 27 cards, 4 charts, 1 dashboard
  * 4 workspaces, 4 sidebars, 4 desktop icons
  * 30 client scripts and 40 server scripts exist, are enabled, and (server) carry a compiled body
  * every report actually runs (falls back to a plain run for reports that need no filters)
  * the desk can build the Apparel page
Prints one line per check; exit code 1 if anything is missing or broken.
"""
import json
import os
import sys
import urllib.parse

HERE = os.path.dirname(os.path.abspath(__file__))
V2 = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(V2, "..", "skill", "scripts"))
BUNDLE = os.path.join(V2, "hosted_bundle")

PASS, FAIL, WARN = [], [], []


def bundle(name):
    return json.load(open(os.path.join(BUNDLE, name)))


def q(v):
    return urllib.parse.quote(json.dumps(v))


def main(argv):
    quick = "--quick" in argv
    from kogo_load import Site, session
    site = Site(session())

    def rows(dt, fields=("name",), filters=None, limit=0):
        path = "/api/resource/%s?fields=%s&limit_page_length=%d" % (
            urllib.parse.quote(dt), q(list(fields)), limit)
        if filters:
            path += "&filters=" + q(filters)
        st, r = site.call("GET", path)
        return (r.get("data") or []) if st == 200 else []

    def ok(label, cond, detail=""):
        (PASS if cond else FAIL).append(label)
        print("  %s %-52s %s" % ("ok  " if cond else "MISS", label, detail))

    # ---- versions
    st, r = site.call("GET", "/api/method/frappe.utils.change_log.get_versions")
    v = ((r.get("message") or {}).get("versions") or {}) if st == 200 else {}
    print("site: frappe %s / erpnext %s" % (
        next((x for k, x in v.items() if k.startswith("frappe")), "?"), v.get("erpnext", "?")))

    # ---- doctypes
    print("\ndoctypes")
    wanted = []
    for rec in bundle("03_doctypes.json")["records"]:
        wanted.append(rec["first"]["name"])
    dt_meta = {d["name"]: d for d in rows("DocType", ["name", "istable", "is_submittable", "issingle"], limit=0)}
    have = set(dt_meta)
    missing = [d for d in wanted if d not in have]
    ok("%d doctypes exist" % len(wanted), not missing, "missing: %s" % missing[:10] if missing else "")
    broken = []
    for d in wanted:
        if dt_meta.get(d, {}).get("issingle"):
            continue                      # a Single has no table, so list queries are not the test
        path = "/api/resource/%s?limit_page_length=1" % urllib.parse.quote(d)
        st, r = site.call("GET", path)
        if st not in (200, 403):
            broken.append((d, st))
    ok("every table doctype answers a list query", not broken, str(broken[:5]) if broken else "")

    # ---- custom fields
    print("\ncustom fields")
    cf = bundle("04_custom_fields.json")["records"]
    live = {(c["dt"], c["fieldname"]) for c in rows("Custom Field", ["dt", "fieldname"], limit=0)}
    miss = [(c["dt"], c["fieldname"]) for c in cf if (c["dt"], c["fieldname"]) not in live]
    ok("%d custom fields present" % len(cf), not miss,
       "%d missing e.g. %s" % (len(miss), miss[:3]) if miss else "")

    # ---- seeds
    print("\nmasters and seeds")
    seeds = bundle("06_seeds.json")["records"]
    by_dt = {}
    for s in seeds:
        by_dt.setdefault(s["doctype"], []).append(s.get("name"))
    for dt, names in sorted(by_dt.items()):
        have_names = {d["name"] for d in rows(dt, ["name"], limit=0)}
        miss = [n for n in names if n and n not in have_names]
        ok("%s (%d)" % (dt, len(names)), not miss,
           "%d missing e.g. %s" % (len(miss), miss[:3]) if miss else "")

    # ---- settings
    st, r = site.call("GET", "/api/resource/Apparel Settings/Apparel Settings")
    settings = (r.get("data") or {}) if st == 200 else {}
    ok("Apparel Settings saved with defaults", bool(settings.get("bundle_size")),
       "bundle_size=%s" % settings.get("bundle_size"))

    # ---- print formats / cards / charts / dashboard
    print("\nUI records")
    pf = {p["name"] for p in rows("Print Format", ["name"], limit=0)}
    want_pf = [p["name"] for p in bundle("08_print_formats.json")["records"]]
    ok("%d print formats" % len(want_pf), all(p in pf for p in want_pf),
       "%d/%d" % (sum(p in pf for p in want_pf), len(want_pf)))
    nc = {c["name"] for c in rows("Number Card", ["name"], limit=0)}
    want_nc = [c["name"] for c in bundle("10_number_cards.json")["records"]]
    ok("%d number cards" % len(want_nc), all(c in nc for c in want_nc),
       "%d/%d" % (sum(c in nc for c in want_nc), len(want_nc)))
    ch = {c["name"] for c in rows("Dashboard Chart", ["name"], limit=0)}
    want_ch = [c["name"] for c in bundle("11_dashboard_charts.json")["records"]]
    ok("4 dashboard charts", all(c in ch for c in want_ch))
    db = {d["name"] for d in rows("Dashboard", ["name"], limit=0)}
    want_db = [d["name"] for d in bundle("12_dashboards.json")["records"]]
    ok("%d dashboard(s)" % len(want_db), all(d in db for d in want_db),
       "%s" % [d for d in want_db if d not in db] if any(d not in db for d in want_db) else "")

    # ---- desk navigation
    print("\ndesk")
    ws = {w["name"]: w for w in rows("Workspace", ["name", "app", "module"], limit=0)}
    want_ws = [w["name"] for w in bundle("13_workspaces.json")["records"]]
    ok("%d workspaces" % len(want_ws), all(w in ws for w in want_ws),
       "%d/%d" % (sum(w in ws for w in want_ws), len(want_ws)))
    bad_app = [w for w in want_ws if w in ws and ws[w].get("app") not in ("erpnext", None, "")]
    ok("workspaces filed under an installed app", not bad_app, str(bad_app))
    sb = {s["name"] for s in rows("Workspace Sidebar", ["name"], limit=0)}
    want_sb = [s["name"] for s in bundle("14_workspace_sidebars.json")["records"]]
    ok("%d sidebars" % len(want_sb), all(s in sb for s in want_sb),
       "%d/%d" % (sum(s in sb for s in want_sb), len(want_sb)))
    ic = {i["name"] for i in rows("Desktop Icon", ["name"], limit=0)}
    want_ic = [i["name"] for i in bundle("15_desktop_icons.json")["records"]]
    ok("%d desktop icons" % len(want_ic), all(i in ic for i in want_ic),
       "%d/%d" % (sum(i in ic for i in want_ic), len(want_ic)))

    # ---- scripts
    print("\nscripts")
    cs = rows("Client Script", ["name", "dt", "enabled"], limit=0)
    want_cs = [c["name"] for c in bundle("16_client_scripts.json")["records"]]
    have_cs = {c["name"]: c for c in cs}
    ok("%d client scripts" % len(want_cs), all(c in have_cs for c in want_cs),
       "%d/%d" % (sum(c in have_cs for c in want_cs), len(want_cs)))
    disabled = [c for c in want_cs if c in have_cs and not have_cs[c].get("enabled")]
    ok("client scripts enabled", not disabled, str(disabled[:5]))

    ss = rows("Server Script", ["name", "script_type", "disabled", "reference_doctype"], limit=0)
    want_ss = [s["name"] for s in bundle("17_server_scripts.json")["records"]]
    have_ss = {s["name"]: s for s in ss}
    ok("%d server scripts" % len(want_ss), all(s in have_ss for s in want_ss),
       "%d/%d" % (sum(s in have_ss for s in want_ss), len(want_ss)))
    st, r = site.call("POST", "/api/method/arinox_engine", {})
    flag_on = st != 403
    off = [s for s in want_ss if s in have_ss and have_ss[s].get("disabled")]
    print("  %s site executes server scripts           %s" % (
        "ok  " if flag_on else "warn",
        "yes" if flag_on else "NO - server_script_enabled is off in the bench config"))
    if flag_on:
        ok("server scripts armed", not off, "%d disabled" % len(off))
    else:
        WARN.append("server scripts inert: bench flag off")
        print("  warn %-52s %d of %d disabled to keep the desk usable"
              % ("server scripts parked until the flag is on", len(off), len(want_ss)))
    api = [s for s in bundle("17_server_scripts.json")["records"] if s.get("script_type") == "API"]
    reach = []
    for a in api:
        st, r = site.call("POST", "/api/method/" + a["api_method"], {})
        reach.append(st)
    n_ok = sum(1 for x in reach if x in (200, 417, 500))
    n_blocked = sum(1 for x in reach if x == 403)
    if flag_on:
        ok("%d API endpoints reachable" % len(api), n_ok == len(api),
           "%d ok, %d blocked" % (n_ok, n_blocked))
    else:
        WARN.append("API endpoints blocked by bench flag")
        print("  warn %-52s %d of %d answered 403 (flag off), %d responded"
              % ("API endpoints", n_blocked, len(api), n_ok))

    # ---- reports actually run
    if not quick:
        print("\nreports")
        for rec in bundle("09_reports.json")["records"]:
            name = rec["name"]
            path = "/api/method/frappe.desk.query_report.run?report_name=%s&ignore_prepared_report=1&filters=%s" % (
                urllib.parse.quote(name), urllib.parse.quote("{}"))
            st, r = site.call("GET", path)
            if st == 200:
                msg = r.get("message") or {}
                n = len(msg.get("result") or [])
                PASS.append("report " + name)
                print("  ok   %-34s %d rows" % (name, n))
            else:
                why = str(r)[:160]
                # a report that demands a filter is not broken, it is waiting for one
                if "ServerScriptNotEnabled" in why:
                    WARN.append(name)
                    print("  warn %-34s parked: bench flag off" % name)
                elif "KeyError" in why or "format requires a mapping" in why:
                    WARN.append(name)
                    print("  warn %-34s needs its filter filled (no rows to feed it)" % name)
                elif "mandatory" in why.lower() or "filter" in why.lower():
                    WARN.append(name)
                    print("  warn %-34s needs a filter: %s" % (name, why[:70]))
                else:
                    FAIL.append("report " + name)
                    print("  MISS %-34s %s" % (name, why[:110]))

    # ---- the book, if the demo ran
    print("\ndata")
    for dt in ("Tech Pack", "Cost Sheet", "Sales Contract", "Production Card", "Lay Report",
               "Fabric Requisition", "Trim Requisition"):
        n = len(rows(dt, ["name"], limit=0))
        print("     %-22s %d record(s)" % (dt, n))

    print("\n%d passed, %d failed, %d warnings" % (len(PASS), len(FAIL), len(WARN)))
    for f in FAIL:
        print("  FAILED:", f)
    return 1 if FAIL else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
