#!/usr/bin/env python3
"""After the bundle is loaded: make the Apparel pages actually show up in the desk.

Three things the payload cannot decide for itself on a site that does not have the app:

1. `Workspace.app`. The bundle files the four Apparel pages under `arinox_apparel`. A page whose
   `app` is not an installed app never appears in the desk rail (this cost a day on 5 Nov). The
   working value is `erpnext`, and `module` has to be a module that maps to a real app folder.
2. `Workspace.module`. Same reason: keep the module if the Module Def exists, else fall back to the
   framework's `Custom`.
3. The per-user boot cache. Desktop icons and the sidebar list are cached per user, so after any
   change the icon record is touched (PUT an unchanged field) to clear it. The browser still needs a
   reload.

Run:  python3 post_fix.py [--dry-run]
"""
import json
import os
import sys
import urllib.parse

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "..", "skill", "scripts"))


def main(argv):
    dry = "--dry-run" in argv
    from kogo_load import Site, session
    site = Site(session())

    # 1. module defs that exist on the site
    st, r = site.call("GET", "/api/resource/Module Def?fields=%s&limit_page_length=0"
                      % urllib.parse.quote(json.dumps(["name", "app_name"])))
    mods = {row["name"]: row.get("app_name") for row in ((r.get("data") or []) if st == 200 else [])}
    print("modules on site: %d (Arinox Apparel: %s)" % (len(mods), "yes" if "Arinox Apparel" in mods else "NO"))
    fallback = "Custom" if "Custom" in mods else ("frappe" if "frappe" in mods else None)

    st, r = site.call("GET", "/api/resource/Workspace?fields=%s&limit_page_length=0"
                      % urllib.parse.quote(json.dumps(
                          ["name", "app", "module", "public", "is_hidden", "sequence_id"])))
    spaces = (r.get("data") or []) if st == 200 else []
    print("workspaces found: %s" % [w["name"] for w in spaces])
    for w in spaces:
        if w.get("app") == "erpnext" and w.get("module") in mods:
            print("  ok   %-28s app=erpnext module=%s" % (w["name"], w.get("module")))
            continue
        body = {"app": "erpnext"}
        if w.get("module") not in mods and fallback:
            body["module"] = fallback
        print("  fix  %-28s app=%s -> erpnext, module=%s -> %s" % (
            w["name"], w.get("app"), w.get("module"), body.get("module", w.get("module"))))
        if not dry:
            st, resp = site.update("Workspace", w["name"], body)
            if st != 200:
                print("       failed:", str(resp)[:200])

    # 2. touch desktop icons so the per-user boot cache drops the stale rail
    st, r = site.call("GET", "/api/resource/Desktop Icon?fields=%s&limit_page_length=0"
                      % urllib.parse.quote(json.dumps(["name", "label", "hidden", "link_to"])))
    icons = (r.get("data") or []) if st == 200 else []
    print("desktop icons: %s" % [(i["label"], i.get("link_to")) for i in icons])
    for i in icons:
        if dry:
            continue
        st, resp = site.update("Desktop Icon", i["name"], {"hidden": i.get("hidden") or 0})
        print("  touched %-20s %s" % (i["name"], "ok" if st == 200 else "FAILED %s" % st))

    # 3. sidebars must exist for the icons to draw
    st, r = site.call("GET", "/api/resource/Workspace Sidebar?fields=%s&limit_page_length=0"
                      % urllib.parse.quote(json.dumps(["name", "title"])))
    bars = (r.get("data") or []) if st == 200 else []
    print("sidebars: %s" % [b["name"] for b in bars])

    # 4. is the Apparel workspace readable the way the desk reads it
    # the desk calls get_desktop_page(page=json.dumps({"name": <workspace>})) - a bare name or a
    # `workspace=` kwarg is rejected because the method itself does loads(page).get("name")
    for w in [x["name"] for x in spaces]:
        st, r = site.call("GET", "/api/method/frappe.desk.desktop.get_desktop_page?page=%s"
                          % urllib.parse.quote(json.dumps({"name": w})))
        ok = st == 200
        n = 0
        if ok:
            msg = r.get("message") or {}
            n = len((msg.get("charts") or {}).get("items") or [])
        print("  desk payload %-24s %s cards=%s" % (w, "ok" if ok else "FAILED %s" % st, n))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
