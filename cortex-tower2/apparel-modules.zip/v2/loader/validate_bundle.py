#!/usr/bin/env python3
"""Offline sanity check of the Arinox hosted bundle before it touches a site.

Checks, with no network access:
  * every doctype's Link / Table / Table MultiSelect options resolve to a doctype that
    will exist after the load (bundle doctype, ERPNext 16.34.1 standard doctype, or a
    frappe framework doctype)
  * fieldname vs field_order mismatches that make the desk render an empty form
  * duplicate fieldnames inside a doctype
  * every server script / client script / report / print format / number card / chart /
    sidebar item points at a doctype that will exist
  * server script required extras (api_method for API type, reference doctype for events)
  * seed records point at doctypes that will exist
  * the insert order respects child-before-parent and closes link loops

Run:  python3 validate_bundle.py [bundle_dir]
Exit code 1 if anything is wrong.
"""
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
BUNDLE = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, "..", "hosted_bundle")

# frappe framework doctypes that ERPNext's own JSON does not define (never in the app bundle)
FRAPPE = {
    "User", "Role", "Role Profile", "File", "Report", "Server Script", "Client Script",
    "Print Format", "Number Card", "Dashboard", "Dashboard Chart", "Workspace",
    "Workspace Sidebar", "Desktop Icon", "DocType", "DocField", "DocPerm", "Module Def",
    "Custom Field", "Property Setter", "Workflow", "Workflow State", "Notification",
    "Email Template", "Letter Head", "Website Settings", "System Settings", "Translation",
    "Language", "Currency", "Country", "State", "Territory", "Salutation", "Gender",
    "Address", "Contact", "Contact Email", "Contact Phone", "Dynamic Link", "Comment",
    "Communication", "ToDo", "Tag", "Tag Link", "UOM", "UOM Conversion Factor",
    "Item Attribute", "Item Attribute Value", "DocType Link", "DocType Action",
    "DocType State", "Data Import", "Scheduled Job Type", "Scheduled Job Log",
    "Error Log", "Activity Log", "Version", "Document Follow", "Leaderboard",
    "Navbar Settings", "Global Search", "Patch Log", "Deleted Document",
    "Session Default Settings", "User Permission", "DefaultValue", "Form Tour",
    "Kanban Board", "Kanban Board Column", "Web Form", "Web Form Field", "Web Page",
    "Website Script", "Blog Post", "Portal Settings", "Route History", "View Log",
    "Prepared Report", "Report Filter", "Report Column", "Workspace Chart",
    "Workspace Link", "Workspace Shortcut", "Workspace Sidebar Item", "Desktop Icon Link",
    "Number Card Link", "Dashboard Chart Link", "Dashboard Chart Field", "Dashboard Settings",
    "RQ Job", "Integration Request", "OAuth Bearer Token", "Transaction Log",
    "Renew Subscription", "Custom HTML Block", "Client Script", "Server Script",
    "Audit Log", "Access Log", "Log Settings", "Print Settings", "Print Style",
}


def load(name):
    path = os.path.join(BUNDLE, name)
    return json.load(open(path))


def dt_records():
    return load("03_doctypes.json")["records"]


def field_list(doc):
    return doc.get("fields") or []


def main():
    problems = []
    warnings = []

    bundle_dts = {r["first"]["name"]: (r["first"], r["doc"]) for r in dt_records()}
    known = set(bundle_dts) | FRAPPE
    try:
        erp = set(json.load(open(os.path.join(HERE, "erpnext_doctypes.json"))))
        known |= erp
    except FileNotFoundError:
        warnings.append("erpnext_doctypes.json missing - standard-doctype checks are limited")

    def check_target(dt, fieldname, options, where):
        if not options:
            return
        if options not in known:
            problems.append("%s: %s.%s points at missing doctype %r" % (where, dt, fieldname, options))

    # 1. doctypes, fields, field_order
    for name, (first, doc) in bundle_dts.items():
        full = doc if doc else first
        fields = field_list(full)
        seen = set()
        for f in fields:
            fn = f.get("fieldname")
            if not fn:
                continue
            if fn in seen:
                problems.append("DocType %s: duplicate fieldname %r" % (name, fn))
            seen.add(fn)
            if f.get("fieldtype") in ("Link", "Table", "Table MultiSelect"):
                check_target(name, fn, f.get("options"), "DocType")
        order = [x for x in (full.get("field_order") or []) if x]
        if order:
            for fn in order:
                if fn not in seen:
                    # layout fields (Section Break / Column Break) are also in field_order; they exist as fields
                    problems.append("DocType %s: field_order has %r but no such field" % (name, fn))
            for fn in seen:
                if fn not in order and not fn.startswith("amended_from"):
                    warnings.append("DocType %s: field %r not in field_order (may not render)" % (name, fn))
        # child tables must exist as istable doctypes
        for f in fields:
            if f.get("fieldtype") in ("Table", "Table MultiSelect"):
                opt = f.get("options")
                if opt in bundle_dts and not bundle_dts[opt][1].get("istable", 0):
                    problems.append("DocType %s.%s is a Table but %r is not istable" % (name, f.get("fieldname"), opt))
        # permissions name roles
        for p in (full.get("permissions") or []):
            if p.get("role") and p["role"] not in {
                "Administrator", "System Manager", "All", "Guest", "Desk User",
            } and p["role"] not in {r.get("role_name") or r.get("name") for r in load("02_roles.json")["records"]}:
                warnings.append("DocType %s: permission for role %r not created by the bundle (must already exist on site)" % (name, p["role"]))

    # 2. server scripts
    for r in load("17_server_scripts.json")["records"]:
        if r.get("reference_doctype"):
            check_target("Server Script", r["name"], r["reference_doctype"], "Server Script")
        if r.get("script_type") == "API" and not r.get("api_method"):
            problems.append("Server Script %s: API type without api_method" % r["name"])
        if r.get("script_type") == "DocType Event" and not r.get("doctype_event"):
            problems.append("Server Script %s: DocType Event without doctype_event" % r["name"])
        if r.get("script_type") == "API" and not str(r.get("api_method", "")).startswith("arinox_"):
            warnings.append("Server Script %s: api_method %r is not arinox_ prefixed" % (r["name"], r.get("api_method")))
        if not (r.get("script") or "").strip():
            problems.append("Server Script %s: empty script" % r["name"])

    # 3. client scripts
    for r in load("16_client_scripts.json")["records"]:
        check_target("Client Script", r["name"], r.get("dt"), "Client Script")
        if not (r.get("script") or "").strip():
            problems.append("Client Script %s: empty script" % r["name"])

    # 4. reports
    for r in load("09_reports.json")["records"]:
        check_target("Report", r["name"], r.get("ref_doctype"), "Report")
        rt = r.get("report_type")
        if rt == "Query Report" and not (r.get("query") or "").strip():
            problems.append("Report %s: Query Report without SQL" % r["name"])
        if rt == "Script Report" and not (r.get("report_script") or "").strip():
            problems.append("Report %s: Script Report without report_script" % r["name"])

    # 5. print formats
    for r in load("08_print_formats.json")["records"]:
        check_target("Print Format", r["name"], r.get("doc_type"), "Print Format")

    # 6. number cards / charts / dashboard
    for r in load("10_number_cards.json")["records"]:
        check_target("Number Card", r["name"], r.get("document_type"), "Number Card")
    for r in load("11_dashboard_charts.json")["records"]:
        check_target("Dashboard Chart", r["name"], r.get("document_type"), "Dashboard Chart")

    # 7. seeds
    for r in load("06_seeds.json")["records"]:
        dt = r.get("doctype")
        if dt not in known:
            problems.append("Seed %r: doctype %r does not exist" % (r.get("name"), dt))
        for k, v in r.items():
            if k.endswith("_doctype") or k.endswith("_type"):
                if isinstance(v, str) and v in known:
                    pass

    # 8. sidebars / workspaces point at doctypes and reports
    reports = {r["name"] for r in load("09_reports.json")["records"]}
    for r in load("14_workspace_sidebars.json")["records"]:
        for item in r.get("items") or []:
            if (item.get("type") or "Link") != "Link":
                continue  # section break / spacer
            lt, lk = item.get("link_type"), item.get("link_to")
            if lt == "DocType":
                if lk not in known:
                    problems.append("Sidebar %s: item %r points at missing doctype %r" % (r["name"], item.get("label"), lk))
            elif lt == "Report":
                if lk not in reports:
                    problems.append("Sidebar %s: item %r points at missing report %r" % (r["name"], item.get("label"), lk))
            if not item.get("icon"):
                warnings.append("Sidebar %s: item %r has no icon (renders as bare text)" % (r["name"], item.get("label")))

    # 9. insert order: every Table option must be inserted before its parent
    order = [r["first"]["name"] for r in dt_records()]
    pos = {n: i for i, n in enumerate(order)}
    for name, (first, doc) in bundle_dts.items():
        full = doc if doc else first
        for f in field_list(full):
            if f.get("fieldtype") in ("Table", "Table MultiSelect"):
                opt = f.get("options")
                if opt in pos and pos[opt] > pos[name]:
                    warnings.append("Order: %s (#%d) uses table %s (#%d) - relies on the deferred second pass" % (name, pos[name], opt, pos[opt]))

    print("bundle:", os.path.abspath(BUNDLE))
    print("doctypes:", len(bundle_dts), "| known targets:", len(known))
    print("problems:", len(problems))
    for p in problems:
        print("  PROBLEM", p)
    print("warnings:", len(warnings))
    for w in warnings[:40]:
        print("  warn", w)
    if len(warnings) > 40:
        print("  ... %d more warnings" % (len(warnings) - 40))
    return 1 if problems else 0


if __name__ == "__main__":
    sys.exit(main())
