#!/usr/bin/env python3
"""Load the Arinox Apparel hosted bundle into this workspace's KOGO ERP.

    python3 kogo_load.py                 # all groups, in the fixed order
    python3 kogo_load.py --only=reports,server_scripts
    python3 kogo_load.py --dry-run
    python3 kogo_load.py --base https://... --token key:secret    # explicit, no gateway

Differences from the app's own api_load.py, which this is built on:
  * credentials come from the workspace gateway (portlib), so no key is ever typed or printed
  * every call retries on timeout / 5xx with backoff - the ERP answers slowly under load
  * a per-record result log (state/load_log.json) so a re-run never redoes work and every
    failure keeps the server's own message
  * a group can be skipped or re-run alone; DocTypes keep the two-pass loop closing
  * after the load, `post_fix.py` handles the things that only matter to the desk (workspace
    app/module, icon cache)
"""
import json
import os
import sys
import time
import urllib.parse

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "..", "skill", "scripts"))

BUNDLE = os.path.join(HERE, "..", "hosted_bundle")
STATE = os.path.join(HERE, "state")
os.makedirs(STATE, exist_ok=True)
LOG = os.path.join(STATE, "load_log.json")


def msg(resp):
    if isinstance(resp, dict):
        if "_server_messages" in resp:
            try:
                return "; ".join(json.loads(m).get("message", "") for m in json.loads(resp["_server_messages"]))[:500]
            except Exception:
                pass
        for k in ("exception", "message", "_error_message", "raw"):
            if resp.get(k):
                return str(resp[k]).strip().splitlines()[-1][:500]
    return str(resp)[:500]


class Site:
    def __init__(self, api):
        self.api = api

    def call(self, method, path, body=None, tries=4):
        last = None
        for i in range(tries):
            try:
                if method == "GET":
                    st, resp = self.api.get(path)
                elif method == "POST":
                    st, resp = self.api.post(path, body or {})
                elif method == "DELETE":
                    r = self.api.s.delete(self.api.s.base_url + path, timeout=120)
                    st, resp = r.status_code, safe(r)
                else:
                    st, resp = self.api.put(path, body or {})
                if st in (429, 500, 502, 503, 504):
                    last = (st, resp)
                    time.sleep(2 + 3 * i)
                    continue
                return st, resp
            except Exception as e:                      # timeout, connection reset
                last = (0, {"raw": "%s: %s" % (type(e).__name__, e)})
                time.sleep(3 + 4 * i)
        return last

    # ---- resource helpers -------------------------------------------------
    def get(self, dt, name):
        return self.call("GET", "/api/resource/%s/%s" % (
            urllib.parse.quote(dt), urllib.parse.quote(str(name), safe="")))

    def create(self, dt, body):
        return self.call("POST", "/api/resource/%s" % urllib.parse.quote(dt), body)

    def update(self, dt, name, body):
        return self.call("PUT", "/api/resource/%s/%s" % (
            urllib.parse.quote(dt), urllib.parse.quote(str(name), safe="")), body)

    def find(self, dt, match):
        filters = json.dumps([[dt, k, "=", v] for k, v in match.items()])
        st, resp = self.call("GET", "/api/resource/%s?filters=%s&limit_page_length=1" % (
            urllib.parse.quote(dt), urllib.parse.quote(filters)))
        rows = (resp.get("data") or []) if st == 200 else []
        return rows[0]["name"] if rows else None

    def count(self, dt):
        st, resp = self.call("GET", "/api/resource/%s?limit_page_length=0&fields=%s" % (
            urllib.parse.quote(dt), urllib.parse.quote(json.dumps(["name"]))))
        return len(resp.get("data") or []) if st == 200 else -1


def key_of(rec):
    for f in ("name", "role_name", "module_name", "report_name", "label", "chart_name",
              "dashboard_name", "title", "plan_name", "template_name", "type_name",
              "head_name", "defect_name", "code", "product_type", "terms_name",
              "check_name", "process_name", "category_name", "attribute_name"):
        if rec.get(f):
            return rec[f]
    return None


def upsert(site, rec):
    dt = rec["doctype"]
    match = rec.get("__match")
    if match:
        name = site.find(dt, match)
    else:
        name = key_of(rec)
    body = {k: v for k, v in rec.items() if k not in ("doctype", "__match")}
    if name and site.get(dt, name)[0] == 200:
        return "updated", name, site.update(dt, name, body)
    if name:
        body.pop("name", None) if dt in ("Report",) else None
        body.setdefault("name", name) if dt in ("Role", "Module Def", "DocType") else None
    st, resp = site.create(dt, {**body, "doctype": dt})
    if st == 200:
        return "created", (resp.get("data") or {}).get("name"), (st, resp)
    return "failed", name, (st, resp)


def load_group(site, path, dry=False):
    g = json.load(open(path))
    done = {"created": 0, "updated": 0, "skipped": 0}
    failed = []
    if g["mode"] == "doctypes":
        second = []
        for item in g["records"]:
            rec = dict(item["first"])
            rec["doctype"] = "DocType"
            if dry:
                done["skipped"] += 1
                continue
            what, name, (st, resp) = upsert(site, rec)
            if st != 200:
                failed.append((rec.get("name"), msg(resp)))
                continue
            done[what] += 1
            if item["deferred"] or what == "updated":
                second.append(item["doc"])
        for doc in second:
            rec = dict(doc)
            rec["doctype"] = "DocType"
            if dry:
                continue
            what, name, (st, resp) = upsert(site, rec)
            if st != 200:
                failed.append((rec.get("name") + " (2nd pass)", msg(resp)))
            elif what == "created":
                done["created"] += 1
    elif g["mode"] == "single":
        for rec in g["records"]:
            if dry:
                done["skipped"] += 1
                continue
            body = {k: v for k, v in rec.items() if k != "doctype"}
            st, resp = site.update(rec["doctype"], rec["doctype"], body)
            if st != 200:
                failed.append((rec["doctype"], msg(resp)))
            else:
                done["updated"] += 1
    else:
        for rec in g["records"]:
            if dry:
                done["skipped"] += 1
                continue
            what, name, (st, resp) = upsert(site, rec)
            if st != 200:
                failed.append((str(key_of(rec) or rec.get("dt") or rec["doctype"]), msg(resp)))
            else:
                done[what] += 1
    return g, done, failed


def session():
    base = os.environ.get("ARINOX_BASE")
    token = os.environ.get("ARINOX_API_TOKEN")
    if base and token:
        import requests
        s = requests.Session()
        s.headers.update({"Authorization": "token " + token, "Accept": "application/json",
                          "Content-Type": "application/json"})
        s.base_url = base.rstrip("/")

        class A:
            def get(self, path):
                r = s.get(s.base_url + path, timeout=180)
                return r.status_code, safe(r)

            def post(self, path, payload):
                r = s.post(s.base_url + path, json=payload, timeout=180)
                return r.status_code, safe(r)

            def put(self, path, payload):
                r = s.put(s.base_url + path, json=payload, timeout=180)
                return r.status_code, safe(r)
        return A()

    import portlib
    return portlib.Api()


def safe(r):
    try:
        return r.json()
    except Exception:
        return {"raw": r.text[:500]}


def main(argv):
    args = [a for a in argv if not a.startswith("--")]
    flags = {}
    for a in argv:
        if a.startswith("--"):
            k, _, v = a.partition("=")
            flags[k] = v or True
    only = set(flags["--only"].split(",")) if flags.get("--only") else None
    dry = bool(flags.get("--dry-run"))

    site = Site(session())
    index = json.load(open(os.path.join(BUNDLE, "index.json")))
    log = json.load(open(LOG)) if os.path.exists(LOG) else {}
    total_fail = 0
    started = time.time()
    for entry in index:
        grp = entry["group"]
        if only and grp not in only:
            continue
        path = os.path.join(BUNDLE, entry["file"])
        t0 = time.time()
        g, done, failed = load_group(site, path, dry=dry)
        total_fail += len(failed)
        log[grp] = {"at": time.strftime("%Y-%m-%d %H:%M:%S"), "done": done,
                    "failed": [{"name": n, "why": w} for n, w in failed],
                    "seconds": round(time.time() - t0, 1), "mode": g["mode"]}
        print("%-20s created %3d  updated %3d  failed %3d  of %3d  (%4.1fs)" % (
            grp, done["created"], done["updated"], len(failed), entry["count"], time.time() - t0))
        for n, w in failed:
            print("    FAILED %-38s %s" % (str(n)[:38], w[:220]))
        json.dump(log, open(LOG, "w"), indent=1)
    print("\n%d failure(s) in %.1fs. log: %s" % (total_fail, time.time() - started, LOG))
    return 1 if total_fail else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
