#!/usr/bin/env bash
# One command: load the Arinox Apparel bundle, fix the desk, park the scripts if the site cannot run
# them, prove the whole thing, and refresh the inventory markdown.
#
#   ./integrate.sh              # the normal full sync (no data is written)
#   ./integrate.sh --demo       # also build the 30-document demo order
#
# Safe to re-run: every step upserts by name, nothing is duplicated.
set -u
cd "$(dirname "$0")"

DEMO=0
[ "${1:-}" = "--demo" ] && DEMO=1

echo "== 0. reachability"
python3 - <<'PY' || { echo "ERP link is down - nothing done."; exit 1; }
import sys, os
sys.path.insert(0, os.path.join("..", "skill", "scripts"))
import portlib
try:
    s = portlib.session()
    print("reachable:", s.base_url)
except Exception as e:
    print("unreachable:", type(e).__name__, str(e)[:80]); sys.exit(1)
PY

echo "== 1. module, roles, doctypes, fields, seeds, settings, UI records, navigation, scripts"
python3 loader/kogo_load.py || echo "(some groups reported failures - see loader/state/load_log.json)"

echo "== 2. desk fixes (workspace app/module, icon cache)"
python3 loader/post_fix.py

echo "== 3. server script state (the site needs server_script_enabled=1 to execute any of them)"
if python3 loader/script_switch.py --probe | grep -q ENABLED; then
  python3 loader/script_switch.py --on
else
  echo "   bench flag is off -> parking DocType Event scripts so documents can still be saved"
  python3 loader/script_switch.py --off --type="DocType Event"
fi

echo "== 4. verification"
python3 loader/verify_after_load.py || true

echo "== 5. inventory markdown"
python3 loader/make_inventory_md.py

if [ "$DEMO" = "1" ]; then
  echo "== 6. demo order"
  python3 demo/make_demo_book.py
fi

echo "done. reports: loader/state/  docs: INTEGRATION.md, INVENTORY.md"
