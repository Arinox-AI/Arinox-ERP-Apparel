# Arinox Apparel: what is on the KOGO ERP

Generated 2026-11-06 16:58 UTC by `loader/make_inventory_md.py` from `hosted_bundle/`.

Source: `github.com/Arinox-AI/Arinox-ERP-Apparel`, branch `apparel-app`, head `75ef036`.

**887 records in 17 groups.** Every row below is a record the loader upserts by name, so a re-run updates instead of duplicating.

| group | file | records | how it loads |
|---|---|---:|---|
| module_def | `01_module_def.json` | 1 | upsert by name |
| roles | `02_roles.json` | 6 | upsert by name |
| doctypes | `03_doctypes.json` | 131 | two-pass, links closed on the second pass |
| custom_fields | `04_custom_fields.json` | 189 | upsert by name |
| property_setters | `05_property_setters.json` | 7 | upsert by name |
| seeds | `06_seeds.json` | 195 | upsert by name |
| apparel_settings | `07_apparel_settings.json` | 1 | PUT on the singleton |
| print_formats | `08_print_formats.json` | 10 | upsert by name |
| reports | `09_reports.json` | 20 | upsert by name |
| number_cards | `10_number_cards.json` | 29 | upsert by name |
| dashboard_charts | `11_dashboard_charts.json` | 4 | upsert by name |
| dashboards | `12_dashboards.json` | 1 | upsert by name |
| workspaces | `13_workspaces.json` | 4 | upsert by name |
| workspace_sidebars | `14_workspace_sidebars.json` | 4 | upsert by name |
| desktop_icons | `15_desktop_icons.json` | 4 | upsert by name |
| client_scripts | `16_client_scripts.json` | 30 | upsert by name |
| server_scripts | `17_server_scripts.json` | 251 | upsert by name |

## DocTypes (131)

`S` = single (no table), `C` = child table, `sub` = submittable, `✓` = present on the site.

| DocType | module | flags | on site |
|---|---|---|---:|
| AQL Plan Row | Arinox Apparel | C | ✓ |
| Apparel Sample Rule | Arinox Apparel | C | ✓ |
| Buyer Claim Row | Arinox Apparel | C | ✓ |
| Cost Head | Arinox Apparel |  | ✓ |
| Cost Sheet Charge | Arinox Apparel | C | ✓ |
| Cost Sheet Material | Arinox Apparel | C | ✓ |
| Cost Sheet Signoff | Arinox Apparel | C | ✓ |
| Costing Parameter Rate | Arinox Apparel | C | ✓ |
| Cut Plan Lay | Arinox Apparel | C | ✓ |
| Cut Plan Ratio | Arinox Apparel | C | ✓ |
| Daily Line Report Hour | Arinox Apparel | C | ✓ |
| Production Card Fabric | Arinox Apparel | C | ✓ |
| Production Card Line | Arinox Apparel | C | ✓ |
| Product Type | Arinox Apparel |  | ✓ |
| Costing Parameter | Arinox Apparel |  | ✓ |
| Tech Pack Colour | Arinox Apparel | C | ✓ |
| Tech Pack Fit Round | Arinox Apparel | C | ✓ |
| Tech Pack Image | Arinox Apparel | C | ✓ |
| Tech Pack Material | Arinox Apparel | C | ✓ |
| Tech Pack Measurement | Arinox Apparel | C | ✓ |
| Tech Pack Size | Arinox Apparel | C | ✓ |
| Tech Pack | Arinox Apparel | sub | ✓ |
| Cost Sheet | Arinox Apparel | sub | ✓ |
| Price Negotiation Round | Arinox Apparel | C | ✓ |
| Price Negotiation Style | Arinox Apparel | C | ✓ |
| Price Negotiation | Arinox Apparel |  | ✓ |
| Sales Contract Item | Arinox Apparel | C | ✓ |
| Sales Contract Size Qty | Arinox Apparel | C | ✓ |
| Sales Contract Tolerance Band | Arinox Apparel | C | ✓ |
| Sales Contract Template | Arinox Apparel |  | ✓ |
| Sales Contract | Arinox Apparel | sub | ✓ |
| PP Meeting Action | Arinox Apparel | C | ✓ |
| PP Meeting Colour | Arinox Apparel | C | ✓ |
| PP Meeting Participant | Arinox Apparel | C | ✓ |
| PP Meeting | Arinox Apparel | sub | ✓ |
| Sample Approval Comment | Arinox Apparel | C | ✓ |
| Sample Approval Round | Arinox Apparel | C | ✓ |
| Sample Measurement | Arinox Apparel | C | ✓ |
| Sample Shrinkage Reading | Arinox Apparel | C | ✓ |
| Sample Test Result | Arinox Apparel | C | ✓ |
| Sample Approval | Arinox Apparel |  | ✓ |
| Subcontract Process | Arinox Apparel |  | ✓ |
| Production Card Process | Arinox Apparel | C | ✓ |
| Production Card | Arinox Apparel | sub | ✓ |
| Cut Plan | Arinox Apparel |  | ✓ |
| Apparel Defect Code | Arinox Apparel |  | ✓ |
| Lay Panel Reject | Arinox Apparel | C | ✓ |
| Lay Roll | Arinox Apparel | C | ✓ |
| Lay Size | Arinox Apparel | C | ✓ |
| Recut Request | Arinox Apparel | sub | ✓ |
| Lay Report | Arinox Apparel | sub | ✓ |
| Cut Bundle | Arinox Apparel |  | ✓ |
| Daily Line Report Output | Arinox Apparel | C | ✓ |
| Delay Penalty Band | Arinox Apparel | C | ✓ |
| Fabric Defect Code | Arinox Apparel |  | ✓ |
| Fabric Inspection Defect | Arinox Apparel | C | ✓ |
| Fabric Inspection Roll | Arinox Apparel | C | ✓ |
| Fabric Requisition Item | Arinox Apparel | C | ✓ |
| Fabric Requisition Summary | Arinox Apparel | C | ✓ |
| Fabric Sampling Band | Arinox Apparel | C | ✓ |
| Factory Allocation Line | Arinox Apparel | C | ✓ |
| AQL Plan | Arinox Apparel |  | ✓ |
| Final Inspection Defect | Arinox Apparel | C | ✓ |
| Final Inspection Lot | Arinox Apparel | C | ✓ |
| Final Inspection | Arinox Apparel | sub | ✓ |
| Packing List Carton | Arinox Apparel | C | ✓ |
| Packing List Content | Arinox Apparel | C | ✓ |
| Packing List Ratio | Arinox Apparel | C | ✓ |
| Packing List SSCC | Arinox Apparel | C | ✓ |
| Packing List | Arinox Apparel | sub | ✓ |
| Final Inspection Carton | Arinox Apparel | C | ✓ |
| Finishing Receipt Row | Arinox Apparel | C | ✓ |
| Learning Curve Day | Arinox Apparel | C | ✓ |
| Line Input Bundle | Arinox Apparel | C | ✓ |
| Line QC Defect | Arinox Apparel | C | ✓ |
| Line QC Disposition | Arinox Apparel | C | ✓ |
| Line QC Hour | Arinox Apparel | C | ✓ |
| Line QC Pass | Arinox Apparel | C | ✓ |
| Line QC Traffic | Arinox Apparel | C | ✓ |
| OB Operation | Arinox Apparel | C | ✓ |
| Production Check Item | Arinox Apparel |  | ✓ |
| Pilot Run Check | Arinox Apparel | C | ✓ |
| Pilot Run Colour | Arinox Apparel | C | ✓ |
| Pilot Run Defect | Arinox Apparel | C | ✓ |
| Pilot Run Operation | Arinox Apparel | C | ✓ |
| Pilot Run Participant | Arinox Apparel | C | ✓ |
| Purchase Qty Band | Arinox Apparel | C | ✓ |
| Shipment Container | Arinox Apparel | C | ✓ |
| Shipment Declaration | Arinox Apparel | C | ✓ |
| Shipment Document | Arinox Apparel | C | ✓ |
| Destination Filing Rule | Arinox Apparel |  | ✓ |
| Shipment Filing | Arinox Apparel | C | ✓ |
| Shipment Packing List | Arinox Apparel | C | ✓ |
| Subcontract Challan Row | Arinox Apparel | C | ✓ |
| Subcontract Return Row | Arinox Apparel | C | ✓ |
| TNA Milestone Type | Arinox Apparel |  | ✓ |
| TNA Template Milestone | Arinox Apparel | C | ✓ |
| Traffic Light Rule | Arinox Apparel | C | ✓ |
| Trim Defect Type | Arinox Apparel |  | ✓ |
| Trim Inspection Defect | Arinox Apparel | C | ✓ |
| Trim Category | Arinox Apparel |  | ✓ |
| Trim Requisition Item | Arinox Apparel | C | ✓ |
| Trim Sampling Plan Row | Arinox Apparel | C | ✓ |
| Material Purchase Terms | Arinox Apparel |  | ✓ |
| TNA Template | Arinox Apparel |  | ✓ |
| Trim Sampling Plan | Arinox Apparel |  | ✓ |
| Apparel Settings | Arinox Apparel | S | ✓ |
| Arinox Number | Arinox Apparel |  | ✓ |
| Buyer Claim | Arinox Apparel | sub | ✓ |
| Daily Line Report | Arinox Apparel | sub | ✓ |
| Fabric Requisition | Arinox Apparel | sub | ✓ |
| Fabric Inspection | Arinox Apparel | sub | ✓ |
| Factory Allocation | Arinox Apparel |  | ✓ |
| Finishing Receipt | Arinox Apparel | sub | ✓ |
| Letter of Credit | Arinox Apparel |  | ✓ |
| Line Input | Arinox Apparel | sub | ✓ |
| Line QC Report | Arinox Apparel | sub | ✓ |
| Material Allowance Rule | Arinox Apparel |  | ✓ |
| Needle Detector Log | Arinox Apparel |  | ✓ |
| Operation Bulletin | Arinox Apparel |  | ✓ |
| Order TNA | Arinox Apparel |  | ✓ |
| Pilot Run | Arinox Apparel | sub | ✓ |
| Production Adjustment | Arinox Apparel | sub | ✓ |
| Production Movement | Arinox Apparel |  | ✓ |
| Sample Requirement | Arinox Apparel |  | ✓ |
| Subcontract Challan | Arinox Apparel | sub | ✓ |
| Subcontract Return | Arinox Apparel | sub | ✓ |
| Subcontract Settlement | Arinox Apparel | sub | ✓ |
| TNA Milestone | Arinox Apparel |  | ✓ |
| Trim Requisition | Arinox Apparel | sub | ✓ |
| Trim Inspection | Arinox Apparel | sub | ✓ |

## Custom fields (189 on 26 documents)

| document | fields | fieldnames |
|---|---:|---|
| Shipment | 53 | `apparel_cost_variance_pct`, `apparel_measures`, `apparel_reason_for_air`, `apparel_delivery_date`, `apparel_dates_col`, `apparel_carrier_cbm`, `apparel_carrier_gross_kg`, `apparel_ship_col1`, `apparel_booking_date`, `apparel_measures_col`, `apparel_customs_gross_kg`, `apparel_filings`, `apparel_chargeable_cbm`, `apparel_declarations`, `apparel_forwarder`, `apparel_freight_quote`, `apparel_lists_section`, `apparel_measure_note`, `apparel_etd`, `apparel_cutoff`, `apparel_hbl_no`, `apparel_documents`, `apparel_booked_cbm`, `apparel_booked_gross_kg`, `apparel_air_section`, `apparel_chargeable_kg`, `apparel_destination_country`, `apparel_actual_total`, `apparel_bl_type`, `apparel_eta`, `apparel_vessel_voyage`, `apparel_booking_no`, `apparel_estimate_total`, `apparel_dates`, `apparel_mbl_no`, `apparel_packing_lists`, `apparel_on_board_date`, `apparel_cost_section`, `apparel_declared_cbm`, `apparel_declared_gross_kg`, `apparel_ship_status`, `apparel_arrival_date`, `apparel_containers`, `apparel_final_destination`, `apparel_pod`, `apparel_air_cost_borne_by`, `apparel_mode`, `apparel_freight_terms`, `apparel_pol`, `apparel_contracts`, `apparel_service_type`, `apparel_stuffing_place`, `apparel_section` |
| Sales Invoice | 19 | `apparel_basis_source`, `apparel_expected_due_date`, `apparel_shipment`, `apparel_promise_date`, `apparel_basis_date`, `apparel_follow_col`, `apparel_followup_status`, `apparel_due_basis`, `apparel_days_overdue`, `apparel_follow_section`, `apparel_letter_of_credit`, `apparel_dispute_reason`, `apparel_next_action_date`, `apparel_promise_amount`, `apparel_is_sample_invoice`, `apparel_all_contracts`, `apparel_commercial_invoice_no`, `apparel_route_leg`, `apparel_sales_contract` |
| Purchase Order | 18 | `apparel_approval_override_reason`, `apparel_po_override_section`, `apparel_po_col`, `apparel_bl_awb_no`, `apparel_eta`, `apparel_etd_revised`, `apparel_etd_actual`, `apparel_etd_planned`, `apparel_mill_ready_date`, `apparel_pi_date`, `apparel_pi_no`, `apparel_approval_override`, `apparel_purchase_terms`, `apparel_destination`, `apparel_supplier_contract_no`, `apparel_port_of_loading`, `apparel_shipment_mode`, `apparel_po_section` |
| Batch | 13 | `apparel_roll_col`, `apparel_shade_band`, `apparel_shrinkage_warp_pct`, `apparel_fabric_inspection`, `apparel_inspection_status`, `apparel_width_cm`, `apparel_dye_lot`, `apparel_roll_no`, `apparel_ticket_length`, `apparel_shrinkage_weft_pct`, `apparel_actual_length`, `apparel_points_per_100`, `apparel_roll_section` |
| Opportunity | 9 | `apparel_target_fob`, `apparel_delivery_to`, `apparel_source_email`, `apparel_season`, `apparel_target_qty`, `apparel_product_type`, `apparel_delivery_from`, `apparel_col_1`, `apparel_section` |
| Item | 8 | `apparel_item_col`, `apparel_construction`, `apparel_fabric_width_cm`, `apparel_fabric_gsm`, `apparel_material_type`, `apparel_trim_category`, `apparel_fabric_content`, `apparel_item_section` |
| Sales Order Item | 8 | `apparel_etd`, `apparel_size`, `apparel_in_warehouse_date`, `apparel_qty_tolerance_pct`, `apparel_cost_sheet`, `apparel_buyer_po`, `apparel_ship_to`, `apparel_colour` |
| Delivery Note | 6 | `apparel_gate_override_reason`, `apparel_over_ship_override`, `apparel_over_ship_override_reason`, `apparel_shipment`, `apparel_gate_override`, `apparel_sales_contract` |
| Material Request Item | 6 | `apparel_hold_reason`, `apparel_requisition_item`, `apparel_style_no`, `apparel_requisition`, `apparel_colour`, `apparel_requisition_type` |
| Purchase Order Item | 6 | `apparel_hold_reason`, `apparel_requisition_item`, `apparel_style_no`, `apparel_requisition`, `apparel_colour`, `apparel_requisition_type` |
| Customer | 5 | `apparel_invoice_via_company`, `apparel_transfer_basis`, `apparel_transfer_pct`, `apparel_transfer_price_list`, `apparel_bill_section` |
| Purchase Receipt | 5 | `apparel_penalty_pct`, `apparel_qty_band_note`, `apparel_penalty_amount`, `apparel_delay_days`, `apparel_pr_section` |
| Company | 4 | `apparel_contract_prefix`, `apparel_fr_prefix`, `apparel_pc_prefix`, `apparel_tr_prefix` |
| Workstation | 4 | `apparel_line_section`, `apparel_default_helpers`, `apparel_line_type`, `apparel_default_operators` |
| Quotation Item | 3 | `apparel_style_no`, `apparel_style_item`, `apparel_cost_sheet` |
| Shipment Parcel Template | 3 | `apparel_max_gross_kg`, `apparel_customer`, `apparel_tare_kg` |
| Supplier | 3 | `apparel_supplier_type`, `apparel_purchase_terms`, `apparel_section` |
| Supplier Quotation Item | 3 | `apparel_min_amount`, `apparel_max_amount`, `apparel_charge_unit` |
| Work Order | 3 | `apparel_gate_override_reason`, `apparel_gate_override`, `apparel_gate_section` |
| Delivery Note Item | 2 | `apparel_packing_list`, `apparel_production_card` |
| Stock Entry | 2 | `apparel_issue_kind`, `apparel_production_card` |
| Supplier Quotation | 2 | `apparel_quote_mode`, `apparel_shipment` |
| Payment Entry | 1 | `apparel_remittance_ref` |
| Purchase Invoice | 1 | `apparel_shipment` |
| Quotation | 1 | `apparel_price_negotiation` |
| Sales Order | 1 | `apparel_sales_contract` |

## Property setters (7)

| doc type | field | property | value |
|---|---|---|---|
| Shipment | value_of_goods | reqd | 0 |
| Shipment | description_of_content | reqd | 0 |
| Shipment | pickup_date | reqd | 0 |
| Shipment | pickup_to | reqd | 0 |
| Shipment | pickup_from | reqd | 0 |
| Shipment | delivery_address_name | reqd | 0 |
| Shipment | pickup_address_name | reqd | 0 |

## Master data and seeds (195 rows in 17 doctypes)

| doctype | rows | names |
|---|---:|---|
| AQL Plan | 1 | Garment AQL 2.5 / 4.0 Level II |
| Apparel Defect Code | 44 | Broken or Loose Stitch, Open Seam or Raw Edge, Puckering, Joint Stitch Visible, Bar Tack Insecure, Button or Buttonhole Missing, Alignment Defect, Wrong Size Label, Incorrect Label Placement, Crossed Label, Poor Ironing, Shine or Crease Marks, Stains, Holes … |
| Cost Head | 17 | Fabric, Trims, Stitching (CMT), Washing, Embellishment, Testing, Rejection Allowance, Overhead, Freight, Finance, Bank Charges, Profit, Fabric Export Cost, Fabric Import Cost … |
| Destination Filing Rule | 1 | Importer Security Filing (US) |
| Fabric Defect Code | 28 | A, B, C, D, E, F, G, H, I, J, K, L, M, N … |
| Item Attribute | 2 | Colour, Size |
| Material Allowance Rule | 7 | ?, ?, ?, ?, ?, ?, ? |
| Material Purchase Terms | 2 | Standard Fabric Terms, Standard Trim Terms |
| Product Type | 6 | Knit Top, Woven Top, Bottom, Dress, Outerwear, Sleepwear |
| Production Check Item | 13 | Fit and measurements after wash, Construction, Wash result vs approved standard, Trims and labels, Needle and thread, Shade, Packing, Line setting, Machines and attachments ready, Operators trained on critical operations, Hang tag and sticker positions, Polybag warning and size, Barcode matches size and colour |
| Quality Inspection Parameter | 7 | Trim Size Mix-up, Trim Defective %, Shrinkage Weft %, Shrinkage Warp %, Average Width (cm), Worst Roll Points per 100, Average Points per 100 Linear Yards |
| Subcontract Process | 6 | Wash, Embroidery, Print, Appliqué, Heat Transfer, Garment Dye |
| TNA Milestone Type | 33 | ORDER_RECEIVED, TECH_PACK_RECEIVED, BOM_RECEIVED, BULK_STANDARD_RECEIVED, MINI_MARKER, FR_RAISED, TR_RAISED, FABRIC_BOOKED, TRIM_PI, FIT, LAB_DIP, TRIMS_APPROVED, BULK_FABRIC_READY_MILL, FABRIC_ETD … |
| TNA Template | 1 | Standard 60-Day (forward) |
| Trim Category | 13 | Woven Label, Size Label, Care Label, Thread, Fusing / Interlining, Security Tag, Hang Tag, Button, Branding, Zipper / Hooks / Fasteners, Elastic / Tape, Packaging, Others |
| Trim Defect Type | 12 | Letter Missing, Print Missing, Shape Out, Stains, Fusing Problem, Scratch, Needle Hole Missing, Damaged Button / Label, Colour Variation, Size Variation, Size Mix-up, Unmatching Thread |
| Trim Sampling Plan | 2 | Trims 10 Percent, AQL 2.5 General II (unconfirmed) |

## Apparel Settings (singleton, 85 fields)

Keys the site now carries as defaults:

```
air_volumetric_divisor, approval_tolerance_pct, auto_submit_material_request, auto_submit_stock_entries, bundle_size, carton_max_gross_kg, carton_pick_rule, claim_requires_evidence, colour_attribute, contract_prefix, controlled_trim_tolerance, cost_overrun_warn_pct, cut_cap_extra_pcs, cut_cap_mode, default_extra_cut_pct, default_margin_floor_pct, default_purchase_terms, default_tna_template, default_trim_sampling_plan, dhu_alert_threshold, enforce_bulk_gate, escalation_days_1, escalation_days_2, escalation_days_3, fabric_due_days_before_pcd, fabric_points_basis, fabric_points_threshold, fabric_sampling_bands, final_block_packed_pct, final_inspection_plan, final_min_packed_pct, fr_material_types, fr_qty_basis, freight_estimate_variance_pct, gpt_test_list, hold_po_until_approval, inline_check_pieces, kit_check, learning_curve, marker_variance_pct, material_gate_fabric, material_gate_min_pct, material_gate_trims, max_extra_cut_pct, max_rejected_rolls_pct, max_shrinkage_pct, max_shrinkage_spread_pct, max_skus_per_contract, max_width_spread_cm, measure_variance_warn_pct, name, needle_check_required, needle_recheck_hours, needle_test_piece_mm, panel_inspection_pct, pilot_default_qty, pilot_min_order_qty, pilot_required_departments, placeholder_words, planned_efficiency_pct, post_fg_receipt, pp_required_departments, reinspection_limit, reminder_days_before_due, remnant_min_m, require_bundle_on_input, require_bundle_on_output, require_costing_signoff, require_pilot_before_bulk_wash, require_pp_meeting, rog_buffer_days, sample_rules, ship_gate_final_inspection, ship_tolerance_basis, size_attribute, subcontract_default_threshold_pct, subcontract_penalty_basis, subcontract_penalty_scope, subcontract_reconcile_days, submit_inspection_stock_entry, traffic_light_rules, trim_allowance_pct, trim_due_days_before_pcd, weight_variance_warn_pct, work_minutes_per_day
```

## Print formats (10)

- **Bundle Ticket** (Cut Bundle) 1951 bytes of HTML
- **Carton Label** (Packing List) 2160 bytes of HTML
- **Commercial Invoice** (Sales Invoice) 4775 bytes of HTML
- **Fabric Requisition Form** (Fabric Requisition) 3984 bytes of HTML
- **Final Inspection Report** (Final Inspection) 4332 bytes of HTML
- **Lay Report Form** (Lay Report) 3947 bytes of HTML
- **Packing List Form** (Packing List) 3806 bytes of HTML
- **Production Card Form** (Production Card) 5512 bytes of HTML
- **Trim Card** (Production Card) 2163 bytes of HTML
- **Trim Requisition Form** (Trim Requisition) 3256 bytes of HTML

## Reports (20)

| report | type | ref doctype | runs today |
|---|---|---|---|
| Production Summary | Query Report | Production Card | needs a filter |
| Contract Delivery Schedule | Script Report | Sales Contract | parked: server scripts off |
| Contract Trail | Script Report | Sales Order | parked: server scripts off |
| Costing Margin Review | Script Report | Cost Sheet | parked: server scripts off |
| Daily Cutting Report | Script Report | Production Card | parked: server scripts off |
| Daily Production Report | Script Report | Production Card | parked: server scripts off |
| Fabric Consumption | Script Report | Production Card | parked: server scripts off |
| Factory Load | Script Report | Factory Allocation | parked: server scripts off |
| Freight Allocation | Script Report | Shipment | parked: server scripts off |
| Inquiry to Contract Tracker | Script Report | Opportunity | parked: server scripts off |
| Line Efficiency and DHU | Script Report | Daily Line Report | parked: server scripts off |
| Line Loading | Script Report | Line Input | parked: server scripts off |
| Material Status | Script Report | Fabric Requisition | parked: server scripts off |
| Negotiation History | Script Report | Price Negotiation | parked: server scripts off |
| Receivables Follow-up | Script Report | Sales Invoice | parked: server scripts off |
| Running Fabric Stock | Script Report | Purchase Order | parked: server scripts off |
| Sample Approval Tracker | Script Report | Sample Approval | parked: server scripts off |
| Sewing WIP | Script Report | Line Input | parked: server scripts off |
| Fabric Overdue Lines | Query Report | Fabric Requisition | 1 rows |
| Trim Lines On Hold Count | Query Report | Trim Requisition | 1 rows |

## Desk UI records

| group | count | names |
|---|---:|---|
| number cards | 29 | Cards In Cutting, Cards In Sewing, Challans Open, Challans Overdue, Contract Value This Month, Contracts Awaiting Order, Costings Pending Approval, Credits Expiring in 14 Days, Disputed Invoices, Draft Invoices To Submit, Fabric Overdue, Final Inspections Rejected 30 Days, Letters of Credit Open, Lists Ready to Ship, Needle Checks Failed Not Re-scanned, Open Buyer Claims, Open Inquiries, Open Negotiations, Orders Awaiting Plan, Overdue Amount, Overdue Invoices, Overdue Samples, Packing Lists Awaiting Inspection, Promises Due This Week, Rejected Lots 30 Days, Rolls Awaiting Inspection, Samples With Buyer, Shipments Not Yet Delivered, TR Lines On Hold |
| dashboard charts | 4 | Apparel Inquiries, Costing Approvals, Negotiations by Status, Signed Contract Value |
| dashboards | 1 | Apparel Pre-Sales |
| workspaces | 4 | Apparel, Apparel Production, Apparel Quality, Apparel Shipping |
| sidebars | 4 | Apparel, Production, Quality and Packing, Shipping and Collections |
| desktop icons | 4 | Apparel, Apparel Production, Apparel Quality, Apparel Shipping |

## Client scripts (30)

| script | document |
|---|---|
| Arinox Buyer Claim | Buyer Claim |
| Arinox Cost Sheet | Cost Sheet |
| Arinox Cut Plan | Cut Plan |
| Arinox Fabric Inspection | Fabric Inspection |
| Arinox Fabric Requisition | Fabric Requisition |
| Arinox Factory Allocation | Factory Allocation |
| Arinox Final Inspection | Final Inspection |
| Arinox Lay Report | Lay Report |
| Arinox Order TNA | Order TNA |
| Arinox Packing List | Packing List |
| Arinox Pilot Run | Pilot Run |
| Arinox PP Meeting | PP Meeting |
| Arinox Price Negotiation | Price Negotiation |
| Arinox Production Card | Production Card |
| Arinox Sales Contract | Sales Contract |
| Arinox Sample Approval | Sample Approval |
| Arinox Subcontract Challan | Subcontract Challan |
| Arinox Subcontract Settlement | Subcontract Settlement |
| Arinox Tech Pack | Tech Pack |
| Arinox TNA Milestone | TNA Milestone |
| Arinox Trim Inspection | Trim Inspection |
| Arinox Trim Requisition | Trim Requisition |
| Arinox Opportunity | Opportunity |
| Arinox Purchase Order | Purchase Order |
| Arinox Purchase Receipt | Purchase Receipt |
| Arinox Quotation | Quotation |
| Arinox Sales Invoice | Sales Invoice |
| Arinox Sales Order | Sales Order |
| Arinox Shipment | Shipment |
| Arinox Work Order | Work Order |

## Server scripts (251)

### API (83)

| script | api method |
|---|---|
| arinox_tna_api_get_tna | `arinox_api_get_tna` |
| arinox_tna_api_update_milestone | `arinox_api_update_milestone` |
| arinox_tna_api_wip_board_data | `arinox_api_wip_board_data` |
| arinox_buyer_claim_api_make_credit_note | `arinox_buyer_claim_make_credit_note` |
| arinox_close_api_commercial_close | `arinox_close_commercial_close` |
| arinox_close_api_get_checklist | `arinox_close_get_checklist` |
| arinox_close_production | `arinox_close_production` |
| arinox_cost_sheet_api_approve | `arinox_cost_sheet_approve` |
| arinox_cost_sheet_api_get_costing_context | `arinox_cost_sheet_get_costing_context` |
| arinox_cost_sheet_api_get_margin_at_price | `arinox_cost_sheet_get_margin_at_price` |
| arinox_cost_sheet_api_get_previous_costing | `arinox_cost_sheet_get_previous_costing` |
| arinox_cost_sheet_api_make_price_negotiation | `arinox_cost_sheet_make_price_negotiation` |
| arinox_cost_sheet_api_make_quotation | `arinox_cost_sheet_make_quotation` |
| arinox_cost_sheet_api_reject | `arinox_cost_sheet_reject` |
| arinox_cost_sheet_api_set_charges_from_parameter | `arinox_cost_sheet_set_charges_from_parameter` |
| arinox_cost_sheet_api_sign_off | `arinox_cost_sheet_sign_off` |
| arinox_cut_plan_api_approve | `arinox_cut_plan_approve` |
| arinox_cut_plan_api_release | `arinox_cut_plan_release` |
| arinox_cut_plan_api_reopen | `arinox_cut_plan_reopen` |
| arinox_cut_plan_api_suggest_rolls | `arinox_cut_plan_suggest_rolls` |
| arinox_cutting_api_get_issuable_rolls | `arinox_cutting_get_issuable_rolls` |
| arinox_cutting_api_issue_fabric | `arinox_cutting_issue_fabric` |
| arinox_engine | `arinox_engine` |
| arinox_fabric_inspection_api_load_rolls | `arinox_fabric_inspection_load_rolls` |
| arinox_fabric_inspection_api_make_inspection | `arinox_fabric_inspection_make_inspection` |
| arinox_fabric_inspection_api_make_purchase_return | `arinox_fabric_inspection_make_purchase_return` |
| arinox_fabric_requisition_api_create_fabric_items | `arinox_fabric_requisition_create_fabric_items` |
| arinox_fabric_requisition_api_get_lines_from_sales_orders | `arinox_fabric_requisition_get_lines_from_sales_orders` |
| arinox_fabric_requisition_api_get_requisition_context | `arinox_fabric_requisition_get_requisition_context` |
| arinox_fabric_requisition_api_revise | `arinox_fabric_requisition_revise_fabric_requisition` |
| arinox_fabric_requisition_api_save | `arinox_fabric_requisition_save_fabric_requisition` |
| arinox_factory_allocation_api_get_lines_from_order | `arinox_factory_allocation_get_lines_from_order` |
| arinox_factory_allocation_api_get_planning_context | `arinox_factory_allocation_get_planning_context` |
| arinox_factory_allocation_api_save_allocation | `arinox_factory_allocation_save_allocation` |
| arinox_final_inspection_api_pick | `arinox_final_inspection_pick_cartons` |
| arinox_followup_api_log | `arinox_followup_log_follow_up` |
| arinox_freight_api_allocated_costs | `arinox_freight_allocated_costs` |
| arinox_invoicing_api_prepare | `arinox_invoicing_prepare_invoices` |
| arinox_invoicing_api_submit | `arinox_invoicing_submit_invoices` |
| arinox_ledger_api_rebuild_movements | `arinox_ledger_rebuild_movements` |
| arinox_operation_bulletin_api_activate | `arinox_operation_bulletin_activate` |
| arinox_order_tna_api_lock | `arinox_order_tna_lock_baseline` |
| arinox_order_tna_api_replan | `arinox_order_tna_replan` |
| arinox_order_tna_api_unlock | `arinox_order_tna_unlock_baseline` |
| arinox_packing_list_api_generate | `arinox_packing_list_generate_cartons` |
| arinox_planner_api_make_order_tnas | `arinox_planner_make_order_tnas` |
| arinox_pp_meeting_api_add_standard_participants | `arinox_pp_meeting_add_standard_participants` |
| arinox_pp_meeting_api_get_buyer_comments | `arinox_pp_meeting_get_buyer_comments` |
| arinox_pp_meeting_api_load_from_requisitions | `arinox_pp_meeting_load_from_requisitions` |
| arinox_price_negotiation_api_make_quotation | `arinox_price_negotiation_make_quotation` |
| arinox_production_card_api_lines | `arinox_production_card_get_card_lines` |
| arinox_production_card_api_styles | `arinox_production_card_get_order_styles` |
| arinox_production_card_api_get_production_context | `arinox_production_card_get_production_context` |
| arinox_production_card_api_get_production_status | `arinox_production_card_get_production_status` |
| arinox_production_card_api_summary | `arinox_production_card_get_summary` |
| arinox_production_card_api_revise | `arinox_production_card_revise_production_card` |
| arinox_production_card_api_save_production_card | `arinox_production_card_save_production_card` |
| arinox_purchase_order_api_make_purchase_orders | `arinox_purchase_order_make_purchase_orders` |
| arinox_rolls_api_import_roll_list | `arinox_rolls_import_roll_list` |
| arinox_sales_contract_api_apply_template | `arinox_sales_contract_apply_template` |
| arinox_sales_contract_api_make_contract | `arinox_sales_contract_make_sales_contract` |
| arinox_sales_contract_api_make_order | `arinox_sales_contract_make_sales_order` |
| arinox_sample_approval_api_get_sample_rules | `arinox_sample_approval_get_sample_rules` |
| arinox_sample_approval_api_get_sampling_milestones | `arinox_sample_approval_get_sampling_milestones` |
| arinox_sample_approval_api_load_spec | `arinox_sample_approval_load_spec_from_tech_pack` |
| arinox_sample_approval_api_load_tests | `arinox_sample_approval_load_standard_tests` |
| arinox_scripts_switch | `arinox_scripts_switch` |
| arinox_shipment_api_get_available_packing_lists | `arinox_shipment_get_available_packing_lists` |
| arinox_shipment_api_make_delivery_notes | `arinox_shipment_make_delivery_notes` |
| arinox_subcontract_challan_api_short_close | `arinox_subcontract_challan_short_close` |
| arinox_subcontract_settlement_api_make_invoices | `arinox_subcontract_settlement_make_invoices` |
| arinox_tech_pack_api_create_style_item | `arinox_tech_pack_create_style_item` |
| arinox_tech_pack_api_make_cost_sheet | `arinox_tech_pack_make_cost_sheet` |
| arinox_tech_pack_api_make_tech_pack | `arinox_tech_pack_make_tech_pack` |
| arinox_tech_pack_api_merge_measurements | `arinox_tech_pack_merge_measurements` |
| arinox_tna | `arinox_tna` |
| arinox_tna_milestone_api_get_events | `arinox_tna_milestone_get_events` |
| arinox_trim_inspection_api_make_inspection | `arinox_trim_inspection_make_inspection` |
| arinox_trim_requisition_api_create_trim_items | `arinox_trim_requisition_create_trim_items` |
| arinox_trim_requisition_api_get_lines_from_sales_orders | `arinox_trim_requisition_get_lines_from_sales_orders` |
| arinox_trim_requisition_api_revise | `arinox_trim_requisition_revise_trim_requisition` |
| arinox_trim_requisition_api_save | `arinox_trim_requisition_save_trim_requisition` |
| arinox_work_order_api_get_bulk_gate | `arinox_work_order_get_bulk_gate` |

### DocType Event (166)

| document | events | scripts |
|---|---|---|
| Buyer Claim | After Cancel, After Save, After Submit, Before Insert, Before Save, Before Submit | 6 |
| Cost Head | Before Save | 1 |
| Cost Sheet | Before Save, Before Submit | 2 |
| Costing Parameter | Before Save | 1 |
| Cut Bundle | Before Save | 1 |
| Cut Plan | Before Save | 1 |
| Daily Line Report | After Cancel, After Submit, Before Save | 3 |
| Delivery Note | After Cancel, After Submit, Before Cancel, Before Save, Before Submit | 7 |
| Fabric Inspection | After Cancel, After Submit, Before Save, Before Submit | 4 |
| Fabric Requisition | After Cancel, After Submit, Before Cancel, Before Insert, Before Save, Before Submit | 6 |
| Factory Allocation | After Save, Before Insert, Before Save | 3 |
| Final Inspection | After Cancel, After Submit, Before Insert, Before Save, Before Submit | 5 |
| Finishing Receipt | After Cancel, After Submit, Before Insert, Before Save | 4 |
| Lay Report | After Cancel, After Submit, Before Save, Before Submit | 4 |
| Letter of Credit | Before Save | 1 |
| Line Input | After Cancel, After Submit, Before Cancel, Before Save | 4 |
| Line QC Report | After Cancel, After Submit, Before Save | 3 |
| Needle Detector Log | Before Save | 1 |
| Operation Bulletin | Before Save | 1 |
| Opportunity | Before Validate | 1 |
| Order TNA | Before Save | 1 |
| PP Meeting | After Cancel, After Save (Submitted Document), After Submit, Before Save, Before Save (Submitted Document), Before Submit | 8 |
| Packing List | After Cancel, After Submit, Before Cancel, Before Insert, Before Save, Before Submit | 6 |
| Pilot Run | After Cancel, After Submit, Before Save, Before Submit | 4 |
| Price Negotiation | Before Save | 1 |
| Production Adjustment | After Cancel, After Submit, Before Save, Before Submit | 4 |
| Production Card | After Cancel, After Submit, Before Cancel, Before Insert, Before Save, Before Submit | 6 |
| Purchase Invoice | After Cancel, After Save, After Submit | 3 |
| Purchase Order | After Cancel, After Save (Submitted Document), After Submit, Before Save, Before Submit | 5 |
| Purchase Receipt | After Cancel, After Submit, Before Save, Before Submit | 4 |
| Quotation | After Submit, Before Save | 2 |
| Recut Request | After Cancel, Before Save | 2 |
| Sales Contract | After Cancel, After Submit, Before Cancel, Before Insert, Before Save, Before Submit | 6 |
| Sales Invoice | Before Save | 1 |
| Sales Order | After Cancel, After Submit, Before Save | 5 |
| Sample Approval | After Save, Before Save | 3 |
| Shipment | After Cancel, After Save, After Save (Submitted Document), Before Cancel, Before Save, Before Validate | 11 |
| Subcontract Challan | After Cancel, After Submit, Before Cancel, Before Insert, Before Save | 5 |
| Subcontract Return | After Cancel, After Submit, Before Cancel, Before Insert, Before Save | 5 |
| Subcontract Settlement | Before Insert, Before Save, Before Submit | 3 |
| Supplier Quotation | Before Validate | 1 |
| TNA Milestone | After Save, Before Delete, Before Save | 3 |
| TNA Template | Before Save | 1 |
| Tech Pack | After Cancel, After Submit, Before Save | 4 |
| Trim Inspection | After Cancel, After Submit, Before Save, Before Submit | 4 |
| Trim Requisition | After Cancel, After Submit, Before Cancel, Before Insert, Before Save, Before Submit | 6 |
| Work Order | After Save, Before Save, Before Submit | 3 |

### Scheduler Event (2)

| script | event |
|---|---|
| arinox_lc_watch |  |
| arinox_followup_daily |  |

