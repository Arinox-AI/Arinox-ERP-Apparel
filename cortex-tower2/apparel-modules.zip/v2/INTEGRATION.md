# Arinox Apparel in the KOGO ERP: integration report

**Date:** 6 November 2026
**Source:** `github.com/Arinox-AI/Arinox-ERP-Apparel`, branch `apparel-app`, head `75ef036`
(`feat(apparel): sync arinox-apparel working tree (hosted scripts, docs, doctype updates)`).
The previous pull in this workspace was head `ede334b`; 332 files and 22,189 lines arrived since,
including a much larger hosted bundle.
**Target:** KOGO ERP, `https://apps.kogo.ai:9446`, site user `apparelerp@gmail.com`,
apps installed: `frappe 16.33`, `erpnext 16.34.1`, `kogo_sso`.
**Method:** REST only. No bench, no app install, no shell on the site. Credentials are discovered
per run from the workspace connector and never stored or printed.

Result: **887 records in 17 groups, all live, 0 failures**, then verified group by group against the
site: **34 checks passed, 0 failed, 20 warnings** and every warning is one known environmental limit
described below.

---

## 1. What is now on the site

| group | file | records | live before this run | after |
|---|---|---:|---:|---:|
| module + roles | `01`, `02` | 1 + 6 | present | updated |
| DocTypes | `03_doctypes.json` | 131 | 131 | 131 (27 new tables created on the first run) |
| custom fields | `04_custom_fields.json` | 189 | 217 total on site | 218 (+1 new) |
| property setters | `05` | 7 | 7 | 7 |
| master data / seeds | `06_seeds.json` | 195 | 194 | 195 (+1 new) |
| Apparel Settings | `07` | singleton | present | rewritten with the full default set |
| print formats | `08` | 10 | 10 | 10 |
| reports | `09_reports.json` | 20 | 13 | 20 (**+7 new**) |
| number cards | `10` | 29 | 27 | 29 (+2) |
| dashboard charts | `11` | 4 | 4 | 4 |
| dashboards | `12` | 1 | 1 | 1 (`Apparel Pre-Sales`) |
| workspaces | `13` | 4 | 4 | 4 |
| workspace sidebars | `14` | 4 | 4 | 4 |
| desktop icons | `15` | 4 | 4 | 4 |
| client scripts | `16` | 30 | 30 | 30 |
| **server scripts** | `17_server_scripts.json` | **251** | **40** | **251 (+211 new)** |

Live totals after the sync: 134 doctypes under the `Arinox Apparel` module, 251 Server Scripts,
217 reports (20 of them from the bundle), 53 print formats, 23 workspaces, 36 sidebars, 40 desktop
icons, 189 bundle custom fields, 195 bundle seeds.

The 211 new server scripts are the build-out of the logic that used to be Python controllers:
production ledger and movement posting, production card rules, delivery-note ship gate, sales
contract rules, shipment checks, letter of credit, buyer claims, T&A stamps, subcontract flow,
plus 83 callable `API` endpoints behind the desk buttons.

Full record-by-record list: **[INVENTORY.md](INVENTORY.md)** (generated, 472 lines: every doctype,
field, seed, report, card, workspace, client script and server script, with live presence marks).

---

## 2. How it was loaded

```bash
python3 loader/kogo_load.py          # 17 groups, fixed order, upsert by name
python3 loader/post_fix.py           # workspace app/module, icon cache, desk page proof
python3 loader/verify_after_load.py  # group-by-group proof against the live site
python3 loader/make_inventory_md.py  # refresh INVENTORY.md
```

or all of it: `./integrate.sh` (`./integrate.sh --demo` also builds the 30-document demo order).

The loader is idempotent by design: doctypes go in two passes (a Link that points at a doctype that
does not exist yet is written as Data first, then PUT back), everything else is matched on its
natural key and updated. A run log per record is kept in `loader/state/load_log.json`; this run is
`loader/state/run_6_75ef036.log` (90.8 s, 0 failures).

Offline pre-flight on the new bundle before touching the site: `loader/validate_bundle.py` ->
`doctypes: 131 | known targets: 756 | problems: 0 | warnings: 143` (all "role X not created by the
bundle", i.e. standard ERPNext roles that already exist).

---

## 3. Verification, group by group

Run 6 Nov 2026, `loader/state/verify_final.log`: **34 passed, 0 failed, 20 warnings**.

Passed:

* all 131 doctypes exist and every table doctype answers a list query
* 189 custom fields on the 26 documents they belong to
* every seed doctype holds its full set (AQL Plan 1, Apparel Defect Code 44, Cost Head 17,
  Destination Filing Rule 1, Fabric Defect Code 28, Item Attribute 2, Material Allowance Rule 7,
  Material Purchase Terms 2, Product Type 6, Production Check Item 13, Quality Inspection Parameter 7,
  Subcontract Process 6, TNA Milestone Type 33, TNA Template 1, Trim Category 13, Trim Defect Type 12,
  Trim Sampling Plan 2)
* Apparel Settings saved with the full default set (`bundle_size=20`)
* 10 print formats, 29 number cards, 4 dashboard charts, 1 dashboard
* 4 workspaces (each filed under an installed app, so they appear in the desk rail), 4 sidebars,
  4 desktop icons
* 30 client scripts, all enabled
* all 251 server script records exist
* 2 query reports run and return rows (Fabric Overdue Lines, Trim Lines On Hold Count)
* all 23 workspaces on the site build a desk page without error

Warnings, all understood (next section):

* 166 of 251 server scripts parked as `disabled` because the site cannot execute them
* 17 script reports therefore parked
* 83 API endpoints answer 403 for the same reason

---

## 4. The one limit: this site cannot execute Server Scripts

Proved, not assumed (`loader/script_switch.py --probe`):

```
POST /api/method/arinox_engine
403 frappe.utils.safe_exec.ServerScriptNotEnabled:
    "Server Scripts are disabled. Please enable server scripts from bench configuration."
```

The flag is `server_script_enabled` in the site's bench config. It is **not** a doctype field, there
is no REST route to it, and the app's own docs say the same (`HOSTED_BUILD_GUIDE.md`,
`HANDOFF.md`: their dev bench has it on, the hosted site does not).

**Why that mattered for the load:** the guard is global and fires *before* the script body, from the
`doc_events` hook. While the 166 DocType Event scripts were enabled, every save on the 47 doctypes
that carry one was rejected. That includes Sales Order, Purchase Order, Quotation, Sales Invoice,
Purchase Receipt, Purchase Invoice, Work Order, Supplier Quotation, Opportunity, Cost Head and TNA
Template, plus the whole apparel document set. Verified before the fix:

```
POST /api/resource/Cost Head {"head_name": "ZZ PROBE COST HEAD"}
403 ServerScriptNotEnabled        <- the record is rejected, the desk cannot save
```

**What was done:** the 166 DocType Event scripts were set `disabled = 1` (records kept, bodies
intact, nothing deleted), so the desk is usable today. After the switch the identical create returns
`200` and the probe record was deleted again (`404` on read-back). The 83 `API` and 2 `Scheduler
Event` scripts are left enabled: they only fail when called, so they block nothing.

**How to turn the logic on, the day the flag is set:**

```bash
# whoever runs the bench, once:
bench --site <site> set-config server_script_enabled 1

# then here:
python3 loader/script_switch.py --probe   # expect: script execution: ENABLED
python3 loader/script_switch.py --on      # re-arms all 251
```

Do not run `--on` before the flag is on: it re-breaks saving on those 47 doctypes. `integrate.sh`
checks the flag every run and picks the right state automatically.

What is lost while the scripts are parked: the automatic production ledger movements, the ship
gates, T&A stamps, the desk buttons (83 API endpoints) and the 17 script reports. What still works:
all 131 doctypes, all masters, all forms, every client script, the 2 query reports, both dashboards
and the whole standard ERPNext transaction set.

---

## 5. Three things that look like failures and are not

* **`Apparel Settings` returns 500 on a list query.** It is a *Single* doctype, so it has no table.
  List queries against a Single always fail; reading `/api/resource/Apparel Settings/Apparel Settings`
  returns 200 with the full record. `verify_after_load.py` now skips Singles for that check.
* **`Production Summary` errors with no filters.** It is a query report with a mandatory
  `production_card` filter (`where pm.production_card = %(production_card)s`). It is waiting for a
  card, not broken. Same for anything else that reports "needs a filter".
* **`get_desktop_page` returning 500.** The method itself does `loads(page).get("name")`, so the
  parameter has to be `page=json.dumps({"name": "<workspace>"})`; a bare name or a `workspace=` kwarg
  makes Frappe throw inside `loads`. That was a bug in my own check, fixed in `post_fix.py`; all 23
  workspaces now return `ok`.

---

## 6. Files

```
v2/
  INTEGRATION.md                 this report
  INVENTORY.md                   every record on the site, generated
  integrate.sh                   reachability -> load -> desk fix -> script state -> verify -> inventory
  hosted_bundle/                 the app's own export, 17 groups (head 75ef036)
  loader/
    kogo_load.py                 the loader (gateway credentials, retries, per-record log)
    post_fix.py                  workspace app/module + icon cache + desk page proof
    script_switch.py             --probe / --on / --off [--type=...] for the 251 server scripts
    verify_after_load.py         group-by-group proof against the live site
    make_inventory_md.py         regenerates INVENTORY.md
    validate_bundle.py           offline pre-flight of the bundle
    erpnext_meta.json            field definitions of all 529 ERPNext doctypes
    state/                       run logs, load_log.json, verification logs
  demo/make_demo_book.py         30-document demo order (--dry-run / --clean), not run in this pass
  docs/                          the authors' own guides (HOSTED_BUILD_GUIDE, HANDOFF, DEPLOY, ...)
```

`demo/make_demo_book.py` was deliberately not run: it writes a fake order book into the live ERP.
It is ready (`--dry-run` resolves all links) and runs in one command when you want it.

---

## 7. Cleanup done in this pass

Removed from the workspace after the load, because every one of them is either a copy of the public
repo or a superseded artefact:

* `/tmp/apparel-app`: the 171 MB clone of the repo (bundle, docs and loader kept in `v2/`)
* `v2/src/`: 3.9 MB of the app's Python source and vendored ERPNext, superseded by `hosted_bundle/`
  (the source is public and can be re-cloned in seconds)
* `v2/loader/official_api_load.py`: the authors' loader, replaced by `kogo_load.py`
* `v2/loader/__pycache__`, `v2/**/__pycache__`, `v2/loader/state/__pycache__`
* the old byte-for-byte copy of the `ede334b` bundle used as a rollback point
* `apparel-modules/ingested.json` + `INGESTED-INVENTORY.md` (5 Nov v1 inventory of a bundle that no
  longer exists), and the 15 one-off `skill/scripts/port_*.py` scripts from the v1 port, whose job
  the loader now does
* the 5 Nov v1 `PORT-REPORT.md`, replaced by this report

Kept on purpose: `hosted_bundle/`, `loader/`, `demo/`, `docs/`, `skill/scripts/portlib.py` (the
credential helper the loader imports), and everything under `artifacts/` (other projects).
