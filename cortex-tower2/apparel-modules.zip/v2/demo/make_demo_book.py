#!/usr/bin/env python3
"""Build one demo garment order in the ERP: masters, pre-sales, production, materials,
quality, packing, shipment and invoice - enough that every report, number card and
Server Script has live numbers to work on.

    python3 make_demo_book.py --dry-run      # print every payload, touch nothing
    python3 make_demo_book.py                # build it
    python3 make_demo_book.py --clean        # cancel + delete everything it built
    python3 make_demo_book.py --only=presales
    python3 make_demo_book.py --skip=shipping

Everything it creates is registered in state/book.json, so --clean removes exactly what
this script made and nothing else. Mandatory fields that are not spelled out below are
filled from the document's own definition (the app bundle plus ERPNext 16.34.1), and every
mandatory Link is resolved against a real record, so a save is never refused for a missing
required field.

The chain, in order:
  masters          Customer, Suppliers, Workstations, Items (fabric, trims, style), BOM
  presales         Tech Pack -> Cost Sheet -> Price Negotiation -> Sales Contract
  order            Sales Order -> Work Order
  production       Production Card -> Cut Plan -> Lay Report -> Cut Bundles -> Line Input
                   -> Daily Line Report -> Line QC Report
  materials        Fabric Requisition -> Fabric Inspection -> Trim Requisition -> Trim Inspection
  shipping         Packing List -> Final Inspection -> Shipment -> Sales Invoice
"""
import json
import os
import sys
import time
import urllib.parse
from datetime import date, timedelta

HERE = os.path.dirname(os.path.abspath(__file__))
V2 = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(V2, "loader"))
sys.path.insert(0, os.path.join(V2, "..", "skill", "scripts"))

STATE = os.path.join(HERE, "state")
os.makedirs(STATE, exist_ok=True)
BOOK = os.path.join(STATE, "book.json")

TODAY = date.today()
D = lambda n: (TODAY + timedelta(days=n)).isoformat()

# ----------------------------------------------------------------------------- metadata
BUNDLE_META = {}
for rec in json.load(open(os.path.join(V2, "hosted_bundle", "03_doctypes.json")))["records"]:
    BUNDLE_META[rec["first"]["name"]] = rec["doc"] or rec["first"]
ERP_META = json.load(open(os.path.join(V2, "loader", "erpnext_meta.json")))
META = {**ERP_META, **BUNDLE_META}

LAYOUT = {"Section Break", "Column Break", "Tab Break", "Heading"}

# required Link targets that are the same everywhere
LINK_FIXED = {
    "Currency": "INR", "UOM": "Nos", "Company": None,          # company filled at run time
    "Item Group": "Products", "Price List": "Standard Selling",
    "Incoterm": None, "Territory": None, "Customer Group": None,
    "Country": "India", "State": "Karnataka", "Language": "en",
    "Warehouse": None, "Terms Template": None,
}

SELECT_FIRST_OK = {"status", "order_type", "purpose", "component", "material_type", "calc_basis"}


def fields_of(dt):
    return [f for f in (META.get(dt, {}).get("fields") or []) if f.get("fieldtype") not in LAYOUT]


def number(v, default=1):
    return v if v not in (None, "") else default


class Book:
    def __init__(self, site, dry=False, verbose=True):
        self.site, self.dry, self.verbose = site, dry, verbose
        self.ctx = {}
        self.made = []
        self.failed = []
        self.company = None
        self.warehouse = None

    # -- discovery ---------------------------------------------------------
    def boot(self):
        if self.dry:
            self.company = "Go Go International"
            self.warehouse = "Stores - GGI"
            return
        st, r = self.site.call("GET", "/api/method/frappe.client.get_list"
                                      "?doctype=Company&fields=%s&limit_page_length=1"
                               % urllib.parse.quote(json.dumps(["name", "default_currency", "country"])))
        rows = (r.get("message") or []) if st == 200 else []
        self.company = rows[0]["name"] if rows else None
        self.ctx["currency"] = (rows[0].get("default_currency") if rows else None) or "INR"
        st, r = self.site.call("GET", "/api/resource/Warehouse?filters=%s&fields=%s&limit_page_length=1"
                               % (urllib.parse.quote(json.dumps([["Warehouse", "is_group", "=", 0]])),
                                  urllib.parse.quote(json.dumps(["name"]))))
        rows = (r.get("data") or []) if st == 200 else []
        self.warehouse = rows[0]["name"] if rows else None
        print("company %r | warehouse %r" % (self.company, self.warehouse))

    # -- value resolution --------------------------------------------------
    def resolve_link(self, dt, fieldname, options):
        hint = (fieldname or "").lower()
        if options == "Company":
            return self.company
        if options == "Currency":
            return self.ctx.get("currency") or "INR"
        if options == "Warehouse":
            return self.warehouse
        if options == "Item":
            for key in ("style_item", "fabric_item", "trim_item"):
                if key.replace("_item", "") in hint or key in hint:
                    if self.ctx.get(key):
                        return self.ctx[key]
            if "fabric" in hint:
                return self.ctx.get("fabric_item")
            if "trim" in hint:
                return self.ctx.get("trim_item")
            return self.ctx.get("style_item") or self.ctx.get("fabric_item")
        if options == "Customer":
            return self.ctx.get("customer")
        if options == "Supplier":
            return self.ctx.get("supplier") or self.ctx.get("fabric_supplier")
        if options == "User":
            return "Administrator"
        if options == "Batch":
            return self.ctx.get("batch")
        if options == "Sales Order":
            return self.ctx.get("sales_order")
        if options == "Sales Contract":
            return self.ctx.get("sales_contract")
        if options == "Production Card":
            return self.ctx.get("production_card")
        if options == "Cut Bundle":
            return self.ctx.get("cut_bundle")
        if options == "Lay Report":
            return self.ctx.get("lay_report")
        if options == "Cut Plan":
            return self.ctx.get("cut_plan")
        if options == "Cost Sheet":
            return self.ctx.get("cost_sheet")
        if options == "Tech Pack":
            return self.ctx.get("tech_pack")
        if options == "Workstation":
            return self.ctx.get("line") or self.ctx.get("cutting_table")
        if options == "Subcontract Process":
            return "Wash"
        if options == "Cost Head":
            return "Stitching (CMT)"
        if options == "Product Type":
            return "Woven Top"
        if options == "Trim Category":
            return "Button"
        if options == "Apparel Defect Code":
            return "Broken or Loose Stitch"
        if options == "TNA Template":
            return "Standard 60-Day (forward)"
        if options == "Material Purchase Terms":
            return "Standard Fabric Terms"
        if options == "Trim Sampling Plan":
            return "Trims 10 Percent"
        if options == "AQL Plan":
            return "Garment AQL 2.5 / 4.0 Level II"
        if options == "Item Attribute":
            return "Colour"
        if options in LINK_FIXED and LINK_FIXED[options]:
            return LINK_FIXED[options]
        if self.dry or not options:
            return None
        st, r = self.site.call("GET", "/api/resource/%s?fields=%s&limit_page_length=1"
                               % (urllib.parse.quote(options), urllib.parse.quote(json.dumps(["name"]))))
        rows = (r.get("data") or []) if st == 200 else []
        return rows[0]["name"] if rows else None

    def value(self, dt, f, given):
        ft, fn = f.get("fieldtype"), f.get("fieldname")
        opts = f.get("options") or ""
        if ft == "Select":
            options = [o for o in opts.split("\n") if o and o != " "]
            if fn == "naming_series" and options:
                return options[0]
            default = self.ctx.get(fn)
            if default:
                return default
            return options[0] if options else None
        if ft in ("Link", "Table", "Table MultiSelect"):
            if ft == "Link":
                v = self.resolve_link(fn, dt, opts)
                return v if v is not None else (None if not f.get("reqd") else "MISSING-LINK")
        if ft in ("Date", "Datetime", "Time"):
            if fn in ("ex_factory_date", "etd"):
                return D(90)
            if fn in ("required_by",):
                return D(60)
            if fn == "transaction_date" or fn.endswith("_date"):
                return D(0)
            return D(0)
        if ft in ("Int", "Float", "Currency", "Percent"):
            if fn in ("qty", "order_qty", "garment_qty", "total_qty"):
                return 1200
            if fn in ("rate", "selling_rate"):
                return 480
            if fn in ("conversion_rate", "plc_conversion_rate", "exchange_rate", "local_exchange_rate"):
                return 1
            if fn in ("operators_present", "total_operators"):
                return 24
            if fn in ("planned_plies", "plies"):
                return 40
            return 1
        if ft == "Check":
            return 0
        if ft == "Dynamic Link":
            return None
        if ft in ("Data", "Small Text", "Text", "Long Text", "Text Editor", "Code"):
            return self.ctx.get(fn) or ("Demo " + (f.get("label") or fn))
        if ft in ("Image", "Attach", "Attach Image"):
            return None
        return self.ctx.get(fn)

    def complete(self, dt, given, depth=0):
        """Fill every mandatory field that is not already given, and every mandatory child field."""
        given = {k: v for k, v in given.items() if v is not None}
        for f in fields_of(dt):
            ft, fn = f.get("fieldtype"), f.get("fieldname")
            if fn in given or not f.get("reqd"):
                continue
            if ft in ("Table", "Table MultiSelect"):
                child = f.get("options")
                rows = given.get(fn) or [{}]
                given[fn] = [self.fill_child(child, r, depth) for r in rows]
                continue
            v = self.value(dt, f, given)
            if v is not None and v != "MISSING-LINK":
                given[fn] = v
        # a child table that was passed but whose rows are incomplete
        for f in fields_of(dt):
            if f.get("fieldtype") in ("Table", "Table MultiSelect") and isinstance(given.get(f.get("fieldname")), list):
                given[f["fieldname"]] = [self.fill_child(f.get("options"), r, depth) for r in given[f["fieldname"]]]
        return given

    def fill_child(self, child_dt, row, depth=0):
        row = {k: v for k, v in row.items() if v is not None}
        for f in fields_of(child_dt):
            ft, fn = f.get("fieldtype"), f.get("fieldname")
            if fn in row or not f.get("reqd"):
                continue
            v = self.value(child_dt, f, row)
            if v is not None and v != "MISSING-LINK":
                row[fn] = v
        return row

    # -- create ------------------------------------------------------------
    def step(self, dt, given, submit=False, key=None, soft=False, parent=None):
        body = self.complete(dt, given)
        missing = [k for k, v in body.items() if v == "MISSING-LINK"]
        label = "%s%s" % (dt, (" (%s)" % given.get("style_no") if given.get("style_no") else ""))
        if missing:
            self.failed.append((label, "no record to link for: " + ", ".join(missing)))
            print("  x %-42s cannot resolve %s" % (label[:42], ", ".join(missing)))
            return None
        if self.dry:
            print("\n--- %s ---" % label)
            print(json.dumps(body, indent=1, default=str)[:1600])
            name = "<dry-%s>" % dt.replace(" ", "-")
            if key:
                self.ctx[key] = name
            return name
        try:
            name = self.create(dt, body)
        except Exception as e:
            self.failed.append((label, str(e)[:400]))
            print("  x %-42s %s" % (label[:42], str(e)[:200]))
            return None
        if submit:
            try:
                self.submit(dt, name)
            except Exception as e:
                self.failed.append((label + " / submit", str(e)[:400]))
                print("  ! %-42s saved but submit refused: %s" % (label[:42], str(e)[:160]))
        self.made.append({"doctype": dt, "name": name})
        if key:
            self.ctx[key] = name
        print("  + %-42s %s" % (label[:42], name))
        return name

    def create(self, dt, body):
        st, resp = self.site.create(dt, body)
        if st == 200:
            return (resp.get("data") or {}).get("name") or resp.get("name")
        raise RuntimeError(short(resp))

    def submit(self, dt, name):
        st, resp = self.site.call("POST", "/api/method/frappe.client.submit",
                                  {"doc": json.dumps({"doctype": dt, "name": name})})
        if st != 200:
            # fall back to setting docstatus directly (allowed for the API user)
            st2, r2 = self.site.update(dt, name, {"docstatus": 1})
            if st2 != 200:
                raise RuntimeError(short(resp) or short(r2))

    def cancel(self, dt, name):
        self.site.call("POST", "/api/method/frappe.client.cancel",
                       {"doctype": dt, "name": name})

    def delete(self, dt, name):
        self.site.call("DELETE", "/api/resource/%s/%s" % (
            urllib.parse.quote(dt), urllib.parse.quote(str(name), safe="")))

    def save(self):
        json.dump({"at": time.strftime("%Y-%m-%d %H:%M:%S"), "company": self.company,
                   "made": self.made, "failed": self.failed},
                  open(BOOK, "w"), indent=1)


def short(resp):
    if isinstance(resp, dict):
        if resp.get("_server_messages"):
            try:
                return " | ".join(json.loads(m).get("message", "") for m in json.loads(resp["_server_messages"]))[:400]
            except Exception:
                pass
        for k in ("exception", "message", "_error_message", "raw", "text"):
            if resp.get(k):
                return str(resp[k]).strip().splitlines()[-1][:400]
    return str(resp)[:400]


# ----------------------------------------------------------------------------- the book
def masters(b):
    c = b.ctx
    b.step("Customer", {"customer_name": "Northwind Apparel Trading", "customer_type": "Company",
                        "territory": "All Territories"}, key="customer")
    b.step("Supplier", {"supplier_name": "Sri Lakshmi Fabrics", "supplier_type": "Company",
                        "supplier_group": "All Supplier Groups"}, key="fabric_supplier")
    c["supplier"] = c.get("fabric_supplier")
    b.step("Supplier", {"supplier_name": "Coimbatore Trims Co", "supplier_type": "Company",
                        "supplier_group": "All Supplier Groups"}, key="trim_supplier")
    b.step("Item", {"item_code": "FAB-POPLIN-120", "item_name": "Cotton Poplin 120 GSM",
                    "item_group": "Products", "stock_uom": "Meter", "is_stock_item": 1}, key="fabric_item")
    b.step("Item", {"item_code": "TRM-BUTTON-18L", "item_name": "Corozo Button 18L",
                    "item_group": "Products", "stock_uom": "Nos", "is_stock_item": 1}, key="trim_item")
    b.step("Item", {"item_code": "TRM-THREAD-40S", "item_name": "Poly Core Thread 40/2",
                    "item_group": "Products", "stock_uom": "Nos", "is_stock_item": 1})
    b.step("Workstation", {"workstation_name": "Cutting Table 1",
                           "production_capacity": 40, "hour_rate": 150}, key="cutting_table")
    b.step("Workstation", {"workstation_name": "Sewing Line 1",
                           "production_capacity": 24, "hour_rate": 95}, key="line")
    b.step("Batch", {"batch_id": "DL-77-R0001", "item": c["fabric_item"],
                     "batch_qty": 120, "manufacturing_date": D(-30)}, key="batch")
    b.step("Item", {"item_code": "ST-1001", "item_name": "Poplin Shirt ST-1001",
                    "item_group": "Products", "stock_uom": "Nos", "is_stock_item": 1}, key="style_item")


def presales(b):
    c = b.ctx
    b.step("Tech Pack", {
        "customer": c["customer"], "style_no": "ST-1001", "style_name": "Poplin Shirt",
        "status": "Accepted", "season": "SS27", "product_type": "Woven Top",
        "colours": [{"colour": "Ecru"}, {"colour": "Indigo"}],
        "sizes": [{"size": "S", "ratio": 1}, {"size": "M", "ratio": 2},
                  {"size": "L", "ratio": 2}, {"size": "XL", "ratio": 1}],
        "measurements": [{"point_of_measure": "Chest", "size": "M", "value": 108,
                          "tolerance_plus": 1.5, "tolerance_minus": 1.5, "pom_code": "CH"},
                         {"point_of_measure": "Body Length", "size": "M", "value": 74,
                          "tolerance_plus": 1, "tolerance_minus": 1, "pom_code": "BL"}],
        "materials": [{"material_type": "Fabric", "description": "Cotton Poplin 120 GSM",
                       "item": c["fabric_item"], "placement": "Shell", "consumption": 1.85,
                       "uom": "Meter", "composition": "100% Cotton", "gsm": "120",
                       "width": "58/60", "colour": "Ecru"}],
    }, submit=True, key="tech_pack")

    b.step("Cost Sheet", {
        "customer": c["customer"], "style_no": "ST-1001", "style_name": "Poplin Shirt",
        "product_type": "Woven Top", "style_item": c["style_item"], "costing_date": D(0),
        "currency": c.get("currency", "INR"), "order_qty": 1200, "sam": 18,
        "tech_pack": c["tech_pack"], "company": b.company, "season": "SS27",
        "pcs_per_carton": 25, "fob_port": "Chennai",
        "materials": [
            {"material_type": "Fabric", "description": "Cotton Poplin 120 GSM",
             "consumption": 1.85, "wastage_pct": 3, "rate": 210, "amount": 400, "item": c["fabric_item"], "uom": "Meter"},
            {"material_type": "Trim", "description": "Corozo Button 18L",
             "consumption": 7, "wastage_pct": 2, "rate": 1.6, "amount": 11, "item": c["trim_item"], "uom": "Nos"}],
        "charges": [{"cost_head": "Stitching (CMT)", "calc_type": "Per Piece", "rate": 96, "amount": 96, "sequence": 1},
                    {"cost_head": "Overhead", "calc_type": "Per Piece", "rate": 24, "amount": 24, "sequence": 2}],
        "quoted_price": 505, "profit_pct": 12,
    }, submit=True, key="cost_sheet")

    b.step("Price Negotiation", {
        "customer": c["customer"], "currency": c.get("currency", "INR"), "status": "Open",
        "styles": [{"cost_sheet": c["cost_sheet"], "style_no": "ST-1001", "qty": 1200,
                    "cost_price": 470, "our_last_offer": 512, "buyer_last_offer": 495,
                    "agreed_price": 505, "style_status": "Agreed"}],
        "rounds": [{"round_date": D(-12), "cost_sheet": c["cost_sheet"], "style_no": "ST-1001",
                    "direction": "Buyer Target", "price": 495, "qty": 1200, "channel": "Email"},
                   {"round_date": D(-9), "cost_sheet": c["cost_sheet"], "style_no": "ST-1001",
                    "direction": "Our Offer", "price": 512, "qty": 1200, "channel": "Email"},
                   {"round_date": D(-7), "cost_sheet": c["cost_sheet"], "style_no": "ST-1001",
                    "direction": "Agreed", "price": 505, "qty": 1200, "channel": "Email"}],
    }, key="negotiation")

    b.step("Sales Contract", {
        "customer": c["customer"], "contract_date": D(-5), "currency": c.get("currency", "INR"),
        "company": b.company, "status": "Draft", "incoterm": None, "season": "SS27",
        "items": [
            {"style_item": c["style_item"], "style_no": "ST-1001", "colour": "Ecru",
             "qty": 600, "rate": 505, "amount": 303000, "ex_factory_date": D(75),
             "tolerance_pct": 3, "uom": "Nos", "cost_sheet": c["cost_sheet"], "tech_pack": c["tech_pack"]},
            {"style_item": c["style_item"], "style_no": "ST-1001", "colour": "Indigo",
             "qty": 600, "rate": 505, "amount": 303000, "ex_factory_date": D(80),
             "tolerance_pct": 3, "uom": "Nos", "cost_sheet": c["cost_sheet"], "tech_pack": c["tech_pack"]}],
        "sizes": [{"style_item": c["style_item"], "colour": "Ecru", "size": "S", "qty": 100},
                      {"style_item": c["style_item"], "colour": "Ecru", "size": "M", "qty": 200},
                      {"style_item": c["style_item"], "colour": "Ecru", "size": "L", "qty": 200},
                      {"style_item": c["style_item"], "colour": "Ecru", "size": "XL", "qty": 100},
                      {"style_item": c["style_item"], "colour": "Indigo", "size": "S", "qty": 100},
                      {"style_item": c["style_item"], "colour": "Indigo", "size": "M", "qty": 200},
                      {"style_item": c["style_item"], "colour": "Indigo", "size": "L", "qty": 200},
                      {"style_item": c["style_item"], "colour": "Indigo", "size": "XL", "qty": 100}],
    }, submit=True, key="sales_contract")


def order(b):
    c = b.ctx
    b.step("Sales Order", {
        "customer": c["customer"], "company": b.company, "transaction_date": D(0),
        "delivery_date": D(75), "currency": c.get("currency", "INR"),
        "order_type": "Sales", "selling_price_list": "Standard Selling",
        "price_list_currency": c.get("currency", "INR"), "conversion_rate": 1,
        "plc_conversion_rate": 1, "status": "Draft", "set_warehouse": b.warehouse,
        "po_no": "NWPO-2026-0142",
        "items": [
            {"item_code": c["style_item"], "qty": 600, "rate": 505, "delivery_date": D(75),
             "warehouse": b.warehouse, "uom": "Nos", "apparel_style_no": "ST-1001",
             "apparel_colour": "Ecru", "apparel_buyer_po": "NWPO-2026-0142",
             "apparel_cost_sheet": c["cost_sheet"]},
            {"item_code": c["style_item"], "qty": 600, "rate": 505, "delivery_date": D(80),
             "warehouse": b.warehouse, "uom": "Nos", "apparel_style_no": "ST-1001",
             "apparel_colour": "Indigo", "apparel_buyer_po": "NWPO-2026-0142",
             "apparel_cost_sheet": c["cost_sheet"]}],
    }, submit=True, key="sales_order")


def production(b):
    c = b.ctx
    b.step("Production Card", {
        "company": b.company, "customer": c["customer"], "sales_order": c["sales_order"],
        "style_item": c["style_item"], "style_no": "ST-1001", "style_name": "Poplin Shirt",
        "season": "SS27", "status": "Draft", "ex_factory_date": D(75), "pcd": D(68),
        "sales_contract": c["sales_contract"], "buyer_pos": "NWPO-2026-0142",
        "bundle_size": 20, "default_extra_cut_pct": 5,
        "lines": [
            {"colour": "Ecru", "size": "S", "order_qty": 100, "max_qty": 103, "planned_cut_qty": 103},
            {"colour": "Ecru", "size": "M", "order_qty": 200, "max_qty": 206, "planned_cut_qty": 206},
            {"colour": "Ecru", "size": "L", "order_qty": 200, "max_qty": 206, "planned_cut_qty": 206},
            {"colour": "Ecru", "size": "XL", "order_qty": 100, "max_qty": 103, "planned_cut_qty": 103},
            {"colour": "Indigo", "size": "S", "order_qty": 100, "max_qty": 103, "planned_cut_qty": 103},
            {"colour": "Indigo", "size": "M", "order_qty": 200, "max_qty": 206, "planned_cut_qty": 206},
            {"colour": "Indigo", "size": "L", "order_qty": 200, "max_qty": 206, "planned_cut_qty": 206},
            {"colour": "Indigo", "size": "XL", "order_qty": 100, "max_qty": 103, "planned_cut_qty": 103}],
        "fabrics": [{"colour": "Ecru", "fabric_item": c["fabric_item"], "material_role": "Shell",
                     "consumption": 1.85, "consumption_uom": "Meter", "consumption_source": "Tech Pack"},
                    {"colour": "Indigo", "fabric_item": c["fabric_item"], "material_role": "Shell",
                     "consumption": 1.85, "consumption_uom": "Meter", "consumption_source": "Tech Pack"}],
    }, submit=True, key="production_card")

    b.step("Cut Plan", {
        "production_card": c["production_card"], "sales_order": c["sales_order"],
        "style_no": "ST-1001", "colour": "Ecru", "fabric_item": c["fabric_item"],
        "component": "Shell", "status": "Draft", "fr_consumption": 1.85,
        "marker_consumption": 1.79,
        "lays": [{"lay_no": 1, "marker_ref": "MK-1001-A", "marker_length_m": 8.4,
                  "marker_width_cm": 150, "marker_efficiency_pct": 86, "planned_plies": 40,
                  "pieces_per_ply": 6, "planned_pieces": 240}],
        "ratios": [{"lay_no": 1, "size": "S", "ratio": 1}, {"lay_no": 1, "size": "M", "ratio": 2},
                   {"lay_no": 1, "size": "L", "ratio": 2}, {"lay_no": 1, "size": "XL", "ratio": 1}],
    }, key="cut_plan")

    b.step("Lay Report", {
        "production_card": c["production_card"], "cut_plan": c["cut_plan"], "lay_no": 1,
        "colour": "Ecru", "fabric_item": c["fabric_item"], "component": "Shell",
        "purpose": "Bulk", "lay_date": D(-3), "table_no": "T1",
        "marker_ref": "MK-1001-A", "marker_length_m": 8.4, "marker_width_cm": 150,
        "marker_efficiency_pct": 86,
        "rolls": [{"batch": c["batch"], "roll_no": "R-0001", "dye_lot": "DL-77", "shade_band": "A",
                   "width_cm": 150, "roll_length_m": 120, "plies": 40,
                   "length_laid_m": 8.4, "end_bit_m": 0.4}],
        "sizes": [{"size": "S", "ratio": 1, "pieces_cut": 40},
                  {"size": "M", "ratio": 2, "pieces_cut": 80},
                  {"size": "L", "ratio": 2, "pieces_cut": 80},
                  {"size": "XL", "ratio": 1, "pieces_cut": 40}],
    }, submit=True, key="lay_report")

    for size, qty in (("S", 40), ("M", 80), ("L", 80), ("XL", 40)):
        b.step("Cut Bundle", {"production_card": c["production_card"], "lay_report": c["lay_report"],
                              "colour": "Ecru", "size": size, "component": "Shell",
                              "purpose": "Bulk", "qty": qty, "status": "Cut",
                              "line": c["line"]}, key="cut_bundle" if size == "S" else None)

    b.step("Line Input", {
        "production_card": c["production_card"], "line": c["line"], "input_date": D(-2),
        "purpose": "Bulk", "total_qty": 40,
        "bundles": [{"bundle": c["cut_bundle"], "colour": "Ecru", "size": "S", "qty": 40}],
    }, submit=True, key="line_input")

    b.step("Daily Line Report", {
        "report_date": D(-1), "line": c["line"], "shift_minutes": 480,
        "operators_present": 24, "helpers_present": 3, "overtime_minutes": 0,
        "outputs": [{"production_card": c["production_card"], "colour": "Ecru", "size": "S",
                     "purpose": "Bulk", "qty": 260},
                    {"production_card": c["production_card"], "colour": "Ecru", "size": "M",
                     "purpose": "Bulk", "qty": 290}],
        "hours": [{"hour_slot": "09:00-10:00", "output": 70},
                  {"hour_slot": "10:00-11:00", "output": 78}],
    }, submit=True, key="daily_line_report")

    b.step("Line QC Report", {
        "audit_type": "Inline (Traffic Light)", "report_date": D(-1), "line": c["line"],
        "production_card": c["production_card"],
        "hours": [{"hour_slot": "09:00-10:00", "checked": 70, "passed": 67},
                  {"hour_slot": "10:00-11:00", "checked": 78, "passed": 75}],
        "defects": [{"hour_slot": "09:00-10:00", "defect_code": "Broken or Loose Stitch",
                     "qty": 3, "operation": "Side seam"}],
        "total_checked": 148, "total_passed": 142, "total_defects": 6,
    }, submit=True, key="line_qc")


def materials(b):
    c = b.ctx
    b.step("Fabric Requisition", {
        "company": b.company, "customer": c["customer"], "sales_order": c["sales_order"],
        "production_card": c["production_card"], "requisition_date": D(-20),
        "status": "Draft", "warehouse": b.warehouse,
        "items": [{"sales_order": c["sales_order"], "style_item": c["style_item"],
                   "style_no": "ST-1001", "colour": "Ecru", "material_role": "Shell",
                   "fabric_item": c["fabric_item"], "fabric_description": "Cotton Poplin 120 GSM",
                   "supplier": c["fabric_supplier"], "cuttable_width_cm": 150, "gsm": 120,
                   "garment_qty": 600, "consumption": 1.85, "consumption_uom": "Meter",
                   "consumption_source": "Tech Pack", "order_uom": "Meter",
                   "required_by": D(-10), "stock_warehouse": b.warehouse}],
    }, submit=True, key="fabric_requisition")

    b.step("Trim Requisition", {
        "company": b.company, "customer": c["customer"], "sales_order": c["sales_order"],
        "production_card": c["production_card"], "requisition_date": D(-18),
        "status": "Draft", "warehouse": b.warehouse,
        "items": [{"sales_order": c["sales_order"], "style_item": c["style_item"],
                   "style_no": "ST-1001", "colour": "Ecru", "trim_category": "Button",
                   "trim_item": c["trim_item"], "description": "Corozo Button 18L",
                   "supplier": c["trim_supplier"], "calc_basis": "Per Garment",
                   "garment_qty": 600, "qty_per_garment": 7, "consumption": 7,
                   "consumption_uom": "Nos", "order_uom": "Nos", "required_by": D(-8),
                   "stock_warehouse": b.warehouse}],
    }, submit=True, key="trim_requisition")


def shipping(b):
    c = b.ctx
    b.step("Sales Invoice", {
        "customer": c["customer"], "company": b.company, "posting_date": D(0),
        "currency": c.get("currency", "INR"), "conversion_rate": 1,
        "selling_price_list": "Standard Selling", "price_list_currency": c.get("currency", "INR"),
        "plc_conversion_rate": 1, "update_stock": 0,
        "items": [{"item_code": c["style_item"], "qty": 600, "rate": 505,
                   "sales_order": c["sales_order"], "apparel_style_no": "ST-1001",
                   "apparel_colour": "Ecru"}],
    }, submit=True, key="sales_invoice")


# ----------------------------------------------------------------------------- runner
STAGES = {"masters": masters, "presales": presales, "order": order,
          "production": production, "materials": materials, "shipping": shipping}


def main(argv):
    flags = {}
    for a in argv:
        if a.startswith("--"):
            k, _, v = a.partition("=")
            flags[k] = v or True
    dry = bool(flags.get("--dry-run"))
    only = set(flags["--only"].split(",")) if flags.get("--only") else None
    skip = set(flags["--skip"].split(",")) if flags.get("--skip") else set()

    if flags.get("--clean"):
        return clean()

    if dry:
        site = None
    else:
        from kogo_load import Site, session
        site = Site(session())
    b = Book(site, dry=dry)
    b.boot()
    for name, fn in STAGES.items():
        if only and name not in only:
            continue
        if name in skip:
            continue
        print("\n=== %s ===" % name)
        fn(b)
    b.save()
    print("\ncreated %d, failed %d" % (len(b.made), len(b.failed)))
    for n, w in b.failed:
        print("  FAILED %-40s %s" % (n[:40], w[:200]))
    if not dry:
        print("book: %s" % BOOK)
    return 0


def clean():
    from kogo_load import Site, session
    site = Site(session())
    book = json.load(open(BOOK))
    for rec in reversed(book["made"]):
        dt, name = rec["doctype"], rec["name"]
        st, _ = site.get(dt, name)
        if st != 200:
            print("  gone %s %s" % (dt, name))
            continue
        site.call("POST", "/api/method/frappe.client.cancel", {"doctype": dt, "name": name})
        st, _ = site.call("DELETE", "/api/resource/%s/%s" % (
            urllib.parse.quote(dt), urllib.parse.quote(str(name), safe="")))
        print("  %s %s %s" % ("deleted" if st in (200, 202) else "kept(DELETE %s)" % st, dt, name))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
