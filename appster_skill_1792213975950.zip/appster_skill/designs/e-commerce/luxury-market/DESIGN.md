---
version: alpha
name: Luxury Market
description: Luxury Market is a premium dark e-commerce theme anchored by deep navy ({colors.background}) and gold as the primary accent ({colors.primary}). The design communicates exclusivity through generous whitespace, restrained typography (Cormorant Garamond for headings, Inter for body), muted gold tones, and subtle texture. Product presentation is gallery-style. CTAs use gold outlines rather than solid fills. Designed for luxury goods, premium marketplace, jewelry, watches, exclusive memberships.

colors:
  primary: "#c9a84c"
  primary-hover: "#b8943e"
  primary-light: "#1f1a0a"
  on-primary: "#0a0a14"
  background: "#0a0a14"
  surface: "#10101e"
  surface-raised: "#161626"
  border: "#1e1e32"
  border-gold: "#c9a84c"
  border-soft: "#161626"
  text: "#e8e4d8"
  text-muted: "#7a7660"
  text-gold: "#c9a84c"
  text-on-light: "#0a0a14"
  divider: "#1e1e2a"
  accent-cream: "#f5f0e0"
  accent-silver: "#a8a8b4"
  semantic-success: "#4a9e6b"
  semantic-error: "#c94040"

typography:
  display:
    fontFamily: Cormorant Garamond
    fontSize: 72px
    fontWeight: 300
    lineHeight: 1.05
    letterSpacing: -1px
  heading-1:
    fontFamily: Cormorant Garamond
    fontSize: 52px
    fontWeight: 400
    lineHeight: 1.1
    letterSpacing: -0.5px
  heading-2:
    fontFamily: Cormorant Garamond
    fontSize: 38px
    fontWeight: 400
    lineHeight: 1.15
  heading-3:
    fontFamily: Cormorant Garamond
    fontSize: 28px
    fontWeight: 400
    lineHeight: 1.2
  product-name:
    fontFamily: Cormorant Garamond
    fontSize: 26px
    fontWeight: 400
    lineHeight: 1.25
  product-name-sm:
    fontFamily: Cormorant Garamond
    fontSize: 18px
    fontWeight: 400
    lineHeight: 1.3
  price:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: 400
    lineHeight: 1.2
    letterSpacing: 0.5px
  body:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: 300
    lineHeight: 1.8
  body-medium:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: 400
    lineHeight: 1.7
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: 400
    lineHeight: 1.6
  button:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: 500
    lineHeight: 1.2
    letterSpacing: 1.5px
  eyebrow:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: 500
    lineHeight: 1.3
    letterSpacing: 2px

rounded:
  xs: 0px
  sm: 2px
  md: 4px
  lg: 6px
  xl: 8px
  full: 9999px

spacing:
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  xxl: 48px
  xxxl: 64px
  section: 96px
  section-lg: 140px

components:
  button-primary:
    backgroundColor: "transparent"
    textColor: "{colors.primary}"
    typography: "{typography.button}"
    rounded: "{rounded.xs}"
    padding: "14px 36px"
    border: "1px solid {colors.primary}"
  button-primary-hover:
    backgroundColor: "{colors.primary}"
    textColor: "{colors.on-primary}"
  button-solid:
    backgroundColor: "{colors.primary}"
    textColor: "{colors.on-primary}"
    typography: "{typography.button}"
    rounded: "{rounded.xs}"
    padding: "14px 36px"
    border: "none"
  button-ghost:
    backgroundColor: "transparent"
    textColor: "{colors.text-muted}"
    typography: "{typography.button}"
    padding: "12px 24px"
    border: "1px solid {colors.border}"
  product-card:
    backgroundColor: "{colors.surface}"
    rounded: "{rounded.sm}"
    border: "none"
    overflow: "hidden"
  product-card-hover:
    border: "1px solid {colors.border-gold}"
  product-image-frame:
    backgroundColor: "{colors.surface-raised}"
    aspectRatio: "3/4"
    overflow: "hidden"
  price-display:
    textColor: "{colors.text-gold}"
    typography: "{typography.price}"
  product-detail-price:
    textColor: "{colors.text}"
    typography: "{typography.price}"
  eyebrow-label:
    textColor: "{colors.text-gold}"
    typography: "{typography.eyebrow}"
    padding: "0 0 12px 0"
    borderBottom: "1px solid {colors.border-gold}"
    display: "inline-block"
  divider-gold:
    border: "none"
    borderTop: "1px solid {colors.border-gold}"
    opacity: "0.4"
  divider-subtle:
    border: "none"
    borderTop: "1px solid {colors.divider}"
  input:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.text}"
    typography: "{typography.body}"
    rounded: "{rounded.xs}"
    border: "none"
    borderBottom: "1px solid {colors.border}"
    padding: "12px 0"
    height: 44px
  input-focused:
    borderBottom: "1px solid {colors.primary}"
  badge-exclusive:
    backgroundColor: "transparent"
    textColor: "{colors.primary}"
    typography: "{typography.eyebrow}"
    rounded: "{rounded.xs}"
    padding: "3px 10px"
    border: "1px solid {colors.primary}"
  badge-sold-out:
    backgroundColor: "transparent"
    textColor: "{colors.text-muted}"
    typography: "{typography.eyebrow}"
    rounded: "{rounded.xs}"
    padding: "3px 10px"
    border: "1px solid {colors.border}"
  gallery-thumbnail:
    backgroundColor: "{colors.surface-raised}"
    border: "1px solid {colors.border-soft}"
    rounded: "{rounded.xs}"
    size: 72px
  gallery-thumbnail-active:
    border: "1px solid {colors.border-gold}"
---

## Overview

Luxury Market strips the interface back to create an art-gallery digital space. Deep navy backgrounds, gold typography, no heavy fills — restraint is the statement. Cormorant Garamond at light weight (300–400) for headings communicates premium editorial. Inter at 300–400 weight for body maintains readability on dark surfaces. Buttons use the gold outline-first approach — hover fills to gold. Product cards lift to show a gold border on hover. Generous spacing (`{spacing.section}` = 96px) ensures breathing room between sections.

**Key characteristics:**
- Deep navy `#0a0a14` — richer than pure black, gemstone depth
- Gold `#c9a84c` — warm, not garish; the luxury signal
- Cormorant Garamond for all headings — editorial, fashion-magazine feel
- Outline-first buttons (border gold, transparent fill → solid gold on hover)
- 0px border radius on most elements — sharp luxury geometry
- Underline-style inputs (no box) — minimal, refined
- Eyebrow labels with gold + wide letter-spacing — brand storytelling

## Typography

**Cormorant Garamond**: Load from Google Fonts at weights 300, 400.
**Inter**: Load from Google Fonts at weights 300, 400, 500.

The mix of serif heading (Cormorant) + sans body (Inter) is deliberate — mimics luxury print design.

## Do's and Don'ts

### Do
- Use Cormorant Garamond at light weight (300–400) for all headings
- Use generous vertical spacing (`{spacing.section}` between sections)
- Use outline-first buttons (`button-primary`), not solid-fill by default
- Use `eyebrow-label` with wide letter-spacing above headings for section labeling
- Use 0px or 2px border radius — sharp geometry = luxury

### Don't
- Don't use pill-shaped or highly-rounded buttons/cards — they read as casual
- Don't use bright colors (red, blue, green) as accents — gold only
- Don't crowd elements — luxury = space = exclusivity
- Don't use bold Inter for body text — light weights only
