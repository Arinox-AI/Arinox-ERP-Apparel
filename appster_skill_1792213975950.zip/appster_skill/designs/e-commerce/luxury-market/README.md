# Luxury Market

Deep navy background with gold accent and generous white space. Exclusive, premium, aspirational.

Best used for: luxury goods, high-end retail, premium marketplace, jewelry, watches, exclusive memberships — anywhere the brand must communicate scarcity and quality.
