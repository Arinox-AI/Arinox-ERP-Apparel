# E-Commerce Themes

Shopping, marketplace, and product-catalog themes. Best for stores, product listings, checkout flows, and retail apps.

## Themes

| Theme | Description |
|---|---|
| `modern-shop` | White background with stark black accent. Clean, product-focused, conversion-optimized. Inspired by Shopify storefronts, Nike, Apple Store. |
| `luxury-market` | Deep navy background with gold accent. Premium, high-end, exclusive feel. For luxury goods, premium marketplaces, high-ticket retail. |
