---
version: alpha
name: Modern Shop
description: Modern Shop is a product-first e-commerce theme on a pure white background ({colors.background}) with black as the dominant action color ({colors.primary}). The design language strips away decoration so product imagery and pricing are the clear focal points. Typography uses DM Sans — clean, slightly geometric, readable at every size. Buttons alternate between black pill (primary CTA) and white outlined (secondary). Cards are white with subtle shadow. Inspired by Shopify storefronts, Nike, minimalist D2C brands.

colors:
  primary: "#111111"
  primary-hover: "#333333"
  on-primary: "#ffffff"
  background: "#ffffff"
  surface: "#f9f9f9"
  surface-hover: "#f2f2f2"
  border: "#e8e8e8"
  border-strong: "#d0d0d0"
  text: "#111111"
  text-secondary: "#555555"
  text-muted: "#999999"
  text-placeholder: "#bbbbbb"
  accent-sale: "#e02020"
  accent-sale-light: "#ffeaea"
  accent-new: "#0070f3"
  accent-new-light: "#e6f0ff"
  accent-sale-tag: "#d4380d"
  semantic-success: "#0a8a2c"
  semantic-success-light: "#e6f7ec"
  semantic-error: "#e02020"
  semantic-error-light: "#ffeaea"
  star-active: "#f5a623"
  star-inactive: "#e0e0e0"

typography:
  display:
    fontFamily: DM Sans
    fontSize: 56px
    fontWeight: 700
    lineHeight: 1.0
    letterSpacing: -2px
  heading-1:
    fontFamily: DM Sans
    fontSize: 40px
    fontWeight: 700
    lineHeight: 1.1
    letterSpacing: -1px
  heading-2:
    fontFamily: DM Sans
    fontSize: 30px
    fontWeight: 600
    lineHeight: 1.15
    letterSpacing: -0.5px
  heading-3:
    fontFamily: DM Sans
    fontSize: 22px
    fontWeight: 600
    lineHeight: 1.25
  product-name:
    fontFamily: DM Sans
    fontSize: 18px
    fontWeight: 500
    lineHeight: 1.3
  product-name-lg:
    fontFamily: DM Sans
    fontSize: 26px
    fontWeight: 600
    lineHeight: 1.2
  price:
    fontFamily: DM Sans
    fontSize: 22px
    fontWeight: 700
    lineHeight: 1.2
  price-sm:
    fontFamily: DM Sans
    fontSize: 16px
    fontWeight: 600
    lineHeight: 1.2
  price-original:
    fontFamily: DM Sans
    fontSize: 16px
    fontWeight: 400
    lineHeight: 1.2
  body:
    fontFamily: DM Sans
    fontSize: 15px
    fontWeight: 400
    lineHeight: 1.6
  body-sm:
    fontFamily: DM Sans
    fontSize: 13px
    fontWeight: 400
    lineHeight: 1.55
  button:
    fontFamily: DM Sans
    fontSize: 14px
    fontWeight: 600
    lineHeight: 1.2
    letterSpacing: 0.3px
  label:
    fontFamily: DM Sans
    fontSize: 11px
    fontWeight: 600
    lineHeight: 1.3
    letterSpacing: 0.8px

rounded:
  xs: 2px
  sm: 4px
  md: 6px
  lg: 8px
  xl: 12px
  full: 9999px

spacing:
  xs: 4px
  sm: 8px
  md: 12px
  lg: 16px
  xl: 20px
  xxl: 24px
  xxxl: 32px
  section: 60px
  section-lg: 96px

components:
  button-primary:
    backgroundColor: "{colors.primary}"
    textColor: "{colors.on-primary}"
    typography: "{typography.button}"
    rounded: "{rounded.full}"
    padding: "13px 28px"
    border: "none"
  button-primary-hover:
    backgroundColor: "{colors.primary-hover}"
  button-secondary:
    backgroundColor: "{colors.background}"
    textColor: "{colors.text}"
    typography: "{typography.button}"
    rounded: "{rounded.full}"
    padding: "12px 28px"
    border: "1.5px solid {colors.text}"
  button-secondary-hover:
    backgroundColor: "{colors.surface}"
  button-add-to-cart:
    backgroundColor: "{colors.primary}"
    textColor: "{colors.on-primary}"
    typography: "{typography.button}"
    rounded: "{rounded.lg}"
    padding: "14px 20px"
    border: "none"
    width: "100%"
  button-wishlist:
    backgroundColor: "transparent"
    textColor: "{colors.text-muted}"
    rounded: "{rounded.full}"
    border: "1px solid {colors.border}"
    padding: "10px"
    size: 40px
  product-card:
    backgroundColor: "{colors.background}"
    rounded: "{rounded.lg}"
    border: "none"
    overflow: "hidden"
  product-card-image:
    backgroundColor: "{colors.surface}"
    rounded: "{rounded.md}"
    aspectRatio: "1/1"
    overflow: "hidden"
  product-card-hover:
    boxShadow: "0 4px 16px rgba(0,0,0,0.10)"
  product-card-featured:
    backgroundColor: "{colors.surface}"
    rounded: "{rounded.xl}"
    overflow: "hidden"
  badge-sale:
    backgroundColor: "{colors.accent-sale}"
    textColor: "#ffffff"
    typography: "{typography.label}"
    rounded: "{rounded.xs}"
    padding: "3px 8px"
  badge-new:
    backgroundColor: "{colors.accent-new}"
    textColor: "#ffffff"
    typography: "{typography.label}"
    rounded: "{rounded.xs}"
    padding: "3px 8px"
  price-display:
    textColor: "{colors.text}"
    typography: "{typography.price}"
  price-sale:
    textColor: "{colors.accent-sale}"
    typography: "{typography.price}"
  price-original-crossed:
    textColor: "{colors.text-muted}"
    typography: "{typography.price-original}"
    textDecoration: "line-through"
  input:
    backgroundColor: "{colors.background}"
    textColor: "{colors.text}"
    typography: "{typography.body}"
    rounded: "{rounded.md}"
    border: "1px solid {colors.border-strong}"
    padding: "11px 14px"
    height: 44px
  input-focused:
    border: "1.5px solid {colors.primary}"
  quantity-selector:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.text}"
    rounded: "{rounded.md}"
    border: "1px solid {colors.border}"
    height: 44px
    minWidth: 120px
  filter-chip:
    backgroundColor: "{colors.background}"
    textColor: "{colors.text-secondary}"
    typography: "{typography.body-sm}"
    rounded: "{rounded.full}"
    border: "1px solid {colors.border}"
    padding: "6px 14px"
  filter-chip-active:
    backgroundColor: "{colors.primary}"
    textColor: "{colors.on-primary}"
    border: "1px solid {colors.primary}"
  rating-star:
    color: "{colors.star-active}"
    size: 16px
  cart-summary:
    backgroundColor: "{colors.surface}"
    rounded: "{rounded.xl}"
    border: "1px solid {colors.border}"
    padding: "{spacing.xxl}"
---

## Overview

Modern Shop puts product images first. The near-black-and-white palette ensures nothing competes with product photography. Black pill buttons (`button-primary`) are the dominant CTA — unmistakable, high contrast. Product cards are borderless on white — hover shadow lifts them. Sale badges use red; New badges use blue — standard e-commerce signaling. DM Sans is slightly geometric vs Inter, giving it a retail-brand feel while staying highly readable.

**Key characteristics:**
- Black `#111111` on white `#ffffff` — maximum contrast, product-first
- Pill-shaped primary buttons (`{rounded.full}`) — CTA emphasis
- Flat borders on product cards (shadow on hover, not static border)
- Standard sale/new badge system (red/blue)
- Price display variants: regular, sale (red), original-crossed (muted + strikethrough)
- Filter chip system for product filtering
- DM Sans — geometric feel, not plain Inter

## Colors

- **Primary** (`{colors.primary}`): Buttons, links, checkboxes — near-black
- **Accent Sale** (`{colors.accent-sale}`): Sale prices, SALE badges — red signal
- **Accent New** (`{colors.accent-new}`): New product badges — blue signal
- **Star Active** (`{colors.star-active}`): Product rating stars

## Product Components

- `product-card` + `product-card-hover`: Product listing card (no border → shadow on hover)
- `badge-sale` / `badge-new`: Corner badges on product images
- `price-display` / `price-sale` / `price-original-crossed`: Pricing variants
- `quantity-selector`: Add-to-cart quantity stepper
- `filter-chip` / `filter-chip-active`: Horizontal filter bar chips
- `button-add-to-cart`: Full-width CTA on product page

## Do's and Don'ts

### Do
- Keep product images as the largest visual element — the UI is the container
- Use black pill buttons (`{rounded.full}`) for primary CTAs consistently
- Show sale price in `{colors.accent-sale}` with original crossed-out next to it
- Use `{rounded.full}` for filter chips to match the button style

### Don't
- Don't use colorful accent colors for non-sale/non-new content
- Don't use heavy decorative backgrounds — white and light gray only
- Don't add complex shadows to product cards at rest — only on hover
