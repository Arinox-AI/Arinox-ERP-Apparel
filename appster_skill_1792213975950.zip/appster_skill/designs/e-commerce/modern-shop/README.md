# Modern Shop

Clean white background with stark black accent. Product-first, conversion-focused, no distractions.

Best used for: Shopify-style stores, product catalogs, fashion/apparel, tech gadgets — anywhere the product image is the hero and the UI should stay out of the way.
