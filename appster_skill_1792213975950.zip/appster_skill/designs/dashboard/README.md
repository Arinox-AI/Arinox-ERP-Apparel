# Dashboard Themes

Data visualization, analytics, reporting, and admin panel themes. Best for BI tools, monitoring dashboards, admin interfaces, and data-heavy apps.

## Themes

| Theme | Description |
|---|---|
| `data-pro` | Dark slate background with cyan accent. Ideal for monitoring, metrics, and real-time analytics. Inspired by PostHog, Grafana, Datadog. |
| `analytics-light` | Off-white background with blue accent. Clean, professional data interface. Inspired by Google Analytics, Mixpanel, business dashboards. |
