# Data Pro

Dark slate background with cyan accent. Built for high-density data display — charts, tables, metrics, and real-time updates all feel at home here.

Best used for: monitoring tools, analytics platforms, DevOps dashboards, BI tools, stock trackers, anything with lots of numbers and charts.
