---
version: alpha
name: Data Pro
description: Data Pro is a dark analytics dashboard theme built on a deep slate background ({colors.background}) with cyan as the primary data accent ({colors.primary}). The design handles high-density data display — charts, tables, metric cards, and real-time feeds — without visual noise. Multiple surface layers (background → surface → surface-raised → surface-overlay) create panel depth. Typography uses JetBrains Mono for metrics/numbers and Inter for labels/body. Inspired by PostHog, Grafana, Datadog.

colors:
  primary: "#06b6d4"
  primary-hover: "#0891b2"
  primary-muted: "#0e3b47"
  on-primary: "#ffffff"
  background: "#0f172a"
  surface: "#131e35"
  surface-raised: "#1a2744"
  surface-overlay: "#1e2e50"
  border: "#1e3050"
  border-bright: "#2a4060"
  text: "#e2e8f0"
  text-secondary: "#94a3b8"
  text-muted: "#475569"
  text-value: "#ffffff"
  chart-1: "#06b6d4"
  chart-2: "#8b5cf6"
  chart-3: "#f59e0b"
  chart-4: "#10b981"
  chart-5: "#f43f5e"
  chart-6: "#3b82f6"
  chart-grid: "#1e3050"
  chart-axis: "#334155"
  semantic-success: "#10b981"
  semantic-success-muted: "#022c22"
  semantic-error: "#f43f5e"
  semantic-error-muted: "#2d0011"
  semantic-warning: "#f59e0b"
  semantic-warning-muted: "#291a00"
  semantic-info: "#06b6d4"
  semantic-info-muted: "#0e3b47"
  positive: "#10b981"
  negative: "#f43f5e"
  neutral: "#64748b"

typography:
  display:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: 700
    lineHeight: 1.1
    letterSpacing: -1px
  heading-1:
    fontFamily: Inter
    fontSize: 26px
    fontWeight: 600
    lineHeight: 1.2
  heading-2:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: 600
    lineHeight: 1.3
  heading-3:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: 600
    lineHeight: 1.4
  metric-hero:
    fontFamily: JetBrains Mono
    fontSize: 44px
    fontWeight: 700
    lineHeight: 1.0
    letterSpacing: -1px
  metric-lg:
    fontFamily: JetBrains Mono
    fontSize: 32px
    fontWeight: 600
    lineHeight: 1.1
  metric-md:
    fontFamily: JetBrains Mono
    fontSize: 24px
    fontWeight: 600
    lineHeight: 1.2
  metric-sm:
    fontFamily: JetBrains Mono
    fontSize: 18px
    fontWeight: 500
    lineHeight: 1.2
  body:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: 400
    lineHeight: 1.6
  body-medium:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: 500
    lineHeight: 1.6
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: 400
    lineHeight: 1.5
  label:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: 500
    lineHeight: 1.3
    letterSpacing: 0.5px
  button:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: 500
    lineHeight: 1.2
  table-header:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: 600
    lineHeight: 1.3
    letterSpacing: 0.8px
  code:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: 400
    lineHeight: 1.7

rounded:
  xs: 3px
  sm: 5px
  md: 7px
  lg: 10px
  xl: 14px
  full: 9999px

spacing:
  xs: 4px
  sm: 6px
  md: 10px
  lg: 14px
  xl: 18px
  xxl: 24px
  xxxl: 32px
  panel: 20px

components:
  button-primary:
    backgroundColor: "{colors.primary}"
    textColor: "{colors.on-primary}"
    typography: "{typography.button}"
    rounded: "{rounded.md}"
    padding: "8px 16px"
  button-secondary:
    backgroundColor: "transparent"
    textColor: "{colors.text-secondary}"
    typography: "{typography.button}"
    rounded: "{rounded.md}"
    padding: "8px 16px"
    border: "1px solid {colors.border-bright}"
  button-icon:
    backgroundColor: "{colors.surface-raised}"
    textColor: "{colors.text-secondary}"
    rounded: "{rounded.md}"
    border: "1px solid {colors.border}"
    padding: "7px"
    size: 32px
  metric-card:
    backgroundColor: "{colors.surface}"
    rounded: "{rounded.lg}"
    border: "1px solid {colors.border}"
    padding: "{spacing.panel}"
  metric-card-highlighted:
    backgroundColor: "{colors.surface-raised}"
    rounded: "{rounded.lg}"
    border: "1px solid {colors.border-bright}"
    padding: "{spacing.panel}"
  chart-container:
    backgroundColor: "{colors.surface}"
    rounded: "{rounded.lg}"
    border: "1px solid {colors.border}"
    padding: "{spacing.panel}"
  chart-tooltip:
    backgroundColor: "{colors.surface-overlay}"
    textColor: "{colors.text}"
    rounded: "{rounded.md}"
    border: "1px solid {colors.border-bright}"
    padding: "8px 12px"
    boxShadow: "0 4px 16px rgba(0,0,0,0.4)"
  table-container:
    backgroundColor: "{colors.surface}"
    rounded: "{rounded.lg}"
    border: "1px solid {colors.border}"
    overflow: "hidden"
  table-header-cell:
    backgroundColor: "{colors.surface-raised}"
    textColor: "{colors.text-muted}"
    typography: "{typography.table-header}"
    padding: "{spacing.md} {spacing.lg}"
    borderBottom: "1px solid {colors.border-bright}"
  table-row:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.text}"
    typography: "{typography.body-sm}"
    padding: "{spacing.md} {spacing.lg}"
    borderBottom: "1px solid {colors.border}"
  table-row-hover:
    backgroundColor: "{colors.surface-raised}"
  delta-positive:
    textColor: "{colors.positive}"
    typography: "{typography.body-sm}"
  delta-negative:
    textColor: "{colors.negative}"
    typography: "{typography.body-sm}"
  badge-live:
    backgroundColor: "{colors.semantic-error-muted}"
    textColor: "{colors.semantic-error}"
    typography: "{typography.label}"
    rounded: "{rounded.full}"
    padding: "3px 8px"
  badge-status-ok:
    backgroundColor: "{colors.semantic-success-muted}"
    textColor: "{colors.semantic-success}"
    typography: "{typography.label}"
    rounded: "{rounded.full}"
    padding: "3px 8px"
  input:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.text}"
    typography: "{typography.body}"
    rounded: "{rounded.md}"
    border: "1px solid {colors.border}"
    padding: "{spacing.md} {spacing.lg}"
    height: 36px
  input-focused:
    border: "1px solid {colors.primary}"
  select:
    backgroundColor: "{colors.surface-raised}"
    textColor: "{colors.text-secondary}"
    typography: "{typography.body}"
    rounded: "{rounded.md}"
    border: "1px solid {colors.border}"
    height: 34px
  date-range:
    backgroundColor: "{colors.surface-raised}"
    textColor: "{colors.text-secondary}"
    typography: "{typography.body-sm}"
    rounded: "{rounded.md}"
    border: "1px solid {colors.border}"
    padding: "6px 12px"
  sidebar:
    backgroundColor: "{colors.surface}"
    borderRight: "1px solid {colors.border}"
    width: 220px
  sidebar-item:
    backgroundColor: "transparent"
    textColor: "{colors.text-secondary}"
    typography: "{typography.body}"
    rounded: "{rounded.md}"
    padding: "7px 10px"
  sidebar-item-active:
    backgroundColor: "{colors.primary-muted}"
    textColor: "{colors.primary}"
---

## Overview

Data Pro optimizes for dense, fast reading. Deep slate backgrounds (`#0f172a`) reduce eye strain during long data analysis sessions. The cyan primary (`#06b6d4`) is the chart baseline color — other chart colors (`{colors.chart-2}` through `{colors.chart-6}`) are pre-calibrated to work together on dark backgrounds without clashing. JetBrains Mono is used exclusively for numeric values; Inter for labels, navigation, and body text. Compact spacing (6–14px base) keeps dashboards dense but organized.

**Key characteristics:**
- Deep slate `#0f172a` — less harsh than true black, ideal for prolonged screen use
- Cyan `#06b6d4` as chart primary; 6 total chart color palette
- JetBrains Mono for all numeric/metric values — clear visual separation from label text
- Compact spacing system — panels pack more data per screen
- Four surface depth levels for layered panel composition
- Delta indicators: `delta-positive` (green) and `delta-negative` (red) for trend display

## Chart Colors

Use in this order for multi-series charts:
1. `{colors.chart-1}` — Cyan (primary)
2. `{colors.chart-2}` — Purple
3. `{colors.chart-3}` — Amber
4. `{colors.chart-4}` — Green
5. `{colors.chart-5}` — Red
6. `{colors.chart-6}` — Blue

Chart grid lines: `{colors.chart-grid}`. Axis labels: `{colors.chart-axis}`.

## Do's and Don'ts

### Do
- Use `{typography.metric-hero}` / `{typography.metric-lg}` for KPI numbers
- Use `delta-positive` (green) and `delta-negative` (red) for trend arrows
- Use the 6-color chart palette in order — don't pick arbitrary colors
- Keep inputs and selects compact (height 34–36px) for control-bar density

### Don't
- Don't use warm/orange as a standalone background — it's a chart color only
- Don't use `{typography.metric-hero}` with Inter — always JetBrains Mono for numbers
- Don't use large rounded corners — `{rounded.lg}` (10px) is the max in this theme
