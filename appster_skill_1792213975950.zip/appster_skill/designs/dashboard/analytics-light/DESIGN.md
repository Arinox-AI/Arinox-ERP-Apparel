---
version: alpha
name: Analytics Light
description: Analytics Light is a bright, professional dashboard theme on an off-white background ({colors.background}) with blue as the primary accent ({colors.primary}). Designed for business reporting, admin panels, and CRM dashboards where stakeholders need to quickly read data in well-lit environments. Typography uses Inter for all text. Cards use white backgrounds with drop shadows. Chart colors are standard business colors (blue, green, orange, purple). Inspired by Google Analytics, Mixpanel, Tableau.

colors:
  primary: "#2563eb"
  primary-hover: "#1d4ed8"
  primary-light: "#dbeafe"
  on-primary: "#ffffff"
  background: "#f8fafc"
  surface: "#ffffff"
  surface-hover: "#f1f5f9"
  border: "#e2e8f0"
  border-strong: "#cbd5e1"
  text: "#0f172a"
  text-secondary: "#475569"
  text-muted: "#94a3b8"
  chart-1: "#2563eb"
  chart-2: "#16a34a"
  chart-3: "#ea580c"
  chart-4: "#7c3aed"
  chart-5: "#0891b2"
  chart-6: "#db2777"
  chart-grid: "#e2e8f0"
  positive: "#16a34a"
  positive-light: "#dcfce7"
  negative: "#dc2626"
  negative-light: "#fee2e2"
  neutral: "#64748b"
  semantic-success: "#16a34a"
  semantic-success-light: "#dcfce7"
  semantic-error: "#dc2626"
  semantic-error-light: "#fee2e2"
  semantic-warning: "#d97706"
  semantic-warning-light: "#fef3c7"

typography:
  display:
    fontFamily: Inter
    fontSize: 34px
    fontWeight: 700
    lineHeight: 1.15
    letterSpacing: -0.5px
  heading-1:
    fontFamily: Inter
    fontSize: 26px
    fontWeight: 600
    lineHeight: 1.2
  heading-2:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: 600
    lineHeight: 1.3
  heading-3:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: 600
    lineHeight: 1.4
  metric-hero:
    fontFamily: Inter
    fontSize: 42px
    fontWeight: 700
    lineHeight: 1.0
    letterSpacing: -1px
  metric-lg:
    fontFamily: Inter
    fontSize: 30px
    fontWeight: 700
    lineHeight: 1.1
  metric-md:
    fontFamily: Inter
    fontSize: 22px
    fontWeight: 600
    lineHeight: 1.2
  body:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: 400
    lineHeight: 1.6
  body-medium:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: 500
    lineHeight: 1.6
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: 400
    lineHeight: 1.5
  label:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: 600
    lineHeight: 1.3
    letterSpacing: 0.5px
  button:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: 500
    lineHeight: 1.2
  table-header:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: 600
    lineHeight: 1.3
    letterSpacing: 0.5px

rounded:
  xs: 4px
  sm: 6px
  md: 8px
  lg: 12px
  xl: 16px
  full: 9999px

spacing:
  xs: 4px
  sm: 8px
  md: 12px
  lg: 16px
  xl: 20px
  xxl: 24px
  xxxl: 32px
  panel: 20px

components:
  button-primary:
    backgroundColor: "{colors.primary}"
    textColor: "{colors.on-primary}"
    typography: "{typography.button}"
    rounded: "{rounded.md}"
    padding: "8px 16px"
    border: "none"
  button-secondary:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.text}"
    typography: "{typography.button}"
    rounded: "{rounded.md}"
    padding: "8px 16px"
    border: "1px solid {colors.border-strong}"
  button-ghost:
    backgroundColor: "transparent"
    textColor: "{colors.text-secondary}"
    typography: "{typography.button}"
    rounded: "{rounded.md}"
    padding: "7px 12px"
  metric-card:
    backgroundColor: "{colors.surface}"
    rounded: "{rounded.lg}"
    border: "1px solid {colors.border}"
    padding: "{spacing.panel}"
    boxShadow: "0 1px 4px rgba(15, 23, 42, 0.06)"
  chart-container:
    backgroundColor: "{colors.surface}"
    rounded: "{rounded.lg}"
    border: "1px solid {colors.border}"
    padding: "{spacing.panel}"
    boxShadow: "0 1px 4px rgba(15, 23, 42, 0.06)"
  chart-tooltip:
    backgroundColor: "{colors.text}"
    textColor: "#ffffff"
    rounded: "{rounded.md}"
    padding: "8px 12px"
    boxShadow: "0 4px 12px rgba(15, 23, 42, 0.15)"
  table-container:
    backgroundColor: "{colors.surface}"
    rounded: "{rounded.lg}"
    border: "1px solid {colors.border}"
    overflow: "hidden"
    boxShadow: "0 1px 4px rgba(15, 23, 42, 0.06)"
  table-header-cell:
    backgroundColor: "{colors.background}"
    textColor: "{colors.text-muted}"
    typography: "{typography.table-header}"
    padding: "10px 16px"
    borderBottom: "1px solid {colors.border}"
  table-row:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.text}"
    typography: "{typography.body-sm}"
    padding: "10px 16px"
    borderBottom: "1px solid {colors.border}"
  table-row-hover:
    backgroundColor: "{colors.surface-hover}"
  delta-positive:
    textColor: "{colors.positive}"
    backgroundColor: "{colors.positive-light}"
    typography: "{typography.body-sm}"
    rounded: "{rounded.full}"
    padding: "2px 8px"
  delta-negative:
    textColor: "{colors.negative}"
    backgroundColor: "{colors.negative-light}"
    typography: "{typography.body-sm}"
    rounded: "{rounded.full}"
    padding: "2px 8px"
  badge-status-active:
    backgroundColor: "{colors.semantic-success-light}"
    textColor: "{colors.semantic-success}"
    typography: "{typography.label}"
    rounded: "{rounded.full}"
    padding: "3px 10px"
  badge-status-warning:
    backgroundColor: "{colors.semantic-warning-light}"
    textColor: "{colors.semantic-warning}"
    typography: "{typography.label}"
    rounded: "{rounded.full}"
    padding: "3px 10px"
  input:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.text}"
    typography: "{typography.body}"
    rounded: "{rounded.md}"
    border: "1px solid {colors.border-strong}"
    padding: "7px 12px"
    height: 36px
  input-focused:
    border: "1px solid {colors.primary}"
    boxShadow: "0 0 0 3px {colors.primary-light}"
  date-range:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.text-secondary}"
    typography: "{typography.body-sm}"
    rounded: "{rounded.md}"
    border: "1px solid {colors.border-strong}"
    padding: "6px 12px"
  sidebar:
    backgroundColor: "{colors.surface}"
    borderRight: "1px solid {colors.border}"
    width: 220px
    boxShadow: "1px 0 0 {colors.border}"
  sidebar-item:
    backgroundColor: "transparent"
    textColor: "{colors.text-secondary}"
    typography: "{typography.body-medium}"
    rounded: "{rounded.md}"
    padding: "7px 10px"
  sidebar-item-active:
    backgroundColor: "{colors.primary-light}"
    textColor: "{colors.primary}"
  top-nav:
    backgroundColor: "{colors.surface}"
    height: 56px
    borderBottom: "1px solid {colors.border}"
    boxShadow: "0 1px 2px rgba(15, 23, 42, 0.04)"
---

## Overview

Analytics Light prioritizes legibility in office and presentation contexts — high contrast on white, standard chart color vocabulary (blue, green, orange, purple), and clear text hierarchy. White cards (`{colors.surface}`) on a very light gray canvas (`{colors.background}`) use thin drop shadows to lift content. This creates a paper-like layered feel. Chart tooltips are dark (inverted from the light background) for maximum readability on data hover.

**Key characteristics:**
- Off-white canvas `#f8fafc` — not pure white, softens the grid
- Blue `#2563eb` primary — instantly recognized as "data/analytics" color
- White cards with minimal shadow — clean, professional
- Standard 6-color chart palette for multi-series data
- Pill badges for delta/trend indicators (green/red pill chips)
- Compact spacing (8–20px) for dense data panels

## Chart Colors

Use in this order for multi-series charts:
1. `{colors.chart-1}` — Blue (primary)
2. `{colors.chart-2}` — Green
3. `{colors.chart-3}` — Orange
4. `{colors.chart-4}` — Purple
5. `{colors.chart-5}` — Cyan
6. `{colors.chart-6}` — Pink

Chart grid lines: `{colors.chart-grid}`.

## Do's and Don'ts

### Do
- Use `delta-positive` / `delta-negative` pill badges next to metric values
- Use dark chart tooltips (inverted) for legibility on light hover surfaces
- Use `table-row-hover` with `{colors.surface-hover}` for interactive table rows
- Keep input height at 36px for dashboard control bars

### Don't
- Don't use dark/moody backgrounds — this is a light theme for office readability
- Don't use more than 6 chart colors in the same chart — it becomes unreadable
- Don't skip the card shadow — it separates panels from the canvas
