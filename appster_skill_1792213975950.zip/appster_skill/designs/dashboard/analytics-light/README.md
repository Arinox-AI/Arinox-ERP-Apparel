# Analytics Light

Off-white background with blue accent. Clean, readable, professional data interface that works well in office/meeting-room environments.

Best used for: business reporting, admin panels, CRM dashboards, Google Analytics-style tools, anything a manager presents on a projector.
