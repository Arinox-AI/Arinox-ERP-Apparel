# Warm Pastel

Warm cream background with coral/terracotta accent. Approachable, human, inviting.

Best used for: community apps, lifestyle tools, booking/reservation apps, wellness, social apps — anything where warmth and friendliness matters more than corporate precision.
