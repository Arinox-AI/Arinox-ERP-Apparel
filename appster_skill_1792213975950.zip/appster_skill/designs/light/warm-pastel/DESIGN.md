---
version: alpha
name: Warm Pastel
description: Warm Pastel uses a cream/off-white background ({colors.background}) with coral-terracotta as the primary accent ({colors.primary}). The palette is drawn from warm earthy tones — ivory, sand, blush, terracotta — creating an approachable, human, inviting aesthetic. Typography uses Plus Jakarta Sans for a friendly yet modern feel. Cards use soft shadows rather than borders. Best for lifestyle apps, community platforms, booking tools, wellness apps, personal projects.

colors:
  primary: "#e8644d"
  primary-hover: "#d4553f"
  primary-light: "#fdf0ee"
  on-primary: "#ffffff"
  background: "#faf8f5"
  surface: "#f3ede5"
  surface-raised: "#ede6db"
  border: "#e5ddd4"
  border-soft: "#ede6db"
  text: "#1a1412"
  text-secondary: "#5c4f47"
  text-muted: "#9e8e85"
  text-on-warm: "#7a6a60"
  accent-green: "#4a9e6b"
  accent-green-light: "#e6f5ec"
  accent-amber: "#d4920a"
  accent-amber-light: "#fef4d6"
  accent-blue: "#3b7dd8"
  accent-blue-light: "#e8f1fc"
  semantic-success: "#4a9e6b"
  semantic-success-light: "#e6f5ec"
  semantic-error: "#c94f3c"
  semantic-error-light: "#fceae8"
  semantic-warning: "#d4920a"
  semantic-warning-light: "#fef4d6"

typography:
  display:
    fontFamily: Plus Jakarta Sans
    fontSize: 52px
    fontWeight: 700
    lineHeight: 1.1
    letterSpacing: -1.5px
  heading-1:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: 700
    lineHeight: 1.15
    letterSpacing: -1px
  heading-2:
    fontFamily: Plus Jakarta Sans
    fontSize: 30px
    fontWeight: 600
    lineHeight: 1.2
    letterSpacing: -0.5px
  heading-3:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: 600
    lineHeight: 1.3
  heading-4:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: 600
    lineHeight: 1.4
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 17px
    fontWeight: 400
    lineHeight: 1.7
  body:
    fontFamily: Plus Jakarta Sans
    fontSize: 15px
    fontWeight: 400
    lineHeight: 1.7
  body-medium:
    fontFamily: Plus Jakarta Sans
    fontSize: 15px
    fontWeight: 500
    lineHeight: 1.7
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: 400
    lineHeight: 1.55
  caption:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: 500
    lineHeight: 1.4
  button:
    fontFamily: Plus Jakarta Sans
    fontSize: 15px
    fontWeight: 600
    lineHeight: 1.2

rounded:
  xs: 6px
  sm: 10px
  md: 14px
  lg: 18px
  xl: 24px
  xxl: 32px
  full: 9999px

spacing:
  xs: 4px
  sm: 8px
  md: 12px
  lg: 16px
  xl: 20px
  xxl: 28px
  xxxl: 40px
  section: 64px
  section-lg: 96px

components:
  button-primary:
    backgroundColor: "{colors.primary}"
    textColor: "{colors.on-primary}"
    typography: "{typography.button}"
    rounded: "{rounded.full}"
    padding: "12px 24px"
    border: "none"
  button-primary-hover:
    backgroundColor: "{colors.primary-hover}"
    boxShadow: "0 4px 14px rgba(232, 100, 77, 0.35)"
  button-secondary:
    backgroundColor: "{colors.background}"
    textColor: "{colors.text}"
    typography: "{typography.button}"
    rounded: "{rounded.full}"
    padding: "12px 24px"
    border: "1.5px solid {colors.border}"
  button-secondary-hover:
    border: "1.5px solid {colors.text-secondary}"
  button-ghost:
    backgroundColor: "transparent"
    textColor: "{colors.text-secondary}"
    typography: "{typography.body-medium}"
    rounded: "{rounded.md}"
    padding: "8px 14px"
  card:
    backgroundColor: "#ffffff"
    rounded: "{rounded.lg}"
    padding: "{spacing.xxl}"
    boxShadow: "0 2px 12px rgba(90, 60, 40, 0.08)"
  card-warm:
    backgroundColor: "{colors.surface}"
    rounded: "{rounded.lg}"
    padding: "{spacing.xxl}"
    border: "1px solid {colors.border-soft}"
  card-featured:
    backgroundColor: "{colors.primary}"
    textColor: "{colors.on-primary}"
    rounded: "{rounded.xl}"
    padding: "{spacing.xxl}"
    boxShadow: "0 8px 32px rgba(232, 100, 77, 0.30)"
  input:
    backgroundColor: "#ffffff"
    textColor: "{colors.text}"
    typography: "{typography.body}"
    rounded: "{rounded.md}"
    border: "1.5px solid {colors.border}"
    padding: "{spacing.md} {spacing.lg}"
    height: 48px
  input-focused:
    border: "1.5px solid {colors.primary}"
    boxShadow: "0 0 0 4px {colors.primary-light}"
  badge-default:
    backgroundColor: "{colors.surface-raised}"
    textColor: "{colors.text-secondary}"
    typography: "{typography.caption}"
    rounded: "{rounded.full}"
    padding: "4px 12px"
  badge-primary:
    backgroundColor: "{colors.primary-light}"
    textColor: "{colors.primary}"
    typography: "{typography.caption}"
    rounded: "{rounded.full}"
    padding: "4px 12px"
  badge-green:
    backgroundColor: "{colors.accent-green-light}"
    textColor: "{colors.accent-green}"
    typography: "{typography.caption}"
    rounded: "{rounded.full}"
    padding: "4px 12px"
  avatar:
    backgroundColor: "{colors.surface}"
    border: "2px solid {colors.border}"
    rounded: "{rounded.full}"
    size: 40px
  avatar-lg:
    backgroundColor: "{colors.surface}"
    border: "2px solid {colors.border}"
    rounded: "{rounded.full}"
    size: 64px
---

## Overview

Warm Pastel creates warmth through cream backgrounds, soft shadows (instead of borders), and coral primary. The elevated border radius (`{rounded.full}` for buttons, `{rounded.lg}` for cards) and warm color palette make interfaces feel friendly and human. White cards on the cream background use soft box shadows to lift off the surface naturally. Plus Jakarta Sans has just enough personality to distinguish from generic Inter-based apps.

**Key characteristics:**
- Warm cream background `#faf8f5` — not cold white, not beige, just warm
- Coral/terracotta primary `#e8644d` — warm, energetic, not harsh red
- Soft drop shadows on cards (not border-separated)
- Pill-shaped buttons (`{rounded.full}`) — friendly, approachable
- Larger border-radius throughout (14–24px) — soft geometry
- Plus Jakarta Sans — humanist personality

## Typography

**Plus Jakarta Sans**: Load from Google Fonts at weights 400, 500, 600, 700.

## Do's and Don'ts

### Do
- Use `{rounded.full}` for primary action buttons
- Use `card` (white + shadow) for primary content; `card-warm` (cream + border) for secondary panels
- Use `{typography.body}` with 1.7 line-height — warmer, more spacious feel
- Use the avatar components for user profiles, review cards, community features

### Don't
- Don't use harsh borders instead of soft shadows on cards
- Don't apply `{rounded.xs}` or sharp corners — they conflict with the warm aesthetic
- Don't use cool blue or gray as primary color — this theme is warm-first
- Don't use condensed heading typography — warm themes benefit from open sizing
