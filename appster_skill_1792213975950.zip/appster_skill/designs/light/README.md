# Light Themes

Light-background UI themes. Best for SaaS apps, productivity tools, documentation, notes, and general-purpose web apps.

## Themes

| Theme | Description |
|---|---|
| `clean-minimal` | Pure white canvas with slate-blue accent. Crisp, minimal, modern. Inspired by Notion, Linear, Vercel docs. |
| `warm-pastel` | Warm cream background with coral/terracotta accent. Approachable, human, lifestyle feel. Inspired by Airbnb, community apps. |
