---
version: alpha
name: Clean Minimal
description: Clean Minimal is a pure-white SaaS theme anchored by a white canvas ({colors.background}) with slate-blue as the primary accent ({colors.primary}). The design language is disciplined and distraction-free — neutral gray surfaces, hairline borders, and generous whitespace let content breathe. Typography uses Inter with tight display sizing and generous body leading. This theme suits productivity tools, note apps, SaaS dashboards, and documentation where the content itself is the focus. Inspired by Linear, Notion (light), Vercel Docs.

colors:
  primary: "#4f6ef7"
  primary-hover: "#3d59e8"
  primary-light: "#eef1fe"
  on-primary: "#ffffff"
  background: "#ffffff"
  surface: "#f8f9fa"
  surface-hover: "#f1f3f5"
  border: "#e5e7eb"
  border-strong: "#d1d5db"
  text: "#111827"
  text-secondary: "#4b5563"
  text-muted: "#9ca3af"
  text-on-light: "#6b7280"
  link: "#4f6ef7"
  semantic-success: "#059669"
  semantic-success-light: "#d1fae5"
  semantic-error: "#dc2626"
  semantic-error-light: "#fee2e2"
  semantic-warning: "#d97706"
  semantic-warning-light: "#fef3c7"
  semantic-info: "#2563eb"
  semantic-info-light: "#dbeafe"

typography:
  display:
    fontFamily: Inter
    fontSize: 52px
    fontWeight: 700
    lineHeight: 1.1
    letterSpacing: -2px
  heading-1:
    fontFamily: Inter
    fontSize: 38px
    fontWeight: 700
    lineHeight: 1.15
    letterSpacing: -1px
  heading-2:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: 600
    lineHeight: 1.2
    letterSpacing: -0.5px
  heading-3:
    fontFamily: Inter
    fontSize: 22px
    fontWeight: 600
    lineHeight: 1.3
  heading-4:
    fontFamily: Inter
    fontSize: 17px
    fontWeight: 600
    lineHeight: 1.4
  body-lg:
    fontFamily: Inter
    fontSize: 17px
    fontWeight: 400
    lineHeight: 1.7
  body:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: 400
    lineHeight: 1.65
  body-medium:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: 500
    lineHeight: 1.65
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: 400
    lineHeight: 1.55
  caption:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: 500
    lineHeight: 1.4
    letterSpacing: 0.2px
  button:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: 500
    lineHeight: 1.2
  label:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: 500
    lineHeight: 1.3

rounded:
  xs: 4px
  sm: 6px
  md: 8px
  lg: 10px
  xl: 14px
  xxl: 20px
  full: 9999px

spacing:
  xs: 4px
  sm: 8px
  md: 12px
  lg: 16px
  xl: 20px
  xxl: 24px
  xxxl: 32px
  section: 48px
  section-lg: 80px

components:
  button-primary:
    backgroundColor: "{colors.primary}"
    textColor: "{colors.on-primary}"
    typography: "{typography.button}"
    rounded: "{rounded.md}"
    padding: "9px 18px"
    border: "none"
  button-primary-hover:
    backgroundColor: "{colors.primary-hover}"
  button-secondary:
    backgroundColor: "{colors.background}"
    textColor: "{colors.text}"
    typography: "{typography.button}"
    rounded: "{rounded.md}"
    padding: "9px 18px"
    border: "1px solid {colors.border-strong}"
  button-ghost:
    backgroundColor: "transparent"
    textColor: "{colors.text-secondary}"
    typography: "{typography.button}"
    rounded: "{rounded.md}"
    padding: "8px 14px"
    border: "none"
  button-link:
    backgroundColor: "transparent"
    textColor: "{colors.primary}"
    typography: "{typography.body-medium}"
    padding: "0"
  card:
    backgroundColor: "{colors.background}"
    rounded: "{rounded.lg}"
    border: "1px solid {colors.border}"
    padding: "{spacing.xl}"
  card-surface:
    backgroundColor: "{colors.surface}"
    rounded: "{rounded.lg}"
    border: "1px solid {colors.border}"
    padding: "{spacing.xl}"
  card-highlighted:
    backgroundColor: "{colors.primary-light}"
    rounded: "{rounded.lg}"
    border: "1px solid {colors.primary}"
    padding: "{spacing.xl}"
  input:
    backgroundColor: "{colors.background}"
    textColor: "{colors.text}"
    typography: "{typography.body}"
    rounded: "{rounded.md}"
    border: "1px solid {colors.border-strong}"
    padding: "{spacing.md} {spacing.lg}"
    height: 40px
  input-focused:
    border: "1px solid {colors.primary}"
    boxShadow: "0 0 0 3px {colors.primary-light}"
  select:
    backgroundColor: "{colors.background}"
    textColor: "{colors.text}"
    rounded: "{rounded.md}"
    border: "1px solid {colors.border-strong}"
    padding: "9px 12px"
    height: 40px
  badge-default:
    backgroundColor: "{colors.surface-hover}"
    textColor: "{colors.text-secondary}"
    typography: "{typography.caption}"
    rounded: "{rounded.full}"
    padding: "3px 10px"
  badge-primary:
    backgroundColor: "{colors.primary-light}"
    textColor: "{colors.primary}"
    typography: "{typography.caption}"
    rounded: "{rounded.full}"
    padding: "3px 10px"
  badge-success:
    backgroundColor: "{colors.semantic-success-light}"
    textColor: "{colors.semantic-success}"
    typography: "{typography.caption}"
    rounded: "{rounded.full}"
    padding: "3px 10px"
  badge-error:
    backgroundColor: "{colors.semantic-error-light}"
    textColor: "{colors.semantic-error}"
    typography: "{typography.caption}"
    rounded: "{rounded.full}"
    padding: "3px 10px"
  sidebar:
    backgroundColor: "{colors.surface}"
    borderRight: "1px solid {colors.border}"
    width: 240px
    padding: "{spacing.lg}"
  sidebar-item:
    backgroundColor: "transparent"
    textColor: "{colors.text-secondary}"
    typography: "{typography.body-medium}"
    rounded: "{rounded.md}"
    padding: "7px 10px"
  sidebar-item-active:
    backgroundColor: "{colors.primary-light}"
    textColor: "{colors.primary}"
  table-header:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.text-muted}"
    typography: "{typography.label}"
    padding: "{spacing.md} {spacing.lg}"
    borderBottom: "1px solid {colors.border}"
  table-row:
    backgroundColor: "{colors.background}"
    textColor: "{colors.text}"
    typography: "{typography.body-sm}"
    padding: "{spacing.md} {spacing.lg}"
    borderBottom: "1px solid {colors.border}"
  table-row-hover:
    backgroundColor: "{colors.surface}"
---

## Overview

Clean Minimal uses a pure white canvas with carefully balanced gray tones to create hierarchy without weight. The slate-blue primary (`#4f6ef7`) is the only color accent — everything else is gray/neutral. Inter at tight negative letter-spacing for headlines; generous line-height (1.65) for body text. Cards are white on white — separated by hairline borders, not background contrast. The sidebar uses light-blue tint for active states instead of bold fills.

**Key characteristics:**
- Pure white `#ffffff` background — no off-white or cream
- Single accent color: slate-blue `#4f6ef7`
- Hairline borders (`{colors.border}`) everywhere — no box shadows by default
- Generous body line-height (1.65) for readability
- Tight negative letter-spacing on display and headings
- Table/list UI patterns included

## Colors

- **Primary** (`{colors.primary}`): Buttons, links, active states, focus rings
- **Primary Light** (`{colors.primary-light}`): Badge backgrounds, highlighted cards, active sidebar
- **Background** (`{colors.background}`): Page canvas — pure white
- **Surface** (`{colors.surface}`): Panel backgrounds, sidebar — very light gray
- **Border / Border Strong** (`{colors.border}`, `{colors.border-strong}`): Hairline separators

## Typography

**Inter** (all weights). Load from Google Fonts: weights 400, 500, 600, 700.
Tightest at display (-2px) → relaxed at body (no tracking).

## Do's and Don'ts

### Do
- Use hairline borders to separate cards rather than background-color differences
- Reserve `{colors.primary}` for interactive elements only — don't use as decorative color
- Use `{typography.body}` with 1.65 line-height for all paragraph content
- Apply `{rounded.md}` (8px) consistently for inputs, buttons, and cards

### Don't
- Don't use drop shadows — border-based separation is the convention here
- Don't add secondary accent colors — this is a monochromatic-accent theme
- Don't use `{colors.text}` (dark) for muted/secondary content — use `{colors.text-secondary}` or `{colors.text-muted}`
