# Clean Minimal

Pure white canvas with slate-blue accent. Crisp, distraction-free, modern SaaS feel.

Best used for: productivity tools, note apps, SaaS dashboards, documentation, anything that needs to feel focused and professional without being corporate.
