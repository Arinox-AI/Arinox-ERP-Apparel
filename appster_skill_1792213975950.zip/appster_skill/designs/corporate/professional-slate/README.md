# Professional Slate

Light gray background with dark navy accent. Conservative, formal, authoritative.

Best used for: legal tech, finance tools, healthcare apps, consulting portals, government-adjacent software — anywhere trust and formality outweigh style.
