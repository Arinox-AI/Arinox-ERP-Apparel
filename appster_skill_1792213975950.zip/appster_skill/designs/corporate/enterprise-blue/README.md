# Enterprise Blue

White background with strong corporate blue accent. Trustworthy, professional, instantly recognizable as "serious business software."

Best used for: enterprise SaaS, B2B tools, HR software, project management for companies, anything sold to a procurement team.
