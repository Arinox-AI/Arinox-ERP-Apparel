---
version: alpha
name: Enterprise Blue
description: Enterprise Blue is a white-background B2B theme with corporate blue ({colors.primary}) as the primary accent. The design communicates authority, scalability, and trustworthiness — the visual language expected by enterprise procurement teams and IT departments. Typography uses IBM Plex Sans for a purposefully tech-corporate feel. Cards are white on white with borders (no shadows). CTAs are blue rectangles. Inspired by IBM, Salesforce, SAP, enterprise SaaS platforms.

colors:
  primary: "#1e40af"
  primary-hover: "#1e3a8a"
  primary-light: "#dbeafe"
  primary-mid: "#1d4ed8"
  on-primary: "#ffffff"
  background: "#ffffff"
  surface: "#f8faff"
  surface-accent: "#eff6ff"
  border: "#dde5f0"
  border-strong: "#b8c8e0"
  text: "#0f172a"
  text-secondary: "#334155"
  text-muted: "#64748b"
  link: "#1d4ed8"
  accent-teal: "#0d9488"
  accent-teal-light: "#ccfbf1"
  semantic-success: "#15803d"
  semantic-success-light: "#dcfce7"
  semantic-error: "#b91c1c"
  semantic-error-light: "#fee2e2"
  semantic-warning: "#b45309"
  semantic-warning-light: "#fef3c7"
  semantic-info: "#1e40af"
  semantic-info-light: "#dbeafe"

typography:
  display:
    fontFamily: IBM Plex Sans
    fontSize: 48px
    fontWeight: 600
    lineHeight: 1.1
    letterSpacing: -1px
  heading-1:
    fontFamily: IBM Plex Sans
    fontSize: 36px
    fontWeight: 600
    lineHeight: 1.15
    letterSpacing: -0.5px
  heading-2:
    fontFamily: IBM Plex Sans
    fontSize: 28px
    fontWeight: 600
    lineHeight: 1.2
  heading-3:
    fontFamily: IBM Plex Sans
    fontSize: 22px
    fontWeight: 600
    lineHeight: 1.3
  heading-4:
    fontFamily: IBM Plex Sans
    fontSize: 18px
    fontWeight: 600
    lineHeight: 1.4
  body-lg:
    fontFamily: IBM Plex Sans
    fontSize: 17px
    fontWeight: 400
    lineHeight: 1.65
  body:
    fontFamily: IBM Plex Sans
    fontSize: 15px
    fontWeight: 400
    lineHeight: 1.6
  body-medium:
    fontFamily: IBM Plex Sans
    fontSize: 15px
    fontWeight: 500
    lineHeight: 1.6
  body-sm:
    fontFamily: IBM Plex Sans
    fontSize: 13px
    fontWeight: 400
    lineHeight: 1.55
  caption:
    fontFamily: IBM Plex Sans
    fontSize: 12px
    fontWeight: 500
    lineHeight: 1.4
    letterSpacing: 0.3px
  button:
    fontFamily: IBM Plex Sans
    fontSize: 14px
    fontWeight: 600
    lineHeight: 1.2
  label:
    fontFamily: IBM Plex Sans
    fontSize: 12px
    fontWeight: 600
    lineHeight: 1.3
    letterSpacing: 0.5px
  code:
    fontFamily: IBM Plex Mono
    fontSize: 13px
    fontWeight: 400
    lineHeight: 1.7

rounded:
  xs: 2px
  sm: 4px
  md: 6px
  lg: 8px
  xl: 12px
  xxl: 16px
  full: 9999px

spacing:
  xs: 4px
  sm: 8px
  md: 12px
  lg: 16px
  xl: 20px
  xxl: 28px
  xxxl: 40px
  section: 56px
  section-lg: 88px

components:
  button-primary:
    backgroundColor: "{colors.primary}"
    textColor: "{colors.on-primary}"
    typography: "{typography.button}"
    rounded: "{rounded.md}"
    padding: "10px 20px"
    border: "none"
  button-primary-hover:
    backgroundColor: "{colors.primary-hover}"
  button-secondary:
    backgroundColor: "{colors.background}"
    textColor: "{colors.primary}"
    typography: "{typography.button}"
    rounded: "{rounded.md}"
    padding: "10px 20px"
    border: "1px solid {colors.primary}"
  button-secondary-hover:
    backgroundColor: "{colors.primary-light}"
  button-ghost:
    backgroundColor: "transparent"
    textColor: "{colors.text-secondary}"
    typography: "{typography.button}"
    rounded: "{rounded.md}"
    padding: "8px 16px"
  button-danger:
    backgroundColor: "{colors.semantic-error}"
    textColor: "#ffffff"
    typography: "{typography.button}"
    rounded: "{rounded.md}"
    padding: "10px 20px"
  card:
    backgroundColor: "{colors.background}"
    rounded: "{rounded.lg}"
    border: "1px solid {colors.border}"
    padding: "{spacing.xxl}"
  card-surface:
    backgroundColor: "{colors.surface}"
    rounded: "{rounded.lg}"
    border: "1px solid {colors.border}"
    padding: "{spacing.xxl}"
  card-highlighted:
    backgroundColor: "{colors.surface-accent}"
    rounded: "{rounded.lg}"
    border: "1px solid {colors.border-strong}"
    borderLeft: "4px solid {colors.primary}"
    padding: "{spacing.xxl}"
  input:
    backgroundColor: "{colors.background}"
    textColor: "{colors.text}"
    typography: "{typography.body}"
    rounded: "{rounded.md}"
    border: "1px solid {colors.border-strong}"
    padding: "{spacing.md} {spacing.lg}"
    height: 42px
  input-focused:
    border: "1px solid {colors.primary}"
    boxShadow: "0 0 0 3px {colors.primary-light}"
  select:
    backgroundColor: "{colors.background}"
    textColor: "{colors.text}"
    rounded: "{rounded.md}"
    border: "1px solid {colors.border-strong}"
    height: 42px
    padding: "10px 12px"
  checkbox:
    accentColor: "{colors.primary}"
    size: 16px
    rounded: "{rounded.xs}"
  badge-default:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.text-secondary}"
    typography: "{typography.caption}"
    rounded: "{rounded.sm}"
    padding: "3px 10px"
    border: "1px solid {colors.border}"
  badge-primary:
    backgroundColor: "{colors.primary-light}"
    textColor: "{colors.primary}"
    typography: "{typography.caption}"
    rounded: "{rounded.sm}"
    padding: "3px 10px"
  badge-success:
    backgroundColor: "{colors.semantic-success-light}"
    textColor: "{colors.semantic-success}"
    typography: "{typography.caption}"
    rounded: "{rounded.sm}"
    padding: "3px 10px"
  badge-error:
    backgroundColor: "{colors.semantic-error-light}"
    textColor: "{colors.semantic-error}"
    typography: "{typography.caption}"
    rounded: "{rounded.sm}"
    padding: "3px 10px"
  breadcrumb:
    textColor: "{colors.text-muted}"
    typography: "{typography.body-sm}"
    separatorColor: "{colors.border-strong}"
  sidebar:
    backgroundColor: "{colors.background}"
    borderRight: "1px solid {colors.border}"
    width: 256px
  sidebar-section-header:
    textColor: "{colors.text-muted}"
    typography: "{typography.label}"
    padding: "8px 14px 4px 14px"
  sidebar-item:
    backgroundColor: "transparent"
    textColor: "{colors.text-secondary}"
    typography: "{typography.body-medium}"
    rounded: "{rounded.md}"
    padding: "8px 14px"
  sidebar-item-active:
    backgroundColor: "{colors.primary-light}"
    textColor: "{colors.primary}"
    borderLeft: "3px solid {colors.primary}"
  top-nav:
    backgroundColor: "{colors.background}"
    height: 60px
    borderBottom: "1px solid {colors.border}"
  table-header-cell:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.text-muted}"
    typography: "{typography.label}"
    padding: "12px 16px"
    borderBottom: "2px solid {colors.border-strong}"
  table-row:
    backgroundColor: "{colors.background}"
    textColor: "{colors.text}"
    typography: "{typography.body-sm}"
    padding: "12px 16px"
    borderBottom: "1px solid {colors.border}"
  table-row-hover:
    backgroundColor: "{colors.surface}"
---

## Overview

Enterprise Blue is built around the visual conventions of large-scale B2B software — IBM, Salesforce, Microsoft 365. White cards on white backgrounds use borders (not shadows) to separate panels. Blue is reserved exclusively for primary CTAs and active states. The secondary button pattern (white fill + blue border) is the enterprise standard, communicating that clicking will take a meaningful action. IBM Plex Sans reinforces the corporate-tech identity. IBM Plex Mono for code blocks.

**Key characteristics:**
- White `#ffffff` background — clean, document-like feel
- Corporate blue `#1e40af` as the sole accent
- Border-separated cards (no drop shadows on desktop)
- `card-highlighted` has a 4px blue left-border accent — enterprise feature highlight pattern
- IBM Plex Sans/Mono — intentional IBM carbon design system aesthetic
- Square-ish border radius (2–8px) — serious and structured, not rounded-casual
- Three-column sidebar with section headers

## Typography

**IBM Plex Sans**: Load from Google Fonts at weights 400, 500, 600.
**IBM Plex Mono**: Load from Google Fonts at weight 400.

## Do's and Don'ts

### Do
- Use `{colors.primary}` (`{colors.primary}`) exclusively for CTAs and active navigation
- Use `card-highlighted` with left blue border for featured/callout content
- Apply `{rounded.md}` (6px) — not pill shapes — to buttons and inputs
- Use breadcrumb navigation for deep application hierarchies

### Don't
- Don't use drop shadows — border-based separation is the enterprise convention
- Don't use pill buttons — the enterprise aesthetic requires rectangular CTAs
- Don't add decorative gradients or colorful backgrounds
- Don't use warm or pastel colors as decorative accents
