# Corporate Themes

Enterprise, B2B, and professional service themes. Best for business software, legal/finance tools, consulting apps, and any audience expecting formal, trustworthy design.

## Themes

| Theme | Description |
|---|---|
| `enterprise-blue` | White background with strong corporate blue accent. Trustworthy, professional, scalable. Inspired by IBM, Salesforce, enterprise SaaS. |
| `professional-slate` | Light gray background with dark navy accent. Conservative, formal, high-trust. Inspired by legal, finance, healthcare apps. |
