# Appster Design System

This folder contains all design templates for the Appster skill.
Templates are organized by **CATEGORY** (not by brand), so you can pick by feel/use-case rather than knowing a brand name.

---

## Folder Structure

```
designs/
├── SKILL.md               ← this file — how to use the design system
├── dark/                  ← dark-background UI themes (terminals, creative tools, dev tools)
│   ├── README.md
│   ├── midnight-pro/
│   └── terminal-dark/
├── light/                 ← light-background UI themes (productivity, SaaS, docs)
│   ├── README.md
│   ├── clean-minimal/
│   └── warm-pastel/
├── e-commerce/            ← shopping, marketplace, product-catalog themes
│   ├── README.md
│   ├── modern-shop/
│   └── luxury-market/
├── dashboard/             ← data dashboards, analytics, reporting, admin panels
│   ├── README.md
│   ├── data-pro/
│   └── analytics-light/
└── corporate/             ← enterprise, B2B, professional service themes
    ├── README.md
    ├── enterprise-blue/
    └── professional-slate/
```

---

## How to Pick a Template

### Step 1 — Read the requirement
From the user's description or REQUIREMENTS.md, identify the primary use-case:

| If the app is about... | Category to look in |
|---|---|
| Developer tool, terminal, code editor, AI chat | `dark/` |
| Productivity, docs, notes, SaaS app | `light/` |
| Shopping cart, product listings, marketplace | `e-commerce/` |
| Charts, analytics, admin panel, reporting | `dashboard/` |
| B2B service, enterprise software, consulting | `corporate/` |

### Step 2 — Browse the category README
Each category folder has a `README.md` listing the themes inside it with 1-line descriptions. Read it to pick the best match.

```bash
cat {DESIGNS_DIR}/{category}/README.md
```

### Step 3 — Read the theme README
Open the chosen theme's `README.md` for a short visual description.

```bash
cat {DESIGNS_DIR}/{category}/{theme-name}/README.md
```

### Step 4 — Copy the DESIGN.md to the project
```bash
cp {DESIGNS_DIR}/{category}/{theme-name}/DESIGN.md {PROJECT_DIR}/DESIGN.md
```

### Step 5 — Update the name only
Open `{PROJECT_DIR}/DESIGN.md` and update the `name:` field at the top to match the actual project name. **Do not change any token values** — the color/typography/component system stays intact.

---

## How to Apply the Design System in Code

### CSS Custom Properties (Tailwind / Vanilla CSS)
Convert hex colors to CSS variables in `index.css`:

```css
:root {
  --color-primary: {colors.primary};        /* e.g. #6366f1 */
  --color-background: {colors.background};
  --color-surface: {colors.surface};
  --color-text: {colors.text};
  --color-border: {colors.border};
  --radius-sm: {rounded.sm};
  --radius-md: {rounded.md};
  --radius-lg: {rounded.lg};
}
```

### Font Loading (bundled — NEVER from a CDN)
The frontend bundles to a single offline `index.html`, so fonts MUST be bundled, not fetched at runtime.
⛔ Do NOT add `<link>` tags to `fonts.googleapis.com` or any external host — that is an external request that breaks the offline bundle and violates the "frontend calls nothing but the middleware" rule.

Install the `@fontsource` package matching `typography.fontFamily` (kebab-case) using the project's package manager, then import it in `main.tsx` so the bundler inlines it:

```tsx
// main.tsx — bundled, zero network requests
import "@fontsource/{font-family-kebab}/400.css";
import "@fontsource/{font-family-kebab}/500.css";
import "@fontsource/{font-family-kebab}/600.css";
import "@fontsource/{font-family-kebab}/700.css";
```
Then in CSS: `font-family: '{fontFamily}', sans-serif;`
If no matching `@fontsource` package exists, fall back to a system font stack — never a CDN link.

### Component Tokens
`components.*` entries define exact values for buttons, cards, inputs.
Apply them directly as inline styles or Tailwind classes:

```tsx
// button-primary from DESIGN.md
<button style={{
  backgroundColor: 'var(--color-primary)',
  color: 'var(--color-on-primary)',
  borderRadius: '{rounded.md}',
  padding: '10px 18px',
  fontWeight: 500
}}>
  Submit
</button>
```

---

## How to Add a New Theme

1. Create a folder under the appropriate category: `designs/{category}/{new-theme-name}/`
2. Add `DESIGN.md` — follow the token structure below
3. Add `README.md` — 2-3 sentences describing the visual style
4. Update the category's `README.md` to list the new theme

### Minimum DESIGN.md Structure

```yaml
---
version: alpha
name: Your Theme Name
description: One paragraph visual description.

colors:
  primary: "#hex"
  primary-hover: "#hex"
  on-primary: "#hex"
  background: "#hex"
  surface: "#hex"
  surface-raised: "#hex"
  text: "#hex"
  text-muted: "#hex"
  border: "#hex"
  semantic-success: "#hex"
  semantic-error: "#hex"
  semantic-warning: "#hex"

typography:
  heading:
    fontFamily: Font Name
    fontSize: 32px
    fontWeight: 700
    lineHeight: 1.2
  body:
    fontFamily: Font Name
    fontSize: 16px
    fontWeight: 400
    lineHeight: 1.6

rounded:
  sm: 4px
  md: 8px
  lg: 12px
  full: 9999px

components:
  button-primary:
    backgroundColor: "{colors.primary}"
    textColor: "{colors.on-primary}"
    rounded: "{rounded.md}"
    padding: "10px 20px"
  card:
    backgroundColor: "{colors.surface}"
    rounded: "{rounded.lg}"
    border: "1px solid {colors.border}"
  input:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.text}"
    rounded: "{rounded.md}"
    border: "1px solid {colors.border}"
    height: 44px
---

## Overview
...
```

---

## Categories at a Glance

| Category | Background | Accent | Best For |
|---|---|---|---|
| `dark/midnight-pro` | Near-black `#0d0d14` | Indigo `#6366f1` | AI tools, dev apps, creative tools |
| `dark/terminal-dark` | Pure black `#000000` | Neon green `#00ff88` | Terminal apps, hacker aesthetic, code tools |
| `light/clean-minimal` | White `#ffffff` | Slate blue `#4f6ef7` | SaaS, productivity, notes, docs |
| `light/warm-pastel` | Cream `#faf8f5` | Coral `#e8644d` | Lifestyle, community, personal apps |
| `e-commerce/modern-shop` | White `#ffffff` | Black `#111111` | Shopify-style stores, product catalogs |
| `e-commerce/luxury-market` | Deep navy `#0a0a14` | Gold `#c9a84c` | Premium goods, luxury brands, high-end retail |
| `dashboard/data-pro` | Dark slate `#0f172a` | Cyan `#06b6d4` | Analytics, metrics, monitoring, BI tools |
| `dashboard/analytics-light` | Off-white `#f8fafc` | Blue `#2563eb` | Reporting, admin panels, business dashboards |
| `corporate/enterprise-blue` | White `#ffffff` | Corporate blue `#1e40af` | B2B SaaS, enterprise tools, consulting |
| `corporate/professional-slate` | Light gray `#f1f5f9` | Navy `#1e293b` | Legal, finance, healthcare, professional services |
