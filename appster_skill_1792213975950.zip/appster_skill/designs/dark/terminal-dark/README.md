# Terminal Dark

Pure black background with neon green accent. Terminal/hacker aesthetic — raw, functional, high-contrast.

Best used for: CLI wrapper apps, code execution tools, developer playgrounds, security tools, anything that should feel like a real terminal.
