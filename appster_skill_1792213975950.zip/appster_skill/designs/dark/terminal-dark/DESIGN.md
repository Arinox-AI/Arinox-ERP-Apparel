---
version: alpha
name: Terminal Dark
description: Terminal Dark is a pure-black theme with neon green accent — the aesthetic of a real Unix terminal elevated to a UI. Background is true black ({colors.background}), text is terminal green ({colors.text}), and accents pulse with bright neon ({colors.primary}). Typography uses JetBrains Mono throughout for authentic terminal feel. Cards are borderless panels, inputs look like command prompts, and the entire design communicates raw technical capability. Best for code execution tools, CLI wrappers, hacker-aesthetic apps.

colors:
  primary: "#00ff88"
  primary-dim: "#00cc6a"
  primary-glow: "rgba(0, 255, 136, 0.15)"
  on-primary: "#000000"
  background: "#000000"
  surface: "#0a0a0a"
  surface-raised: "#111111"
  border: "#1a1a1a"
  border-active: "#00ff88"
  text: "#c8ffd4"
  text-bright: "#ffffff"
  text-muted: "#4a7a5a"
  text-dim: "#2a4a35"
  on-dark: "#c8ffd4"
  accent-yellow: "#ffdd00"
  accent-cyan: "#00ddff"
  accent-red: "#ff4455"
  semantic-success: "#00ff88"
  semantic-success-muted: "#001a0d"
  semantic-error: "#ff4455"
  semantic-error-muted: "#1a0008"
  semantic-warning: "#ffdd00"
  semantic-warning-muted: "#1a1600"

typography:
  display:
    fontFamily: JetBrains Mono
    fontSize: 42px
    fontWeight: 700
    lineHeight: 1.1
    letterSpacing: -1px
  heading-1:
    fontFamily: JetBrains Mono
    fontSize: 32px
    fontWeight: 700
    lineHeight: 1.15
  heading-2:
    fontFamily: JetBrains Mono
    fontSize: 24px
    fontWeight: 600
    lineHeight: 1.2
  heading-3:
    fontFamily: JetBrains Mono
    fontSize: 18px
    fontWeight: 600
    lineHeight: 1.3
  body:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: 400
    lineHeight: 1.7
  body-sm:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: 400
    lineHeight: 1.6
  button:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: 600
    lineHeight: 1.2
    letterSpacing: 0.5px
  prompt:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: 400
    lineHeight: 1.7
  output:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: 400
    lineHeight: 1.8

rounded:
  xs: 2px
  sm: 4px
  md: 4px
  lg: 6px
  xl: 8px
  full: 9999px

spacing:
  xs: 4px
  sm: 8px
  md: 12px
  lg: 16px
  xl: 20px
  xxl: 24px
  xxxl: 32px

components:
  button-primary:
    backgroundColor: "{colors.primary}"
    textColor: "{colors.on-primary}"
    typography: "{typography.button}"
    rounded: "{rounded.sm}"
    padding: "8px 16px"
    border: "none"
  button-primary-hover:
    backgroundColor: "{colors.primary-dim}"
    boxShadow: "0 0 12px {colors.primary-glow}"
  button-outline:
    backgroundColor: "transparent"
    textColor: "{colors.primary}"
    typography: "{typography.button}"
    rounded: "{rounded.sm}"
    padding: "8px 16px"
    border: "1px solid {colors.primary}"
  button-ghost:
    backgroundColor: "transparent"
    textColor: "{colors.text-muted}"
    typography: "{typography.button}"
    rounded: "{rounded.sm}"
    padding: "6px 12px"
    border: "1px solid {colors.border}"
  card:
    backgroundColor: "{colors.surface}"
    rounded: "{rounded.md}"
    border: "1px solid {colors.border}"
    padding: "16px"
  card-active:
    backgroundColor: "{colors.surface}"
    border: "1px solid {colors.primary}"
    boxShadow: "0 0 8px {colors.primary-glow}"
  terminal-block:
    backgroundColor: "{colors.background}"
    textColor: "{colors.text}"
    typography: "{typography.output}"
    rounded: "{rounded.sm}"
    border: "1px solid {colors.border}"
    padding: "16px"
  prompt-line:
    backgroundColor: "transparent"
    textColor: "{colors.text}"
    typography: "{typography.prompt}"
    padding: "4px 0"
    borderLeft: "2px solid {colors.primary}"
    paddingLeft: "12px"
  input:
    backgroundColor: "{colors.background}"
    textColor: "{colors.text}"
    typography: "{typography.prompt}"
    rounded: "{rounded.xs}"
    border: "1px solid {colors.border}"
    borderBottom: "1px solid {colors.primary}"
    padding: "8px 12px"
    height: 38px
  input-focused:
    border: "1px solid {colors.primary}"
    boxShadow: "0 0 6px {colors.primary-glow}"
  badge-success:
    backgroundColor: "{colors.semantic-success-muted}"
    textColor: "{colors.primary}"
    typography: "{typography.body-sm}"
    rounded: "{rounded.xs}"
    padding: "2px 8px"
    border: "1px solid {colors.primary-dim}"
  badge-error:
    backgroundColor: "{colors.semantic-error-muted}"
    textColor: "{colors.accent-red}"
    typography: "{typography.body-sm}"
    rounded: "{rounded.xs}"
    padding: "2px 8px"
    border: "1px solid {colors.accent-red}"
  status-bar:
    backgroundColor: "{colors.surface-raised}"
    textColor: "{colors.text-muted}"
    typography: "{typography.body-sm}"
    padding: "4px 12px"
    borderTop: "1px solid {colors.border}"
---

## Overview

Terminal Dark channels the aesthetic of a real Unix terminal — pure black background, phosphor-green text, monospace throughout. Unlike decorative dark themes, this one is **functional-first**: every component looks like it belongs in a real terminal environment. The neon green glow on interactive elements (`{colors.primary-glow}`) reinforces the CRT monitor aesthetic without being cartoonish.

**Key characteristics:**
- True black `#000000` base — uncompromising terminal aesthetic
- JetBrains Mono for ALL typography — no mixed fonts
- Neon green `#00ff88` primary — the phosphor signal
- Minimal border radius (2-4px) — square terminal geometry
- Glow effects on hover/focus using `{colors.primary-glow}`
- Prompt-line component for command-style UI patterns
- Status bar component for terminal footer

## Colors

- **Primary Green** (`{colors.primary}`): Interactive elements, active borders, success states
- **Primary Glow** (`{colors.primary-glow}`): Box shadow for glow effects
- **Background** (`{colors.background}`): True black — the terminal canvas
- **Surface** (`{colors.surface}`): Panels, cards — barely lighter than black
- **Text** (`{colors.text}`): Phosphor green text — muted, readable
- **Text Bright** (`{colors.text-bright}`): White for emphasis — use sparingly
- **Text Muted** (`{colors.text-muted}`): Secondary text, placeholders, inactive

## Typography

**JetBrains Mono** is used for EVERYTHING in this theme — it is the font. Load from Google Fonts.

## Components

### Terminal-specific
- `terminal-block`: Code/output display panel
- `prompt-line`: Sidebar or chat message with a left green border — command prompt style
- `status-bar`: Fixed footer bar with tiny text, like a real terminal statusline

### Buttons
- `button-primary`: Solid green fill — primary action
- `button-outline`: Transparent + green border — secondary action
- `button-ghost`: Subtle text-only button

### Inputs
- `input`: Minimal prompt-style input, bottom-border highlighted in green

## Do's and Don'ts

### Do
- Use JetBrains Mono for all text — it is the theme
- Use `{colors.primary-glow}` box-shadow on hover/active states for glow effect
- Use `prompt-line` pattern for user-input contexts (chat, code editors)
- Keep radius minimal (2-4px) — this theme does not use pill shapes

### Don't
- Don't use soft rounded corners (`{rounded.lg}` 12px+) — they break the terminal feel
- Don't mix Inter or other sans-serif fonts into this theme
- Don't use warm colors (orange, red backgrounds) — keep to green/cyan/yellow accents only
- Don't add decorative gradients or background patterns
