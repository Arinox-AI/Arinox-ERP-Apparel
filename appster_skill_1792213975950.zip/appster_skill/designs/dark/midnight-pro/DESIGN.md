---
version: alpha
name: Midnight Pro
description: Midnight Pro is a sophisticated dark theme anchored by a near-black background ({colors.background}) with indigo-violet as the primary accent ({colors.primary}). The palette uses multiple dark surface layers to create depth without harsh contrast — background, surface, and raised-surface each step up subtly. Typography uses Inter for a clean modern developer feel. Buttons are gently rounded pills, cards use subtle border + backdrop, and the overall aesthetic is premium-dark, used by tools like Raycast, Linear, and high-end dev tools.

colors:
  primary: "#6366f1"
  primary-hover: "#4f52e8"
  primary-muted: "#312e81"
  on-primary: "#ffffff"
  background: "#0d0d14"
  surface: "#13131f"
  surface-raised: "#1a1a2e"
  surface-hover: "#1f1f36"
  border: "#2a2a40"
  border-strong: "#3d3d5c"
  text: "#e8e8f0"
  text-muted: "#8888a8"
  text-subtle: "#5a5a7a"
  on-dark: "#ffffff"
  accent-purple: "#a78bfa"
  accent-cyan: "#22d3ee"
  accent-pink: "#f472b6"
  semantic-success: "#10b981"
  semantic-success-muted: "#064e3b"
  semantic-error: "#f43f5e"
  semantic-error-muted: "#4c0519"
  semantic-warning: "#f59e0b"
  semantic-warning-muted: "#451a03"

typography:
  display:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: 700
    lineHeight: 1.1
    letterSpacing: -1.5px
  heading-1:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: 700
    lineHeight: 1.15
    letterSpacing: -1px
  heading-2:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: 600
    lineHeight: 1.2
    letterSpacing: -0.5px
  heading-3:
    fontFamily: Inter
    fontSize: 22px
    fontWeight: 600
    lineHeight: 1.3
  heading-4:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: 600
    lineHeight: 1.4
  body-lg:
    fontFamily: Inter
    fontSize: 17px
    fontWeight: 400
    lineHeight: 1.65
  body:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: 400
    lineHeight: 1.6
  body-medium:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: 500
    lineHeight: 1.6
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: 400
    lineHeight: 1.5
  caption:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: 500
    lineHeight: 1.4
    letterSpacing: 0.3px
  button:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: 500
    lineHeight: 1.2
  code:
    fontFamily: JetBrains Mono, Fira Code, monospace
    fontSize: 13px
    fontWeight: 400
    lineHeight: 1.7

rounded:
  xs: 4px
  sm: 6px
  md: 8px
  lg: 12px
  xl: 16px
  xxl: 20px
  full: 9999px

spacing:
  xs: 4px
  sm: 8px
  md: 12px
  lg: 16px
  xl: 20px
  xxl: 24px
  xxxl: 32px
  section: 48px
  section-lg: 64px

components:
  button-primary:
    backgroundColor: "{colors.primary}"
    textColor: "{colors.on-primary}"
    typography: "{typography.button}"
    rounded: "{rounded.md}"
    padding: "10px 20px"
    border: "none"
  button-primary-hover:
    backgroundColor: "{colors.primary-hover}"
  button-secondary:
    backgroundColor: "transparent"
    textColor: "{colors.text}"
    typography: "{typography.button}"
    rounded: "{rounded.md}"
    padding: "10px 20px"
    border: "1px solid {colors.border-strong}"
  button-ghost:
    backgroundColor: "transparent"
    textColor: "{colors.text-muted}"
    typography: "{typography.button}"
    rounded: "{rounded.md}"
    padding: "8px 14px"
    border: "none"
  button-danger:
    backgroundColor: "{colors.semantic-error}"
    textColor: "#ffffff"
    typography: "{typography.button}"
    rounded: "{rounded.md}"
    padding: "10px 20px"
  card:
    backgroundColor: "{colors.surface}"
    rounded: "{rounded.lg}"
    border: "1px solid {colors.border}"
    padding: "{spacing.xl}"
  card-raised:
    backgroundColor: "{colors.surface-raised}"
    rounded: "{rounded.lg}"
    border: "1px solid {colors.border-strong}"
    padding: "{spacing.xl}"
  input:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.text}"
    typography: "{typography.body}"
    rounded: "{rounded.md}"
    border: "1px solid {colors.border}"
    padding: "{spacing.md} {spacing.lg}"
    height: 42px
  input-focused:
    border: "1px solid {colors.primary}"
    boxShadow: "0 0 0 3px rgba(99, 102, 241, 0.15)"
  badge:
    backgroundColor: "{colors.primary-muted}"
    textColor: "{colors.accent-purple}"
    typography: "{typography.caption}"
    rounded: "{rounded.full}"
    padding: "3px 10px"
  badge-success:
    backgroundColor: "{colors.semantic-success-muted}"
    textColor: "{colors.semantic-success}"
    typography: "{typography.caption}"
    rounded: "{rounded.full}"
    padding: "3px 10px"
  badge-error:
    backgroundColor: "{colors.semantic-error-muted}"
    textColor: "{colors.semantic-error}"
    typography: "{typography.caption}"
    rounded: "{rounded.full}"
    padding: "3px 10px"
  sidebar:
    backgroundColor: "{colors.surface}"
    border: "1px solid {colors.border}"
    width: 240px
  sidebar-item:
    backgroundColor: "transparent"
    textColor: "{colors.text-muted}"
    typography: "{typography.body-medium}"
    rounded: "{rounded.md}"
    padding: "8px 12px"
  sidebar-item-active:
    backgroundColor: "{colors.surface-raised}"
    textColor: "{colors.text}"
    border: "1px solid {colors.border-strong}"
  code-block:
    backgroundColor: "{colors.background}"
    textColor: "{colors.text}"
    typography: "{typography.code}"
    rounded: "{rounded.md}"
    border: "1px solid {colors.border}"
    padding: "{spacing.lg}"
---

## Overview

Midnight Pro uses a layered dark palette — three background levels (background → surface → surface-raised) create natural depth without heavy shadows. The indigo primary (`#6366f1`) functions as a crisp accent on dark surfaces while remaining accessible. Inter with tight negative letter-spacing gives headlines a sharp, modern feel. Code blocks and monospaced elements use `JetBrains Mono` to reinforce the developer context.

**Key characteristics:**
- Near-black base `#0d0d14` — dark enough to feel premium without pure black harshness
- Indigo primary that pops on dark backgrounds at WCAG AA ratio
- Three surface layers for natural depth: `background` → `surface` → `surface-raised`
- No heavy drop shadows — border-based card separation (`{colors.border}`)
- Rectangular-ish buttons (`{rounded.md}` = 8px) with optional pill badges
- Dense sidebar pattern with active state using `surface-raised`

## Colors

- **Primary Indigo** (`{colors.primary}`): Main CTA, active states, focus rings
- **Primary Hover** (`{colors.primary-hover}`): Button hover state
- **Primary Muted** (`{colors.primary-muted}`): Badge backgrounds, subtle highlights
- **Background** (`{colors.background}`): Page/app canvas — deepest dark level
- **Surface** (`{colors.surface}`): Cards, sidebar, panels — first layer up
- **Surface Raised** (`{colors.surface-raised}`): Hover states, modals, nested cards
- **Border / Border Strong** (`{colors.border}`, `{colors.border-strong}`): Card outlines; strong for interactive elements
- **Text** (`{colors.text}`): Primary body text — near-white `#e8e8f0`
- **Text Muted** (`{colors.text-muted}`): Secondary text, labels, inactive items
- **Text Subtle** (`{colors.text-subtle}`): Placeholders, disabled

## Typography

**Inter** (primary): Load via Google Fonts at weights 400, 500, 600, 700.
**JetBrains Mono** (code): Load via Google Fonts or CDN.

Negative letter spacing on display and heading sizes (-1px to -1.5px) gives headlines that compressed, premium feel.

## Components

### Buttons
- `button-primary`: Solid indigo, 8px radius — main CTA
- `button-secondary`: Transparent + strong border — secondary action
- `button-ghost`: Text only, muted — tertiary/icon buttons
- `button-danger`: Solid red — destructive actions

### Cards
- `card`: Standard panel with surface background + subtle border
- `card-raised`: Elevated panel for modals, popovers, highlighted content

### Inputs
- `input`: Surface background, border-separated, 42px height
- `input-focused`: Indigo border + translucent glow ring

### Badges
- `badge`: Indigo-muted background, purple text — default tag
- `badge-success` / `badge-error`: Green/red variants with muted backgrounds

### Sidebar
- `sidebar`: Fixed-width 240px panel with surface background
- `sidebar-item` / `sidebar-item-active`: Hover + active state using surface-raised

## Do's and Don'ts

### Do
- Use `{colors.primary}` for interactive elements, focus rings, and active states
- Layer surfaces: background → surface → surface-raised to create depth
- Use `{typography.code}` with JetBrains Mono for any code/terminal content
- Keep text at `{colors.text}` for primary content; mute secondary content

### Don't
- Don't use pure white (`#ffffff`) text — use `{colors.text}` (`#e8e8f0`) instead
- Don't use heavy box shadows on dark backgrounds — borders convey separation better
- Don't use `{colors.primary}` as a background for large areas
- Don't mix the indigo accent with warm accent colors (orange, yellow) in the same view
