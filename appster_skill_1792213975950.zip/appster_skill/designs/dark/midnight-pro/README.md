# Midnight Pro

Deep near-black background with indigo/violet accent. Sophisticated developer tool feel — elegant, focused, and premium without being aggressive.

Best used for: AI tools, dev dashboards, creative apps, coding environments, anything that needs to feel "pro" and modern.
