# Dark Themes

Dark-background UI themes. Best for developer tools, AI chat apps, creative tools, terminals, and any app where a dark aesthetic fits the audience.

## Themes

| Theme | Description |
|---|---|
| `midnight-pro` | Deep near-black background with indigo/violet accent. Sophisticated developer tool feel. Inspired by VS Code, Linear, Raycast. |
| `terminal-dark` | Pure black background with neon green accent. Terminal/hacker aesthetic. Good for code execution tools, CLI wrappers, matrix-style apps. |
