---
name: appster
category: fullstack-development
description: "Use this for ANY request to build or modify a fullstack web app (React frontend + Python/SQLite backend) — regardless of domain or complexity. Drives the full pipeline (requirements → spec → backend → frontend → QA) and produces a standard project structure with REQUIREMENTS.md, SPEC.md, a bundled index.html, and a QA report. Delegates phases to sub-agents when matching ones exist; otherwise the main agent does each phase inline. Specialized domain logic is built inline within the pipeline — never a reason to skip it."
---

# Appster — Complete Application Builder

> ⚠️ **THIS SKILL IS ACTIVE. YOU MUST USE IT FOR EVERY PROJECT REQUEST — new build or edit.**
> No exceptions. For any project creation or modification, follow this skill exactly.

> 🛑 **EVERY app gets KOGO SSO — see core-builder HARD RULE 0.** A user system (users table,
> `kogo_me`, `kogo_register_users`, the frontend gate) is built into every project, including
> static pages, one-screen tools and demos, and including when the user says login is not needed.
> Simplicity is never a reason to skip it.

> 🛑 **Domain complexity is NEVER a reason to bypass this skill.**
> The value of this skill is the **pipeline and its output artifacts** (REQUIREMENTS.md → SPEC.md → structured backend → bundled `index.html` → QA_REPORT.md) — NOT the sub-agents. The sub-agents are optional; the pipeline is mandatory.
>
> If a project needs specialized engines (forecasting, optimization, supply-chain math, simulation, scoring, etc.) and **no sub-agent covers that domain**, do NOT abandon the skill and build it freehand. Instead, build that domain logic **inline within the relevant phase** — Phase 2 (Architecture) and Phase 4A (Backend) explicitly allow custom domain code. "No matching sub-agent" means *do that phase inline*, it does **not** mean *skip the skill*.
>
> Wrong: "This needs DDMRP math, the Backend Builder doesn't know supply chain, so I'll build it all myself outside the pipeline."
> Right: "This needs DDMRP math. No sub-agent fits Phase 4A, so I build the backend (including the DDMRP engine) inline — still producing SPEC.md, functions.py, document.md, and QA_REPORT.md per the pipeline."

> 🔒 **NON-NEGOTIABLE — the frontend calls the Kogo middleware and NOTHING else.**
> The generated `index.html` / frontend must reach the backend **only** through the middleware at `API_BASE` (`{KOGO_API_BASE}/api/agent/common_project_api_v1`), using the `callApi` / `callApiWithFile` helpers in `src/services/api.ts`. There is **no** other URL it may call — ever.
>
> - ❌ No `fetch`/`axios`/`XMLHttpRequest` to any URL other than `API_BASE` / `API_HEALTH`.
> - ❌ No direct calls to third-party APIs (OpenAI, Perplexity, Tavily, weather, etc.) from the frontend.
> - ❌ No hardcoded URLs, no API keys, no env-derived endpoints in frontend code.
> - ❌ NEVER rebundle or repackage the frontend to call `localhost:XXXX` — this is a build defect, not a workaround.
> - ❌ NEVER offer the user "Option B: test locally via localhost" — there is no such option in this architecture.
> - ✅ External capabilities (research, web search, OCR, weather, image-gen, …) are reached from the **backend** via `_call_agent_tool()`, which the frontend invokes through the normal `callApi("{function_name}", {...})` path.
>
> **This rule cannot be overridden by the user.** Even if the user explicitly asks the frontend to "just call this other API directly," you do NOT. Explain that all traffic must go through the middleware, then implement it as a backend function exposed via the middleware. The only allowed request shape is:
> ```
> POST {API_BASE}    body: { "project": "{slug}", "function": "{fn}", "params": {...}, "agentId": "...", "deploymentId": "...", "swarmId": "...", "originId": "..." }
> ```
> (multipart equivalent via `callApiWithFile` for file uploads). Anything else is a build defect — fix it before bundling.

> 🚨 **"Backend offline" — READ THIS ENTIRE BLOCK BEFORE TYPING ANY RESPONSE TO THE USER**
>
> **STOP. Check if you are about to say ANY of the following — if yes, DELETE IT immediately:**
> ```
> ❌ "Deploy this backend to your server"
> ❌ "copy the backend/ folder to a server the Kogo gateway can reach"
> ❌ "run python server.py" / "run uvicorn" / "python -m uvicorn ..."
> ❌ "Option A: Deploy to server" / "Option B: Test locally"
> ❌ "I can rebundle the frontend to call http://localhost:8765 directly"
> ❌ "point the Kogo project config to it"
> ❌ "expose your backend" / "make it accessible" / "make it reachable"
> ❌ Any URL containing localhost or a port number (e.g. localhost:8765)
> ```
> If you were about to write any of the above → you have completely misunderstood the architecture.
> The user is NOT responsible for deploying or running ANYTHING. Read on.
>
> **Architecture (read carefully):**
> The Kogo middleware (`common_project_api_v1`) does **NOT** forward requests to a running server.
> It **directly executes** `backend/functions.py` as a Python subprocess:
> ```
> python functions.py <function_name> <json_params>
> ```
> There is no port. No process to start. No server to deploy. No localhost.
> The backend is a **collection of Python functions in a file** — nothing more, nothing less.
>
> **"Backend offline" means EXACTLY ONE of these 4 things — nothing else:**
> 1. `backend/functions.py` is missing from the project folder
> 2. `backend/document.md` is missing
> 3. Wrong `project` slug (doesn't match the folder name)
> 4. Wrong `originId` in `config.js` — `ORIGIN_ID` must be `SWARM_ID` (workspace) or `AGENT_ID` (direct)
>
> **Fix procedure — in order:**
> ```bash
> # 1. Confirm files exist
> ls {PROJECT_DIR}/backend/functions.py
> ls {PROJECT_DIR}/backend/document.md
>
> # 2. If missing — CREATE the file. That is the ENTIRE fix. Nothing else.
>
> # 3. Verify health check now shows the project
> curl "{API_HEALTH}?userId={USER_ID}&originId={ORIGIN_ID}&project={project_slug}"
> # → projects array must contain "{project_slug}"
> # → If slug is missing: functions.py does not exist or is empty — fix it
> ```
>
> **ABSOLUTE PROHIBITIONS — these apply at all times, not just when debugging:**
> - ❌ NEVER create `server.py`, `backend_api.py`, `app.py`, or any FastAPI/Flask/uvicorn file
> - ❌ NEVER run `uvicorn`, `flask run`, `python server.py`, or any server start command
> - ❌ NEVER suggest using `localhost:XXXX` or any port number
> - ❌ NEVER suggest "deploying" or "exposing" the backend
> - ❌ NEVER tell the user to run anything locally
> - ❌ NEVER offer alternative "options" that involve a server or localhost — there are no such options
> - ❌ NEVER modify `config.ts` or `api.ts` to point to localhost — the ONLY valid URL is `KOGO_API_BASE`
>
> If you find yourself writing any of the above — STOP. You have misunderstood the architecture. Re-read this block.

---

## Folder Structure

```
appster_skill/
├── SKILL.md                        ← You are here (master orchestrator)
└── sub-skills/                     ← Drop a new skill folder here to extend appster
    ├── core-builder/
    │   └── SKILL.md                ← Backend + frontend build rules (ALWAYS active)
    ├── chat-module/
    │   └── SKILL.md                ← Chat interface module
    ├── feature-module/
    │   └── SKILL.md                ← Analytics widgets (graphs, reports, summaries)
    ├── kogo-workspace/
    │   ├── SKILL.md                ← Workspace ops index (tasks, boards, members)
    │   └── features/
    │       └── team-tasks.md       ← Team task lists, subtasks, assign, status
    ├── backend-tester/
    │   └── SKILL.md                ← Phase 6 QA enhancer (replaces inline CLI tests)
    └── frontend-tester/
        └── SKILL.md                ← Phase 6B browser QA via Playwright (34 skills, 7 phases)
```

**Reference paths** (relative to userfiles/):
```
SCRIPTS_DIR  = skills/appster_skill/scripts
DESIGNS_DIR  = skills/appster_skill/designs
SUB_SKILLS   = skills/appster_skill/sub-skills
```

---

## 🔢 Execution Order (follow EXACTLY — this overrides document order)

The sections below are written in reading order, but they MUST execute in this exact sequence. Every read-only discovery step AND the requirements gate happen BEFORE anything is written to disk:

```
1. Step 1   — Sub-Agent Awareness      (READ-ONLY)
2. Step 0   — Discover sub-skills       (READ-ONLY)
3. Step 0A  — Detect configuration env  (READ-ONLY)
4. Step 0C  — Scan available tools       (READ-ONLY)
5. ⛔ STOP  — Gather Requirements        (ASK the user, then WAIT for answers)
6. Step 0B  — Create project directory   (WRITE — only after answers)
7. Step 0B.5— Capture config files       (WRITE — only after answers)
8. SDLC Phases 1 → 2 → 3 → 4A/4B → 5 → 6 → 6B (if frontend-tester active)
```

⛔ **Never create a directory or write any file (Step 0B / 0B.5 or any phase output) until the user has answered the requirements questions.** Discovery steps 0/0A/0C never write — they only read env vars, tools, and folders. The project name needed for Step 0B comes FROM the requirements answers, so writing earlier is impossible anyway.

---

## ⚡ Step 1 — Sub-Agent Awareness (Run FIRST, Before Anything Else)

**Check if `run_subagent` tool is in your toolset.**

### If `run_subagent` is NOT available:
Every phase will be done inline by you. Proceed to Step 0.

### If `run_subagent` IS available:
You have sub-agents. You know them — they are part of your context (created under your Sub-Agents tab).

**For each of your sub-agents, note:**
- Their name
- Their description / goal

Then build a **Phase → Sub-Agent map** in your head using the matching table below.

#### Phase Matching Table

**⛔ Do NOT judge "best fit", "semantic similarity", or "close enough" — that varies run to run.** Use the exact, repeatable procedure below so the SAME set of sub-agents ALWAYS produces the SAME map (identical across 100,000 runs).

#### Deterministic Matching Procedure

1. **Candidate list** = your sub-agents in the exact order they appear in your context (Sub-Agents tab). This order is your fixed tie-break — never reorder it.
2. **For each phase below, in order (1, 3, 4A, 4B, 5, 6):** scan the candidate list top-to-bottom and assign the **FIRST** sub-agent whose name OR goal text contains (case-insensitive substring) **ANY** of that phase's match-keywords. Stop at the first hit. Do not evaluate "which is better" — first hit in list order wins.
3. A sub-agent MAY be assigned to more than one phase. If the same sub-agent is assigned to consecutive phases (e.g. Phase 1 + Phase 3), call it ONCE with a combined task.
4. If **NO** candidate contains any of a phase's keywords → that phase is **INLINE** (you do it yourself). Never assign on a hunch or "partial vibe".
5. **Phase 2 (Architecture) is ALWAYS inline — never delegated.**
6. **Phase 4A + 4B may run in parallel** via `run_subagents_parallel` ONLY if step 2 assigned a sub-agent to each.
7. **Never skip a phase:** every phase completes via a sub-agent or inline. The project must be 100% built.

#### Phase Match-Keywords (case-insensitive substring in the sub-agent's name OR goal)

| Phase | Match-keywords |
|---|---|
| **Phase 1 — Requirements** | `requirement`, `analyst`, `analyze`, `gather`, `understand` |
| **Phase 3 — Planning** | `plan`, `planner`, `spec`, `specification`, `schema` |
| **Phase 4A — Backend** | `backend`, `python`, `database`, `sqlite`, `server`, `api` |
| **Phase 4B — Frontend** | `frontend`, `react`, `component`, `typescript`, `css`, `ui`, `style` |
| **Phase 5 — Feature Inject** | `integrat`, `inject`, `module`, `feature` |
| **Phase 6 — QA** | `qa`, `test`, `verif`, `quality`, `bug` |

> A sub-agent named e.g. "Builder" with goal "builds complete projects" contains neither `backend`/`python` nor `frontend`/`react` keywords → it does NOT match Phase 4A/4B by this rule → those phases go inline. If you want such an agent used, give it a goal containing the keywords above. Keyword presence, not vibes, decides.

---

## Step 0 — Discover Capabilities (run silently)

```bash
pwd   # → {PWD} = /app/kogo-data/user/{userId}/{agentId}/userfiles

ls {PWD}/skills/appster_skill/sub-skills/
# For EACH folder: read SKILL.md → extract name, keyword_triggers, provides.*
```

**Activate sub-skills** that match the user's request:

| Sub-skill | Always? | Activate when user mentions… |
|---|---|---|
| `core-builder` | YES | (always) |
| `chat-module` | NO | chat, conversation, messaging, talk to agent, threads |
| `feature-module` | NO | analytics, graph, chart, report, summary, dashboard, query, data insights |
| `kogo-workspace` | NO | workspace, task, tasks, task list, task board, assign task, team task, to-do, todo, sprint, backlog, work item, my tasks |
| `backend-tester` | YES | (always — Phase 6 backend QA is mandatory) |
| `frontend-tester` | NO | frontend test, ui test, browser test, playwright, e2e test |
| `[future skill]` | NO | check its `keyword_triggers` |

> 🚫 **A feature owned by an ACTIVE sub-skill is NOT a local SQLite entity — build it ONLY via that sub-skill.**
> When a sub-skill is activated, that sub-skill *owns* its feature end-to-end (backend functions + UI). You MUST
> read that sub-skill's SKILL.md and use its functions verbatim. Do NOT re-implement the feature yourself:
> - **`chat-module` active** → do NOT create a `messages` table; use its chat functions.
> - **`kogo-workspace` active** (team tasks) → do NOT create a `tasks`/`TaskModel` SQLite table, do NOT invent
>   a status set (todo/in_progress/done/blocked) or a from-scratch Kanban. Team tasks live on the **real KOGO
>   workspace API** with a fixed **List → Task → Subtask** hierarchy (statuses `todo/in_review/completed/qc_completed`).
>   Use kogo-workspace's `get_task_lists`/`get_tasks`/`create_task`/… functions; a task cannot exist without a list.
>
> Only build local SQLite tables/CRUD for features that **no active sub-skill owns** (e.g. a plain Notes feature).
> In SPEC.md, list sub-skill-owned features under "Active Sub-Skills" — never under local Entities/Base Functions.

---

## Step 0A — Detect Configuration

```bash
echo ${KOGO_API_BASE}   # → API_BASE (for frontend config.ts) — use EXACTLY as provided, never a hardcoded fallback
echo ${API_PATH:-}                             # → API_PATH  (backend uses this to call any Kogo gateway API)
echo ${TOOL_URL:-}                             # → TOOL_URL  (MIDDLEWARE-internal: pi-api's /call_tool proxies to this; backend does NOT read it — _call_agent_tool uses KOGO_API_BASE/.../call_tool)
echo ${CHAT_API_PATH:-}                        # → CHAT_API_PATH (used by the chat module; if empty, derive from API_PATH)
echo ${DEPLOYMENT_ID:-}                        # → DEPLOYMENT_ID (critical for chat/analytics)
echo ${SWARM_ID:-}                             # → SWARM_ID (may be empty)
echo ${USER_JWT_TOKEN:-}                       # → confirms JWT is available
pwd
# USER_ID  = segment after /user/  in pwd output
# AGENT_ID = segment after USER_ID in pwd output
```

**Capture all values — you will need them in config.py, config.ts, SPEC.md, and ARCHITECTURE.md.**

If `DEPLOYMENT_ID` is empty and the project includes chat or analytics features → **stop and ask the user**:
> "This project needs an AI deployment. What is your Deployment ID? (Find it in your Kogo dashboard under Deployments)"

Do NOT proceed with chat/analytics features if `DEPLOYMENT_ID` is empty.

---

## Step 0B — Create Project Directory

⛔ **Do NOT run this step until the requirements gate (below) is satisfied and the user has answered.** This is the FIRST step that writes to disk — see the Execution Order block above.

```bash
mkdir -p {PWD}/artifacts/{project-name}/backend/data
mkdir -p {PWD}/artifacts/{project-name}/frontend/src
# PROJECT_DIR = {PWD}/artifacts/{project-name}
# SCRIPTS_DIR = {PWD}/skills/appster_skill/scripts
# DESIGNS_DIR = {PWD}/skills/appster_skill/designs
```

### Step 0B.5 — Capture Config Files

**⛔ CRITICAL:** `config.js` (frontend runtime config) MUST be written NOW with actual env values — this happens in **core-builder Step 6B** during the build phase. `config.py` uses `os.environ.get()` at runtime (middleware injects values from request). `config.ts` uses `window.APP_CONFIG` (reads from `config.js`). Do NOT hardcode IDs anywhere.

**Step 1 — Read env values once (for documentation / ARCHITECTURE.md):**

```bash
# Layer 2 — read EXACTLY from env, never hardcode a host. (The host differs per environment,
# e.g. uatos vs os — substituting a literal value will be wrong and may leak into config/output.)
API_PATH_VAL="${API_PATH}"           # backend → call any Kogo gateway API
TOOL_URL_VAL="${TOOL_URL}"           # MIDDLEWARE-internal only: pi-api's /call_tool proxies to this. Backend never reads it (uses KOGO_API_BASE/.../call_tool).

# CHAT_API_PATH is its own env var (used by the chat module). Use it as-is.
# Only if it is empty, derive from API_PATH: strip trailing /gateway, append /chatai.
CHAT_API_PATH_VAL="${CHAT_API_PATH:-${API_PATH%/gateway}/chatai}"

# Layer 1 (ONLY available now — gone after build):
AGENT_ID_VAL="${AGENT_ID}"
DEPLOYMENT_ID_VAL="${DEPLOYMENT_ID}"
SWARM_ID_VAL="${SWARM_ID}"           # may be "null" or empty
USER_ID_VAL="${USER_ID}"             # project creator user id

# ─── Effective Agent ID for config.ts ──────────────────────────────────────────
# In workspace context: files are stored under SWARM_ID path (NOT AGENT_ID).
# The health check and all API calls must use the ID that matches the file path.
# Rule: use SWARM_ID when non-empty and not "null"; otherwise use AGENT_ID.
#
# Direct agent: SWARM_ID="" → EFFECTIVE_AGENT_ID = AGENT_ID
# Workspace:    SWARM_ID="abc123" → EFFECTIVE_AGENT_ID = SWARM_ID (files live here)
if [ -z "${SWARM_ID}" ] || [ "${SWARM_ID}" = "null" ]; then
  EFFECTIVE_AGENT_ID_VAL="${AGENT_ID}"
else
  EFFECTIVE_AGENT_ID_VAL="${SWARM_ID}"
fi

# Frontend API base — use KOGO_API_BASE EXACTLY as the environment provides it. NO hardcoded fallback.
API_BASE_VAL="${KOGO_API_BASE}"
# ⛔ Never substitute a literal host (localhost, agent.kogo.ai, etc.) into config.ts or print it to the user.
# If KOGO_API_BASE is empty, STOP and ask the user for the correct API base — do not invent one.
```

**Step 2 — Write `{PROJECT_DIR}/backend/config.py`:**

```python
"""{Project Name} — Configuration constants."""

import os as _os

PROJECT_SLUG    = "{project_slug}"

AGENT_ID        = _os.environ.get("AGENT_ID")        or ""
DEPLOYMENT_ID   = _os.environ.get("DEPLOYMENT_ID")   or ""
USER_ID         = _os.environ.get("USER_ID")          or ""
SWARM_ID        = _os.environ.get("SWARM_ID")        or ""
KOGO_API_BASE   = _os.environ.get("KOGO_API_BASE")   or ""
API_PATH        = _os.environ.get("API_PATH")        or ""
TOOL_URL        = _os.environ.get("TOOL_URL")        or ""
CHAT_API_PATH   = _os.environ.get("CHAT_API_PATH")   or ""
```

**Step 3 — Write `{PROJECT_DIR}/frontend/src/config.ts`:**

```typescript
// {Project Name} — Frontend configuration (reads from window.APP_CONFIG set by config.js)
const _cfg = (window as any).APP_CONFIG || {};

// API_BASE / API_HEALTH are FULL URLs — config.js already bakes the complete path
// (KOGO_API_BASE + /api/agent/common_project_api_v1), and pi-api rewrites config.js with the
// full URL at serve/install time. Use them VERBATIM — do NOT append the path again (that
// double-prefixes → .../common_project_api_v1/api/agent/common_project_api_v1/health).
export const API_BASE       = _cfg.API_BASE       || "";
export const API_HEALTH     = _cfg.API_HEALTH     || "";
export const PROJECT: string = _cfg.PROJECT       || "{project_slug}";
export const USER_ID: string = _cfg.USER_ID       || "";
// The 3 identity ids are ALWAYS distinct — never equal, never derived from one another.
export const AGENT_ID: string      = _cfg.AGENT_ID      || "";
// DEPLOYMENT_ID: distinct from AGENT_ID — do NOT fall back to it (would mask a missing value).
export const DEPLOYMENT_ID: string = _cfg.DEPLOYMENT_ID || "";
export const SWARM_ID: string      = _cfg.SWARM_ID      || "";
export const ORIGIN_ID: string     = _cfg.ORIGIN_ID     || "";
```

> ⛔ NEVER hardcode AGENT_ID, DEPLOYMENT_ID, SWARM_ID, ORIGIN_ID, or any URL into config.ts.
> All values come from `window.APP_CONFIG` which is set by `config.js` at creation time
> and overwritten at AI software install time with the workspace's IDs.

---

## Step 0C — Scan Available Tools (run silently, before Phase 3)

Look at your tool list directly — no bash, no API calls needed. You can see your tools in your context.

For each tool you have, read:
- **Exact name** (as it appears in your tool list — this exact string goes into `_call_agent_tool()`)
- **Description** (to decide if it matches a project requirement)
- **Input params** (exact param names + types)

Match tools to user requirements. Write down each match as:
```
project_function_name | exact_tool_name | param1: type, param2: type
Example: get_weather    | GetWeatherInfo    | city: str
Example: do_research    | PerplexitySearch  | query: str
Example: extract_pdf    | MistralOCR        | file_path: str
Example: search_web     | TavilySearch      | query: str
```

This becomes the **Tool Proxy Map** — pass it to project-planner in Phase 3.
If no tools match the project → write `none`.

**Rules:**
- API keys, URLs, env var suffixes → ignore. The proxy handles all auth automatically.
- Never ask the user about tools — match automatically from your tool list.
- Tool functions in Python use `_call_agent_tool()` — never raw API calls.

**⛔ CRITICAL — Never use external API keys directly:**
If the agent has a tool for a capability (research, web search, PDF, weather, image generation, etc.),
**ALWAYS use `_call_agent_tool`** — never call Perplexity, Tavily, OpenAI, etc. APIs directly.
Direct API calls require hardcoded keys and break billing/auth — the proxy handles everything.

Example: if user wants a "Research tab" and the agent has `PerplexitySearch` tool:
```
# CORRECT — use the tool via proxy
def do_research(db, query: str) -> dict:
    return _call_agent_tool("PerplexitySearch", {"query": query})

# WRONG — never do this
import requests
resp = requests.get("https://api.perplexity.ai/...", headers={"Authorization": "pplx-..."})
```

---

## ⛔ STOP — Gather Requirements First

**Before running ANY phase of the SDLC pipeline, you MUST ask the user clarifying questions.**

Do NOT start building, do NOT create directories, do NOT write any files until you have received the user's answers.

### What to Ask

Look at the user's request. If ANY of these are unclear or unspecified, ask about them:

1. **Core features** — What exactly should the app do? List the specific features they want (e.g. for a todo app: due dates? priority levels? categories/tags? subtasks? recurring tasks?)
2. **Users** — Who uses this app? Just themselves (personal), a team, or end customers?
3. **Design style** — What look and feel? (options: dark/sleek, light/clean, corporate/professional, colorful/modern, minimal)
4. **Extras** — Do they want: chat with an AI agent? analytics/reports/graphs? file uploads? any specific tools or integrations?
5. **Scale** — Is this a simple prototype or a production-ready app?

### How to Ask

Compose your questions as a **single conversational message** — not a numbered form. Be friendly and concise. Example:

> Before I start building, let me ask a few quick questions so I build exactly what you need:
>
> 1. **Features**: Beyond basic add/complete/delete tasks — do you want due dates, priority levels, categories/tags, or subtasks?
> 2. **Users**: Is this for personal use or will multiple users share it?
> 3. **Design**: Any preference on style? Dark theme, light and minimal, colorful, corporate?
> 4. **Extras**: Do you want an AI chat feature, analytics/graphs, or any tool integrations?
>
> Feel free to say "keep it simple" for any of these — I'll use sensible defaults.

### When to Skip Questions

Only skip if the user's request already answers everything:
- Already specifies features in detail ("todo app with categories, due dates, and priority")
- Already specifies design ("dark theme")
- Already specifies extras ("no chat, no analytics, just basic CRUD")

If the request is vague (e.g. "I need a todo app" / "build me a CRM" / "make a dashboard") → **ALWAYS ask first.**

### After Receiving Answers

Once the user has replied → proceed to SDLC pipeline below.

---

## SDLC Pipeline

For each phase: **check your Phase → Sub-Agent map → delegate or inline.**

---

### Phase 1 — Requirements

**What must happen:** Using the user's answers from the requirements gathering above, decide project name, entities, features needed, pages, design preference. Produce `REQUIREMENTS.md`.

**[DELEGATE]** — if you have a sub-agent suited for requirements/analysis/planning:

```
run_subagent(
  agent_name = "{best matching sub-agent name}",
  task = """
User request (verbatim): {user_request}
User's answers to clarifying questions: {user_answers}

Project directory: {PROJECT_DIR}
Active sub-skills detected: {list — e.g. core-builder, chat-module}

Using the user's request AND their answers above, write REQUIREMENTS.md at: {PROJECT_DIR}/REQUIREMENTS.md

REQUIREMENTS.md must include:
- Project name (kebab-case) and slug (snake_case)
- Purpose: what does this app do, who uses it
- Entities: every data object with all fields, types, required/optional
- Features needed: Basic CRUD / Chat / Analytics / File upload (check each from user's answers)
- Pages and tabs needed (include chat tab if chat feature, analytics tab if analytics feature)
- Design preference (from user's answers, or "agent to decide" if user said no preference)

Be decisive — make sensible defaults for anything still unspecified. Do NOT ask further questions.
  """
)
```

**[INLINE]** — no matching sub-agent. Use the user's request + their answers to the clarifying questions. Write REQUIREMENTS.md directly:

```markdown
# {Project Name} — Requirements

## Project
- Name: {project-name}
- Slug: {project_slug}
- Purpose: {what it does, who uses it}

## Entities
{every data entity — all fields, types, required/optional}

## Features
- [x/ ] Basic CRUD
- [x/ ] Chat with agent        ← activate if user mentioned chat/conversation
- [x/ ] Analytics / graphs     ← activate if user mentioned graphs/analytics/data
- [x/ ] File upload

## Pages / Tabs
{all pages — include chat tab and analytics tab if those features are active}

## Design Preference
{from user, or "agent to decide"}
```

---

### Phase 2 — Architecture (Always Inline — Main Agent Decides)

Read REQUIREMENTS.md. Decide:

**1. Sub-skills to activate:**
```bash
ls {PWD}/skills/appster_skill/sub-skills/
# Read each SKILL.md, match keyword_triggers to REQUIREMENTS.md
```

**2. Pick design template:**
```bash
ls {DESIGNS_DIR}/
# Read README.md of closest 3–5 templates → pick ONE best match
cp {DESIGNS_DIR}/{chosen}/DESIGN.md {PROJECT_DIR}/DESIGN.md
# Update only the `name:` field in copied DESIGN.md — do NOT change colors/tokens
```

**3. Write `{PROJECT_DIR}/ARCHITECTURE.md`:**

```markdown
# {Project Name} — Architecture

## Active Sub-Skills
- core-builder: always
- chat-module: yes/no — {reason}
- feature-module: yes/no — {reason}

## Design Template: {folder-name}

## Entities: {list}

## Base Functions (CRUD only — sub-skill functions added in Phase 5)
{list function names}

## Pages / Tabs
{list — mark sub-skill tabs as PLACEHOLDER}

## Step 0A Values
- API_BASE: {api_base}
- API_PATH: {api_path — from env, exactly as provided (backend → call Kogo gateway APIs)}
- TOOL_URL: {tool_url — from env, exactly as provided (MIDDLEWARE-internal: /call_tool proxies to this; backend never reads it)}
- CHAT_API_PATH: {chat_api_path — from env; if empty, derived from API_PATH (used by chat module)}
- USER_ID: {userId}
- AGENT_ID: {agentId}
- DEPLOYMENT_ID: {deployment_id — from env, required for chat/analytics}
- SWARM_ID: {swarm_id — from env, may be null}
- PROJECT_DIR: {PROJECT_DIR}
- SCRIPTS_DIR: {SCRIPTS_DIR}
- DESIGNS_DIR: {DESIGNS_DIR}
```

---

### Phase 3 — Planning

**What must happen:** Create complete `SPEC.md` — every entity, every function with exact signature, every page, Step 0A values embedded.

**[DELEGATE]** — if you have a sub-agent suited for planning/specification/SPEC.md:

> **If this sub-agent also handled Phase 1** (same sub-agent matched both): it already wrote REQUIREMENTS.md — give it the combined task of REQUIREMENTS + SPEC in one call. Do not call it twice.
>
> **If this is a different sub-agent than Phase 1**: REQUIREMENTS.md already exists — instruct it to read that file.

```
run_subagent(
  agent_name = "{best matching sub-agent name}",
  task = """
Project directory: {PROJECT_DIR}
REQUIREMENTS.md: {PROJECT_DIR}/REQUIREMENTS.md   ← already written, read this
ARCHITECTURE.md: {PROJECT_DIR}/ARCHITECTURE.md   ← already written, read this
DESIGNS_DIR: {DESIGNS_DIR}
Active sub-skills: {list from ARCHITECTURE.md}
Tool Proxy Map (from Step 0C scan): {tool map or "none"}

Create SPEC.md at exactly: {PROJECT_DIR}/SPEC.md
DESIGN.md already exists at {PROJECT_DIR}/DESIGN.md — do NOT overwrite it.

SPEC.md format (use this exact structure):

# {Project Name} — Specification

## Meta
- Project name: {project-name}
- Project slug: {project_slug}
- Absolute project directory: {PROJECT_DIR}

## Step 0A Values
- API_BASE: {api_base}
- USER_ID: {userId}
- AGENT_ID: {agentId}
- DEPLOYMENT_ID: {deployment_id}
- SCRIPTS_DIR: {SCRIPTS_DIR}

## Tool Proxy Map
(copy exactly from what was passed — backend-builder uses these values as-is)
(write "none" if no tools fit this project)
### {project_function_name}
- Tool name: {exact_tool_name}
- Params: {param_name}: {param_type}
- Call: `_call_agent_tool("{exact_tool_name}", {{"{param_name}": value}})`

## Entities
### {Entity}
| Field | Type | Required | Default | Description |
(all fields including id, created_at, updated_at)

## Functions
### function_name(param: type = default, ...) → return_shape
(cover ALL standard CRUD: get_{entities}, get_{entity}, create_{entity}, update_{entity}, delete_{entity})
(for update_: list EVERY updatable field explicitly)
(for file-processing: note file_name + file_path — file_path is server-injected, never from frontend)
(for tool-calling functions — add these two extra lines):
  Tool: {exact_tool_name} — calls _call_agent_tool("{exact_tool_name}", {{param: value}})
  UI form inputs: {param1} (text/textarea/file), {param2} (...)
Show a JSON example of the return shape for each function.

## Pages
### Page Name
- Purpose: ...
- Functions called: function_name(param, ...) → what it shows
- Key UI elements: ...

## Design
- Aesthetic: {specific — e.g. "dark slate, cyan accent, monospace metrics"}
- Font: {specific font name from DESIGN.md}
- Color scheme: {from DESIGN.md tokens}
  """
)
```

**[INLINE]** — no matching sub-agent, write SPEC.md directly using REQUIREMENTS.md + ARCHITECTURE.md.

---

### Phase 4 — Core Build

#### Before starting Phase 4:

Check your sub-agent map:
- Have a backend sub-agent AND a frontend sub-agent? → **run both in parallel**
- Have only one of them? → **delegate that one, do the other inline**
- Have neither? → **do both inline (backend first, then frontend)**

---

#### Phase 4A — Backend

**What must happen:** Build `database.py`, `models.py`, `functions.py`, `document.md`, `seed.py`. CLI-test every function.

**[DELEGATE]** — if you have a sub-agent suited for backend/Python/database/API:

```
run_subagent(
  agent_name = "{best matching sub-agent name}",
  task = """
Project directory: {PROJECT_DIR}
SPEC.md: {PROJECT_DIR}/SPEC.md
Core builder rules: {PWD}/skills/appster_skill/sub-skills/core-builder/SKILL.md

Read SPEC.md and core-builder/SKILL.md PART 1 fully before writing any code.

Build inside {PROJECT_DIR}/backend/:
  database.py  — SQLite setup, self-contained, DB in data/ subdir
  models.py    — SQLAlchemy models, own Base class, to_dict() on every model
  functions.py — all CRUD functions + tool-backed functions + FUNCTIONS dict + call_function() + CLI mode
                 + the KOGO SSO block: users table, _current_user(), kogo_me(), kogo_register_users()
                 (core-builder → "File: functions.py — KOGO SSO block". MANDATORY: it is what gives
                 the app auto-login, roles and access control. KOGO detects support by finding
                 kogo_register_users in document.md — undocumented means unsupported.)
  document.md  — complete API reference (schema + every function documented, kogo_* included)
  seed.py      — 5–10 realistic demo items, check for existing data first

Read SPEC.md FULLY before writing any code. Then:

1. Build ALL functions from SPEC.md ## Functions section:
   A. Base CRUD functions (get/create/update/delete for each entity)
   B. Tool-Backed Functions — check `## Tool Proxy Map` in SPEC.md:
      - If "none" → skip, write normal Python for all functions
      - If tools listed → for each entry:
          • Add `_call_agent_tool` helper at top of functions.py (from core-builder SKILL.md)
          • Write function as: `return _call_agent_tool("exact_tool_name", {"param": value})`
          • Use exact_tool_name and param names directly from Tool Proxy Map — as-is
          • ⛔ NO custom HTTP code, NO API keys, NO TOOL_BASE constants, NO requests.get to external APIs
          • The proxy handles all auth — Python only passes tool name + params

Do NOT add chat or feature-module functions (Phase 5 handles those).
CLI-test every function until all pass:
  cd {PROJECT_DIR}/backend
  python functions.py get_{entities} '{}'
  python functions.py create_{entity} '{"name":"Test"}'
Run seed.py after all tests pass.
ALL files inside {PROJECT_DIR}/ only.
  """
)
```

**[INLINE]** — no matching sub-agent. Read `sub-skills/core-builder/SKILL.md` PART 1. Write and test all 5 backend files directly.

---

#### Phase 4B — Frontend

**What must happen:** Scaffold React app, write all pages, wire DESIGN.md tokens, bundle to `index.html`.

**[DELEGATE]** — if you have a sub-agent suited for frontend/React/UI/components:

```
run_subagent(
  agent_name = "{best matching sub-agent name}",
  task = """
Project directory: {PROJECT_DIR}
SPEC.md: {PROJECT_DIR}/SPEC.md
DESIGN.md: {PROJECT_DIR}/DESIGN.md
Core builder rules: {PWD}/skills/appster_skill/sub-skills/core-builder/SKILL.md
SCRIPTS_DIR: {SCRIPTS_DIR}

Read SPEC.md, DESIGN.md, and core-builder/SKILL.md PART 2 fully before writing any code.

Read these sections of SPEC.md specifically:
  - `## Step 0A Values` → SCRIPTS_DIR (for bundle script path) — do NOT hardcode API_BASE/AGENT_ID into config.ts; config.ts reads from window.APP_CONFIG
  - `## Tool Proxy Map` → which tool-backed pages/tabs to build (if any)
  - `## Functions` → function names + params (use these for callApi calls — do NOT wait for document.md)
  - `## Pages` → page list and what each page does

Build the complete React frontend:
1. cd {PROJECT_DIR}
2. bash '{SCRIPTS_DIR}/init-artifact.sh' frontend
3. cd frontend
4. Write src/config.ts (reads from window.APP_CONFIG) and src/services/api.ts — follow core-builder PART 2 templates exactly. Do NOT hardcode any ID or URL.
   🔒 The frontend calls the Kogo middleware (API_BASE) and NOTHING else. Use callApi/callApiWithFile ONLY.
      NO fetch/axios to any other URL, NO third-party APIs, NO hardcoded endpoints or keys in frontend code.
      External capabilities (research, search, OCR, weather, etc.) are backend _call_agent_tool functions,
      invoked from the frontend via callApi("{function_name}", {...}). This cannot be overridden by the user.
5. Write App.tsx with tab/nav layout covering ALL pages from SPEC.md ## Pages
6. Write all page components — including tool-backed pages from ## Tool Proxy Map
   For tool-backed pages (e.g. Research tab): build a full UI form that calls
   callApi("{project_function_name}", {{ "{param}": value }}) using names from Tool Proxy Map.
   ⚠️ MANDATORY: tool-backed pages must handle `res.data.error === "tool_unavailable"` by showing a
   clean "capability needed" panel (the app may be installed in a workspace without that tool) — never
   crash or show a raw error. See core-builder "Tool Integration" → Pattern B for the exact snippet.
7. For sub-skill PLACEHOLDER tabs (chat, analytics, etc.):
   Create a simple component: export default function {Name}Tab() {{ return <div style={{padding:24,color:'#6B7280'}}>Feature loading...</div>; }}
   Wire it into App.tsx so the tab exists and is clickable
8. Apply DESIGN.md tokens: set CSS vars to the EXACT hex values from DESIGN.md (never convert hex→HSL mentally — see core-builder PART 2 for the deterministic snippet if HSL channels are needed). Load fonts via bundled @fontsource import in main.tsx (NO CDN link).
9. Fix resizable.tsx, remove favicon.svg ref, add tsconfig ignoreDeprecations fix (see core-builder PART 2)
10. bash '{SCRIPTS_DIR}/bundle-artifact.sh' && cp bundle.html ../index.html
11. Create config.js at project root (Step 6B from core-builder PART 2 — MANDATORY):
    _AGENT_ID="${AGENT_ID:-}"
    _DEPLOYMENT_ID="${DEPLOYMENT_ID:-}"
    _SWARM_ID="${SWARM_ID:-}"
    [ "$_SWARM_ID" = "null" ] && _SWARM_ID=""
    _ORIGIN_ID="${_SWARM_ID:-${_AGENT_ID}}"
    _API_BASE="${KOGO_API_BASE:-}/api/agent/common_project_api_v1"
    _API_HEALTH="${KOGO_API_BASE:-}/api/agent/common_project_api_v1/health"
    cat > ../config.js << CONFIG
    (function(){window.APP_CONFIG={API_BASE:'${_API_BASE}',API_HEALTH:'${_API_HEALTH}',PROJECT:'{project_slug}',AGENT_ID:'${_AGENT_ID}',DEPLOYMENT_ID:'${_DEPLOYMENT_ID}',SWARM_ID:'${_SWARM_ID}',ORIGIN_ID:'${_ORIGIN_ID}'};})();
    CONFIG
12. Inject <script src="./config.js"> as FIRST script in ../index.html (Step 6C from core-builder PART 2 — MANDATORY)
13. rm -rf node_modules dist bundle.html .parcel-cache
14. rm -f src/assets/react.svg src/assets/vite.svg vite.config.ts README.md
ALL files inside {PROJECT_DIR}/ only.
  """
)
```

**[INLINE]** — no matching sub-agent. Read `sub-skills/core-builder/SKILL.md` PART 2. Build and bundle frontend directly.

---

### Phase 5 — Feature Integration

**What must happen:** For each active sub-skill (besides core-builder), inject its backend functions + frontend component into the existing project, then rebuild.

Skip this phase entirely if only `core-builder` is active.

For **each active sub-skill**, run sequentially (each rebuild after the previous inject):

**[DELEGATE]** — if you have a sub-agent suited for feature integration/module injection:

```
run_subagent(
  agent_name = "{best matching sub-agent name}",
  task = """
Project directory: {PROJECT_DIR}
Sub-skill to integrate: {sub-skill-name}
Sub-skill SKILL.md: {PWD}/skills/appster_skill/sub-skills/{sub-skill-name}/SKILL.md
SCRIPTS_DIR: {SCRIPTS_DIR}

Read the sub-skill SKILL.md fully — follow its "## Module Integration Steps" exactly:

Step 1 — Backend:
  Read existing {PROJECT_DIR}/backend/functions.py first
  Append backend functions block to functions.py
  Register new function names in FUNCTIONS dict
  Do NOT remove or overwrite any existing functions

Step 2 — Frontend Component:
  Create component file at {PROJECT_DIR}/frontend/src/components/{ComponentName}.tsx

Step 3 — API Layer:
  Append additions to {PROJECT_DIR}/frontend/src/services/api.ts

Step 4 — App Integration:
  In {PROJECT_DIR}/frontend/src/App.tsx, replace the placeholder for this sub-skill's tab
  with the real component import and render

Step 5 — Document:
  Append new function docs to {PROJECT_DIR}/backend/document.md

Rebuild after injecting:
  cd {PROJECT_DIR}/frontend
  bash '{SCRIPTS_DIR}/bundle-artifact.sh' && cp bundle.html ../index.html
  # Re-inject config.js script tag (cp overwrites index.html, tag must be re-added):
  node -e "
  const fs=require('fs');
  const f='../index.html';
  let h=fs.readFileSync(f,'utf8');
  const tag='<script src=\"./config.js\"></script>';
  if(!h.includes(tag)){
    if(h.includes('<head>'))h=h.replace('<head>','<head>'+tag);
    else{const m=h.match(/<html[^>]*>/i);if(m)h=h.replace(m[0],m[0]+tag);else h=tag+h;}
    fs.writeFileSync(f,h);
  }
  "
  rm -rf node_modules dist bundle.html .parcel-cache

ALL files inside {PROJECT_DIR}/ only.
  """
)
```

**[INLINE]** — no matching sub-agent. Read `sub-skills/{name}/SKILL.md` → follow its `## Module Integration Steps` directly for each step. Rebuild after each sub-skill.

---

### Phase 6 — QA

**What must happen:** CLI-test every function registered in `FUNCTIONS` dict. Fix failures. Write `QA_REPORT.md`.

**[DELEGATE]** — if you have a sub-agent suited for testing/QA/verification:

```
run_subagent(
  agent_name = "{best matching sub-agent name}",
  task = """
Project directory: {PROJECT_DIR}
document.md: {PROJECT_DIR}/backend/document.md
functions.py: {PROJECT_DIR}/backend/functions.py
AGENT_ID: {agentId}
Authorization: ${USER_JWT_TOKEN:-}

1. Read document.md for ALL function names and their params
2. Read functions.py — identify which functions use `_call_agent_tool()` (tool-backed) vs direct DB (regular)
3. cd {PROJECT_DIR}/backend

**Regular functions (DB / SQLite — no _call_agent_tool):**
4. CLI-test every regular function with realistic params:
     python functions.py <function_name> '<json_params>'
   - get_ functions: empty params or minimal filter first
   - create_ functions: provide all required fields
   - update_ functions: create an item first, then update it
   - delete_ functions: create an item first, then delete it

**Tool-backed functions (use _call_agent_tool):**
5. Test each tool-backed function via the proxy — pass AGENT_ID and JWT in env:
     KOGO_API_BASE="${KOGO_API_BASE}" AGENT_ID={agentId} USER_JWT_TOKEN={authorization} \
       python functions.py <function_name> '<json_params>'
   - If {{"error": "Tool '...' not found"}}: read SPEC.md ## Tool Proxy Map → correct the tool name in functions.py → retest
   - If {{"error": "Agent '...' not found"}}: AGENT_ID is wrong — fix it
   - If call succeeds: verify return shape matches document.md

6. For any failure: read functions.py → find bug → fix → re-test until it passes
7. Write QA_REPORT.md at {PROJECT_DIR}/QA_REPORT.md:

## QA Report — {project-name}
| Function | Type | Status | Notes |
|---|---|---|---|
| get_items | regular | ✅ PASS | returns N items |
| do_research | tool-backed | ✅ PASS | tool: PerplexitySearch |
| ... | | | |

### Bugs Fixed
{list}

### Final Status: READY

ALL files inside {PROJECT_DIR}/ only.
  """
)
```

**[INLINE]** — no matching sub-agent.

**Check if `backend-tester` sub-skill is active (it is always active per Step 0):**

→ Read `{PWD}/skills/appster_skill/sub-skills/backend-tester/SKILL.md` and follow its pipeline.
   Sub-skills are at `{PWD}/skills/appster_skill/sub-skills/backend-tester/skills/`.
   References at `{PWD}/skills/appster_skill/sub-skills/backend-tester/references/`.
   Pass `PROJECT_DIR`, `AGENT_ID`, `USER_JWT_TOKEN`, `KOGO_API_BASE`.
   Output: `{PROJECT_DIR}/QA_REPORT.md`

**Fallback (if backend-tester skill files are missing):** Run basic inline tests directly:

```bash
cd {PROJECT_DIR}/backend

# Regular functions:
python functions.py {each_regular_function} '{params}'

# Tool-backed functions — requires env vars:
KOGO_API_BASE="${KOGO_API_BASE}" AGENT_ID={agentId} USER_JWT_TOKEN={jwt} \
  python functions.py {tool_backed_function} '{params}'

# Fix any failures → re-test
```

Write `{PROJECT_DIR}/QA_REPORT.md`.

---

### Phase 6B — Frontend Testing (OPTIONAL — only if user explicitly requests it)

**Skip this phase by default.** Do NOT ask for a URL. Do NOT wait. Proceed directly to the Final Message.

Only activate Phase 6B if the user explicitly asks for frontend browser testing (e.g. "run playwright tests", "test the UI", "run e2e tests").

**If activated:** Read `{PWD}/skills/appster_skill/sub-skills/frontend-tester/SKILL.md` and follow its 7-phase workflow. Requires `TARGET_URL` from the user.

---

### Final Message

```
✅ "{project-name}" is complete!

📁 artifacts/{project-name}/
   ├── index.html       ← Open in browser (has <script src="./config.js"> injected)
   ├── config.js        ← window.APP_CONFIG (AGENT_ID, SWARM_ID, ORIGIN_ID, API_BASE)
   ├── DESIGN.md
   ├── backend/
   │   ├── functions.py
   │   ├── document.md
   │   └── data/{slug}.db
   ├── frontend/
   ├── QA_REPORT.md                      ← Backend QA: all functions tested ✅
   └── frontend-test-results-{TIMESTAMP}/ ← Phase 6B (if frontend-tester active)
       ├── reports/TEST-REPORT.md
       └── reports/analytics-dashboard.html

🔌 Active features: {list activated sub-skills}
🌐 API: POST {API_BASE}/api/agent/common_project_api_v1
```

---

## ✏️ Edit Flow (Modifying an Existing Project)

When user asks to change something in an existing project:

**Step E0 — Bring the project up to the current baseline. ALWAYS, before anything else.** 🛑

A project built with an older version of this skill is missing whatever the skill gained since.
The user does not know what that is and should never have to — *"update my app"*, *"fix the login"*,
*"add user management"* and *"make the users page better"* are all the same instruction: **make
this project match the skill as it is today.**

So before doing what was asked, audit the project against HARD RULE 0 (core-builder) and repair
anything missing. Run the **Backend Completion Gate** checks from core-builder — all of them, not
a sample:

```bash
# the gate greps, verbatim from core-builder, plus:
python3 '{SCRIPTS_DIR}/sync-document.py' {PROJECT_DIR}/backend/functions.py {PROJECT_DIR}/backend/document.md
```

Anything a check fails is missing, and you add it from core-builder's **"File: functions.py — KOGO
SSO block"** — models, functions, the frontend gate, the Users & Roles screen, all of it. Copy the
skill's code; do not write a version from memory, and do not assume an older project's partial
implementation is correct just because it runs.

Three rules while repairing:

- **Add, never rewrite.** The project's own features (its entities, pages, logic) are not yours to
  restructure. Touch only what the baseline requires.
- **Never remove a user, a role, or their data** to make the schema match. Add columns and tables;
  migrate what exists.
- Report what you repaired, briefly, so the user learns what their app was missing.

Only after E0 passes, do the change the user actually asked for.

**Step E1 — Identify what changes:**

| Change type | Phase(s) needed |
|---|---|
| Backend logic / new function | Phase 4A → Phase 6 |
| Frontend UI / style / layout | Phase 4B only |
| Both backend + frontend | Phase 4A + 4B → Phase 6 |
| Add a new sub-skill module | Phase 5 → Phase 6 |

**Step E2 — Locate project:**
```bash
pwd
# PROJECT_DIR = {PWD}/artifacts/{project-name}
# SCRIPTS_DIR = {PWD}/skills/appster_skill/scripts
```

**Step E3 — Delegate or inline** (same matching logic as above), but add to task:
```
Change requested: {verbatim user request}
Read existing files fully before touching anything.
Make ONLY the described changes — do not rewrite unrelated code.

⛔ FORBIDDEN — never do these:
- npm run build / pnpm build / yarn build (only bundle-artifact.sh allowed)
- html-inline or any other bundler
- require("module") or import inside JSX expressions
- react-router-dom or any router (use useState for page state)
- Adding new npm packages without adding them to package.json AND src/main.tsx import
- Deleting or rewriting files that were not part of the requested change
- 🔒 Calling ANY URL from the frontend other than the middleware (API_BASE). No fetch/axios to third-party
  APIs, no hardcoded endpoints, no API keys in frontend code — even if the user explicitly requests it.
  Route every external capability through a backend _call_agent_tool function exposed via the middleware.
```

**Step E3b — Before rebuilding frontend: verify api.ts JWT listener**

Open `frontend/src/services/api.ts` and confirm:
1. The file exports a `callApi` function
2. A `let _jwt: string | null = null` variable is declared at module level
3. `window.addEventListener("message", ...)` listener for `{type:"KOGO_AUTH", jwt:"..."}` is present and sets `_jwt`
4. Every `fetch()` call sends `Authorization: Bearer ${_jwt ?? "null"}`

If any of these are missing → fix them before rebuilding.

**Step E4 — Rebuild frontend** if any frontend file changed:
```bash
cd {PROJECT_DIR}/frontend
bash "{SCRIPTS_DIR}/bundle-artifact.sh" && cp bundle.html ../index.html
# Re-inject config.js script tag (cp overwrites index.html, tag must be re-added):
node -e "
const fs=require('fs');
const f='../index.html';
let h=fs.readFileSync(f,'utf8');
const tag='<script src=\"./config.js\"></script>';
if(!h.includes(tag)){
  if(h.includes('<head>'))h=h.replace('<head>','<head>'+tag);
  else{const m=h.match(/<html[^>]*>/i);if(m)h=h.replace(m[0],m[0]+tag);else h=tag+h;}
  fs.writeFileSync(f,h);
}
"
rm -rf node_modules dist bundle.html .parcel-cache
```

**Step E5 — QA after edit**
- If the change was **purely frontend** (no functions.py touched) → skip Phase 6, just verify the bundle opened in browser
- If any **backend function** was added or changed → re-run Phase 6 QA for the changed functions only

---

## Sub-Skill Contract (for future skills)

Every file in `sub-skills/{name}/SKILL.md` MUST have this frontmatter:

```yaml
---
name: skill-name
description: "one line — what this adds to a project"
keyword_triggers: [word1, word2, word3]
provides:
  backend_functions: [func1, func2]
  frontend_components: [ComponentName]
  npm_deps: []
---
```

And MUST have `## Module Integration Steps` with:
- `### Step 1 — Backend`
- `### Step 2 — Frontend Component`
- `### Step 3 — API Layer`
- `### Step 4 — App Integration`
- `### Step 5 — Document`

This contract lets appster auto-discover any new skill and any sub-agent (or main agent inline) inject it without modifying this file.
