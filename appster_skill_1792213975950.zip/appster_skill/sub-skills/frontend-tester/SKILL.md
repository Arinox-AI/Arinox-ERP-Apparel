---
name: frontend-tester
description: "Phase 6B — Browser-based frontend testing of the built index.html via Playwright. 7-phase pipeline with 34 skills: setup/explore, validation & auth, E2E flows, responsive/mobile, accessibility, performance & security, RBAC. Produces TEST-REPORT.md and analytics-dashboard.html."
keyword_triggers: [frontend test, ui test, browser test, playwright, e2e, test ui, test frontend, qa ui, responsive test, accessibility test, visual test, test html, full qa]
provides:
  backend_functions: []
  frontend_components: []
  npm_deps: []
---

# Frontend Tester (sub-skill)

This sub-skill handles **Phase 6B — Frontend QA** for appster. It browser-tests the built `index.html` using a 34-skill, 7-phase Playwright pipeline.

> Phase 6B is **optional** — only runs when the user explicitly requests frontend browser testing. Do not activate this unless asked.

All 34 sub-skills live inside this folder — no external paths needed.

```
sub-skills/frontend-tester/
├── SKILL.md                              ← This file (master router)
└── skills/
    ├── playwright-cli/                   ← Core browser automation (ALL phases)
    ├── playwright-skill/                 ← Complete browser automation (ALL phases)
    ├── console-error-hunter/             ← JS errors, warnings (ALL phases)
    ├── visual-diff/                      ← Screenshot comparison (ALL phases)
    ├── visual-regression/                ← Visual regression (ALL phases)
    ├── playwright-cli-agents/            ← 3-agent E2E system (Phase 1)
    ├── project-testing-hub/              ← Multi-project manager (Phase 1)
    ├── e2e-test-suite-init/              ← Test suite scaffolding (Phase 1)
    ├── e2e-test-conventions/             ← Core E2E rules (Phase 1)
    ├── form-validation-breaker/          ← Form inputs, boundary values (Phase 2)
    ├── error-boundary-tester/            ← Error boundaries (Phase 2)
    ├── loading-state-tester/             ← Spinners, skeletons (Phase 2)
    ├── empty-state-reviewer/             ← Empty screens (Phase 2)
    ├── create-pom/                       ← Page Object Model (Phase 2)
    ├── e2e-pom-visual/                   ← E2E + visual regression (Phase 3)
    ├── playwright-e2e/                   ← E2E testing (Phase 3)
    ├── playwright-advance-e2e/           ← Advanced E2E framework (Phase 3)
    ├── orchestkit-testing-e2e/           ← OrchestKit E2E patterns (Phase 3)
    ├── create-regression-test/           ← Regression test creation (Phase 3)
    ├── ux-friction-logger/               ← UX friction scoring (Phase 3)
    ├── playwright-mobile-web/            ← Mobile emulation (Phase 4)
    ├── responsive-layout-breaker/        ← Layout overflow detection (Phase 4)
    ├── dark-mode-bug-finder/             ← Dark mode CSS bugs (Phase 4)
    ├── orchestkit-responsive-patterns/   ← Responsive patterns (Phase 4)
    ├── accessibility-a11y-enhanced/      ← Enhanced a11y (Phase 5)
    ├── axe-accessibility/                ← axe-core WCAG 2.1 AA (Phase 5)
    ├── orchestkit-accessibility/         ← OrchestKit a11y (Phase 5)
    ├── logical-testing-reporter/         ← Logical flow reporting (Phase 5)
    ├── orchestkit-storybook-testing/     ← Storybook testing (Phase 5)
    ├── perf-audit/                       ← Lighthouse perf (Phase 6)
    ├── orchestkit-testing-perf/          ← Load & memory (Phase 6)
    ├── pentest/                          ← Penetration testing (Phase 6)
    ├── security-audit/                   ← Security headers, CORS (Phase 6)
    └── rbac-change-detector/             ← Permission & UI change tracking (Phase 7)
```

---

## 7-Phase Workflow

Execute all 7 phases in order. Read each skill's SKILL.md from `skills/<folder>/SKILL.md` before running its tests.

| Phase | Name | Skills folder names | Min tests |
|---|---|---|---|
| **1** | Setup & Explore | playwright-cli-agents, project-testing-hub, e2e-test-suite-init, e2e-test-conventions | 14 |
| **2** | Validation & Auth | form-validation-breaker, error-boundary-tester, loading-state-tester, empty-state-reviewer, create-pom | 29 |
| **3** | E2E & Logical Flows | e2e-pom-visual, playwright-e2e, playwright-advance-e2e, orchestkit-testing-e2e, create-regression-test, ux-friction-logger | 30 |
| **4** | Responsive & Mobile | playwright-mobile-web, responsive-layout-breaker, dark-mode-bug-finder, orchestkit-responsive-patterns | 18 |
| **5** | Accessibility | accessibility-a11y-enhanced, axe-accessibility, orchestkit-accessibility, logical-testing-reporter, orchestkit-storybook-testing | 25 |
| **6** | Perf & Security | perf-audit, orchestkit-testing-perf, pentest, security-audit | 22 |
| **7** | RBAC Detection | rbac-change-detector | 5 |

Skills always active across all phases: `playwright-cli`, `playwright-skill`, `console-error-hunter`, `visual-diff`, `visual-regression`

**Total minimum: 150 test cases across all 34 skills.**

---

## Mandatory rules (enforce always)

### Fresh session
Every run is a fresh test. Create a new timestamped directory:
```
{PROJECT_DIR}/frontend-test-results-{YYYY-MM-DD-HHMM}/
```
Never reuse old screenshots or reports. Use previous results only for regression comparison.

### Credential & session isolation (Phase 2)
Every auth test case gets its OWN browser context. Test order:
1. Invalid email + invalid password (new context)
2. Valid email + invalid password (new context)
3. Invalid email + valid password (new context)
4. Empty fields (new context)
5. SQL injection in email (new context)
6. XSS in email field (new context)
7. Valid credentials (new context)

### Negative tests — minimum 27
Every phase must include negative test cases (marked 🔴). Minimum per phase: 3, 7, 5, 3, 3, 3, 3.

### Screenshot every failure
Use `safeScreenshot()` pattern: fullPage first → viewport fallback → HTML capture fallback. No silent failures.

### Always generate the report
Even when test stops early — generate `TEST-REPORT.md` with `test_status: PARTIAL | BLOCKED | SITE_DOWN`.

---

## Context needed

```
TARGET_URL  = URL where index.html is served (ask user if unknown)
RESULTS_DIR = {PROJECT_DIR}/frontend-test-results-{TIMESTAMP}
```

**If TARGET_URL is unknown** — ask the user before starting. If they cannot provide one, skip this phase entirely.

---

## Output structure

```
{PROJECT_DIR}/frontend-test-results-{TIMESTAMP}/
├── screenshots/
├── bugs/           ← BUG-001.md + BUG-001.json per bug
├── reports/
│   ├── TEST-REPORT.md             ← primary detailed report
│   ├── FINAL-TEST-REPORT.md       ← structured data
│   └── analytics-dashboard.html  ← interactive charts (Chart.js)
├── scripts/        ← Playwright .js files (one per phase)
├── evidence/       ← console-errors.json, network-failures.json, flow-map.json
└── rbac/           ← baselines, screenshots, reports
```

## Failed case format (mandatory)

Every failed test must include:
- ❌ **WHY it failed** — root cause
- ❌ **WHAT went wrong** — expected vs actual
- 🔧 **HOW to solve** — actionable fix
