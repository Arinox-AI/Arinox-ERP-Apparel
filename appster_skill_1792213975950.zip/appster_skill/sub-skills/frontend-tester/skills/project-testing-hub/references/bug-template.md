# BUG-{NNN}: {Title}

**Project**: {project-name}
**Severity**: 🔴 Critical / 🟡 Warning / 🟢 Low
**Status**: Open / Investigating / Fixed / Won't Fix
**Discovered**: {YYYY-MM-DD}
**Test Case**: TC-{NNN} (if found during a specific test)
**Reporter**: Tester Agent

---

## Summary

{One-line summary of the bug.}

---

## Steps to Reproduce

1. {Step 1}
2. {Step 2}
3. {Step 3}
4. ...

---

## Expected Behavior

{What should happen.}

---

## Actual Behavior

{What actually happens.}

---

## Evidence

**Screenshot**: `{path-to-screenshot}`
**Console Error**: `{error message if any}`
**Network Failure**: `{failed request if any}`
**URL**: `{page URL where bug occurs}`
**Viewport**: `{desktop/tablet/mobile + resolution}`

---

## Impact

{Who is affected and how. e.g., "All mobile users cannot see the navigation menu"}

---

## Suggested Fix

{If identifiable, suggest what should be changed. e.g., "Add aria-expanded attribute to accordion buttons"}

---

## Environment

- **Browser**: {Chrome/Firefox/WebKit + version}
- **OS**: {Operating system}
- **Viewport**: {Width x Height}
- **URL**: {Full page URL}
