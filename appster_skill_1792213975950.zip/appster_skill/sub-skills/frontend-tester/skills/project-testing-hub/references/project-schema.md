# Project.json Schema

The `project.json` file is the central configuration and metadata file for each project.

---

## Full Schema

```json
{
  "name": "Human-Readable Name",
  "slug": "project-slug",
  "url": "https://example.com",
  "type": "public | authenticated",
  "owner": "Client/Team Name",
  "priority": "high | medium | low",
  "status": "active | paused | archived",
  "created": "YYYY-MM-DD",
  "lastTested": "YYYY-MM-DD or null",
  "lastReport": "reports/filename.md or null",
  "testCases": {
    "total": 0,
    "passed": 0,
    "failed": 0,
    "skipped": 0
  },
  "bugs": {
    "open": 0,
    "closed": 0,
    "critical": 0
  },
  "suites": [
    {
      "name": "Suite Name",
      "slug": "suite-slug",
      "testCases": ["TC-001", "TC-002"],
      "lastRun": "YYYY-MM-DD or null",
      "passRate": null
    }
  ],
  "credentials": {
    "required": false,
    "tenant": null,
    "email": null,
    "loginUrl": null,
    "postLoginUrl": null
  },
  "tags": ["tag1", "tag2"],
  "notes": ""
}
```

---

## Field Reference

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `name` | string | ✅ | Human-readable project name |
| `slug` | string | ✅ | kebab-case identifier, used as folder name |
| `url` | string | ✅ | Primary URL to test |
| `type` | enum | ✅ | `public` (no auth needed) or `authenticated` (login required) |
| `owner` | string | ❌ | Client or team this project belongs to |
| `priority` | enum | ✅ | `high`, `medium`, or `low` |
| `status` | enum | ✅ | `active`, `paused`, or `archived` |
| `created` | date | ✅ | Date project was initialized |
| `lastTested` | date/null | ✅ | Date of last test run |
| `lastReport` | string/null | ✅ | Path to latest report file |
| `testCases` | object | ✅ | Test case statistics |
| `bugs` | object | ✅ | Bug statistics |
| `suites` | array | ✅ | List of test suites with their test cases |
| `credentials` | object | ✅ | Auth configuration (null values if type=public) |
| `tags` | array | ❌ | Freeform tags for categorization |
| `notes` | string | ❌ | Any additional notes |

---

## Usage Notes

- **Never delete** `project.json` — it's the source of truth for the project
- **Update `lastTested`** after every test run
- **Update `testCases`** counts after every test run
- **Update `bugs`** counts when bugs are logged or closed
- **Update `suites`** when test suites are added/removed
- **Update `status`** via the `update-status` command only
