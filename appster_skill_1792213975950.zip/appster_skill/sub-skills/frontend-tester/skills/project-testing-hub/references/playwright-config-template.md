# Playwright Config Template for Projects

Use this template when generating `test-scripts/playwright.config.js` for a new project.

---

```javascript
// @ts-check
const { defineConfig, devices } = require('@playwright/test');

/**
 * Playwright configuration for {PROJECT_NAME}
 * Project URL: {PROJECT_URL}
 * Generated: {YYYY-MM-DD}
 */
module.exports = defineConfig({
  // Test directory
  testDir: '.',

  // Test matching pattern
  testMatch: '**/*.spec.js',

  // Timeout per test
  timeout: 30_000,

  // Timeout for expect assertions
  expect: {
    timeout: 10_000,
  },

  // Run tests in parallel
  fullyParallel: true,

  // Fail build on CI if you accidentally left test.only
  forbidOnly: !!process.env.CI,

  // Retry on CI
  retries: process.env.CI ? 1 : 0,

  // Reporters
  reporter: [
    ['list'],
    ['json', { outputFile: '../reports/test-results.json' }],
    ['html', { open: 'never', outputFolder: '../reports/html' }],
  ],

  // Shared settings for all projects
  use: {
    // Base URL for this project
    baseURL: '{PROJECT_URL}',

    // Collect trace on failure
    trace: 'on-first-retry',

    // Screenshot on failure
    screenshot: 'only-on-failure',

    // Video on failure
    video: 'retain-on-failure',

    // Artifacts output
    outputDir: '../traces',
  },

  // Browser projects
  projects: [
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] },
    },
    // Uncomment to enable more browsers:
    // {
    //   name: 'firefox',
    //   use: { ...devices['Desktop Firefox'] },
    // },
    // {
    //   name: 'webkit',
    //   use: { ...devices['Desktop Safari'] },
    // },
    // {
    //   name: 'mobile-chrome',
    //   use: { ...devices['Pixel 5'] },
    // },
    // {
    //   name: 'mobile-safari',
    //   use: { ...devices['iPhone 12'] },
    // },
  ],
});
```

---

## Notes

- Replace `{PROJECT_NAME}` and `{PROJECT_URL}` with actual values
- Replace `{YYYY-MM-DD}` with creation date
- baseURL is set to the project's primary URL
- Screenshot, trace, and video are captured on failure by default
- Reports go to `../reports/` (relative to test-scripts/)
- Only Chromium is enabled by default — uncomment others as needed
