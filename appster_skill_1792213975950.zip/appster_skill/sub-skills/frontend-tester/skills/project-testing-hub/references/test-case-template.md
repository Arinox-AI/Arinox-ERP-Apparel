# TC-{NNN}: {Title}

**Project**: {project-name}
**Suite**: {suite-name} (smoke / regression / handover / accessibility / performance / security)
**Priority**: {high / medium / low}
**Type**: {functional / visual / a11y / perf / security}
**Status**: {draft / active / deprecated}
**Created**: {YYYY-MM-DD}
**Last Run**: {YYYY-MM-DD or —}

---

## Description

{Brief description of what this test case verifies.}

---

## Pre-Conditions

- [ ] {Pre-condition 1, e.g., "Application is accessible at {URL}"}
- [ ] {Pre-condition 2, e.g., "User is logged in" (if authenticated)}
- [ ] {Pre-condition 3, e.g., "No console errors on page load"}

---

## Test Steps

| Step | Action | Expected Result |
|------|--------|----------------|
| 1 | {e.g., "Navigate to {URL}"} | {e.g., "Page loads with HTTP 200"} |
| 2 | {e.g., "Check page title"} | {e.g., "Title contains expected text"} |
| 3 | {e.g., "Click navigation link"} | {e.g., "Page navigates to correct URL"} |
| 4 | ... | ... |

---

## Expected Result

{Detailed description of the expected outcome.}

---

## Actual Result

{To be filled after test execution.}

---

## Result

- [ ] ✅ PASS
- [ ] ❌ FAIL
- [ ] ⏭️ SKIP
- [ ] 🚫 BLOCKED

---

## Failure Details

_If FAIL, document:_

**Error**: {Error message or description}
**Selector**: {CSS selector or ref that failed}
**Screenshot**: {Path to screenshot}
**Console Errors**: {Any JS errors observed}
**Network Errors**: {Any failed requests}

---

## Notes

{Any additional observations, edge cases, or follow-up actions.}
