---
name: project-testing-hub
description: |
  Master project management system for multi-project frontend testing. Initializes new project folders, registers projects, manages test cases per project, runs tests, and generates isolated reports. Use when: starting tests for a new company/website, managing multiple test projects, organizing test artifacts by project, or needing a structured way to track QA work across different clients.
user-invocable: true
argument-hint: "[command] [project-name] [url]"
---

# 🧪 Project Testing Hub

A structured multi-project testing system. Each company/website gets its own isolated folder with test cases, scripts, reports, and bugs — all self-contained.

---

## Commands

| Command | Arguments | Description |
|---------|-----------|-------------|
| `init-project` | `[name] [url]` | Create a new project with full folder structure |
| `list-projects` | — | Show all registered projects |
| `add-testcase` | `[project] [suite] [title]` | Add a test case to a project |
| `list-testcases` | `[project]` | List all test cases for a project |
| `run-tests` | `[project] [suite?]` | Execute tests for a project |
| `generate-report` | `[project]` | Generate latest test report |
| `log-bug` | `[project] [title]` | Log a bug found during testing |
| `list-bugs` | `[project]` | List all bugs for a project |
| `update-status` | `[project] [status]` | Update project status (active/paused/archived) |
| `remove-project` | `[project]` | Remove project from registry |

---

## Project Root

All projects live under:
```
userfiles/projects/
```

The master registry is:
```
userfiles/projects/PROJECTS_REGISTRY.md
```

---

## Workflow: Initialize a New Project

### Step 1 — Validate Inputs

Get the project name and URL. If not provided, ask:
- **Project name**: A short identifier (e.g., "acme-corp", "kogo-ai"). Will be slugified to kebab-case.
- **URL**: The website to test (e.g., "https://acme.com")

Also ask (or infer):
- **Project type**: `public` (no auth) or `authenticated` (needs login)
- **Owner**: Who is this project for? (client name, team name)
- **Priority**: `high` / `medium` / `low`

### Step 2 — Check for Duplicates

Read `projects/PROJECTS_REGISTRY.md`. If a project with the same slug already exists:
- If status is `active` or `paused`: **ABORT** — inform user, suggest using existing project
- If status is `archived`: Offer to reactivate

### Step 3 — Create Folder Structure

```
projects/{project-slug}/
├── project.json              # Project config & metadata
├── test-cases/               # Test case definitions (Markdown)
├── test-scripts/             # Playwright scripts & configs
│   └── e2e/                  # E2E test suite (initialized on demand)
│       ├── poms/
│       ├── fixtures/
│       ├── helpers/
│       ├── test-data/
│       ├── tests/
│       │   ├── smoke/
│       │   ├── regression/
│       │   └── handover/
│       ├── auth/
│       └── .auth/
├── reports/                  # Test reports (Markdown + DOCX)
├── screenshots/              # Captured screenshots
├── traces/                   # Playwright traces
└── bugs/                     # Bug reports
```

### Step 4 — Generate project.json

```json
{
  "name": "Human-Readable Name",
  "slug": "project-slug",
  "url": "https://example.com",
  "type": "public",
  "owner": "Client/Team Name",
  "priority": "medium",
  "status": "active",
  "created": "2026-04-21",
  "lastTested": null,
  "lastReport": null,
  "testCases": {
    "total": 0,
    "passed": 0,
    "failed": 0
  },
  "bugs": {
    "open": 0,
    "closed": 0,
    "critical": 0
  },
  "suites": [],
  "credentials": {
    "required": false,
    "tenant": null,
    "email": null
  }
}
```

### Step 5 — Register in PROJECTS_REGISTRY.md

Add a row to the Active Projects table in `projects/PROJECTS_REGISTRY.md`:
```
| N+1 | {name} | {url} | {today} | — | ✅ Active |
```

### Step 6 — Generate Initial Test Cases

Based on the project type, auto-generate starter test cases:

**For public websites** (no auth):
- TC-001: Page Load & Meta
- TC-002: Navigation & Links
- TC-003: Forms & Validation
- TC-004: Responsive Layout
- TC-005: Accessibility Basics
- TC-006: Console Errors
- TC-007: Performance Check
- TC-008: Security Headers

**For authenticated apps** (needs login):
- All the above PLUS:
- TC-009: Login Flow
- TC-010: Auth State Persistence
- TC-011: Protected Routes
- TC-012: Sidebar/Navigation (post-login)
- TC-013: Dashboard Load
- TC-014: Logout Flow

Each test case is saved as a Markdown file in `test-cases/` following the template in [references/test-case-template.md](references/test-case-template.md).

### Step 7 — Generate Playwright Config

Create `test-scripts/playwright.config.js` configured for this project's URL.

### Step 8 — Print Summary

Tell the user:
1. Project created at: `projects/{slug}/`
2. N test cases generated
3. Next steps: Run `run-tests {slug}` to start testing

---

## Workflow: Run Tests for a Project

### Step 1 — Load Project Config

Read `projects/{slug}/project.json` to get URL, type, credentials.

### Step 2 — Determine What to Run

If a suite is specified (e.g., "smoke", "regression"), run only that suite.
If not, run all test cases listed in `test-cases/`.

### Step 3 — Execute Using Playwright CLI

Use the `playwright-cli` skill to:
1. Open browser
2. Navigate to project URL
3. Execute each test case sequentially
4. Capture screenshots on failure
5. Capture console errors
6. Capture network failures
7. Close browser

### Step 4 — Update Results

Update `project.json` with:
- `lastTested`: today's date
- `testCases.total/passed/failed`: updated counts

### Step 5 — Generate Report

Create a dated report in `reports/` following [references/report-template.md](references/report-template.md).

### Step 6 — Log Bugs

For each failure, create a bug report in `bugs/` following [references/bug-template.md](references/bug-template.md).

---

## Workflow: Generate Report

1. Read all test case results from `test-cases/`
2. Read all bug reports from `bugs/`
3. Compile into a structured Markdown report in `reports/{date}-{slug}-report.md`
4. **If logical tests were run, generate visual charts:**
   - Write `reports/logical-test-data.json` with test results
   - Run `node skills/logical-testing-reporter/scripts/generate-logical-report.js reports/logical-test-data.json reports/logical-testing-report.html`
   - Serve via `python3 -m http.server 8888` in `reports/`
   - Open in Playwright: `playwright-cli goto http://localhost:8888/logical-testing-report.html`
   - Screenshot pie chart and bar chart as PNG files
   - Include chart images in the final report
5. Update `project.json` with `lastReport` path
6. Optionally generate DOCX version using the `docx` skill

> **Chart Generation is MANDATORY** for logical testing. Never describe charts in text only — always render and screenshot them. See `logical-testing-reporter` skill for the full workflow.

---

## Workflow: Log a Bug

1. Create `bugs/BUG-{NNN}-{slug}.md` following [references/bug-template.md](references/bug-template.md)
2. Update `project.json` bug counts
3. Include: title, severity, steps to reproduce, expected vs actual, screenshot path

---

## Project Isolation Rules

⚠️ **CRITICAL: These rules ensure projects stay isolated.**

1. **All files go in the project folder** — Never write test artifacts outside `projects/{slug}/`
2. **One project = one folder** — Never mix files between projects
3. **Screenshots go in the project's screenshots/ folder** — Not in a global location
4. **Reports go in the project's reports/ folder** — Not at the userfiles root
5. **Bug reports go in the project's bugs/ folder** — Not scattered
6. **Test scripts reference only their project's URL** — Never hardcode another project's URL
7. **Credentials are stored per-project** — In `project.json`, never shared

---

## Integration with Other Skills

| Skill | When to Use |
|-------|-------------|
| `playwright-cli` | For all browser interactions during test execution |
| `playwright-e2e` | For writing proper E2E test specs |
| `e2e-test-suite-init` | To scaffold full E2E suite inside `test-scripts/e2e/` |
| `create-pom` | To create Page Object Models for a project |
| `create-regression-test` | To add regression tests to a project |
| `form-validation-breaker` | To deep-test forms in a project |
| `security-audit` | To run security checks on a project |
| `accessibility-a11y-enhanced` | To run a11y audits on a project |
| `frontend-performance` | To run perf audits on a project |
| `responsive-layout-breaker` | To test responsive layouts |
| `console-error-hunter` | To hunt for console errors |
| `visual-diff` | To compare visual changes between runs |
| `logical-testing-reporter` | To generate logical structure reports with pie/bar charts |
| `docx` | To export reports as Word documents |

When using these skills, **always set the working context to the project folder** and reference paths relative to `projects/{slug}/`.

---

## Naming Conventions

| Item | Format | Example |
|------|--------|---------|
| Project slug | kebab-case | `acme-corp` |
| Test case file | `TC-{NNN}-{title}.md` | `TC-001-page-load.md` |
| Bug file | `BUG-{NNN}-{title}.md` | `BUG-001-missing-csp.md` |
| Report file | `{YYYY-MM-DD}-{slug}-{type}.md` | `2026-04-21-kogo-ai-comprehensive.md` |
| Screenshot | `{YYYY-MM-DD}-{slug}-{viewport}-{desc}.png` | `2026-04-21-kogo-ai-desktop-home.png` |
| Spec file | `{feature}.spec.js` | `navigation.spec.js` |

---

## Safety Rules

1. **Never test against production with destructive actions** — No real form submissions that create data
2. **Never modify another project's files** — Strict isolation
3. **Never delete a project without confirmation** — Use `remove-project` which only removes from registry
4. **Never share credentials between projects** — Each project.json is independent
5. **Always confirm before running authenticated tests** — Verify credentials are test-safe
