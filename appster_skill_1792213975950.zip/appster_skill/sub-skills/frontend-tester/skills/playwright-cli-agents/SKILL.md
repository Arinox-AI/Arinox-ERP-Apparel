---
name: playwright-cli-agents
description: Three-agent system for E2E test generation — Planner (analyzes page structure), Generator (writes test code), Healer (auto-fixes broken tests). Works with playwright-cli for autonomous test creation and maintenance.
allowed-tools: Bash(playwright-cli:*) Bash(npx:*) Bash(npm:*)
---

# Playwright CLI Agents — Planner, Generator, Healer

Three specialized agents that work together to create, maintain, and auto-heal E2E tests using playwright-cli.

## How It Works

### Agent 1: Planner (`agents/playwright-cli-planner.md`)
Analyzes a web page and generates a structured test plan:
1. Opens the target URL via playwright-cli
2. Takes a snapshot to identify all interactive elements
3. Maps user flows (login, navigation, form submission)
4. Produces a prioritized test plan with step-by-step instructions

**When to use:** When you need to plan what tests to write for a new page or feature.

### Agent 2: Generator (`agents/playwright-cli-generator.md`)
Takes a test plan and generates executable Playwright code:
1. Reads the test plan from the Planner
2. Generates Page Object Model classes
3. Writes test spec files with proper assertions
4. Follows e2e-test-conventions for naming and structure

**When to use:** When you have a test plan and need to generate the actual test code.

### Agent 3: Healer (`agents/playwright-cli-healer.md`)
Automatically fixes broken or flaky tests:
1. Identifies failing selectors (element not found, timeout)
2. Takes a fresh snapshot to find the correct element
3. Updates selectors in the test code
4. Re-runs the test to verify the fix

**When to use:** When existing tests are failing due to UI changes or flaky selectors.

## 🔗 Related Skills

| Skill | When to Use |
|-------|-------------|
| `playwright-cli` | For all browser interactions during agent execution |
| `e2e-pom-visual` | Alternative E2E generator with visual regression |
| `create-pom` | For manually creating Page Object Models |
| `create-regression-test` | For manually creating regression test specs |
| `e2e-test-conventions` | For conventions the Generator should follow |
