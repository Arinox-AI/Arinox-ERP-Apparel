# RBAC Change Detector

## Description

Multi-tenant, multi-role UI testing framework that:
- **Tests every button, link, form, and UI element** across all pages of a web application
- **Remembers previous state** (baselines) and detects changes between runs
- **Asks permission questions** when elements appear or disappear unexpectedly
- **Validates RBAC permissions** — checks what each role can see and do
- **Supports multiple tenants** with different role configurations
- **Generates HTML/Markdown/JSON reports** with full element inventory

Use when user asks to:
- Test UI for changes over time
- Check what buttons/links are present on each page
- Validate role-based access control (RBAC) visually
- Detect if anything was removed or added to the UI
- Compare UI state between runs for a website
- Test multi-tenant applications with different permissions

---

## Architecture Overview

```
run-rbac-tests.js (CLI Entry Point)
    │
    ├── config/tenants.json (Your app config: URLs, credentials, pages, roles)
    │
    ├── src/rbac-tester.js (Main orchestrator)
    │       ├── Logs in per role
    │       ├── Navigates to each page
    │       ├── Extracts all elements
    │       ├── Compares against baseline
    │       └── Reports changes
    │
    ├── src/element-extractor.js (Scans the page)
    │       ├── buttons, links, forms
    │       ├── navigation, menus, tabs
    │       ├── modals, tables, cards, actions
    │       └── Captures: text, id, class, position, disabled, visible, clickable
    │
    ├── src/baseline-manager.js (Saves/loads snapshots)
    │       ├── Organized by: tenant/role/page.json
    │       └── Each baseline = full element inventory
    │
    ├── src/diff-engine.js (Compares current vs baseline)
    │       ├── Fingerprint matching (stable IDs)
    │       ├── Detects: NEW, REMOVED, MODIFIED elements
    │       └── Generates permission questions
    │
    └── src/report-generator.js (Creates reports)
            ├── HTML dashboard (interactive)
            ├── Markdown summary
            └── JSON full data
```

---

## What It Tests (Per Page, Per Role, Per Tenant)

### Element Categories Scanned

| Category | CSS Selector | What Is Captured |
|----------|-------------|------------------|
| **buttons** | `button, [role='button'], input[type='button']` | Every clickable button |
| **links** | `a[href], [role='link']` | Every hyperlink |
| **forms** | `form, input, textarea, select` | Form fields and controls |
| **navigation** | `nav, .sidebar, [class*='nav']` | Navigation containers |
| **menus** | `[role='menu'], .dropdown-menu` | Dropdown/context menus |
| **tabs** | `[role='tab'], [role='tablist']` | Tab interfaces |
| **modals** | `[role='dialog'], .modal` | Dialog boxes |
| **tables** | `table, [role='table'], [role='grid']` | Data tables |
| **cards** | `.card, [class*='card']` | Card components |
| **actions** | `[class*='action'], [data-action]` | Action buttons |

### Element Properties Captured (20+ fields per element)

```
index          → Position in DOM
tagName        → HTML tag (button, a, input)
id             → Element ID
className      → CSS classes
text           → Visible text content (first 100 chars)
ariaLabel      → ARIA label
ariaRole       → ARIA role
dataTestId     → data-testid attribute
href           → Link target
type           → Input type (email, password, submit)
disabled       → Is element disabled?
hidden         → Is element hidden?
visible        → Is element visible on screen?
clickable      → Can it be clicked?
boundingBox    → {x, y, width, height} exact pixel position
title          → title attribute
name           → name attribute
placeholder    → placeholder text
value          → Input value
parentTag      → Parent element tag
parentClass    → Parent element class
fingerprint    → Unique hash for matching across runs
```

---

## How Change Detection Works

### Step 1: Create Baseline (First Run)

```bash
node run-rbac-tests.js --baseline --config config/tenants.json
```

What happens:
1. Opens browser (Playwright)
2. Logs in as each role (tenant + email + password)
3. Navigates to each page URL
4. Extracts ALL elements using element-extractor.js
5. Saves to `baselines/tenant-id/role-id/PageName.json`

Each baseline file contains the complete element inventory for that page.

### Step 2: Detect Changes (Subsequent Runs)

```bash
node run-rbac-tests.js --config config/tenants.json
```

What happens:
1. Same login and page navigation
2. Extracts current elements
3. **Compares against baseline** using diff-engine.js
4. Reports any differences

### Fingerprint Matching Algorithm

Each element gets a **stable fingerprint** used for matching:

```
fingerprint = category + tagName + text + ariaLabel + id + name + type + ariaRole + dataTestId + href
```

Example:
```
buttons | button | "Delete User" | null | btn-delete | null | null | null | null | null
```

**Dynamic IDs are filtered out:**
- React-generated IDs (`radix-_*`) → **ignored** (change on every render)
- Auto-generated random IDs → **ignored**
- Only stable, meaningful attributes used for matching

### What Counts as a "Change"

| Change Type | Detection | Question Asked |
|-------------|-----------|---------------|
| **NEW element** | Fingerprint exists in current, NOT in baseline | "Is this a new feature or unexpected permission leak?" |
| **REMOVED element** | Fingerprint exists in baseline, NOT in current | "Was this element intentionally removed or is this a permission issue?" |
| **MODIFIED element** | Same fingerprint, but properties changed | "Was this state change (disabled/visible) intentional?" |

### Property Changes Detected

When an element is modified, the diff engine tracks exactly what changed:

```
MODIFIED: [buttons] "Save" 
  → disabled changed: false → true
  
MODIFIED: [links] "/admin/users" 
  → visible changed: true → false
  
MODIFIED: [buttons] "Export" 
  → text changed: "Export" → "Export CSV"
```

---

## How RBAC Permission Testing Works

### Multi-Tenant Support

Each tenant gets its own baseline folder:

```
baselines/
├── tenant-acme/
│   ├── admin/
│   │   ├── Dashboard.json
│   │   └── Users.json
│   └── manager/
│       ├── Dashboard.json
│       └── Users.json
│
└── tenant-globex/
    ├── admin/
    │   └── Dashboard.json
    └── user/
        └── Dashboard.json
```

### Multi-Role Support

Each role within a tenant gets separate baselines:

```
baselines/tenant-1/
├── admin/          (sees everything)
├── manager/        (sees limited buttons)
├── user/           (read-only view)
└── guest/          (public pages only)
```

### What RBAC Testing Validates

1. **Element Visibility** — Does the right role see the right elements?
   - Admin sees "Delete" button → ✅
   - User sees "Delete" button → ❓ Permission leak?

2. **Element State** — Are buttons disabled for unauthorized actions?
   - Manager: "Edit" enabled, "Delete" disabled → ✅
   - Manager: "Delete" enabled → ❓ Permission issue?

3. **Page Access** — Can roles access pages they shouldn't?
   - User navigates to `/admin/settings` → Should redirect or 403

4. **Navigation Consistency** — Same sidebar items across pages?
   - Dashboard shows 11 nav items → ✅
   - Settings shows only 8 nav items → ❓ Missing items?

### Permission Review Questions Generated

When changes are detected, the report includes specific questions:

```
⚠️ Permission Review Required (3 items)

MISSING_EXPECTED_ELEMENT
Element: "Delete User" button
Message: Element is no longer visible. May be permission-related or removed.
Question: Was this element intentionally removed or is this a permission issue?

NEW_ELEMENT_APPEARED
Element: "Admin Settings" link
Message: New element appeared on the page.
Question: Is this a new feature or unexpected permission leak?

STATE_CHANGED
Element: "Export Report" button
Before: disabled=false, visible=true
After: disabled=true, visible=true
Question: Was this state change (now disabled) intentional?
```

---

## Configuration (`config/tenants.json`)

### Structure

```json
{
  "baseUrl": "https://your-app.com",
  "loginUrl": "/login",
  
  "pages": [
    { "name": "Dashboard", "path": "/admin/dashboard", "required": true },
    { "name": "Users", "path": "/admin/users", "required": false },
    { "name": "Settings", "path": "/admin/settings", "required": false }
  ],
  
  "tenants": [
    {
      "id": "tenant-1",
      "name": "Acme Corp",
      "roles": [
        {
          "id": "admin",
          "name": "Super Admin",
          "credentials": {
            "company": "acme",
            "email": "admin@acme.com",
            "password": "AdminPass123!"
          },
          "expectedPermissions": {
            "Dashboard": { "view": true, "edit": true, "delete": true },
            "Users": { "view": true, "create": true, "edit": true, "delete": true },
            "Settings": { "view": true, "edit": true }
          }
        }
      ]
    }
  ],
  
  "elementSelectors": {
    "buttons": "button, [role='button'], .btn",
    "links": "a[href], [role='link']",
    "forms": "form, input, textarea, select",
    "navigation": "nav, .sidebar, [class*='nav']",
    "menus": "[role='menu'], .dropdown-menu",
    "tabs": "[role='tab'], [role='tablist']",
    "modals": "[role='dialog'], .modal",
    "tables": "table, [role='table']",
    "cards": ".card, [class*='card']",
    "actions": "[class*='action'], [data-action]"
  },
  
  "testingOptions": {
    "headless": true,
    "screenshotOnFailure": true,
    "screenshotOnSuccess": true,
    "fullPageScreenshots": true,
    "waitForNetworkIdle": true,
    "delayBetweenPagesMs": 3000,
    "viewport": { "width": 1920, "height": 1080 },
    "extractHiddenElements": false,
    "checkApiEndpoints": true
  }
}
```

### Key Fields

| Field | Purpose |
|-------|---------|
| `baseUrl` | Your application's base URL |
| `loginUrl` | Path to login page |
| `pages` | Array of pages to test (name, path, required) |
| `tenants` | Multi-tenant config (id, name, roles) |
| `roles` | Each role has credentials + expectedPermissions |
| `credentials.company` | Tenant/workspace field for multi-step login |
| `expectedPermissions` | What each role SHOULD be able to do (for validation) |
| `elementSelectors` | Customize CSS selectors for your UI framework |
| `testingOptions` | Headless mode, screenshots, delays, viewport |

---

## Handling React/SPA Login

For React-controlled login forms (where `.fill()` doesn't work):

```javascript
// In rbac-tester.js login method:
const setInputValue = async (page, index, value) => {
  await page.evaluate(({ idx, val }) => {
    const inputs = document.querySelectorAll('input');
    if (inputs[idx]) {
      // Use native value setter to bypass React's onChange
      const valueSetter = Object.getOwnPropertyDescriptor(
        window.HTMLInputElement.prototype, 'value'
      ).set;
      valueSetter.call(inputs[idx], val);
      
      // Dispatch React's expected events
      inputs[idx].dispatchEvent(new Event('input', { bubbles: true }));
      inputs[idx].dispatchEvent(new Event('change', { bubbles: true }));
    }
  }, { idx: index, val: value });
};

// Fill tenant, email, password
await setInputValue(page, 0, credentials.company);  // tenant field
await setInputValue(page, 1, credentials.email);     // email field
await setInputValue(page, 2, credentials.password); // password field

// Submit via JS click
await page.evaluate(() => {
  document.querySelector('button[type="submit"]').click();
});
```

---

## Reports Generated

### 1. HTML Report (`reports/report-YYYY-MM-DD.html`)

Interactive dashboard with:
- Summary cards (Unchanged / Changed / New / Removed / Modified / Errors)
- Permission Review Required section (when elements change)
- Detailed results table (Tenant | Role | Page | Status | Elements | Changes)
- Collapsible change details

### 2. Markdown Report (`reports/report-YYYY-MM-DD.md`)

Clean text format for GitHub/Slack/Email:

```markdown
# 🔐 RBAC Change Detection Report

**Mode:** CHANGE_DETECTION  
**Total Tests:** 8

## Summary
| Metric | Count |
|--------|-------|
| ✅ Unchanged | 7 |
| ⚠️ Changed | 1 |
| ➕ New Elements | 2 |
| ➖ Removed | 1 |

## ⚠️ Permission Review Required (3 items)

### MISSING_EXPECTED_ELEMENT
- **Element:** "Delete User" button
- **Question:** Was this element intentionally removed or is this a permission issue?

## Detailed Results
| Tenant | Role | Page | Status | Elements | Changes |
|--------|------|------|--------|----------|---------|
| t1 | admin | Dashboard | UNCHANGED | 108 | - |
| t1 | admin | Users | CHANGED | 94 | +2 -1 |
```

### 3. JSON Report (`reports/report-YYYY-MM-DD.json`)

Full structured data with every element's properties:

```json
{
  "summary": { "totalTests": 8, "passed": 7, "changed": 1, ... },
  "results": [
    {
      "tenantId": "kogo",
      "roleId": "admin",
      "pageName": "Dashboard",
      "status": "CHANGED",
      "diff": {
        "added": [ { "category": "buttons", "text": "New Feature", ... } ],
        "removed": [ { "category": "buttons", "text": "Old Button", ... } ],
        "changed": [ { "type": "modified", "before": {...}, "after": {...} } ]
      },
      "permissionIssues": [ ... ]
    }
  ]
}
```

### 4. Screenshots (`screenshots/tenant/role/date/*.png`)

Full-page screenshots per page per run:
- `Dashboard.png` — AI App Store page
- `Workspace.png` — Chat interface
- `Users.png` — User management
- etc.

---

## Usage Commands

```bash
# 1. Install dependencies
cd rbac-change-detector
npm install
npx playwright install

# 2. Create baselines (FIRST RUN ONLY)
node run-rbac-tests.js --baseline --config config/tenants.json

# 3. Daily change detection
node run-rbac-tests.js --config config/tenants.json

# 4. Test specific tenant only
node run-rbac-tests.js --tenant tenant-1 --config config/tenants.json

# 5. Test specific role only
node run-rbac-tests.js --role admin --config config/tenants.json

# 6. Test specific page only
node run-rbac-tests.js --page Dashboard --config config/tenants.json

# 7. Recreate baselines after intentional UI redesign
node run-rbac-tests.js --baseline --config config/tenants.json

# 8. Generate report from existing results
node run-rbac-tests.js --report-only
```

---

## CI/CD Integration (GitHub Actions)

```yaml
name: RBAC Change Detection

on:
  schedule:
    - cron: '0 2 * * *'  # Daily at 2 AM UTC
  workflow_dispatch:

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with: { node-version: 20 }
      
      - run: cd rbac-change-detector && npm install && npx playwright install
      
      - run: cd rbac-change-detector && node run-rbac-tests.js --config config/tenants.json
        continue-on-error: true  # Don't fail build, just report
        
      - uses: actions/upload-artifact@v4
        with:
          name: rbac-reports
          path: rbac-change-detector/reports/
          
      - uses: actions/upload-artifact@v4
        with:
          name: rbac-baselines
          path: rbac-change-detector/baselines/
```

---

## What the Report Shows (With Examples)

### Example: No Changes

```
🚀 Starting RBAC Change Detection Test
Mode: CHANGE_DETECTION

🏢 Tenant: Kogo (kogo)
  👤 Role: Admin (admin)
    ✅ Logged in as abhishek@kogo.ai
    📄 Page: Dashboard (/admin/dashboard)
      ✅ No changes detected
    📄 Page: Workspace (/admin/dashboard/swarm)
      ✅ No changes detected
    📄 Page: Settings (/admin/dashboard/settings)
      ✅ No changes detected

============================================================
📋 SUMMARY
============================================================
Total Tests:      8
Unchanged:        8
Changed:          0
New Elements:     0
Removed Elements: 0
Modified:         0
Permission Questions: 0
Errors:           0
============================================================
✅ All checks passed!
```

### Example: Changes Detected

```
🏢 Tenant: Kogo (kogo)
  👤 Role: Admin (admin)
    ✅ Logged in as abhishek@kogo.ai
    📄 Page: Users (/admin/users)
      🔍 Changes: +2 new, -1 removed, ~1 modified
         ➕ NEW: [buttons] "Bulk Delete"
         ➕ NEW: [links] "/admin/advanced-settings"
         ➖ REMOVED: [buttons] "Old Import"
         ~ MODIFIED: [buttons] "Create User" — disabled: false → true
         ❓ Is this a new feature or unexpected permission leak?
         ❓ Is this a new feature or unexpected permission leak?
         ❓ Was this element intentionally removed or is this a permission issue?
         ❓ Was this state change (disabled) intentional?

⚠️  Changes detected! Review the report for details.
```

### Example: Baseline Created

```
🚀 Starting RBAC Change Detection Test
Mode: BASELINE CREATION

🏢 Tenant: Kogo (kogo)
  👤 Role: Admin (admin)
    ✅ Logged in as abhishek@kogo.ai
    📄 Page: Dashboard (/admin/dashboard)
      💾 Baseline saved (108 elements)
    📄 Page: Workspace (/admin/dashboard/swarm)
      💾 Baseline saved (94 elements)

============================================================
📋 SUMMARY
============================================================
Total Tests:      8
Baselines Created: 8
Errors:           0
============================================================
✅ All checks passed!
```

---

## File Organization

```
rbac-change-detector/
├── run-rbac-tests.js              # CLI entry point
├── config/
│   └── tenants.json               # App configuration
├── src/
│   ├── rbac-tester.js            # Main orchestrator
│   ├── element-extractor.js      # Page scanner
│   ├── baseline-manager.js       # Save/load baselines
│   ├── diff-engine.js            # Compare current vs baseline
│   └── report-generator.js       # HTML/MD/JSON reports
├── baselines/                     # ⭐ BASELINES (save these!)
│   └── tenant-id/
│       └── role-id/
│           └── PageName.json
├── screenshots/                   # Full-page screenshots
│   └── tenant/role/date/*.png
└── reports/                        # Generated reports
    └── tenant/role/date/
        ├── report.html
        ├── report.md
        └── report.json
```

---

## Troubleshooting

### React login inputs not filling
Use native `HTMLInputElement.prototype.value` setter + dispatch `input` and `change` events.

### Radix UI / auto-generated IDs changing
The diff engine automatically strips `radix-_*` prefixes from fingerprints. No manual fix needed.

### Dynamic content (timestamps, counts) changing
The fingerprint uses text content. If dynamic text changes (e.g., "107" → "108" LLM count), it will be detected as a modification. Adjust selectors to exclude dynamic content, or accept these as expected changes.

### Pages take long to load (SPAs)
Increase `delayBetweenPagesMs` in config (e.g., 5000ms for heavy SPAs).

### Elements hidden by CSS but still in DOM
Set `extractHiddenElements: false` in config to only track visible elements.

---

## Key Principles

1. **Baseline first** — Run with `--baseline` before any change detection
2. **Test per role** — Each role gets its own baseline (Admin ≠ User ≠ Guest)
3. **Test per tenant** — Each tenant gets its own baseline (Tenant A ≠ Tenant B)
4. **Ask questions** — Changes trigger human review questions, not automatic failure
5. **Full inventory** — Every button, link, and element is tracked with 20+ properties
6. **Stable matching** — Dynamic IDs filtered, meaningful attributes used for matching
7. **Report everything** — HTML dashboard + Markdown summary + JSON data

---

## Dependencies

- `playwright` — Browser automation
- Node.js 18+ — Runtime

Install:
```bash
npm install playwright
npx playwright install chromium
```

---

*RBAC Change Detector v1.0*  
*Built for: Multi-tenant, multi-role UI regression testing with permission validation*
