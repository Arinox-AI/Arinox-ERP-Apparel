---
name: Logical Testing Reporter
description: Perform logical order testing (DOM hierarchy, heading structure, tab order, semantic structure) and generate visual reports with pie charts, bar charts, and detailed failure case documentation. Always produces a report regardless of pass/fail status.
version: 1.0.0
author: Tester Agent
license: MIT
tags: [logical-testing, dom-order, heading-hierarchy, tab-order, semantic-structure, reporting, charts, accessibility]
testingTypes: [accessibility, e2e, logical-order]
frameworks: [playwright, axe-core]
languages: [typescript, javascript]
domains: [web]
agents: [claude-code, cursor, github-copilot, windsurf, codex, aider, continue, cline, zed, bolt]
---

# Logical Testing Reporter Skill

You are an expert logical structure testing engineer. When asked to perform logical testing on a web page, you verify that the DOM structure, heading hierarchy, tab order, semantic landmarks, and content flow follow logical and accessible patterns — then generate a visual report with pie charts, bar charts, and detailed failure documentation.

## Core Principle

**Always create the report — even if every test fails.** The report is the deliverable. Never skip report generation.

---

## What is Logical Testing?

Logical testing verifies that a web page's underlying structure makes sense to assistive technologies, search engines, and keyboard users — regardless of how it visually appears.

### Test Categories

| # | Category | What It Checks | Impact |
|---|----------|---------------|--------|
| 1 | **Heading Hierarchy** | H1→H2→H3 order, no skipped levels, exactly one H1 | HIGH |
| 2 | **DOM Order vs Visual Order** | CSS `order`, `float`, `position` don't break reading order | HIGH |
| 3 | **Tab Order / Focus Sequence** | Tab key follows visual+logical flow, no traps, no jumps | CRITICAL |
| 4 | **Semantic Landmarks** | `<header>`, `<nav>`, `<main>`, `<aside>`, `<footer>` used correctly | MEDIUM |
| 5 | **List Structure** | `<ul>`/`<ol>` used for grouped items, not fake lists with `<div>` | MEDIUM |
| 6 | **Table Structure** | Data tables use `<table>`, `<th>`, `scope`; no layout tables | MEDIUM |
| 7 | **Form Logic** | Labels precede/follow inputs logically, fieldsets group related fields | HIGH |
| 8 | **Link/Button Purpose** | Text makes sense out of context, no "click here" or "read more" | MEDIUM |
| 9 | **Landmark Uniqueness** | Each ARIA landmark has unique label if multiple exist | MEDIUM |
| 10 | **Document Language** | `<html lang>` matches content language | LOW |

---

## Playwright Test Scripts

### 1. Heading Hierarchy Test

```typescript
// tests/logical/heading-hierarchy.spec.ts
import { test, expect } from '@playwright/test';

test.describe('Heading Hierarchy', () => {
  test('should have exactly one H1', async ({ page }) => {
    await page.goto('/');
    const h1s = await page.locator('h1').count();
    expect(h1s, `Found ${h1s} <h1> elements — expected exactly 1`).toBe(1);
  });

  test('heading levels should not skip', async ({ page }) => {
    await page.goto('/');
    const headings = await page.locator('h1, h2, h3, h4, h5, h6').all();
    const levels: number[] = [];

    for (const h of headings) {
      const tag = await h.evaluate(el => el.tagName.toLowerCase());
      levels.push(parseInt(tag.replace('h', '')));
    }

    for (let i = 1; i < levels.length; i++) {
      const prev = levels[i - 1];
      const curr = levels[i];
      expect(curr, `Heading jump: h${prev} → h${curr}`).toBeLessThanOrEqual(prev + 1);
    }
  });

  test('headings should contain text', async ({ page }) => {
    await page.goto('/');
    const headings = await page.locator('h1, h2, h3, h4, h5, h6').all();
    for (const h of headings) {
      const text = await h.textContent();
      expect(text?.trim().length, 'Empty heading found').toBeGreaterThan(0);
    }
  });
});
```

### 2. DOM Order vs Visual Order Test

```typescript
// tests/logical/dom-order.spec.ts
import { test, expect } from '@playwright/test';

test.describe('DOM Order vs Visual Order', () => {
  test('elements with tabindex should not disrupt logical order', async ({ page }) => {
    await page.goto('/');

    const tabIndexed = await page.locator('[tabindex]').all();
    for (const el of tabIndexed) {
      const tabindex = await el.getAttribute('tabindex');
      const tag = await el.evaluate(e => e.tagName.toLowerCase());
      // Only allow tabindex="0" or tabindex="-1"
      expect(
        tabindex === '0' || tabindex === '-1',
        `Element <${tag}> has tabindex="${tabindex}" — positive tabindex disrupts logical order`
      ).toBe(true);
    }
  });

  test('flex/grid order property should not misalign with DOM order', async ({ page }) => {
    await page.goto('/');

    const orderedElements = await page.locator('[style*="order:"], .order-\d+').all();
    // Log for manual review — automated detection of visual/DOM mismatch is heuristic
    if (orderedElements.length > 0) {
      console.warn(`⚠️ Found ${orderedElements.length} elements with CSS 'order' — verify visual order matches DOM order manually`);
    }
  });
});
```

### 3. Tab Order / Focus Sequence Test

```typescript
// tests/logical/tab-order.spec.ts
import { test, expect } from '@playwright/test';

test.describe('Tab Order / Focus Sequence', () => {
  test('tab sequence should follow visual top-to-bottom left-to-right flow', async ({ page }) => {
    await page.goto('/');
    await page.keyboard.press('Tab'); // get into page

    const focusRects: { tag: string; text: string; top: number; left: number }[] = [];

    for (let i = 0; i < 30; i++) {
      const active = await page.evaluate(() => {
        const el = document.activeElement;
        if (!el || el === document.body) return null;
        const rect = el.getBoundingClientRect();
        return {
          tag: el.tagName.toLowerCase(),
          text: (el.textContent || '').trim().substring(0, 40),
          top: rect.top,
          left: rect.left,
        };
      });

      if (!active) break;
      focusRects.push(active);
      await page.keyboard.press('Tab');
    }

    // Check that tab order roughly follows top-to-bottom progression
    for (let i = 1; i < focusRects.length; i++) {
      const prev = focusRects[i - 1];
      const curr = focusRects[i];
      // Allow small backtracking (same row, different column) but flag large jumps upward
      if (curr.top < prev.top - 100) {
        console.warn(`⚠️ Large upward tab jump: ${prev.tag} "${prev.text}" → ${curr.tag} "${curr.text}"`);
      }
    }

    expect(focusRects.length, 'No focusable elements found on page').toBeGreaterThan(0);
  });

  test('no keyboard traps should exist', async ({ page }) => {
    await page.goto('/');
    await page.keyboard.press('Tab');

    const start = await page.evaluate(() => document.activeElement?.outerHTML?.substring(0, 100));
    let trapDetected = false;

    for (let i = 0; i < 20; i++) {
      await page.keyboard.press('Tab');
    }

    const after20Tabs = await page.evaluate(() => document.activeElement?.outerHTML?.substring(0, 100));
    // If we're back at the exact same element after 20 tabs, might be a trap
    // (simplistic heuristic — modals legitimately trap focus)
    if (start === after20Tabs && focusRects.length < 3) {
      trapDetected = true;
    }

    expect(trapDetected, 'Possible keyboard trap detected').toBe(false);
  });
});
```

### 4. Semantic Landmarks Test

```typescript
// tests/logical/landmarks.spec.ts
import { test, expect } from '@playwright/test';

test.describe('Semantic Landmarks', () => {
  test('page should have main landmark', async ({ page }) => {
    await page.goto('/');
    const mainCount = await page.locator('main, [role="main"]').count();
    expect(mainCount, 'No <main> or role="main" found').toBeGreaterThanOrEqual(1);
  });

  test('navigation should be in nav or role="navigation"', async ({ page }) => {
    await page.goto('/');
    const navCount = await page.locator('nav, [role="navigation"]').count();
    expect(navCount, 'No navigation landmark found').toBeGreaterThanOrEqual(1);
  });

  test('multiple landmarks of same type should have unique aria-label', async ({ page }) => {
    await page.goto('/');

    const types = ['nav', 'aside', '[role="region"]', '[role="complementary"]'];
    for (const type of types) {
      const elements = await page.locator(type).all();
      if (elements.length > 1) {
        const labels: (string | null)[] = [];
        for (const el of elements) {
          const label = await el.getAttribute('aria-label');
          labels.push(label);
        }
        const uniqueLabels = new Set(labels.filter(Boolean));
        expect(uniqueLabels.size, `Multiple ${type} landmarks without unique aria-label`).toBeGreaterThanOrEqual(labels.filter(Boolean).length);
      }
    }
  });
});
```

### 5. List & Table Structure Test

```typescript
// tests/logical/structure.spec.ts
import { test, expect } from '@playwright/test';

test.describe('List and Table Structure', () => {
  test('grouped items should use semantic lists', async ({ page }) => {
    await page.goto('/');

    // Heuristic: find divs that look like lists (multiple sibling divs with similar structure)
    const fakeLists = await page.evaluate(() => {
      const suspicious: string[] = [];
      const divs = document.querySelectorAll('div');
      divs.forEach(div => {
        const children = Array.from(div.children);
        if (children.length >= 3 && children.every(c => c.tagName === 'DIV')) {
          // Check if children have similar structure (all have same first child tag)
          const firstTags = children.map(c => c.firstElementChild?.tagName);
          if (new Set(firstTags).size === 1 && firstTags[0]) {
            suspicious.push(div.className || div.id || 'unnamed div');
          }
        }
      });
      return suspicious.slice(0, 5); // limit output
    });

    if (fakeLists.length > 0) {
      console.warn(`⚠️ Possible fake lists detected: ${fakeLists.join(', ')}`);
    }
  });

  test('data tables should have th elements', async ({ page }) => {
    await page.goto('/');
    const tables = await page.locator('table').all();
    for (const table of tables) {
      const thCount = await table.locator('th').count();
      expect(thCount, 'Table without <th> headers found').toBeGreaterThan(0);
    }
  });
});
```

---

## Report Generation — Always Created

The report is generated as an **HTML file** with embedded SVG charts. It is created **even when all tests fail**.

### Report Structure

```
reports/
  logical-testing-report.html   ← Always generated
  logical-testing-report.json   ← Raw data for CI/CD
  screenshots/                  ← Failure screenshots
```

### Generating the Report

Use the provided helper script (see `scripts/generate-logical-report.js`) or embed this logic in your Playwright test runner:

```typescript
// utils/logical-report.ts
export interface LogicalTestCase {
  name: string;
  category: string;
  status: 'PASS' | 'FAIL' | 'WARN' | 'SKIP';
  message?: string;
  selector?: string;
  html?: string;
  screenshot?: string;
}

export interface LogicalReport {
  url: string;
  timestamp: string;
  total: number;
  passed: number;
  failed: number;
  warnings: number;
  skipped: number;
  testCases: LogicalTestCase[];
}
```

### HTML Report with Charts

The report includes:
1. **Pie Chart** — Overall distribution (Pass / Fail / Warn / Skip)
2. **Bar Chart** — Failures per category (Headings, DOM Order, Tab Order, Landmarks, Structure, Forms, Links)
3. **Detailed failure table** — Every failed case with selector, message, and screenshot

---

## 🖼️ Visual Chart Rendering — MANDATORY

**NEVER describe charts in text only.** When this skill is invoked, you MUST render the charts as actual images and present them to the user. Follow this exact workflow:

### Step-by-Step Chart Rendering Workflow

```bash
# 1. Run logical tests and collect results (via page.evaluate)
# Results array saved to: reports/logical-test-data.json

# 2. Generate the HTML report with embedded SVG charts
node scripts/generate-logical-report.js reports/logical-test-data.json reports/logical-testing-report.html

# 3. Serve the report via local HTTP server
cd reports && python3 -m http.server 8888

# 4. Open the report in Playwright browser
playwright-cli goto http://localhost:8888/logical-testing-report.html

# 5. Screenshot the pie chart element
playwright-cli screenshot <pie-chart-ref> --filename=pie-chart.png

# 6. Screenshot the bar chart element
playwright-cli screenshot <bar-chart-ref> --filename=bar-chart.png

# 7. Present both images to user with data tables
```

### Why This Matters
- SVG charts in HTML are **invisible to the LLM** — the raw SVG code is just text
- Screenshots produce **actual rendered images** that the user can see
- Users explicitly expect visual deliverables, not ASCII art descriptions
- This distinguishes professional testing from amateur text-only reporting

### Required Deliverables
After every logical test run, provide:
1. **Pie Chart image** (PNG screenshot) + data table with counts
2. **Bar Chart image** (PNG screenshot) + category breakdown table
3. **Failed/Warn cases table** — every non-pass case with full details
4. **Full HTML report file** — for sharing with development teams

### File Naming Convention
```
reports/
  logical-test-data.json                          ← Raw test results
  logical-testing-report-<page-name>.html         ← HTML report with charts
  pie-chart-<page-name>.png                     ← Pie chart screenshot
  bar-chart-<page-name>.png                     ← Bar chart screenshot
  report-full-page-<page-name>.png              ← Full report screenshot
```

---

## Quick Start — Full Logical Test Suite

```typescript
// tests/logical/full-suite.spec.ts
import { test, expect } from '@playwright/test';
import { generateLogicalReport } from '../../utils/logical-report';

const results: LogicalTestCase[] = [];

function record(name: string, category: string, status: LogicalTestCase['status'], message?: string) {
  results.push({ name, category, status, message });
}

test.afterAll(async () => {
  // ALWAYS generate the report
  await generateLogicalReport({
    url: test.info().config.projects[0]?.use?.baseURL || 'unknown',
    timestamp: new Date().toISOString(),
    total: results.length,
    passed: results.filter(r => r.status === 'PASS').length,
    failed: results.filter(r => r.status === 'FAIL').length,
    warnings: results.filter(r => r.status === 'WARN').length,
    skipped: results.filter(r => r.status === 'SKIP').length,
    testCases: results,
  });
});

test.describe('Logical Testing Suite', () => {
  test('heading hierarchy', async ({ page }) => {
    await page.goto('/');
    // ... run tests ...
    // record('Exactly one H1', 'Headings', h1Count === 1 ? 'PASS' : 'FAIL', `Found ${h1Count} H1s`);
  });
});
```

---

## Failure Case Documentation

Every failed test is documented with:

| Field | Description |
|-------|-------------|
| **Test Name** | Human-readable description |
| **Category** | Heading / DOM Order / Tab Order / Landmarks / Structure / Forms / Links |
| **Severity** | CRITICAL / HIGH / MEDIUM / LOW |
| **Selector** | CSS selector of affected element |
| **HTML Snippet** | Relevant HTML (truncated) |
| **Expected** | What the standard requires |
| **Actual** | What was found |
| **Screenshot** | Visual capture of the issue |
| **WCAG Reference** | Related WCAG criterion |
| **Fix Suggestion** | Actionable developer guidance |

---

## Example Output

### Pie Chart (SVG)

```
        ┌──────────┐
       /   PASS    \    72%
      /   ████████  \
     │   ██  FAIL  ██ │  18%
      \  ██  WARN  ██ /
       \ █  SKIP   █ /
        └──────────┘
```

### Bar Chart — Failures by Category

```
Headings     ████████ 8
DOM Order    ████     4
Tab Order    ██████   6
Landmarks    ██       2
Structure    █        1
Forms        ████     4
Links        ██       2
```

---

## Best Practices

1. **Always generate the report** — even with 0 passes. The absence of data is also data.
2. **Run on every page variant** — desktop, mobile, modal states, error states.
3. **Combine with axe-core** — Logical testing + axe-core gives the most complete a11y picture.
4. **Save screenshots for every FAIL** — Visual proof accelerates bug triage.
5. **Track trends over time** — Store JSON reports to graph improvement/regression.
6. **Warn > Fail for heuristics** — CSS `order` detection is a warning, not a hard fail.
7. **Include keyboard-only user journey** — Tab through real tasks, not just generic tab loops.
8. **ALWAYS render charts as images** — Use the Visual Chart Rendering workflow above. Never describe charts in text only. Users expect actual pie chart and bar chart screenshots.

## Anti-Patterns to Flag

| Anti-Pattern | Why It's Bad | Fix |
|--------------|-------------|-----|
| `h1` → `h3` (skip h2) | Confuses screen reader outline | Insert proper heading levels |
| Positive `tabindex` | Hijacks natural tab order | Use `tabindex="0"` or DOM reordering |
| `<div>` buttons with no `role` | Unreachable to screen readers | Use `<button>` or add `role="button"` |
| Multiple `<nav>` without `aria-label` | Screen reader can't distinguish | Add `aria-label="Primary"` / `aria-label="Footer"` |
| Fake lists with `<div>` + CSS bullets | No list semantics conveyed | Use `<ul>`/`<ol>`/`<li>` |
| Tables for layout | Screen readers announce columns/rows incorrectly | Use CSS Grid / Flexbox for layout |
| "Click here" links | No context when tabbing through links | Use descriptive link text |

---

## Related Skills

- `axe-accessibility` — Automated WCAG violation scanning (complement to logical testing)
- `accessibility-a11y-enhanced` — Full WCAG 2.1/2.2 compliance testing
- `orchestkit-accessibility` — React Aria and focus management patterns
- `playwright-e2e` — General E2E testing with Playwright
- `console-error-hunter` — Detect JS errors that may break logical structure

## 🔗 Skill References

- **SKILL_DIR**: `/workspace/user/69ca076285ad7e2f84c1ae64/69e6fbc0c58cc1eb6440bd9b/userfiles/skills/logical-testing-reporter`
- **Scripts**: `scripts/generate-logical-report.js` — HTML report generator with SVG charts
- **Templates**: `templates/` — Report HTML template and JSON schema
