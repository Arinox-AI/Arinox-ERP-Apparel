/**
 * Logical Testing Reporter — Playwright Integration Utilities
 *
 * Import this in your Playwright test suite to record results
 * and automatically generate the HTML report.
 */

import { execSync } from 'child_process';
import * as fs from 'fs';
import * as path from 'path';

export type TestStatus = 'PASS' | 'FAIL' | 'WARN' | 'SKIP';

export interface LogicalTestCase {
  name: string;
  category: string;
  status: TestStatus;
  message?: string;
  selector?: string;
  html?: string;
  screenshot?: string;
}

export interface LogicalReportData {
  url: string;
  timestamp: string;
  total: number;
  passed: number;
  failed: number;
  warnings: number;
  skipped: number;
  testCases: LogicalTestCase[];
}

export class LogicalReporter {
  private cases: LogicalTestCase[] = [];
  private reportDir: string;

  constructor(reportDir = 'logical-test-reports') {
    this.reportDir = reportDir;
    if (!fs.existsSync(reportDir)) {
      fs.mkdirSync(reportDir, { recursive: true });
    }
  }

  record(name: string, category: string, status: TestStatus, details?: { message?: string; selector?: string; html?: string; screenshot?: string }) {
    this.cases.push({
      name,
      category,
      status,
      message: details?.message,
      selector: details?.selector,
      html: details?.html,
      screenshot: details?.screenshot,
    });
  }

  generate(url: string): { jsonPath: string; htmlPath: string } {
    const data: LogicalReportData = {
      url,
      timestamp: new Date().toISOString(),
      total: this.cases.length,
      passed: this.cases.filter(c => c.status === 'PASS').length,
      failed: this.cases.filter(c => c.status === 'FAIL').length,
      warnings: this.cases.filter(c => c.status === 'WARN').length,
      skipped: this.cases.filter(c => c.status === 'SKIP').length,
      testCases: this.cases,
    };

    const timestamp = Date.now();
    const jsonPath = path.join(this.reportDir, `logical-report-${timestamp}.json`);
    const htmlPath = path.join(this.reportDir, `logical-report-${timestamp}.html`);

    fs.writeFileSync(jsonPath, JSON.stringify(data, null, 2), 'utf-8');

    // Call the Node.js generator script
    const generatorPath = path.resolve(__dirname, 'generate-logical-report.js');
    try {
      execSync(`node "${generatorPath}" "${jsonPath}" "${htmlPath}"`, { stdio: 'inherit' });
    } catch (e) {
      // Fallback: inline generation if script fails
      const { buildReport } = require('./generate-logical-report.js');
      const html = buildReport(data);
      fs.writeFileSync(htmlPath, html, 'utf-8');
    }

    return { jsonPath, htmlPath };
  }

  /** Always call this in test.afterAll() */
  async finalize(url: string) {
    const { htmlPath } = this.generate(url);
    console.log(`\n📊 Logical Testing Report: ${htmlPath}`);
    return htmlPath;
  }
}
