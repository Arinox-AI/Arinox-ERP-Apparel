#!/usr/bin/env node
/**
 * Logical Testing Report Generator
 * Generates an HTML report with SVG pie chart and bar chart from JSON test results.
 *
 * Usage:
 *   node generate-logical-report.js <input.json> [output.html]
 *
 * If no arguments provided, reads from stdin and writes to stdout.
 */

const fs = require('fs');
const path = require('path');

// ────────────────────────────────────────────────
// SVG Chart Helpers
// ────────────────────────────────────────────────

function generatePieChartSVG(pass, fail, warn, skip, size = 320) {
  const total = pass + fail + warn + skip;
  if (total === 0) {
    return `<svg width="${size}" height="${size}" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
      <circle cx="50" cy="50" r="40" fill="#e5e7eb" stroke="#9ca3af" stroke-width="1"/>
      <text x="50" y="52" text-anchor="middle" font-size="6" fill="#6b7280">No tests run</text>
    </svg>`;
  }

  const cx = 50, cy = 50, r = 40;
  let angle = -90; // Start at top

  const slices = [];
  const data = [
    { label: 'PASS', value: pass, color: '#22c55e' },
    { label: 'FAIL', value: fail, color: '#ef4444' },
    { label: 'WARN', value: warn, color: '#f59e0b' },
    { label: 'SKIP', value: skip, color: '#6b7280' },
  ];

  for (const d of data) {
    if (d.value === 0) continue;
    const frac = d.value / total;
    const sweep = frac * 360;
    const endAngle = angle + sweep;

    const x1 = cx + r * Math.cos((angle * Math.PI) / 180);
    const y1 = cy + r * Math.sin((angle * Math.PI) / 180);
    const x2 = cx + r * Math.cos((endAngle * Math.PI) / 180);
    const y2 = cy + r * Math.sin((endAngle * Math.PI) / 180);

    const largeArc = sweep > 180 ? 1 : 0;
    const pathD = `M ${cx} ${cy} L ${x1} ${y1} A ${r} ${r} 0 ${largeArc} 1 ${x2} ${y2} Z`;

    // Label position (mid-angle)
    const midAngle = angle + sweep / 2;
    const lr = r * 0.65;
    const lx = cx + lr * Math.cos((midAngle * Math.PI) / 180);
    const ly = cy + lr * Math.sin((midAngle * Math.PI) / 180);
    const pct = ((d.value / total) * 100).toFixed(1);

    slices.push({ pathD, color: d.color, label: `${d.label} ${pct}%`, lx, ly });
    angle = endAngle;
  }

  // Donut hole
  const holeR = r * 0.45;

  let svg = `<svg width="${size}" height="${size}" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">\n`;
  for (const s of slices) {
    svg += `  <path d="${s.pathD}" fill="${s.color}" stroke="#fff" stroke-width="0.5"/>\n`;
  }
  svg += `  <circle cx="${cx}" cy="${cy}" r="${holeR}" fill="#ffffff"/>\n`;
  for (const s of slices) {
    svg += `  <text x="${s.lx.toFixed(2)}" y="${s.ly.toFixed(2)}" text-anchor="middle" font-size="4" fill="#fff" font-weight="bold" style="text-shadow: 0 0 1px #000;">${s.label}</text>\n`;
  }
  svg += `  <text x="${cx}" y="${cy + 1}" text-anchor="middle" font-size="6" fill="#374151" font-weight="bold">${total}</text>\n`;
  svg += `  <text x="${cx}" y="${cy + 6}" text-anchor="middle" font-size="3.5" fill="#6b7280">Total Tests</text>\n`;
  svg += `</svg>`;
  return svg;
}

function generateBarChartSVG(categoryData, size = 520) {
  // categoryData: { category: string, count: number }[]
  const maxVal = Math.max(...categoryData.map(d => d.count), 1);
  const barHeight = 24;
  const gap = 10;
  const labelWidth = 110;
  const chartWidth = size - labelWidth - 20;
  const chartHeight = categoryData.length * (barHeight + gap) + gap;

  let svg = `<svg width="${size}" height="${chartHeight}" viewBox="0 0 ${size} ${chartHeight}" xmlns="http://www.w3.org/2000/svg">\n`;

  // Background
  svg += `  <rect width="${size}" height="${chartHeight}" fill="#f9fafb" rx="6"/>\n`;

  categoryData.forEach((d, i) => {
    const y = gap + i * (barHeight + gap);
    const barW = (d.count / maxVal) * chartWidth;
    const color = d.count === 0 ? '#e5e7eb' : '#ef4444';

    // Label
    svg += `  <text x="10" y="${y + barHeight / 2 + 4}" font-size="12" fill="#374151" font-weight="500">${escapeXml(d.category)}</text>\n`;

    // Bar background
    svg += `  <rect x="${labelWidth}" y="${y}" width="${chartWidth}" height="${barHeight}" fill="#f3f4f6" rx="4"/>\n`;

    // Bar
    if (d.count > 0) {
      svg += `  <rect x="${labelWidth}" y="${y}" width="${barW}" height="${barHeight}" fill="${color}" rx="4"/>\n`;
    }

    // Count label
    svg += `  <text x="${labelWidth + barW + 6}" y="${y + barHeight / 2 + 4}" font-size="12" fill="#374151" font-weight="bold">${d.count}</text>\n`;
  });

  svg += `</svg>`;
  return svg;
}

function escapeXml(str) {
  return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

// ────────────────────────────────────────────────
// Report Builder
// ─────────────────────────────────────────────────

function buildReport(data) {
  const {
    url = 'unknown',
    timestamp = new Date().toISOString(),
    total = 0,
    passed = 0,
    failed = 0,
    warnings = 0,
    skipped = 0,
    testCases = [],
  } = data;

  const pieChart = generatePieChartSVG(passed, failed, warnings, skipped, 360);

  // Build category bar chart from failures
  const categories = ['Headings', 'DOM Order', 'Tab Order', 'Landmarks', 'Structure', 'Forms', 'Links', 'Other'];
  const categoryCounts = categories.map(cat => ({
    category: cat,
    count: testCases.filter(tc =>
      (tc.category || '').toLowerCase().includes(cat.toLowerCase()) && tc.status === 'FAIL'
    ).length,
  }));
  // Add any uncategorized failures to Other
  const totalCatFailures = categoryCounts.reduce((s, c) => s + c.count, 0);
  const allFailures = testCases.filter(tc => tc.status === 'FAIL').length;
  if (allFailures > totalCatFailures) {
    categoryCounts.find(c => c.category === 'Other').count += (allFailures - totalCatFailures);
  }

  const barChart = generateBarChartSVG(categoryCounts, 560);

  // Build failure table rows
  const failedCases = testCases.filter(tc => tc.status === 'FAIL');
  const failureRows = failedCases.map((tc, idx) => `
    <tr class="failure-row">
      <td class="cell-idx">${idx + 1}</td>
      <td class="cell-name">${escapeXml(tc.name)}</td>
      <td class="cell-cat"><span class="badge-cat">${escapeXml(tc.category || 'Uncategorized')}</span></td>
      <td class="cell-msg">${escapeXml(tc.message || 'No details')}</td>
      <td class="cell-sel"><code>${escapeXml(tc.selector || '—')}</code></td>
      <td class="cell-html"><pre>${escapeXml((tc.html || '').substring(0, 200))}${(tc.html || '').length > 200 ? '…' : ''}</pre></td>
      ${tc.screenshot ? `<td class="cell-ss"><a href="${escapeXml(tc.screenshot)}" target="_blank">📷 View</a></td>` : '<td class="cell-ss">—</td>'}
    </tr>
  `).join('\n');

  const warnCases = testCases.filter(tc => tc.status === 'WARN');
  const warnRows = warnCases.map((tc, idx) => `
    <tr class="warn-row">
      <td class="cell-idx">${idx + 1}</td>
      <td class="cell-name">${escapeXml(tc.name)}</td>
      <td class="cell-cat"><span class="badge-cat-warn">${escapeXml(tc.category || 'Uncategorized')}</span></td>
      <td class="cell-msg">${escapeXml(tc.message || 'No details')}</td>
    </tr>
  `).join('\n');

  const passCases = testCases.filter(tc => tc.status === 'PASS');
  const passRows = passCases.map((tc, idx) => `
    <tr class="pass-row">
      <td class="cell-idx">${idx + 1}</td>
      <td class="cell-name">${escapeXml(tc.name)}</td>
      <td class="cell-cat"><span class="badge-cat-pass">${escapeXml(tc.category || 'Uncategorized')}</span></td>
      <td class="cell-msg">✅ ${escapeXml(tc.message || 'Passed')}</td>
    </tr>
  `).join('\n');

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Logical Testing Report — ${escapeXml(url)}</title>
  <style>
    :root {
      --pass: #22c55e;
      --fail: #ef4444;
      --warn: #f59e0b;
      --skip: #6b7280;
      --bg: #f8fafc;
      --card: #ffffff;
      --text: #1f2937;
      --muted: #6b7280;
      --border: #e5e7eb;
    }
    * { box-sizing: border-box; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
      background: var(--bg);
      color: var(--text);
      margin: 0;
      padding: 24px;
      line-height: 1.5;
    }
    .container { max-width: 1100px; margin: 0 auto; }
    header {
      background: var(--card);
      border-radius: 12px;
      padding: 28px 32px;
      margin-bottom: 24px;
      box-shadow: 0 1px 3px rgba(0,0,0,0.06);
    }
    h1 { margin: 0 0 8px; font-size: 26px; }
    .meta { color: var(--muted); font-size: 14px; }
    .meta span { margin-right: 18px; }

    .stats-grid {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 16px;
      margin-bottom: 24px;
    }
    .stat-card {
      background: var(--card);
      border-radius: 10px;
      padding: 20px 24px;
      text-align: center;
      box-shadow: 0 1px 3px rgba(0,0,0,0.06);
    }
    .stat-value { font-size: 32px; font-weight: 700; }
    .stat-label { font-size: 13px; color: var(--muted); text-transform: uppercase; letter-spacing: 0.5px; }
    .stat-pass .stat-value { color: var(--pass); }
    .stat-fail .stat-value { color: var(--fail); }
    .stat-warn .stat-value { color: var(--warn); }
    .stat-skip .stat-value { color: var(--skip); }

    .charts-row {
      display: grid;
      grid-template-columns: 1fr 1.6fr;
      gap: 20px;
      margin-bottom: 24px;
    }
    .chart-card {
      background: var(--card);
      border-radius: 10px;
      padding: 20px;
      box-shadow: 0 1px 3px rgba(0,0,0,0.06);
    }
    .chart-title { font-size: 15px; font-weight: 600; margin-bottom: 12px; color: var(--text); }

    .section {
      background: var(--card);
      border-radius: 10px;
      padding: 24px;
      margin-bottom: 20px;
      box-shadow: 0 1px 3px rgba(0,0,0,0.06);
    }
    .section h2 { margin: 0 0 14px; font-size: 18px; }

    table {
      width: 100%;
      border-collapse: collapse;
      font-size: 13px;
    }
    th {
      text-align: left;
      padding: 10px 12px;
      border-bottom: 2px solid var(--border);
      color: var(--muted);
      font-weight: 600;
      text-transform: uppercase;
      font-size: 11px;
      letter-spacing: 0.4px;
    }
    td {
      padding: 10px 12px;
      border-bottom: 1px solid var(--border);
      vertical-align: top;
    }
    tr:hover { background: #f9fafb; }
    .failure-row td { border-left: 3px solid var(--fail); }
    .warn-row td { border-left: 3px solid var(--warn); }
    .pass-row td { border-left: 3px solid var(--pass); }

    .badge-cat {
      display: inline-block;
      background: #fee2e2;
      color: #991b1b;
      padding: 2px 8px;
      border-radius: 999px;
      font-size: 11px;
      font-weight: 600;
    }
    .badge-cat-warn {
      display: inline-block;
      background: #fef3c7;
      color: #92400e;
      padding: 2px 8px;
      border-radius: 999px;
      font-size: 11px;
      font-weight: 600;
    }
    .badge-cat-pass {
      display: inline-block;
      background: #dcfce7;
      color: #166534;
      padding: 2px 8px;
      border-radius: 999px;
      font-size: 11px;
      font-weight: 600;
    }

    pre {
      background: #f3f4f6;
      padding: 6px 8px;
      border-radius: 6px;
      overflow-x: auto;
      max-width: 300px;
      font-size: 11px;
      margin: 0;
    }
    code {
      background: #f3f4f6;
      padding: 2px 6px;
      border-radius: 4px;
      font-size: 12px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, monospace;
    }

    .empty-state {
      text-align: center;
      padding: 40px;
      color: var(--muted);
    }
    .footer {
      text-align: center;
      color: var(--muted);
      font-size: 12px;
      padding: 20px;
    }

    @media (max-width: 860px) {
      .stats-grid { grid-template-columns: repeat(2, 1fr); }
      .charts-row { grid-template-columns: 1fr; }
      body { padding: 12px; }
    }
  </style>
</head>
<body>
  <div class="container">
    <header>
      <h1>🧠 Logical Testing Report</h1>
      <div class="meta">
        <span>🔗 <strong>URL:</strong> ${escapeXml(url)}</span>
        <span>🕒 <strong>Run:</strong> ${new Date(timestamp).toLocaleString()}</span>
        <span>📊 <strong>Total:</strong> ${total} tests</span>
      </div>
    </header>

    <div class="stats-grid">
      <div class="stat-card stat-pass">
        <div class="stat-value">${passed}</div>
        <div class="stat-label">Passed</div>
      </div>
      <div class="stat-card stat-fail">
        <div class="stat-value">${failed}</div>
        <div class="stat-label">Failed</div>
      </div>
      <div class="stat-card stat-warn">
        <div class="stat-value">${warnings}</div>
        <div class="stat-label">Warnings</div>
      </div>
      <div class="stat-card stat-skip">
        <div class="stat-value">${skipped}</div>
        <div class="stat-label">Skipped</div>
      </div>
    </div>

    <div class="charts-row">
      <div class="chart-card">
        <div class="chart-title">📊 Result Distribution</div>
        <div style="display:flex;justify-content:center;">${pieChart}</div>
      </div>
      <div class="chart-card">
        <div class="chart-title">📉 Failures by Category</div>
        <div style="display:flex;justify-content:center;">${barChart}</div>
      </div>
    </div>

    ${failedCases.length > 0 ? `
    <div class="section">
      <h2>❌ Failed Cases (${failedCases.length})</h2>
      <div style="overflow-x:auto;">
        <table>
          <thead>
            <tr>
              <th>#</th>
              <th>Test Name</th>
              <th>Category</th>
              <th>Failure Message</th>
              <th>Selector</th>
              <th>HTML Snippet</th>
              <th>Screenshot</th>
            </tr>
          </thead>
          <tbody>
            ${failureRows}
          </tbody>
        </table>
      </div>
    </div>
    ` : `
    <div class="section">
      <h2>❌ Failed Cases</h2>
      <div class="empty-state">🎉 No failures detected!</div>
    </div>
    `}

    ${warnCases.length > 0 ? `
    <div class="section">
      <h2>⚠️ Warnings (${warnCases.length})</h2>
      <div style="overflow-x:auto;">
        <table>
          <thead>
            <tr><th>#</th><th>Test Name</th><th>Category</th><th>Message</th></tr>
          </thead>
          <tbody>${warnRows}</tbody>
        </table>
      </div>
    </div>
    ` : ''}

    ${passCases.length > 0 ? `
    <div class="section">
      <h2>✅ Passed Cases (${passCases.length})</h2>
      <div style="overflow-x:auto;">
        <table>
          <thead>
            <tr><th>#</th><th>Test Name</th><th>Category</th><th>Details</th></tr>
          </thead>
          <tbody>${passRows}</tbody>
        </table>
      </div>
    </div>
    ` : ''}

    <div class="footer">
      Generated by Logical Testing Reporter Skill — KOGO AI Tester Agent
    </div>
  </div>
</body>
</html>`;
}

// ────────────────────────────────────────────────
// CLI
// ────────────────────────────────────────────────

function main() {
  let inputData;
  let outputPath;

  if (process.argv.length >= 3) {
    const inputPath = process.argv[2];
    outputPath = process.argv[3] || inputPath.replace(/\.json$/i, '.html');
    inputData = JSON.parse(fs.readFileSync(inputPath, 'utf-8'));
  } else {
    // Read from stdin
    let stdin = '';
    process.stdin.setEncoding('utf-8');
    process.stdin.on('data', d => stdin += d);
    process.stdin.on('end', () => {
      inputData = JSON.parse(stdin);
      const html = buildReport(inputData);
      process.stdout.write(html);
    });
    return;
  }

  const html = buildReport(inputData);

  // Always write the report
  const outDir = path.dirname(outputPath);
  if (!fs.existsSync(outDir)) {
    fs.mkdirSync(outDir, { recursive: true });
  }
  fs.writeFileSync(outputPath, html, 'utf-8');
  console.log(`✅ Logical Testing Report generated: ${outputPath}`);
  console.log(`   URL: ${inputData.url || 'unknown'}`);
  console.log(`   Total: ${inputData.total || 0} | Pass: ${inputData.passed || 0} | Fail: ${inputData.failed || 0} | Warn: ${inputData.warnings || 0} | Skip: ${inputData.skipped || 0}`);
}

if (require.main === module) {
  main();
}

module.exports = { buildReport, generatePieChartSVG, generateBarChartSVG };
