// SKILL VALIDATION TEST SUITE
// Tests all 32 active skills against https://kogo.ai
// Run from: cd playwright-skill && node ../skill-validation-test.js

const { chromium, devices } = require('playwright');
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const TARGET = 'https://kogo.ai';
const RESULTS_DIR = '/tmp/skill-validation-results';
const SCREENSHOTS_DIR = `${RESULTS_DIR}/screenshots`;
const SKILLS_ROOT = '/workspace/user/69ca076285ad7e2f84c1ae64/69e6fbc0c58cc1eb6440bd9b/userfiles/skills';

fs.mkdirSync(RESULTS_DIR, { recursive: true });
fs.mkdirSync(SCREENSHOTS_DIR, { recursive: true });

const results = { target: TARGET, timestamp: new Date().toISOString(), skills: {}, summary: { total: 0, passed: 0, failed: 0, warnings: 0 } };

function record(skillName, status, detail, evidence = '') {
  results.skills[skillName] = { status, detail, evidence };
  results.summary.total++;
  if (status === 'PASS') results.summary.passed++;
  else if (status === 'FAIL') results.summary.failed++;
  else results.summary.warnings++;
  const icon = status === 'PASS' ? '✅' : status === 'FAIL' ? '❌' : '⚠️';
  console.log(`${icon} [${skillName}] ${status}: ${detail}`);
}

function readSkill(name) {
  return fs.readFileSync(`${SKILLS_ROOT}/${name}/SKILL.md`, 'utf8');
}

(async () => {
  console.log('\n🔬 SKILL VALIDATION — Testing all 32 skills against ' + TARGET);
  console.log('='.repeat(70));

  const browser = await chromium.launch({ headless: true, args: ['--no-sandbox', '--disable-gpu'] });
  const context = await browser.newContext({ viewport: { width: 1920, height: 1080 }, ignoreHTTPSErrors: true });
  const page = await context.newPage();

  // ── 1. playwright-cli ──────────────────────────────────
  try {
    await page.goto(TARGET, { waitUntil: 'domcontentloaded', timeout: 30000 });
    const title = await page.title();
    await page.screenshot({ path: `${SCREENSHOTS_DIR}/01-homepage.png` });
    record('playwright-cli', 'PASS', `Navigated, title: "${title}", screenshot saved`);
  } catch (e) { record('playwright-cli', 'FAIL', e.message); }

  // ── 2. playwright-skill ────────────────────────────────
  try {
    assert(fs.existsSync(`${SKILLS_ROOT}/playwright-skill/lib/helpers.js`), 'helpers.js missing');
    assert(fs.existsSync(`${SKILLS_ROOT}/playwright-skill/run.js`), 'run.js missing');
    const out = execSync(`node -e "const p=require('playwright'); console.log('OK:'+p.chromium?"yes":"no")"`, { encoding: 'utf8', timeout: 10000 });
    record('playwright-skill', 'PASS', 'helpers.js + run.js exist, playwright module loads');
  } catch (e) { record('playwright-skill', 'FAIL', e.message); }

  // ── 3. playwright-cli-agents ───────────────────────────
  try {
    ['playwright-cli-planner.md', 'playwright-cli-generator.md', 'playwright-cli-healer.md', '../SKILL.md'].forEach(f => {
      const p = f.includes('..') ? `${SKILLS_ROOT}/playwright-cli-agents/SKILL.md` : `${SKILLS_ROOT}/playwright-cli-agents/agents/${f}`;
      assert(fs.existsSync(p), `${f} missing`);
    });
    record('playwright-cli-agents', 'PASS', 'Planner + Generator + Healer + SKILL.md all exist');
  } catch (e) { record('playwright-cli-agents', 'FAIL', e.message); }

  // ── 4. playwright-e2e ─────────────────────────────────
  try {
    const md = readSkill('playwright-e2e');
    assert(md.includes('getByRole'), 'Should mention getByRole');
    const h1 = await page.locator('h1').first().textContent().catch(() => null);
    record('playwright-e2e', h1 ? 'PASS' : 'WARN', `E2E selectors work — h1: "${(h1||'').substring(0,60)}"`);
  } catch (e) { record('playwright-e2e', 'FAIL', e.message); }

  // ── 5. playwright-advance-e2e ─────────────────────────
  try {
    const md = readSkill('playwright-advance-e2e');
    const layers = ['Config','Pages','Modules','Utils','API','Fixtures','Reporting','CI'];
    const found = layers.filter(l => md.includes(l));
    record('playwright-advance-e2e', found.length >= 6 ? 'PASS' : 'FAIL', `${found.length}/8 layers documented: ${found.join(', ')}`);
  } catch (e) { record('playwright-advance-e2e', 'FAIL', e.message); }

  // ── 6. e2e-pom-visual ─────────────────────────────────
  try {
    const md = readSkill('e2e-pom-visual');
    assert(md.includes('visual'), 'Should reference visual');
    const navCount = await page.locator('nav a').count().catch(() => 0);
    record('e2e-pom-visual', 'PASS', `POM+Visual patterns documented, ${navCount} nav links found`);
  } catch (e) { record('e2e-pom-visual', 'FAIL', e.message); }

  // ── 7. e2e-test-conventions ───────────────────────────
  try {
    const md = readSkill('e2e-test-conventions');
    assert(md.includes('getByRole') || md.includes('selector'), 'selector priority');
    assert(md.includes('BasePage') || md.includes('base'), 'BasePage');
    record('e2e-test-conventions', 'PASS', 'Selector priority + BasePage conventions documented');
  } catch (e) { record('e2e-test-conventions', 'FAIL', e.message); }

  // ── 8. e2e-test-suite-init ────────────────────────────
  try {
    const md = readSkill('e2e-test-suite-init');
    assert(md.includes('playwright.config') || md.includes('config'), 'config');
    fs.mkdirSync('/tmp/scaffold-test/e2e', { recursive: true });
    fs.writeFileSync('/tmp/scaffold-test/e2e/demo.spec.ts', `test('x', async ({page}) => {});`);
    assert(fs.existsSync('/tmp/scaffold-test/e2e/demo.spec.ts'), 'scaffold works');
    record('e2e-test-suite-init', 'PASS', 'Scaffold pattern validated — can create e2e/ structure');
  } catch (e) { record('e2e-test-suite-init', 'FAIL', e.message); }

  // ── 9. create-pom ─────────────────────────────────────
  try {
    const md = readSkill('create-pom');
    assert(md.includes('LIFECYCLE') || md.includes('LOCATORS'), 'POM sections');
    const h1 = await page.locator('h1').first().textContent().catch(() => 'N/A');
    record('create-pom', 'PASS', `POM generation pattern works — h1: "${(h1).substring(0,50)}"`);
  } catch (e) { record('create-pom', 'FAIL', e.message); }

  // ── 10. create-regression-test ────────────────────────
  try {
    const md = readSkill('create-regression-test');
    assert(md.includes('regression') || md.includes('smoke'), 'regression/smoke');
    assert(md.includes('fixture') || md.includes('test data'), 'fixtures');
    record('create-regression-test', 'PASS', 'Regression + fixture patterns documented');
  } catch (e) { record('create-regression-test', 'FAIL', e.message); }

  // ── 11. accessibility-a11y-enhanced ───────────────────
  try {
    const AxeBuilder = require('@axe-core/playwright').default;
    const res = await new AxeBuilder({ page }).withTags(['wcag2a','wcag2aa']).analyze();
    record('accessibility-a11y-enhanced', 'PASS', `axe-core scan: ${res.violations.length} violations, ${res.passes.length} passes`);
  } catch (e) { record('accessibility-a11y-enhanced', 'WARN', `axe-core issue: ${e.message.substring(0,150)}`); }

  // ── 12. axe-accessibility ─────────────────────────────
  try {
    const AxeBuilder = require('@axe-core/playwright').default;
    const navCount = await page.locator('nav').count();
    if (navCount > 0) {
      const res = await new AxeBuilder({ page }).include('nav').analyze();
      record('axe-accessibility', 'PASS', `Component axe on <nav>: ${res.violations.length} violations`);
    } else {
      record('axe-accessibility', 'WARN', 'No <nav> for component scan');
    }
  } catch (e) { record('axe-accessibility', 'WARN', `Component scan issue: ${e.message.substring(0,150)}`); }

  // ── 13. orchestkit-accessibility ──────────────────────
  try {
    const md = readSkill('orchestkit-accessibility');
    assert(md.includes('React Aria') || md.includes('FocusScope'), 'React Aria');
    assert(md.includes('WCAG'), 'WCAG');
    record('orchestkit-accessibility', 'PASS', 'React Aria + WCAG + FocusScope patterns documented');
  } catch (e) { record('orchestkit-accessibility', 'FAIL', e.message); }

  // ── 14. visual-regression ─────────────────────────────
  try {
    await page.screenshot({ path: `${SCREENSHOTS_DIR}/14-baseline.png`, fullPage: true });
    await page.reload({ waitUntil: 'domcontentloaded' });
    await page.screenshot({ path: `${SCREENSHOTS_DIR}/14-compare.png`, fullPage: true });
    const b1 = fs.statSync(`${SCREENSHOTS_DIR}/14-baseline.png`).size;
    const b2 = fs.statSync(`${SCREENSHOTS_DIR}/14-compare.png`).size;
    record('visual-regression', 'PASS', `Baseline screenshots captured (${b1} vs ${b2} bytes)`);
  } catch (e) { record('visual-regression', 'FAIL', e.message); }

  // ── 15. visual-diff ──────────────────────────────────
  try {
    const vps = [{n:'desktop',w:1920,h:1080},{n:'tablet',w:768,h:1024},{n:'mobile',w:375,h:812}];
    for (const v of vps) {
      await page.setViewportSize({width:v.w,height:v.h});
      await page.screenshot({path:`${SCREENSHOTS_DIR}/15-${v.n}.png`});
    }
    await page.setViewportSize({width:1920,height:1080});
    record('visual-diff', 'PASS', 'Desktop + Tablet + Mobile screenshots captured');
  } catch (e) { record('visual-diff', 'FAIL', e.message); }

  // ── 16. orchestkit-storybook-testing ──────────────────
  try {
    const md = readSkill('orchestkit-storybook-testing');
    assert(md.includes('CSF3') || md.includes('Storybook'), 'Storybook');
    assert(md.includes('Chromatic') || md.includes('play()'), 'visual testing');
    record('orchestkit-storybook-testing', 'PASS', 'Storybook 10 + Vitest + CSF3 + Chromatic documented');
  } catch (e) { record('orchestkit-storybook-testing', 'FAIL', e.message); }

  // ── 17. playwright-mobile-web ─────────────────────────
  try {
    const iPhone = devices['iPhone 13'];
    const mCtx = await browser.newContext({ ...iPhone, ignoreHTTPSErrors: true });
    const mPage = await mCtx.newPage();
    await mPage.goto(TARGET, { waitUntil: 'domcontentloaded', timeout: 30000 });
    const t = await mPage.title();
    await mPage.screenshot({ path: `${SCREENSHOTS_DIR}/17-mobile.png` });
    await mCtx.close();
    record('playwright-mobile-web', 'PASS', `iPhone 13 emulation works — title: "${t}"`);
  } catch (e) { record('playwright-mobile-web', 'FAIL', e.message); }

  // ── 18. responsive-layout-breaker ────────────────────
  try {
    const vps = [{w:320,h:568},{w:375,h:667},{w:768,h:1024},{w:1280,h:720},{w:1920,h:1080}];
    let overflows = 0;
    for (const v of vps) {
      await page.setViewportSize({width:v.w,height:v.h});
      const o = await page.evaluate(() => ({ h: Math.max(0, document.body.scrollWidth - document.documentElement.clientWidth) }));
      if (o.h > 10) overflows++;
    }
    await page.setViewportSize({width:1920,height:1080});
    record('responsive-layout-breaker', 'PASS', `5 viewports tested, ${overflows} overflow issues detected`);
  } catch (e) { record('responsive-layout-breaker', 'FAIL', e.message); }

  // ── 19. orchestkit-responsive-patterns ───────────────
  try {
    const md = readSkill('orchestkit-responsive-patterns');
    assert(md.includes('Container') || md.includes('container'), 'Container Queries');
    assert(md.includes('fluid') || md.includes('clamp'), 'fluid/clamp');
    record('orchestkit-responsive-patterns', 'PASS', 'Container Queries + fluid typography patterns documented');
  } catch (e) { record('orchestkit-responsive-patterns', 'FAIL', e.message); }

  // ── 20. perf-audit ───────────────────────────────────
  try {
    const lhOut = execSync(`npx lighthouse ${TARGET} --output=json --chrome-flags="--headless --no-sandbox --disable-gpu" --only-categories=performance 2>/dev/null`, { timeout: 60000, encoding: 'utf8' });
    const lh = JSON.parse(lhOut);
    const score = Math.round((lh.categories?.performance?.score ?? 0) * 100);
    const lcp = lh.audits?.['largest-contentful-paint']?.displayValue || 'N/A';
    const cls = lh.audits?.['cumulative-layout-shift']?.displayValue || 'N/A';
    record('perf-audit', 'PASS', `Lighthouse perf: ${score}/100, LCP: ${lcp}, CLS: ${cls}`);
  } catch (e) { record('perf-audit', 'WARN', `Lighthouse issue: ${e.message.substring(0,200)}`); }

  // ── 21. orchestkit-testing-perf ──────────────────────
  try {
    const md = readSkill('orchestkit-testing-perf');
    assert(md.includes('k6') || md.includes('Locust'), 'k6/Locust');
    record('orchestkit-testing-perf', 'PASS', 'k6 + Locust load testing patterns documented');
  } catch (e) { record('orchestkit-testing-perf', 'FAIL', e.message); }

  // ── 22. console-error-hunter ──────────────────────────
  try {
    const errs = [], warns = [];
    page.on('console', m => { if (m.type()==='error') errs.push(m.text()); if (m.type()==='warning') warns.push(m.text()); });
    page.on('pageerror', e => errs.push(`PAGE_ERR: ${e.message}`));
    await page.goto(TARGET, { waitUntil: 'networkidle', timeout: 30000 }).catch(()=>{});
    await page.waitForTimeout(2000);
    record('console-error-hunter', 'PASS', `Captured ${errs.length} errors, ${warns.length} warnings — skill WORKS`);
  } catch (e) { record('console-error-hunter', 'FAIL', e.message); }

  // ── 23. dark-mode-bug-finder ─────────────────────────
  try {
    await page.emulateMedia({ colorScheme: 'dark' });
    await page.reload({ waitUntil: 'domcontentloaded' });
    await page.screenshot({ path: `${SCREENSHOTS_DIR}/23-dark-mode.png` });
    const darkCss = await page.evaluate(() => {
      const s = getComputedStyle(document.documentElement);
      return { bg: s.backgroundColor, fg: s.color };
    });
    await page.emulateMedia({ colorScheme: 'light' });
    await page.reload({ waitUntil: 'domcontentloaded' });
    record('dark-mode-bug-finder', 'PASS', `Dark mode emulation works — bg: "${darkCss.bg}", fg: "${darkCss.fg}"`);
  } catch (e) { record('dark-mode-bug-finder', 'FAIL', e.message); }

  // ── 24. form-validation-breaker ──────────────────────
  try {
    const forms = await page.locator('form').count();
    const inputs = await page.locator('input:visible').count();
    const emailInput = page.locator('input[type="email"], input[name*="email"]').first();
    const hasEmail = await emailInput.count().catch(()=>0);
    if (hasEmail > 0) {
      await emailInput.fill('a'.repeat(256) + '@test.com');
      const val = await emailInput.inputValue();
      record('form-validation-breaker', 'PASS', `${forms} forms, ${inputs} inputs. Boundary test: input accepted ${val.length} chars`);
    } else {
      record('form-validation-breaker', 'PASS', `${forms} forms, ${inputs} inputs found — form detection works`);
    }
  } catch (e) { record('form-validation-breaker', 'FAIL', e.message); }

  // ── 25. loading-state-tester ─────────────────────────
  try {
    const loading = await page.evaluate(() => {
      const spinners = document.querySelectorAll('[class*="spinner"],[class*="loading"],[class*="skeleton"],[role="progressbar"]');
      return { count: spinners.length, hasText: document.body.innerText.includes('Loading') };
    });
    record('loading-state-tester', 'PASS', `Loading detection works — ${loading.count} spinner elements, hasText: ${loading.hasText}`);
  } catch (e) { record('loading-state-tester', 'FAIL', e.message); }

  // ── 26. empty-state-reviewer ────────────────────────
  try {
    const empty = await page.evaluate(() => {
      return {
        emptyContainers: document.querySelectorAll('[class*="empty"],[class*="no-data"],[class*="no-results"]').length,
        illustrations: document.querySelectorAll('[class*="illustration"],[class*="empty-state"]').length
      };
    });
    record('empty-state-reviewer', 'PASS', `Empty state detection works — ${empty.emptyContainers} empty containers, ${empty.illustrations} illustrations`);
  } catch (e) { record('empty-state-reviewer', 'FAIL', e.message); }

  // ── 27. error-boundary-tester ────────────────────────
  try {
    const react = await page.evaluate(() => ({
      hasReact: typeof window.__REACT_DEVTOOLS_GLOBAL_HOOK__ !== 'undefined',
      hasRoot: document.querySelector('#root, #__next') !== null,
      hasBoundary: document.querySelector('[class*="error-boundary"],[class*="ErrorBoundary"]') !== null
    }));
    record('error-boundary-tester', 'PASS', `React detection: ${react.hasReact}, Root: ${react.hasRoot}, Boundary: ${react.hasBoundary}`);
  } catch (e) { record('error-boundary-tester', 'FAIL', e.message); }

  // ── 28. ux-friction-logger ───────────────────────────
  try {
    const ux = await page.evaluate(() => ({
      navItems: document.querySelectorAll('nav a,nav button').length,
      formFields: document.querySelectorAll('input,select,textarea').length,
      modals: document.querySelectorAll('[role="dialog"],[class*="modal"]').length,
      tooltips: document.querySelectorAll('[role="tooltip"],[class*="tooltip"]').length
    }));
    record('ux-friction-logger', 'PASS', `UX friction metrics: ${ux.navItems} nav, ${ux.formFields} fields, ${ux.modals} modals, ${ux.tooltips} tooltips`);
  } catch (e) { record('ux-friction-logger', 'FAIL', e.message); }

  // ── 29. pentest ──────────────────────────────────────
  try {
    const recon = await page.evaluate(() => ({
      cookies: document.cookie ? document.cookie.split(';').length : 0,
      hiddenInputs: document.querySelectorAll('input[type="hidden"]').length,
      inlineScripts: document.querySelectorAll('script:not([src])').length,
      forms: document.querySelectorAll('form').length
    }));
    record('pentest', 'PASS', `Recon (PASSIVE) works — ${recon.cookies} cookies, ${recon.hiddenInputs} hidden inputs, ${recon.inlineScripts} inline scripts`);
  } catch (e) { record('pentest', 'FAIL', e.message); }

  // ── 30. security-audit ───────────────────────────────
  try {
    const sec = await page.evaluate(() => {
      const issues = [];
      document.querySelectorAll('script').forEach(s => {
        if (s.textContent?.includes('innerHTML')) issues.push('innerHTML usage');
        if (s.textContent?.includes('eval(')) issues.push('eval() usage');
      });
      document.querySelectorAll('form[method="post"],form[method="POST"]').forEach(f => {
        if (!f.querySelector('input[name*="csrf"],input[name*="token"]')) issues.push('POST form without CSRF');
      });
      return { issues: [...new Set(issues)], formCount: document.querySelectorAll('form').length };
    });
    record('security-audit', 'PASS', `Security scan works — ${sec.formCount} forms, ${sec.issues.length} issues: ${sec.issues.join(', ') || 'none'}`);
  } catch (e) { record('security-audit', 'FAIL', e.message); }

  // ── 31. project-testing-hub ──────────────────────────
  try {
    const md = readSkill('project-testing-hub');
    assert(md.includes('init-project'), 'init-project');
    assert(md.includes('generate-report') || md.includes('report'), 'report');
    assert(md.includes('log-bug') || md.includes('bug'), 'bug tracking');
    record('project-testing-hub', 'PASS', 'init-project + report + bug tracking all documented');
  } catch (e) { record('project-testing-hub', 'FAIL', e.message); }

  // ── 32. orchestkit-testing-e2e ───────────────────────
  try {
    const md = readSkill('orchestkit-testing-e2e');
    assert(md.includes('page object') || md.includes('Page Object'), 'page objects');
    assert(md.includes('accessibility') || md.includes('axe'), 'accessibility');
    record('orchestkit-testing-e2e', 'PASS', 'Page objects + accessibility patterns documented');
  } catch (e) { record('orchestkit-testing-e2e', 'FAIL', e.message); }

  // ── INTERLINKING TEST ────────────────────────────────
  try {
    const cliMd = readSkill('playwright-cli');
    const skillMd = readSkill('playwright-skill');
    const expected = ['accessibility-a11y-enhanced','axe-accessibility','visual-regression','visual-diff','perf-audit','security-audit','pentest','form-validation-breaker','console-error-hunter','responsive-layout-breaker','playwright-mobile-web','dark-mode-bug-finder','loading-state-tester','empty-state-reviewer','error-boundary-tester','ux-friction-logger','project-testing-hub','e2e-test-suite-init','create-pom','create-regression-test','playwright-advance-e2e'];
    let cliN = 0, skillN = 0;
    for (const l of expected) { if (cliMd.includes(l)) cliN++; if (skillMd.includes(l)) skillN++; }
    record('interlinking-cli', cliN >= 15 ? 'PASS' : 'FAIL', `playwright-cli links ${cliN}/${expected.length} spoke skills`);
    record('interlinking-skill', skillN >= 15 ? 'PASS' : 'FAIL', `playwright-skill links ${skillN}/${expected.length} spoke skills`);
  } catch (e) { record('interlinking', 'FAIL', e.message); }

  // ── SAFETY GATE TEST ─────────────────────────────────
  try {
    const pentestMd = readSkill('pentest');
    const formMd = readSkill('form-validation-breaker');
    const pSafe = pentestMd.includes('SAFETY GATE') && pentestMd.includes('confirm') && pentestMd.includes('production');
    const fSafe = formMd.includes('SAFETY GATE') && formMd.includes('confirm') && formMd.includes('production');
    record('safety-pentest', pSafe ? 'PASS' : 'FAIL', `Pentest safety gate: ${pSafe}`);
    record('safety-form-breaker', fSafe ? 'PASS' : 'FAIL', `Form breaker safety gate: ${fSafe}`);
  } catch (e) { record('safety-gates', 'FAIL', e.message); }

  // ── CLEANUP ──────────────────────────────────────────
  await browser.close();

  fs.writeFileSync(`${RESULTS_DIR}/skill-validation-report.json`, JSON.stringify(results, null, 2));

  console.log('\n' + '='.repeat(70));
  console.log('📊 FINAL CERTIFICATION RESULTS');
  console.log('='.repeat(70));
  console.log(`Total: ${results.summary.total} | ✅ Passed: ${results.summary.passed} | ❌ Failed: ${results.summary.failed} | ⚠️ Warnings: ${results.summary.warnings}`);
  console.log(`Pass Rate: ${((results.summary.passed / results.summary.total) * 100).toFixed(1)}%`);
  console.log(`Report: ${RESULTS_DIR}/skill-validation-report.json`);
  console.log(`Screenshots: ${SCREENSHOTS_DIR}/`);

  const fails = Object.entries(results.skills).filter(([_,v]) => v.status === 'FAIL');
  if (fails.length) { console.log('\n❌ FAILURES:'); fails.forEach(([n,v]) => console.log(`   - ${n}: ${v.detail}`)); }

  const warns = Object.entries(results.skills).filter(([_,v]) => v.status === 'WARN');
  if (warns.length) { console.log('\n⚠️ WARNINGS:'); warns.forEach(([n,v]) => console.log(`   - ${n}: ${v.detail}`)); }

})().catch(err => { console.error('FATAL:', err); process.exit(1); });
