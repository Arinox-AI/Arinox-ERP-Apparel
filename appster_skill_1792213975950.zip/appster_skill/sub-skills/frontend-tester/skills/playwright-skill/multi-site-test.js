// LIVE MULTI-SITE VALIDATION — 3 popular websites, all 32 skills
const { chromium, devices } = require('playwright');
const fs = require('fs');
const { execSync } = require('child_process');

const SITES = [
  { name: 'Wikipedia', url: 'https://www.wikipedia.org' },
  { name: 'GitHub', url: 'https://github.com' },
  { name: 'Amazon', url: 'https://www.amazon.com' }
];

const RESULTS_DIR = '/tmp/multi-site-validation';
const SCREENSHOTS_DIR = `${RESULTS_DIR}/screenshots`;
const SKILLS_ROOT = '/workspace/user/69ca076285ad7e2f84c1ae64/69e6fbc0c58cc1eb6440bd9b/userfiles/skills';

fs.mkdirSync(RESULTS_DIR, { recursive: true });
fs.mkdirSync(SCREENSHOTS_DIR, { recursive: true });

const allResults = {};

function record(site, skill, status, detail) {
  if (!allResults[site]) allResults[site] = {};
  allResults[site][skill] = { status, detail };
  const icon = status === 'PASS' ? '✅' : status === 'FAIL' ? '❌' : '⚠️';
  console.log(`${icon} [${site}|${skill}] ${status}: ${detail.substring(0, 120)}`);
}

(async () => {
  const browser = await chromium.launch({ headless: true, args: ['--no-sandbox', '--disable-gpu', '--disable-dev-shm-usage'] });

  for (const site of SITES) {
    console.log(`\n${'='.repeat(70)}`);
    console.log(`🌐 Testing: ${site.name} (${site.url})`);
    console.log('='.repeat(70));

    const context = await browser.newContext({ viewport: { width: 1920, height: 1080 }, ignoreHTTPSErrors: true });
    const page = await context.newPage();
    const consoleErrors = [], consoleWarnings = [], pageErrors = [];
    
    page.on('console', m => {
      if (m.type() === 'error') consoleErrors.push(m.text().substring(0, 200));
      if (m.type() === 'warning') consoleWarnings.push(m.text().substring(0, 200));
    });
    page.on('pageerror', e => pageErrors.push(e.message.substring(0, 200)));

    try {
      await page.goto(site.url, { waitUntil: 'domcontentloaded', timeout: 30000 });
    } catch (e) {
      console.log(`⚠️ Navigation warning: ${e.message.substring(0, 100)}`);
      await page.goto(site.url, { waitUntil: 'load', timeout: 30000 }).catch(() => {});
    }

    const title = await page.title().catch(() => 'N/A');
    const ssDir = `${SCREENSHOTS_DIR}/${site.name.toLowerCase()}`;
    fs.mkdirSync(ssDir, { recursive: true });

    // ── 1. PLAYWRIGHT-CLI: Core navigation + screenshot ──
    try {
      await page.screenshot({ path: `${ssDir}/01-homepage.png` });
      const snapshot = await page.locator('body').ariaSnapshot().catch(() => 'N/A');
      record(site.name, 'playwright-cli', 'PASS', `Title: "${title}", screenshot saved, snapshot: ${snapshot.length} chars`);
    } catch (e) { record(site.name, 'playwright-cli', 'FAIL', e.message); }

    // ── 2. PLAYWRIGHT-E2E: Selector patterns ──
    try {
      const h1 = await page.locator('h1').first().textContent().catch(() => 'N/A');
      const navLinks = await page.locator('nav a, [role="navigation"] a').count().catch(() => 0);
      const links = await page.locator('a').count().catch(() => 0);
      record(site.name, 'playwright-e2e', 'PASS', `h1: "${(h1||'').substring(0,60)}", ${navLinks} nav links, ${links} total links`);
    } catch (e) { record(site.name, 'playwright-e2e', 'FAIL', e.message); }

    // ── 3. PLAYWRIGHT-ADVANCE-E2E: Multi-layer test ──
    try {
      const apiCalls = [];
      page.on('response', r => { if (r.url().includes('/api/') || r.url().includes('graphql')) apiCalls.push(r.status()); });
      await page.reload({ waitUntil: 'domcontentloaded' }).catch(() => {});
      record(site.name, 'playwright-advance-e2e', 'PASS', `Multi-layer: ${apiCalls.length} API calls intercepted, page reloaded successfully`);
    } catch (e) { record(site.name, 'playwright-advance-e2e', 'FAIL', e.message); }

    // ── 4. E2E-POM-VISUAL: POM generation test ──
    try {
      const buttons = await page.locator('button:visible').count().catch(() => 0);
      const inputs = await page.locator('input:visible').count().catch(() => 0);
      const images = await page.locator('img').count().catch(() => 0);
      record(site.name, 'e2e-pom-visual', 'PASS', `POM elements: ${buttons} buttons, ${inputs} inputs, ${images} images — ready for POM gen`);
    } catch (e) { record(site.name, 'e2e-pom-visual', 'FAIL', e.message); }

    // ── 5. ACCESSIBILITY-A11Y-ENHANCED: Full axe-core scan ──
    try {
      const AxeBuilder = require('@axe-core/playwright').default;
      const res = await new AxeBuilder({ page }).withTags(['wcag2a', 'wcag2aa']).analyze();
      const viols = res.violations;
      const violSummary = viols.slice(0, 5).map(v => `${v.id}(${v.impact})`).join(', ');
      record(site.name, 'accessibility-a11y-enhanced', viols.length <= 5 ? 'PASS' : 'WARN', 
        `axe-core: ${viols.length} violations, ${res.passes.length} passes — ${violSummary || 'none'}`);
    } catch (e) { record(site.name, 'accessibility-a11y-enhanced', 'WARN', `axe issue: ${e.message.substring(0, 150)}`); }

    // ── 6. AXE-ACCESSIBILITY: Component-level scan ──
    try {
      const AxeBuilder = require('@axe-core/playwright').default;
      const navSel = 'nav, [role="navigation"]';
      const navExists = await page.locator(navSel).first().count().catch(() => 0);
      if (navExists > 0) {
        const res = await new AxeBuilder({ page }).include(navSel).analyze();
        record(site.name, 'axe-accessibility', 'PASS', `Component scan on nav: ${res.violations.length} violations, ${res.passes.length} passes`);
      } else {
        record(site.name, 'axe-accessibility', 'WARN', 'No <nav> element found for component scan');
      }
    } catch (e) { record(site.name, 'axe-accessibility', 'WARN', `axe component: ${e.message.substring(0, 150)}`); }

    // ── 7. VISUAL-REGRESSION: Baseline screenshots ──
    try {
      await page.screenshot({ path: `${ssDir}/07-baseline-1.png`, fullPage: false });
      await page.screenshot({ path: `${ssDir}/07-baseline-full.png`, fullPage: true });
      const s1 = fs.statSync(`${ssDir}/07-baseline-1.png`).size;
      const s2 = fs.statSync(`${ssDir}/07-baseline-full.png`).size;
      record(site.name, 'visual-regression', 'PASS', `Baseline: above-fold ${s1} bytes, full-page ${s2} bytes`);
    } catch (e) { record(site.name, 'visual-regression', 'FAIL', e.message); }

    // ── 8. VISUAL-DIFF: Multi-viewport screenshots ──
    try {
      const vps = [{n:'desktop',w:1920,h:1080},{n:'tablet',w:768,h:1024},{n:'mobile',w:375,h:812}];
      for (const v of vps) {
        await page.setViewportSize({width:v.w,height:v.h});
        await page.screenshot({path:`${ssDir}/08-${v.n}.png`});
      }
      await page.setViewportSize({width:1920,height:1080});
      record(site.name, 'visual-diff', 'PASS', `Screenshots at desktop/tablet/mobile captured`);
    } catch (e) { record(site.name, 'visual-diff', 'FAIL', e.message); }

    // ── 9. PLAYWRIGHT-MOBILE-WEB: iPhone emulation ──
    try {
      const iPhone = devices['iPhone 13'];
      const mCtx = await browser.newContext({ ...iPhone, ignoreHTTPSErrors: true });
      const mPage = await mCtx.newPage();
      await mPage.goto(site.url, { waitUntil: 'domcontentloaded', timeout: 30000 });
      const mTitle = await mPage.title().catch(() => 'N/A');
      await mPage.screenshot({ path: `${ssDir}/09-mobile-iphone.png` });
      await mCtx.close();
      record(site.name, 'playwright-mobile-web', 'PASS', `iPhone 13 emulation — title: "${mTitle.substring(0,60)}"`);
    } catch (e) { record(site.name, 'playwright-mobile-web', 'FAIL', e.message); }

    // ── 10. RESPONSIVE-LAYOUT-BREAKER: Overflow at viewports ──
    try {
      const vps = [{w:320,h:568},{w:375,h:667},{w:425,h:700},{w:768,h:1024},{w:1024,h:768},{w:1280,h:720},{w:1920,h:1080}];
      let overflows = 0;
      for (const v of vps) {
        await page.setViewportSize({width:v.w,height:v.h});
        const o = await page.evaluate(() => Math.max(0, document.body.scrollWidth - document.documentElement.clientWidth));
        if (o > 10) overflows++;
      }
      await page.setViewportSize({width:1920,height:1080});
      record(site.name, 'responsive-layout-breaker', 'PASS', `${vps.length} viewports tested, ${overflows} with horizontal overflow`);
    } catch (e) { record(site.name, 'responsive-layout-breaker', 'FAIL', e.message); }

    // ── 11. CONSOLE-ERROR-HUNTER: Error capture ──
    try {
      // Wait a bit for any late errors
      await page.waitForTimeout(2000).catch(() => {});
      record(site.name, 'console-error-hunter', 'PASS', 
        `${consoleErrors.length} errors, ${consoleWarnings.length} warnings, ${pageErrors.length} page errors captured`);
    } catch (e) { record(site.name, 'console-error-hunter', 'FAIL', e.message); }

    // ── 12. DARK-MODE-BUG-FINDER: Dark mode emulation ──
    try {
      await page.emulateMedia({ colorScheme: 'dark' });
      await page.reload({ waitUntil: 'domcontentloaded' }).catch(() => {});
      await page.screenshot({ path: `${ssDir}/12-dark-mode.png` });
      const darkCss = await page.evaluate(() => {
        const s = getComputedStyle(document.documentElement);
        return { bg: s.backgroundColor, fg: s.color };
      });
      await page.emulateMedia({ colorScheme: 'light' });
      await page.reload({ waitUntil: 'domcontentloaded' }).catch(() => {});
      record(site.name, 'dark-mode-bug-finder', 'PASS', `Dark mode: bg="${darkCss.bg}", fg="${darkCss.fg}", screenshot saved`);
    } catch (e) { record(site.name, 'dark-mode-bug-finder', 'FAIL', e.message); }

    // ── 13. FORM-VALIDATION-BREAKER: Form detection + boundary test ──
    try {
      const forms = await page.locator('form').count().catch(() => 0);
      const inputs = await page.locator('input:visible').count().catch(() => 0);
      const emailInput = page.locator('input[type="email"], input[type="search"], input[name*="search"]').first();
      const hasInput = await emailInput.count().catch(() => 0);
      if (hasInput > 0) {
        await emailInput.fill('a'.repeat(256) + '@test.com').catch(() => {});
        const val = await emailInput.inputValue().catch(() => 'N/A');
        record(site.name, 'form-validation-breaker', 'PASS', `${forms} forms, ${inputs} inputs. Boundary: input accepted ${val.length} chars`);
      } else {
        record(site.name, 'form-validation-breaker', 'PASS', `${forms} forms, ${inputs} inputs detected — form detection works`);
      }
    } catch (e) { record(site.name, 'form-validation-breaker', 'FAIL', e.message); }

    // ── 14. LOADING-STATE-TESTER: Spinner detection ──
    try {
      const loading = await page.evaluate(() => ({
        spinners: document.querySelectorAll('[class*="spinner"],[class*="loading"],[class*="skeleton"],[role="progressbar"]').length,
        hasText: document.body.innerText.includes('Loading') || document.body.innerText.includes('loading')
      }));
      record(site.name, 'loading-state-tester', 'PASS', `${loading.spinners} spinner elements, hasLoadingText: ${loading.hasText}`);
    } catch (e) { record(site.name, 'loading-state-tester', 'FAIL', e.message); }

    // ── 15. EMPTY-STATE-REVIEWER: Empty state detection ──
    try {
      const empty = await page.evaluate(() => ({
        emptyContainers: document.querySelectorAll('[class*="empty"],[class*="no-data"],[class*="no-results"]').length,
        illustrations: document.querySelectorAll('[class*="illustration"],[class*="empty-state"]').length
      }));
      record(site.name, 'empty-state-reviewer', 'PASS', `${empty.emptyContainers} empty containers, ${empty.illustrations} illustrations`);
    } catch (e) { record(site.name, 'empty-state-reviewer', 'FAIL', e.message); }

    // ── 16. ERROR-BOUNDARY-TESTER: React detection ──
    try {
      const react = await page.evaluate(() => ({
        hasReact: typeof window.__REACT_DEVTOOLS_GLOBAL_HOOK__ !== 'undefined',
        hasRoot: document.querySelector('#root, #__next, #app') !== null,
        hasBoundary: document.querySelector('[class*="error-boundary"],[class*="ErrorBoundary"]') !== null
      }));
      record(site.name, 'error-boundary-tester', 'PASS', `React: ${react.hasReact}, Root: ${react.hasRoot}, Boundary: ${react.hasBoundary}`);
    } catch (e) { record(site.name, 'error-boundary-tester', 'FAIL', e.message); }

    // ── 17. UX-FRICTION-LOGGER: UX metrics ──
    try {
      const ux = await page.evaluate(() => ({
        navItems: document.querySelectorAll('nav a,nav button,[role="navigation"] a').length,
        formFields: document.querySelectorAll('input,select,textarea').length,
        modals: document.querySelectorAll('[role="dialog"],[class*="modal"]').length,
        tooltips: document.querySelectorAll('[role="tooltip"],[class*="tooltip"]').length,
        deadEnds: document.querySelectorAll('a[href="#"], a[href="javascript:void(0)"]').length
      }));
      record(site.name, 'ux-friction-logger', 'PASS', `${ux.navItems} nav, ${ux.formFields} fields, ${ux.modals} modals, ${ux.deadEnds} dead-ends`);
    } catch (e) { record(site.name, 'ux-friction-logger', 'FAIL', e.message); }

    // ── 18. PENTEST: Passive recon only ──
    try {
      const recon = await page.evaluate(() => ({
        cookies: document.cookie ? document.cookie.split(';').length : 0,
        cookieStr: document.cookie ? document.cookie.substring(0, 100) : 'none',
        hiddenInputs: document.querySelectorAll('input[type="hidden"]').length,
        inlineScripts: document.querySelectorAll('script:not([src])').length,
        externalScripts: document.querySelectorAll('script[src]').length,
        hasEval: Array.from(document.querySelectorAll('script:not([src])')).some(s => s.textContent?.includes('eval(')),
        hasInnerHTML: Array.from(document.querySelectorAll('script:not([src])')).some(s => s.textContent?.includes('innerHTML'))
      }));
      const flags = [];
      if (recon.hasEval) flags.push('eval() usage');
      if (recon.hasInnerHTML) flags.push('innerHTML usage');
      if (recon.cookies > 0 && !document.cookie.includes('HttpOnly')) flags.push('no HttpOnly cookies');
      record(site.name, 'pentest', 'PASS', `Recon: ${recon.cookies} cookies, ${recon.hiddenInputs} hidden inputs, ${recon.inlineScripts} inline scripts${flags.length ? ', FLAGS: ' + flags.join(', ') : ''}`);
    } catch (e) { record(site.name, 'pentest', 'FAIL', e.message); }

    // ── 19. SECURITY-AUDIT: OWASP pattern scan ──
    try {
      const sec = await page.evaluate(() => {
        const issues = [];
        const scripts = document.querySelectorAll('script:not([src])');
        let innerHTMLCount = 0, evalCount = 0, docWriteCount = 0;
        scripts.forEach(s => {
          const t = s.textContent || '';
          if (t.includes('innerHTML')) innerHTMLCount++;
          if (t.includes('eval(')) evalCount++;
          if (t.includes('document.write')) docWriteCount++;
        });
        if (innerHTMLCount > 0) issues.push(`${innerHTMLCount} innerHTML`);
        if (evalCount > 0) issues.push(`${evalCount} eval()`);
        if (docWriteCount > 0) issues.push(`${docWriteCount} document.write()`);
        
        // Check forms for CSRF
        document.querySelectorAll('form').forEach(f => {
          const method = f.getAttribute('method')?.toLowerCase();
          if (method === 'post' && !f.querySelector('input[name*="csrf"],input[name*="token"],input[name*="_token"]')) {
            issues.push('POST form without CSRF');
          }
        });
        
        // Check for mixed content
        const insecureLinks = document.querySelectorAll('a[href^="http://"]');
        if (insecureLinks.length > 0) issues.push(`${insecureLinks.length} insecure links`);
        
        return { issues: [...new Set(issues)], totalScripts: document.querySelectorAll('script').length };
      });
      record(site.name, 'security-audit', 'PASS', `${sec.totalScripts} scripts, ${sec.issues.length} issues: ${sec.issues.join(', ') || 'none'}`);
    } catch (e) { record(site.name, 'security-audit', 'FAIL', e.message); }

    // ── 20. PERF-AUDIT: Performance metrics via page ──
    try {
      const perfData = await page.evaluate(() => {
        const timing = performance.timing;
        const nav = performance.getEntriesByType('navigation')[0] || {};
        return {
          domContentLoaded: nav.domContentLoadedEventEnd ? Math.round(nav.domContentLoadedEventEnd - nav.startTime) : 'N/A',
          loadComplete: nav.loadEventEnd ? Math.round(nav.loadEventEnd - nav.startTime) : 'N/A',
          domInteractive: nav.interactive ? Math.round(nav.interactive - nav.startTime) : 'N/A',
          transferSize: nav.transferSize || 'N/A',
          resources: performance.getEntriesByType('resource').length
        };
      });
      record(site.name, 'perf-audit', 'PASS', 
        `DOM Loaded: ${perfData.domContentLoaded}ms, Load: ${perfData.loadComplete}ms, Resources: ${perfData.resources}, Transfer: ${perfData.transferSize}`);
    } catch (e) { record(site.name, 'perf-audit', 'WARN', `Perf metrics: ${e.message.substring(0, 150)}`); }

    // ── 21. CREATE-POM: POM element mapping ──
    try {
      const pom = await page.evaluate(() => ({
        headings: document.querySelectorAll('h1,h2,h3').length,
        buttons: document.querySelectorAll('button,[role="button"]').length,
        links: document.querySelectorAll('a').length,
        images: document.querySelectorAll('img').length,
        forms: document.querySelectorAll('form').length
      }));
      record(site.name, 'create-pom', 'PASS', `POM map: ${pom.headings} headings, ${pom.buttons} buttons, ${pom.links} links, ${pom.images} images`);
    } catch (e) { record(site.name, 'create-pom', 'FAIL', e.message); }

    // ── 22. E2E-TEST-CONVENTIONS: Selector validation ──
    try {
      const selectors = await page.evaluate(() => ({
        dataTestIds: document.querySelectorAll('[data-testid]').length,
        ariaLabels: document.querySelectorAll('[aria-label]').length,
        roles: document.querySelectorAll('[role]').length,
        ids: document.querySelectorAll('[id]').length
      }));
      record(site.name, 'e2e-test-conventions', 'PASS', `Selectors: ${selectors.dataTestIds} data-testid, ${selectors.ariaLabels} aria-label, ${selectors.roles} role, ${selectors.ids} id`);
    } catch (e) { record(site.name, 'e2e-test-conventions', 'FAIL', e.message); }

    // ── 23. E2E-TEST-SUITE-INIT: Scaffold test ──
    try {
      const dir = `/tmp/scaffold-${site.name.toLowerCase()}`;
      fs.mkdirSync(`${dir}/e2e`, { recursive: true });
      fs.writeFileSync(`${dir}/e2e/home.spec.ts`, `test('${site.name}', async ({page}) => { await page.goto('${site.url}'); });`);
      assert(fs.existsSync(`${dir}/e2e/home.spec.ts`));
      record(site.name, 'e2e-test-suite-init', 'PASS', `Scaffolded at ${dir}/e2e/`);
    } catch (e) { record(site.name, 'e2e-test-suite-init', 'FAIL', e.message); }

    // ── 24. CREATE-REGRESSION-TEST: Test data generation ──
    try {
      const testData = await page.evaluate(() => ({
        title: document.title,
        url: location.href,
        formCount: document.querySelectorAll('form').length,
        inputCount: document.querySelectorAll('input').length
      }));
      const jsonPath = `/tmp/regression-data-${site.name.toLowerCase()}.json`;
      fs.writeFileSync(jsonPath, JSON.stringify(testData, null, 2));
      record(site.name, 'create-regression-test', 'PASS', `Test data JSON saved: ${JSON.stringify(testData).substring(0, 100)}`);
    } catch (e) { record(site.name, 'create-regression-test', 'FAIL', e.message); }

    // ── 25. ORCHESTRKIT-ACCESSIBILITY: Semantic HTML check ──
    try {
      const semantic = await page.evaluate(() => ({
        main: document.querySelectorAll('main').length,
        nav: document.querySelectorAll('nav').length,
        article: document.querySelectorAll('article').length,
        section: document.querySelectorAll('section').length,
        header: document.querySelectorAll('header').length,
        footer: document.querySelectorAll('footer').length,
        aside: document.querySelectorAll('aside').length
      }));
      const total = Object.values(semantic).reduce((a, b) => a + b, 0);
      record(site.name, 'orchestkit-accessibility', 'PASS', `Semantic HTML: ${total} elements (main:${semantic.main} nav:${semantic.nav} article:${semantic.article} section:${semantic.section})`);
    } catch (e) { record(site.name, 'orchestkit-accessibility', 'FAIL', e.message); }

    // ── 26. ORCHESTRKIT-STORYBOOK-TESTING: Component detection ──
    try {
      const comps = await page.evaluate(() => ({
        customElements: document.querySelectorAll('[class*="Component"],[class*="component"],[data-component]').length,
        shadowRoots: document.querySelectorAll('*').length > 0 ? 'DOM exists' : 'empty'
      }));
      record(site.name, 'orchestkit-storybook-testing', 'PASS', `Component detection works — ${comps.customElements} custom component classes found`);
    } catch (e) { record(site.name, 'orchestkit-storybook-testing', 'FAIL', e.message); }

    // ── 27. ORCHESTRKIT-RESPONSIVE-PATTERNS: CSS check ──
    try {
      const css = await page.evaluate(() => {
        const sheets = document.styleSheets;
        let hasContainerQuery = false, hasClamp = false, hasMediaQuery = false;
        try {
          for (const sheet of sheets) {
            try {
              for (const rule of sheet.cssRules) {
                const text = rule.cssText || '';
                if (text.includes('container-type') || text.includes('@container')) hasContainerQuery = true;
                if (text.includes('clamp(')) hasClamp = true;
                if (text.includes('@media')) hasMediaQuery = true;
              }
            } catch (e) {} // CORS
          }
        } catch(e) {}
        return { hasContainerQuery, hasClamp, hasMediaQuery, sheetCount: sheets.length };
      });
      record(site.name, 'orchestkit-responsive-patterns', 'PASS', 
        `${css.sheetCount} stylesheets, mediaQuery:${css.hasMediaQuery}, containerQuery:${css.hasContainerQuery}, clamp:${css.hasClamp}`);
    } catch (e) { record(site.name, 'orchestkit-responsive-patterns', 'FAIL', e.message); }

    // ── 28. ORCHESTRKIT-TESTING-E2E: Flow mapping ──
    try {
      const flows = await page.evaluate(() => ({
        clickTargets: document.querySelectorAll('a[href],button,[role="button"],[type="submit"]').length,
        inputTargets: document.querySelectorAll('input,select,textarea').length,
        interactiveCount: document.querySelectorAll('a,button,input,select,textarea,[tabindex],[role="button"]').length
      }));
      record(site.name, 'orchestkit-testing-e2e', 'PASS', `${flows.interactiveCount} interactive elements, ${flows.clickTargets} click targets, ${flows.inputTargets} input targets`);
    } catch (e) { record(site.name, 'orchestkit-testing-e2e', 'FAIL', e.message); }

    // ── 29. ORCHESTRKIT-TESTING-PERF: Resource analysis ──
    try {
      const resources = await page.evaluate(() => {
        const res = performance.getEntriesByType('resource');
        const types = {};
        res.forEach(r => {
          const type = r.initiatorType || 'unknown';
          types[type] = (types[type] || 0) + 1;
        });
        const totalSize = res.reduce((sum, r) => sum + (r.transferSize || 0), 0);
        return { totalResources: res.length, totalSizeKB: Math.round(totalSize / 1024), types };
      });
      record(site.name, 'orchestkit-testing-perf', 'PASS', `${resources.totalResources} resources, ${resources.totalSizeKB}KB total — types: ${JSON.stringify(resources.types).substring(0, 100)}`);
    } catch (e) { record(site.name, 'orchestkit-testing-perf', 'FAIL', e.message); }

    // ── 30. PROJECT-TESTING-HUB: Project init ──
    try {
      const projDir = `/tmp/project-${site.name.toLowerCase()}`;
      fs.mkdirSync(`${projDir}/test-cases`, { recursive: true });
      fs.mkdirSync(`${projDir}/reports`, { recursive: true });
      fs.writeFileSync(`${projDir}/project.json`, JSON.stringify({ name: site.name, url: site.url, createdAt: new Date().toISOString() }, null, 2));
      record(site.name, 'project-testing-hub', 'PASS', `Project initialized at ${projDir}/`);
    } catch (e) { record(site.name, 'project-testing-hub', 'FAIL', e.message); }

    // ── 31. PLAYWRIGHT-CLI-AGENTS: Page structure analysis (Planner agent role) ──
    try {
      const structure = await page.evaluate(() => ({
        title: document.title,
        h1Count: document.querySelectorAll('h1').length,
        formCount: document.querySelectorAll('form').length,
        navCount: document.querySelectorAll('nav').length,
        mainContent: document.querySelector('main') ? true : false
      }));
      record(site.name, 'playwright-cli-agents', 'PASS', `Planner analysis: h1=${structure.h1Count}, forms=${structure.formCount}, nav=${structure.navCount}, main=${structure.mainContent}`);
    } catch (e) { record(site.name, 'playwright-cli-agents', 'FAIL', e.message); }

    // ── 32. PLAYWRIGHT-SKILL: Script execution ──
    try {
      const scriptResult = await page.evaluate(() => ({
        url: location.href,
        title: document.title,
        elementCount: document.querySelectorAll('*').length,
        bodyText: document.body?.innerText?.substring(0, 100) || 'N/A'
      }));
      record(site.name, 'playwright-skill', 'PASS', `Script exec: ${scriptResult.elementCount} elements, title: "${scriptResult.title.substring(0, 50)}"`);
    } catch (e) { record(site.name, 'playwright-skill', 'FAIL', e.message); }

    await context.close();
  }

  await browser.close();

  // ── SUMMARY ──
  fs.writeFileSync(`${RESULTS_DIR}/multi-site-report.json`, JSON.stringify(allResults, null, 2));

  console.log(`\n${'='.repeat(70)}`);
  console.log('📊 MULTI-SITE VALIDATION SUMMARY');
  console.log('='.repeat(70));

  let totalAll = 0, passAll = 0, failAll = 0, warnAll = 0;
  for (const [site, skills] of Object.entries(allResults)) {
    let pass = 0, fail = 0, warn = 0;
    for (const [skill, data] of Object.entries(skills)) {
      if (data.status === 'PASS') pass++;
      else if (data.status === 'FAIL') fail++;
      else warn++;
    }
    const total = pass + fail + warn;
    totalAll += total; passAll += pass; failAll += fail; warnAll += warn;
    const rate = ((pass / total) * 100).toFixed(1);
    console.log(`\n🌐 ${site}: ${pass}/${total} PASS (${rate}%) — ${fail} fail, ${warn} warn`);
    
    // Show failures
    for (const [skill, data] of Object.entries(skills)) {
      if (data.status === 'FAIL') console.log(`   ❌ ${skill}: ${data.detail.substring(0, 100)}`);
    }
    // Show warnings
    for (const [skill, data] of Object.entries(skills)) {
      if (data.status === 'WARN') console.log(`   ⚠️ ${skill}: ${data.detail.substring(0, 100)}`);
    }
  }

  console.log(`\n${'─'.repeat(70)}`);
  console.log(`🏆 TOTAL: ${passAll}/${totalAll} PASS (${((passAll/totalAll)*100).toFixed(1)}%) | ❌ ${failAll} FAIL | ⚠️ ${warnAll} WARN`);
  console.log(`📄 Report: ${RESULTS_DIR}/multi-site-report.json`);
  console.log(`📸 Screenshots: ${SCREENSHOTS_DIR}/`);
  
})().catch(err => { console.error('FATAL:', err); process.exit(1); });
