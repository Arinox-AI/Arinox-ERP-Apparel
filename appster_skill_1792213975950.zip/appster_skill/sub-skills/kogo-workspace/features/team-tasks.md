# Feature: Team Task Management

> Prerequisite: you have already read the **Common rules** in `../SKILL.md`
> (endpoint, auth token, workspace id, the `kogo_gql` helper, and the `{ status, message, data }` envelope). This file only covers what is specific to Team Tasks.

## 🚫 OUTPUT CONTRACT — read this first, it overrides everything below

The steps in this file are **internal instructions for you**, not a script to read aloud. Do all API work **silently**, then send the user **one** short, clean message.

**Emit ZERO assistant text between tool calls.** Do not write a sentence before or after each tool call (no "Now let me…", "Let me set up…", "Looking at the results…", "your user ID is…", "the results are in"). Run every tool call needed, silently, and then write **exactly one** message — the final result. If you are about to type a sentence that is not the final answer to the user, don't send it.

**SELF-CHECK before sending ANY message (do this every time):** if your text contains a long id (a ~24-character run of letters/numbers like `69e9f53bd56a837ea81dd7e1`), the word `assignee_ids`, or phrases like "Not yours"/"→ Vaibhav & Nikhil"/"Looking at the … tasks" — **delete that text and rewrite** with names and titles only. The filtering by id happens in your head, never on screen. The user must never see an id or your comparison reasoning.

**Never, in any message to the user:**
- narrate steps — no "let me set up the helper", "now let me fetch the task lists", "let me get the workspace id / your user id". The workspace id and your user id are already in the environment (`$SWARM_ID`, `$USER_ID`) — just use them, silently.
- show any raw identifier — no `_id`, `assignee_ids`, `USER_ID`, list/task ids, no "your ID is …", no "Nikhil's ID is …", no "Not you"/"Not your ID" reasoning, no curl/jq/env details.
- reveal your filtering logic (who is/isn't assigned and why). Just give the final answer.

**Identity / name:** the current user is `$USER_ID` (id) and `$USER_EMAIL` (email) from the environment. If you address the user by name, use `$USER_EMAIL` or the workspace member whose id equals `$USER_ID` — **never a name taken from the chat history or earlier messages** (a different person may have used this chat). If unsure of their name, don't use one.

**Your final message is ONLY the human result:**
- a clean table of their tasks (Task · Status · Priority · Due · Assignees-by-name), **or**
- "You don't have any tasks assigned to you." — plus, if useful, a one-line offer (e.g. "Want me to show the full board or create one?").

## 🔐 Access policy — only the logged-in user's tasks

- "Show my tasks / task list / what's assigned to me" → follow the flow (Queries below): `getGroupTaskList` → `getTeamTaskList(list_id)`, and present **only the tasks assigned to the current user** — the one whose id is `$USER_ID`. Keep only tasks whose `assignee_ids` contains `$USER_ID`. Do this selection **silently**; the user must only ever see their own tasks.
- If the user asks for **someone else's** tasks (e.g. "get Vaibhav's tasks", "show Sandeep's list", "what is X working on") → **refuse politely**: say you can only show *their own* tasks, not other people's. Do not present another person's tasks as a list.
- The only identity you ever use is `$USER_ID` (the logged-in user). Never use or send any other person's id in a request.

## The hierarchy

```
LIST (board / group)
  └── TASK (root task)
        └── SUBTASK
```

- A **task lives inside a list** — you cannot create a task without a `list_id`.
- A **subtask lives inside a task** — you cannot create a subtask without a `parent_task_id`.
- A person can only be **assigned if they are a member of this workspace** (fetch the member list first).

## ⭐ The ID chain (the #1 source of mistakes — follow exactly)

Every level's `_id` becomes the next level's parameter. Never guess or invent an `_id`; if you don't have it, fetch the parent level first.

| To get… | Call… | The `_id` you get back is used as… |
|---|---|---|
| Lists (boards) | `getGroupTaskList(workspace_id, search)` | `list_id` for tasks + list mutations |
| Tasks in a list | `getTeamTaskList(list_id)` | `task_id` / `parent_task_id` for subtasks + task mutations |
| Subtasks of a task | `getTeamSubTaskList(task_id)` | subtask `id` for subtask mutations |

Never pass a list `_id` where a `task_id` is expected, or a task `_id` where a subtask `id` is expected.

---

## Queries

### 1. List all boards — `getGroupTaskList`
**Start here for any task request** (including "my tasks"). Returns the lists/boards the user can access (no nested tasks). Each list's `_id` is the `list_id` you feed to the next query.
```graphql
query ($workspace_id: ID!, $search: String) {
  getGroupTaskList(workspace_id: $workspace_id, search: $search) {
    status message
    data { _id name color visibility assignee_ids total_tasks completed_tasks
           assignees { _id name email } created_at updated_at }
  }
}
```
Variables: `{ "workspace_id": "$WORKSPACE_ID", "search": null }` (see Common rules for `$WORKSPACE_ID`)
→ each `data[]._id` is a **list_id**.

### 2. Tasks in a list — `getTeamTaskList`
```graphql
query ($list_id: ID!) {
  getTeamTaskList(list_id: $list_id) {
    status message
    data { _id title description list_id status priority due_date order is_completed
           assignee_ids attachments created_at updated_at
           created_by { _id name email } assignees { _id name email }
           status_history { status changed_at user { _id name } } }
  }
}
```
Variables: `{ "list_id": "<_id from getGroupTaskList>" }`
→ each `data[]._id` is a **task_id**.

### 3. Subtasks of a task — `getTeamSubTaskList`
```graphql
query ($task_id: ID!) {
  getTeamSubTaskList(task_id: $task_id) {
    status message
    data { _id title description list_id parent_task_id status priority due_date order
           is_completed assignee_ids attachments created_at updated_at
           created_by { _id name email } assignees { _id name email }
           status_history { status changed_at user { _id name } } }
  }
}
```
Variables: `{ "task_id": "<_id from getTeamTaskList>" }`

### 4. Workspace members — `kogo_swarm_memberList`
Call before assigning anyone. Only these members can be assignees.
```graphql
query ($_id: ID!) {
  kogo_swarm_memberList(_id: $_id) {
    _id swarm_name edit_access
    memberList { _id fname lname email phone user_type organization_name is_deactivate }
  }
}
```
Variables: `{ "_id": "$WORKSPACE_ID" }`
→ map the person the user named to their `memberList[]._id`; use those ids as `assignee_ids`.

---

## Mutations

All take/return the standard envelope. Enums: `visibility` = `public|private|shared`, `priority` = `Low|Medium|High`, `status` = `todo|in_review|completed`. `due_date` = epoch **milliseconds**.

### Lists
```graphql
mutation ($input: CreateTaskListInput!) { createTaskList(input: $input) { status message data { _id name color visibility assignee_ids } } }
mutation ($id: ID!, $input: UpdateTaskListInput!) { updateTaskList(id: $id, input: $input) { status message data { _id name color visibility assignee_ids } } }
mutation ($id: ID!) { deleteTaskList(id: $id) { status message data { _id } } }
```
- `CreateTaskListInput`: `name!`, `workspace_id!`, `color`, `visibility` (default `private`), `assignee_ids` (only used when `shared`).
- `UpdateTaskListInput` (all optional): `name`, `color`, `visibility`, `assignee_ids`. Switching away from `shared` clears assignees.
- `deleteTaskList` cascades to all tasks in the list. `id` = a **list_id**.

### Tasks
```graphql
mutation ($input: CreateTaskInput!) { createTask(input: $input) { status message data { _id title list_id status order priority due_date } } }
mutation ($id: ID!, $input: UpdateTaskInput!) { updateTask(id: $id, input: $input) { status message data { _id title description status priority due_date is_completed assignee_ids attachments } } }
mutation ($id: ID!) { deleteTask(id: $id) { status message data { _id } } }
```
- `CreateTaskInput`: `list_id!`, `title!`, `workspace_id!`, `description`, `assignee_ids`, `due_date`, `attachments` (JSON objects), `priority`, `is_completed`. New tasks start `todo` at the bottom.
- `UpdateTaskInput` (all optional): `title`, `description`, `assignee_ids`, `due_date`, `attachments`, `priority`, `is_completed`. (No `list_id` — tasks can't move lists.)
- `deleteTask` cascades to subtasks. `id` = a **task_id**.

### Subtasks
```graphql
mutation ($input: CreateSubtaskInput!) { createSubtask(input: $input) { status message data { _id title parent_task_id status order priority due_date } } }
mutation ($id: ID!, $input: UpdateTaskInput!) { updateSubtask(id: $id, input: $input) { status message data { _id title description status priority due_date is_completed assignee_ids attachments } } }
mutation ($id: ID!) { deleteSubtask(id: $id) { status message data { _id } } }
```
- `CreateSubtaskInput`: `parent_task_id!`, `title!`, `description`, `assignee_ids`, `due_date`, `attachments` (**array of strings** here, not JSON objects), `priority`, `is_completed`.
- `updateSubtask` reuses `UpdateTaskInput`. `id` = a **subtask id** (from `getTeamSubTaskList`).

### Status
```graphql
mutation ($id: ID!) { advanceTaskStatus(id: $id) { status message data { _id status is_completed status_history { status changed_at user { _id name } } } } }
```
Advances a task **or** subtask one step in the fixed cycle `todo → in_review → completed → todo …`. There is **no direct set-status** — to skip states, call it repeatedly. `is_completed` stays in sync (`true` only at `completed`).

---

## Standard flows (recipes)

**What's assigned to me** ("what tasks are assigned to me", "my tasks", "what should I work on")
Do all of this silently (see the OUTPUT CONTRACT). The current user is `$USER_ID`.
1. `getGroupTaskList` (workspace_id = `$WORKSPACE_ID`) → get the lists.
2. For each list, `getTeamTaskList(list_id)`.
3. From all tasks returned, **keep only those whose `assignee_ids` contains `$USER_ID`** — silent selection; never surface anyone else's tasks. (For subtasks too: `getTeamSubTaskList(task_id)`, keep the same way.)
4. Reply with just the result: a clean table (Task · Status · Priority · Due). If none are yours, reply exactly that they have no tasks assigned to them (optionally offer to create one). No ids, no steps.

**Update / delete / advance my task** ("mark my design task done", "change the due date")
1. Find the user's task via the same flow (`getGroupTaskList` → `getTeamTaskList`, keep only tasks with `$USER_ID` in `assignee_ids`) → take its `_id`.
2. Call the matching mutation (`updateTask` / `deleteTask` / `advanceTaskStatus`). The user only operates on their own tasks.

**Create a task** ("add 'Design review' to the Sprint board")
1. `getGroupTaskList` → find the list whose name matches "Sprint" → take its `_id` as `list_id` (if none matches, `createTaskList` first).
2. `createTask` with `{ list_id, title, workspace_id }` (+ any priority/due_date/assignees).

**Create a subtask**
1. `getGroupTaskList` → `getTeamTaskList(list_id)` → find the parent task → take its `_id` as `parent_task_id`.
2. `createSubtask` with `{ parent_task_id, title }`.

**Assign a task to a person** ("assign the QA task to Rahul")
1. `kogo_swarm_memberList` → find the member whose name is Rahul → take `_id`.
2. `updateTask(id, { assignee_ids: ["<member _id>"] })`. If no member matches, tell the user instead of guessing.

---

## Feature-specific guardrails
- Never invent an `_id`, `assignee_id`, `list_id`, `task_id`, or `parent_task_id`. Fetch the parent level to obtain it.
- Confirm before `deleteTaskList` (cascades to every task) and `deleteTask` (cascades to subtasks).
- Times are IST for the user; convert to/from epoch **milliseconds** for `due_date`.
