---
name: kogo-workspace
category: productivity
description: "Build the Team Task Management feature into a dashboard — task lists/boards, tasks, subtasks, assignees, and status — backed by the REAL KOGO workspace task API (GraphQL). Activate whenever the user's dashboard should manage team tasks / task lists / boards / to-dos / assign work. This provides the actual workspace task backend + a React UI; it is NOT a generic local table."
keyword_triggers: [workspace, task, tasks, task list, task board, team task, to-do, todo, sprint, backlog, work item, my tasks, assign task, kanban, board]
provides:
  backend_functions: [get_task_lists, get_tasks, get_subtasks, get_task, get_task_count_summary, get_my_tasks, get_workspace_members, create_task_list, update_task_list, delete_task_list, create_task, update_task, delete_task, create_subtask, update_subtask, delete_subtask, advance_task_status, reorder_tasks, reorder_subtasks]
  frontend_components: [WorkspaceTasks]
  npm_deps: []
---

# KOGO Workspace — Team Task Feature (BUILD sub-skill)

When a dashboard needs **team task management**, build it with THIS sub-skill. It wires the project
to the **real KOGO workspace task API** (GraphQL) and ships a React UI — exactly like chat-module
wires chat. Follow the build steps verbatim.

---

## 🚫 HARD RULES — read first, never override (these are the mistakes to avoid)

1. **NEVER build a local task table.** Team tasks live on the KOGO workspace backend, reached via the
   GraphQL gateway. Do **NOT** create a SQLite `tasks` table, a `TaskModel`, or any local
   `create_task`/`get_tasks` that reads a local DB. Do **NOT** invent a status set like
   `todo/in_progress/done/blocked` or a generic Kanban. Every task operation goes through the
   `_tt_gql` helper below to the real API. (Notes/other features may use SQLite — team tasks NEVER.)
2. **The hierarchy is fixed: LIST → TASK → SUBTASK.** You CANNOT create a task without a `list_id`,
   and you CANNOT create a subtask without a `parent_task_id`. The UI must show lists/boards first;
   "create task" always happens **inside a chosen list**. Never render a create-task form without a
   list selector.
3. **Real status enum (FIXED):** `todo | in_review | completed | qc_completed`. `priority`: `Low | Medium | High`.
   `visibility`: `public | private | shared`. `due_date` = epoch **milliseconds** (number).
4. **WORKSPACE-ONLY at runtime — but ALWAYS BUILD IT FULLY.** A dashboard is created/tested inside an
   **agent** where there is NO `SWARM_ID` — that is expected. Build the whole feature anyway. At
   runtime without `SWARM_ID` every function returns a clean `{"error": "…workspace…"}` and the UI
   shows a friendly "requires a workspace" state (no crash). When the dashboard is added to a
   workspace (SWARM_ID present) it works automatically. NEVER fall back to `AGENT_ID` for tasks,
   NEVER hardcode a swarm id, NEVER skip building because SWARM_ID is missing at build time.
5. **All ids/paths from `config.py`** (`SWARM_ID`=workspace_id, `API_PATH`=gateway, `USER_ID`,
   `USER_JWT_TOKEN` from env at runtime). Operation + argument names are FIXED CONTRACT — copy verbatim.
6. **Two-layer response envelope (the #1 past bug):** `callApi` returns `{ success, data, message }`,
   and each backend function returns its payload **inside** `data` (e.g. `{ lists: [...] }`) or
   `{ error: "..." }`. The React component MUST read `res.data.<key>` and check BOTH `res.success`
   and `res.data.error` — never `res.status` or a bare `res.data`. Use the `tt()` helper provided.

---

## ✅ API contract (verified against the server `teamTaskSchema.js` — copy arg names EXACTLY)

**Queries:** `getGroupTaskList(workspace_id: ID!, search: String)` · `getTeamTaskList(list_id: ID!, search: String)` ·
`getTeamSubTaskList(task_id: ID!, search: String)` · `getTeamTask(id: ID!)` · `getTaskCountSummary(workspace_id: ID!)`

**Mutations:** `createTaskList(input: CreateTaskListInput!)` · `updateTaskList(id, input: UpdateTaskListInput!)` ·
`deleteTaskList(id)` · `createTask(input: CreateTaskInput!)` · `updateTask(id, input: UpdateTaskInput!)` ·
`deleteTask(id)` · `createSubtask(input: CreateSubtaskInput!)` · `updateSubtask(id, input: UpdateTaskInput!)` ·
`deleteSubtask(id)` · `advanceTaskStatus(id)` · `reorderTasks(list_id, ordered_ids: [ID!]!)` ·
`reorderSubtasks(parent_task_id, ordered_ids: [ID!]!)`

Inputs: `CreateTaskListInput { name!, workspace_id!, color, visibility, assignee_ids }` ·
`CreateTaskInput { list_id!, title!, workspace_id!, description, assignee_ids, due_date, attachments, priority, is_completed }` ·
`CreateSubtaskInput { parent_task_id!, title!, description, assignee_ids, due_date, attachments (**[String]**), priority, is_completed }` ·
`UpdateTaskInput { title, description, assignee_ids, due_date, attachments, priority, is_completed }`.
Members (for assignees): `kogo_swarm_memberList(_id: ID!)` → `memberList { _id fname lname email is_deactivate }`.

---

## Mode detection
- `frontend/src/App.tsx` exists → **Module** (add a "Tasks" tab).
- No `App.tsx` → **Standalone** (render `<WorkspaceTasks />` full-screen in `App.tsx`). Steps are identical; only App wiring differs.

### Pre-Flight
Grep `backend/config.py` for `SWARM_ID`, `API_PATH`, `USER_ID` (all must exist). Building inside an agent
(no SWARM_ID) is normal — build everything; it activates in a workspace. Do not skip or fake.

---

## Step 1 — Backend (append to `functions.py`, BEFORE the `FUNCTIONS = {` dict)

Ensure `import os`, `import requests`, `from typing import Optional` exist at the top (check first, don't duplicate).

```python
# ═══════════════════════════════════════════════════════════════════════════
# TEAM TASK MODULE — real KOGO workspace task API (NO local table). Workspace-only.
# ═══════════════════════════════════════════════════════════════════════════
from config import SWARM_ID as CFG_SWARM_ID, API_PATH as CFG_API_PATH, USER_ID as CFG_USER_ID

# workspace_id = SWARM_ID (never AGENT_ID for team tasks). "null" sentinel → "".
TT_WORKSPACE_ID = CFG_SWARM_ID if (CFG_SWARM_ID and CFG_SWARM_ID != "null") else ""
TT_USER_ID = CFG_USER_ID
TT_API_PATH = CFG_API_PATH if CFG_API_PATH.endswith("/gateway") else (f"{CFG_API_PATH}/gateway" if CFG_API_PATH else "")


def _tt_headers() -> dict:
    return {"Authorization": f"Bearer {os.environ.get('USER_JWT_TOKEN', '')}", "Content-Type": "application/json"}


def _tt_gql(op_name: str, query: str, variables: dict) -> dict:
    """POST a GraphQL op and unwrap the { status, message, data } envelope.
    Returns {"ok": True, "data": <inner>} or {"ok": False, "error": "..."}.
    Workspace-only: fails loud when there is no SWARM_ID (agent context)."""
    if not TT_WORKSPACE_ID:
        return {"ok": False, "error": "Team Tasks is a workspace-only feature (no SWARM_ID / not in a workspace)."}
    if not TT_API_PATH:
        return {"ok": False, "error": "Team task module not configured: missing API_PATH."}
    try:
        resp = requests.post(TT_API_PATH, json={"query": query, "variables": variables}, headers=_tt_headers(), timeout=30)
        resp.raise_for_status()
        body = resp.json()
        if body.get("errors"):
            return {"ok": False, "error": body["errors"][0].get("message", "GraphQL error")}
        env = (body.get("data") or {}).get(op_name) or {}
        if env.get("status") != "success":
            return {"ok": False, "error": env.get("message", f"{op_name} failed")}
        return {"ok": True, "data": env.get("data")}
    except requests.exceptions.RequestException as e:
        return {"ok": False, "error": f"Team task API call failed: {e}"}


_TT_LIST_F = "_id name color visibility assignee_ids total_tasks completed_tasks pending_tasks assignees { _id name email } created_at updated_at"
_TT_TASK_F = ("_id title description list_id parent_task_id status priority due_date order is_completed "
              "assignee_ids attachments created_at updated_at created_by { _id name email } "
              "assignees { _id name email } status_history { status changed_at user { _id name } }")

_Q_LISTS   = f"query ($workspace_id: ID!, $search: String) {{ getGroupTaskList(workspace_id: $workspace_id, search: $search) {{ status message data {{ {_TT_LIST_F} }} }} }}"
_Q_TASKS   = f"query ($list_id: ID!, $search: String) {{ getTeamTaskList(list_id: $list_id, search: $search) {{ status message data {{ {_TT_TASK_F} }} }} }}"
_Q_SUBS    = f"query ($task_id: ID!, $search: String) {{ getTeamSubTaskList(task_id: $task_id, search: $search) {{ status message data {{ {_TT_TASK_F} }} }} }}"
_Q_TASK    = f"query ($id: ID!) {{ getTeamTask(id: $id) {{ status message data {{ {_TT_TASK_F} }} }} }}"
_Q_COUNT   = "query ($workspace_id: ID!) { getTaskCountSummary(workspace_id: $workspace_id) { status message data { total_tasks completed_tasks pending_tasks } } }"
_M_CL      = "mutation ($input: CreateTaskListInput!) { createTaskList(input: $input) { status message data { _id name color visibility assignee_ids } } }"
_M_UL      = "mutation ($id: ID!, $input: UpdateTaskListInput!) { updateTaskList(id: $id, input: $input) { status message data { _id name color visibility assignee_ids } } }"
_M_DL      = "mutation ($id: ID!) { deleteTaskList(id: $id) { status message data { _id } } }"
_M_CT      = "mutation ($input: CreateTaskInput!) { createTask(input: $input) { status message data { _id title list_id status priority due_date assignee_ids } } }"
_M_UT      = "mutation ($id: ID!, $input: UpdateTaskInput!) { updateTask(id: $id, input: $input) { status message data { _id title description status priority due_date is_completed assignee_ids } } }"
_M_DT      = "mutation ($id: ID!) { deleteTask(id: $id) { status message data { _id } } }"
_M_CS      = "mutation ($input: CreateSubtaskInput!) { createSubtask(input: $input) { status message data { _id title parent_task_id status priority due_date assignee_ids } } }"
_M_US      = "mutation ($id: ID!, $input: UpdateTaskInput!) { updateSubtask(id: $id, input: $input) { status message data { _id title description status priority due_date is_completed assignee_ids } } }"
_M_DS      = "mutation ($id: ID!) { deleteSubtask(id: $id) { status message data { _id } } }"
_M_ADV     = "mutation ($id: ID!) { advanceTaskStatus(id: $id) { status message data { _id status is_completed } } }"
_M_RT      = "mutation ($list_id: ID!, $ordered_ids: [ID!]!) { reorderTasks(list_id: $list_id, ordered_ids: $ordered_ids) { status message data { _id } } }"
_M_RS      = "mutation ($parent_task_id: ID!, $ordered_ids: [ID!]!) { reorderSubtasks(parent_task_id: $parent_task_id, ordered_ids: $ordered_ids) { status message data { _id } } }"
_Q_MEMBERS = "query ($_id: ID!) { kogo_swarm_memberList(_id: $_id) { _id swarm_name memberList { _id fname lname email user_type is_deactivate } } }"


def get_task_lists(db, search: Optional[str] = None) -> dict:
    r = _tt_gql("getGroupTaskList", _Q_LISTS, {"workspace_id": TT_WORKSPACE_ID, "search": search})
    return {"error": r["error"]} if not r["ok"] else {"lists": r["data"] or []}

def get_tasks(db, list_id: str, search: Optional[str] = None) -> dict:
    r = _tt_gql("getTeamTaskList", _Q_TASKS, {"list_id": list_id, "search": search})
    return {"error": r["error"]} if not r["ok"] else {"tasks": r["data"] or []}

def get_subtasks(db, task_id: str, search: Optional[str] = None) -> dict:
    r = _tt_gql("getTeamSubTaskList", _Q_SUBS, {"task_id": task_id, "search": search})
    return {"error": r["error"]} if not r["ok"] else {"subtasks": r["data"] or []}

def get_task(db, task_id: str) -> dict:
    r = _tt_gql("getTeamTask", _Q_TASK, {"id": task_id})
    return {"error": r["error"]} if not r["ok"] else {"task": r["data"]}

def get_task_count_summary(db) -> dict:
    r = _tt_gql("getTaskCountSummary", _Q_COUNT, {"workspace_id": TT_WORKSPACE_ID})
    return {"error": r["error"]} if not r["ok"] else {"summary": r["data"] or {}}

def get_my_tasks(db) -> dict:
    lists = get_task_lists(db)
    if lists.get("error"):
        return lists
    mine = []
    for lst in lists.get("lists", []):
        tr = get_tasks(db, lst["_id"])
        for t in tr.get("tasks", []):
            if TT_USER_ID in (t.get("assignee_ids") or []):
                t["list_name"] = lst.get("name")
                mine.append(t)
    return {"tasks": mine}

def get_workspace_members(db) -> dict:
    r = _tt_gql("kogo_swarm_memberList", _Q_MEMBERS, {"_id": TT_WORKSPACE_ID})
    if not r["ok"]:
        return {"error": r["error"]}
    members = []
    for m in ((r["data"] or {}).get("memberList") or []):
        if m.get("is_deactivate"):
            continue
        name = " ".join(x for x in [m.get("fname"), m.get("lname")] if x) or m.get("email")
        members.append({"_id": m["_id"], "name": name, "email": m.get("email")})
    return {"members": members}

def create_task_list(db, name, color=None, visibility="private", assignee_ids=None) -> dict:
    inp = {"name": name, "workspace_id": TT_WORKSPACE_ID, "visibility": visibility}
    if color: inp["color"] = color
    if visibility == "shared" and assignee_ids: inp["assignee_ids"] = assignee_ids
    r = _tt_gql("createTaskList", _M_CL, {"input": inp})
    return {"error": r["error"]} if not r["ok"] else {"list": r["data"]}

def update_task_list(db, list_id, name=None, color=None, visibility=None, assignee_ids=None) -> dict:
    inp = {k: v for k, v in {"name": name, "color": color, "visibility": visibility, "assignee_ids": assignee_ids}.items() if v is not None}
    r = _tt_gql("updateTaskList", _M_UL, {"id": list_id, "input": inp})
    return {"error": r["error"]} if not r["ok"] else {"list": r["data"]}

def delete_task_list(db, list_id) -> dict:
    r = _tt_gql("deleteTaskList", _M_DL, {"id": list_id})
    return {"error": r["error"]} if not r["ok"] else {"deleted": True, "list_id": list_id}

def create_task(db, list_id, title, description=None, assignee_ids=None, due_date=None, priority=None, is_completed=None) -> dict:
    inp = {"list_id": list_id, "title": title, "workspace_id": TT_WORKSPACE_ID}
    for k, v in {"description": description, "assignee_ids": assignee_ids, "due_date": due_date, "priority": priority, "is_completed": is_completed}.items():
        if v is not None: inp[k] = v
    r = _tt_gql("createTask", _M_CT, {"input": inp})
    return {"error": r["error"]} if not r["ok"] else {"task": r["data"]}

def update_task(db, task_id, title=None, description=None, assignee_ids=None, due_date=None, priority=None, is_completed=None) -> dict:
    inp = {k: v for k, v in {"title": title, "description": description, "assignee_ids": assignee_ids, "due_date": due_date, "priority": priority, "is_completed": is_completed}.items() if v is not None}
    r = _tt_gql("updateTask", _M_UT, {"id": task_id, "input": inp})
    return {"error": r["error"]} if not r["ok"] else {"task": r["data"]}

def delete_task(db, task_id) -> dict:
    r = _tt_gql("deleteTask", _M_DT, {"id": task_id})
    return {"error": r["error"]} if not r["ok"] else {"deleted": True, "task_id": task_id}

def create_subtask(db, parent_task_id, title, description=None, assignee_ids=None, due_date=None, priority=None, is_completed=None) -> dict:
    inp = {"parent_task_id": parent_task_id, "title": title}
    for k, v in {"description": description, "assignee_ids": assignee_ids, "due_date": due_date, "priority": priority, "is_completed": is_completed}.items():
        if v is not None: inp[k] = v
    r = _tt_gql("createSubtask", _M_CS, {"input": inp})
    return {"error": r["error"]} if not r["ok"] else {"subtask": r["data"]}

def update_subtask(db, subtask_id, title=None, description=None, assignee_ids=None, due_date=None, priority=None, is_completed=None) -> dict:
    inp = {k: v for k, v in {"title": title, "description": description, "assignee_ids": assignee_ids, "due_date": due_date, "priority": priority, "is_completed": is_completed}.items() if v is not None}
    r = _tt_gql("updateSubtask", _M_US, {"id": subtask_id, "input": inp})
    return {"error": r["error"]} if not r["ok"] else {"subtask": r["data"]}

def delete_subtask(db, subtask_id) -> dict:
    r = _tt_gql("deleteSubtask", _M_DS, {"id": subtask_id})
    return {"error": r["error"]} if not r["ok"] else {"deleted": True, "subtask_id": subtask_id}

def advance_task_status(db, task_id) -> dict:
    r = _tt_gql("advanceTaskStatus", _M_ADV, {"id": task_id})
    return {"error": r["error"]} if not r["ok"] else {"task": r["data"]}

def reorder_tasks(db, list_id, ordered_ids) -> dict:
    r = _tt_gql("reorderTasks", _M_RT, {"list_id": list_id, "ordered_ids": ordered_ids})
    return {"error": r["error"]} if not r["ok"] else {"ok": True}

def reorder_subtasks(db, parent_task_id, ordered_ids) -> dict:
    r = _tt_gql("reorderSubtasks", _M_RS, {"parent_task_id": parent_task_id, "ordered_ids": ordered_ids})
    return {"error": r["error"]} if not r["ok"] else {"ok": True}
```

Register in the `FUNCTIONS` dict (add alongside existing entries — do NOT create a local `TaskModel`):
```python
"get_task_lists": get_task_lists, "get_tasks": get_tasks, "get_subtasks": get_subtasks,
"get_task": get_task, "get_task_count_summary": get_task_count_summary, "get_my_tasks": get_my_tasks,
"get_workspace_members": get_workspace_members,
"create_task_list": create_task_list, "update_task_list": update_task_list, "delete_task_list": delete_task_list,
"create_task": create_task, "update_task": update_task, "delete_task": delete_task,
"create_subtask": create_subtask, "update_subtask": update_subtask, "delete_subtask": delete_subtask,
"advance_task_status": advance_task_status, "reorder_tasks": reorder_tasks, "reorder_subtasks": reorder_subtasks,
```

---

## Step 2 — Frontend component `frontend/src/components/WorkspaceTasks.tsx`

The UI MUST reflect the hierarchy: **Boards (lists) → tasks inside each list → subtasks inside each task.**
Create-task is only available inside a list. Uses the `tt()` unwrap helper (two-envelope safe).

```tsx
import { useState, useEffect, useCallback } from "react";
import { callApi } from "../services/api";

interface Member { _id: string; name: string; email?: string; }
interface Assignee { _id: string; name?: string; email?: string; }
interface Task { _id: string; title: string; description?: string; status: string; priority?: string;
  due_date?: number | null; assignee_ids?: string[]; assignees?: Assignee[]; list_name?: string; }
interface TaskList { _id: string; name: string; color?: string; total_tasks?: number; completed_tasks?: number; }

const STATUS_LABEL: Record<string, string> = { todo: "To Do", in_review: "In Review", completed: "Completed", qc_completed: "QC Completed" };
const PRIORITIES = ["Low", "Medium", "High"];

// Two-envelope unwrap: middleware { success, data, message } + fn payload {...} | { error }.
async function tt(fn: string, params: Record<string, any> = {}): Promise<any> {
  const res = await callApi(fn, params);
  if (!res?.success) throw new Error(res?.message || "Request failed");
  if (res.data?.error) throw new Error(res.data.error);
  return res.data;
}

export default function WorkspaceTasks() {
  const [view, setView] = useState<"boards" | "mine">("boards");
  const [lists, setLists] = useState<TaskList[]>([]);
  const [tasksByList, setTasksByList] = useState<Record<string, Task[]>>({});
  const [myTasks, setMyTasks] = useState<Task[]>([]);
  const [members, setMembers] = useState<Member[]>([]);
  const [subtasks, setSubtasks] = useState<Record<string, Task[]>>({});
  const [expanded, setExpanded] = useState<Record<string, boolean>>({});
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [needsWorkspace, setNeedsWorkspace] = useState(false);
  const [newListName, setNewListName] = useState("");
  const [taskForm, setTaskForm] = useState<{ list_id: string; title: string; priority: string; assignee_ids: string[] } | null>(null);

  function showErr(e: any) { const m = e?.message || "Something went wrong"; if (/workspace/i.test(m)) setNeedsWorkspace(true); else setError(m); }

  const loadBoards = useCallback(async () => {
    setLoading(true); setError(""); setNeedsWorkspace(false);
    try {
      const { lists } = await tt("get_task_lists");
      setLists(lists || []);
      const map: Record<string, Task[]> = {};
      await Promise.all((lists || []).map(async (l: TaskList) => { const { tasks } = await tt("get_tasks", { list_id: l._id }); map[l._id] = tasks || []; }));
      setTasksByList(map);
    } catch (e: any) { showErr(e); }
    setLoading(false);
  }, []);

  const loadMine = useCallback(async () => {
    setLoading(true); setError(""); setNeedsWorkspace(false);
    try { const { tasks } = await tt("get_my_tasks"); setMyTasks(tasks || []); } catch (e: any) { showErr(e); }
    setLoading(false);
  }, []);

  useEffect(() => { tt("get_workspace_members").then(d => setMembers(d.members || [])).catch(() => {}); }, []);
  useEffect(() => { view === "boards" ? loadBoards() : loadMine(); }, [view, loadBoards, loadMine]);
  const refresh = () => (view === "boards" ? loadBoards() : loadMine());
  const run = (p: Promise<any>) => p.then(refresh).catch(showErr);

  const createList = () => { if (newListName.trim()) { run(tt("create_task_list", { name: newListName.trim() })); setNewListName(""); } };
  const deleteList = (id: string) => { if (confirm("Delete this list and all its tasks?")) run(tt("delete_task_list", { list_id: id })); };
  const createTask = () => { if (taskForm?.title.trim()) { run(tt("create_task", { list_id: taskForm.list_id, title: taskForm.title.trim(), priority: taskForm.priority, assignee_ids: taskForm.assignee_ids })); setTaskForm(null); } };
  const deleteTask = (id: string) => { if (confirm("Delete this task?")) run(tt("delete_task", { task_id: id })); };
  const advance = (id: string) => run(tt("advance_task_status", { task_id: id }));

  async function toggleSubs(taskId: string) {
    setExpanded(e => ({ ...e, [taskId]: !e[taskId] }));
    if (!subtasks[taskId]) { try { const { subtasks: s } = await tt("get_subtasks", { task_id: taskId }); setSubtasks(m => ({ ...m, [taskId]: s || [] })); } catch (e: any) { showErr(e); } }
  }
  const reloadSubs = (parent: string) => tt("get_subtasks", { task_id: parent }).then(d => setSubtasks(m => ({ ...m, [parent]: d.subtasks || [] })));
  const addSubtask = (parent: string) => { const t = prompt("Subtask title:"); if (t?.trim()) tt("create_subtask", { parent_task_id: parent, title: t.trim() }).then(() => reloadSubs(parent)).catch(showErr); };
  const delSubtask = (id: string, parent: string) => { if (confirm("Delete subtask?")) tt("delete_subtask", { subtask_id: id }).then(() => reloadSubs(parent)).catch(showErr); };
  const memberName = (id: string) => members.find(m => m._id === id)?.name || "—";

  if (needsWorkspace) return (
    <div style={{ padding: 40, textAlign: "center", color: "#6B7280", fontFamily: "inherit" }}>
      <div style={{ fontSize: 32, marginBottom: 10 }}>📋</div>
      <div style={{ fontSize: 15, fontWeight: 600, color: "#374151" }}>Team Tasks is a workspace feature</div>
      <div style={{ fontSize: 13, marginTop: 6, maxWidth: 360, marginInline: "auto" }}>It becomes active once this dashboard is added to a workspace — nothing to configure.</div>
    </div>
  );

  const S: Record<string, React.CSSProperties> = {
    wrap: { padding: 20, height: "100%", overflow: "auto", boxSizing: "border-box", fontFamily: "inherit" },
    row: { display: "flex", alignItems: "center", gap: 10, marginBottom: 16, flexWrap: "wrap" },
    tab: (a: boolean) => ({ padding: "6px 14px", borderRadius: 6, border: "none", cursor: "pointer", fontSize: 13, background: a ? "var(--primary,#3B82F6)" : "var(--surface2,#E5E7EB)", color: a ? "#fff" : "var(--text,#374151)" }) as any,
    input: { padding: "7px 10px", borderRadius: 6, border: "1px solid var(--border,#D1D5DB)", fontSize: 13 },
    btn: { padding: "7px 12px", borderRadius: 6, border: "none", cursor: "pointer", background: "var(--primary,#3B82F6)", color: "#fff", fontSize: 13 },
    col: { minWidth: 280, maxWidth: 320, background: "var(--surface,#F9FAFB)", border: "1px solid var(--border,#E5E7EB)", borderRadius: 10, padding: 12 },
    card: { background: "var(--surface-raised,#fff)", border: "1px solid var(--border,#E5E7EB)", borderRadius: 8, padding: 10, marginBottom: 8 },
    chip: { display: "inline-block", padding: "1px 8px", borderRadius: 10, fontSize: 11, background: "var(--primary-muted,#EEF2FF)", color: "var(--primary,#4338CA)", marginRight: 4 },
    small: { fontSize: 12, color: "var(--text-muted,#6B7280)" },
    x: { background: "none", border: "none", cursor: "pointer", color: "#EF4444", fontSize: 13 },
  };

  const TaskCard = ({ t }: { t: Task }) => (
    <div style={S.card}>
      <div style={{ display: "flex", justifyContent: "space-between", gap: 6 }}>
        <strong style={{ fontSize: 13 }}>{t.title}</strong>
        <button style={S.x} onClick={() => deleteTask(t._id)} title="Delete">✕</button>
      </div>
      <div style={{ display: "flex", gap: 6, flexWrap: "wrap", alignItems: "center", marginTop: 6 }}>
        <button onClick={() => advance(t._id)} style={{ ...S.chip, cursor: "pointer", border: "none" }} title="Advance status">{STATUS_LABEL[t.status] || t.status}</button>
        {t.priority && <span style={S.small}>● {t.priority}</span>}
        {t.due_date ? <span style={S.small}>📅 {new Date(t.due_date).toLocaleDateString("en-IN")}</span> : null}
        {(t.assignees || []).map(a => <span key={a._id} style={S.chip}>{a.name || a.email}</span>)}
        {!t.assignees?.length && (t.assignee_ids || []).map(id => <span key={id} style={S.chip}>{memberName(id)}</span>)}
      </div>
      <div style={{ marginTop: 6, display: "flex", gap: 10 }}>
        <button style={{ ...S.small, background: "none", border: "none", cursor: "pointer", color: "var(--primary,#3B82F6)" }} onClick={() => toggleSubs(t._id)}>{expanded[t._id] ? "▾ Subtasks" : "▸ Subtasks"}</button>
        <button style={{ ...S.small, background: "none", border: "none", cursor: "pointer", color: "var(--primary,#3B82F6)" }} onClick={() => addSubtask(t._id)}>+ Subtask</button>
      </div>
      {expanded[t._id] && (subtasks[t._id] || []).map(st => (
        <div key={st._id} style={{ marginLeft: 12, marginTop: 6, display: "flex", justifyContent: "space-between", alignItems: "center", gap: 6 }}>
          <span style={{ fontSize: 12 }}>{st.title}</span>
          <span style={{ display: "flex", gap: 6, alignItems: "center" }}>
            <button onClick={() => advance(st._id)} style={{ ...S.chip, cursor: "pointer", border: "none" }}>{STATUS_LABEL[st.status] || st.status}</button>
            <button style={S.x} onClick={() => delSubtask(st._id, t._id)}>✕</button>
          </span>
        </div>
      ))}
    </div>
  );

  return (
    <div style={S.wrap}>
      <div style={S.row}>
        <button style={S.tab(view === "boards")} onClick={() => setView("boards")}>All Boards</button>
        <button style={S.tab(view === "mine")} onClick={() => setView("mine")}>My Tasks</button>
      </div>
      {view === "boards" && (
        <div style={S.row}>
          <input style={S.input} placeholder="New list name…" value={newListName} onChange={e => setNewListName(e.target.value)} />
          <button style={S.btn} onClick={createList}>+ Create List</button>
        </div>
      )}
      {error && <p style={{ color: "#EF4444", fontSize: 13 }}>{error}</p>}
      {loading && <p style={S.small}>Loading…</p>}

      {view === "mine" && !loading && (myTasks.length === 0 ? <p style={S.small}>No tasks assigned to you.</p> : myTasks.map(t => <TaskCard key={t._id} t={t} />))}

      {view === "boards" && !loading && (
        <div style={{ display: "flex", gap: 14, overflowX: "auto", paddingBottom: 8 }}>
          {lists.length === 0 ? <p style={S.small}>No lists yet. Create one above.</p> : lists.map(l => (
            <div key={l._id} style={S.col}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
                <strong style={{ fontSize: 14 }}>{l.name}</strong>
                <span style={{ display: "flex", gap: 8, alignItems: "center" }}>
                  <span style={S.small}>{l.completed_tasks ?? 0}/{l.total_tasks ?? 0}</span>
                  <button style={S.x} onClick={() => deleteList(l._id)}>✕</button>
                </span>
              </div>
              {(tasksByList[l._id] || []).map(t => <TaskCard key={t._id} t={t} />)}
              {taskForm?.list_id === l._id ? (
                <div style={{ ...S.card, background: "var(--surface2,#F3F4F6)" }}>
                  <input style={{ ...S.input, width: "100%", boxSizing: "border-box", marginBottom: 6 }} placeholder="Task title" value={taskForm.title} onChange={e => setTaskForm({ ...taskForm, title: e.target.value })} />
                  <select style={{ ...S.input, width: "100%", marginBottom: 6 }} value={taskForm.priority} onChange={e => setTaskForm({ ...taskForm, priority: e.target.value })}>{PRIORITIES.map(p => <option key={p} value={p}>{p}</option>)}</select>
                  <select multiple style={{ ...S.input, width: "100%", marginBottom: 6, height: 70 }} value={taskForm.assignee_ids} onChange={e => setTaskForm({ ...taskForm, assignee_ids: Array.from(e.target.selectedOptions, o => o.value) })}>{members.map(m => <option key={m._id} value={m._id}>{m.name}</option>)}</select>
                  <div style={{ display: "flex", gap: 6 }}>
                    <button style={S.btn} onClick={createTask}>Add</button>
                    <button style={{ ...S.btn, background: "var(--surface2,#E5E7EB)", color: "var(--text,#374151)" }} onClick={() => setTaskForm(null)}>Cancel</button>
                  </div>
                </div>
              ) : (
                <button style={{ ...S.small, background: "none", border: "1px dashed var(--border,#D1D5DB)", borderRadius: 6, padding: "6px 10px", cursor: "pointer", width: "100%" }} onClick={() => setTaskForm({ list_id: l._id, title: "", priority: "Medium", assignee_ids: [] })}>+ Add task</button>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
```

> **Assignee is required at create time** → the form loads `get_workspace_members` and shows a
> multi-select; `assignee_ids` holds member `_id`s. **Drag reorder is OPTIONAL** (call
> `reorder_tasks` / `reorder_subtasks` with the ordered `_id` array; needs a dnd lib — skip unless asked).

---

## Step 3 — API layer
No `api.ts` changes — everything uses the existing `callApi` helper through the middleware.

## Step 4 — App integration (grep `App.tsx`)
- `activeTab` state → add a "Tasks" tab: `{activeTab === "tasks" && <WorkspaceTasks />}`
- `page` state → render `<WorkspaceTasks />` on the tasks page.
- Placeholder tab ("Feature loading") → replace it with `<WorkspaceTasks />`.
- Standalone → render `<WorkspaceTasks />` in `App.tsx`.

## Step 5 — Document (append to `backend/document.md`)
Document each function: `get_task_lists`→`{lists}`, `get_tasks(list_id)`→`{tasks}`, `get_subtasks(task_id)`→`{subtasks}`,
`get_task(task_id)`→`{task}`, `get_task_count_summary`→`{summary}`, `get_my_tasks`→`{tasks}`,
`get_workspace_members`→`{members}`, `create_task_list`/`update_task_list`/`delete_task_list`,
`create_task`/`update_task`/`delete_task`, `create_subtask`/`update_subtask`/`delete_subtask`,
`advance_task_status`, `reorder_tasks`, `reorder_subtasks`. All return their payload or `{error}`.

---

## Agent direct use (conversational — separate from building)
If the agent itself needs to answer "what are my tasks" in chat (not build a UI), see
`features/team-tasks.md` for the bash/`kogo_gql` flow and output rules. That mode is unrelated to the
BUILD steps above — when adding the feature to a dashboard, always use Steps 1–5.
