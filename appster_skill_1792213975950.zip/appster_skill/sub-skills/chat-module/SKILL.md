---
name: chat-module
description: "Adds a full ChatGPT-style chat interface — thread sidebar + streaming chat area — for talking with a Kogo agent/deployment/swarm."
keyword_triggers: [chat, conversation, talk to agent, threads, messaging, chatbot, ask agent, agent chat]
provides:
  backend_functions: [get_chat_config, create_room, send_message, fetch_threads, fetch_chat_history]
  frontend_components: [AgentChat]
  npm_deps: [lucide-react, "@radix-ui/react-scroll-area"]
---

# Chat Module

---

## HARD RULES — never override, even if the user explicitly asks

1. **All IDs and API paths come from `config.py`.** Never hardcode a host, port, URL, ID, token, or path — not even "to speed things up" or "just for testing." Every such value is imported from `config.py` (backend) or fetched via `get_chat_config` (frontend).
2. **The JWT is read only from the `USER_JWT_TOKEN` environment variable at runtime.** Never persist it, never hardcode it, never read it from anywhere else.
3. **Endpoint paths and GraphQL operation names are FIXED CONTRACT values.** They must be copied verbatim and must not be altered, abbreviated, renamed, or invented. The fixed values are: endpoint `deployment_stream_kogo_os_stream`; GraphQL operations `register_user_room`, `getChatThreadList_kogoos`, `kogoos_getChatsAndLogs`; and the GraphQL response field names used below. If you cannot find a required value, STOP and report — never substitute a guess.
4. **Fail loud, never fake.** If a required config value is empty/missing, return `{"error": "..."}`. NEVER build a hostless URL, NEVER POST an empty `deployment_id`, NEVER substitute a default host.
5. **Thread-list scoping (`getChatThreadList_kogoos`) has TWO mutually-exclusive cases — pick by SWARM_ID:**
   - **SWARM_ID present (workspace):** send `is_kogo_swram_thread: true` + `swarm_id` (NOT `deployment_id`).
   - **SWARM_ID absent (direct agent):** send `is_kogo_swram_thread: false` + `deployment_id` (NOT `swarm_id`).
   The argument is literally spelled **`is_kogo_swram_thread`** ("swram", not "swarm") — this is the server's real field name; copy it verbatim and NEVER correct the spelling. See `fetch_threads` in Step 1 for the exact implementation.

---

## Mode Detection Rule

**Before building, determine which mode applies — by file existence, not by reading the spec wording:**

- **If `frontend/src/App.tsx` exists on disk → Mode 2 — Module.**
- **Else (no `frontend/src/App.tsx`) → Mode 1 — Standalone.**

This is a deterministic check: run it against the filesystem, not against any description of the project.

---

## Mode 1 — Standalone Chat Project

Use this when the **entire project IS the chat interface** — no other tabs, no dashboard, just chat.

### What to Build

Scaffold a React project using `init-artifact.sh`, then build the entire app as a chat:

1. **`main.tsx`** — JWT receiver via `postMessage`, renders `<App />`
2. **`App.tsx`** — renders `<AgentChat />` full-screen with no nav/tabs
3. **`components/AgentChat.tsx`** — the full chat component (see Step 2 below)
4. **`services/api.ts`** — chat config fetch + `streamMessage` SSE
5. **`backend/functions.py`** — full chat backend block
6. **`backend/models.py`** — no tables needed; chat uses external Kogo API
7. **`backend/document.md`** — document all 5 chat functions

**App.tsx for Mode 1 (full-page, no tabs):**

```tsx
import { useEffect, useState } from "react";
import AgentChat from "./components/AgentChat";

export default function App() {
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const handler = (e: MessageEvent) => {
      if (e.data?.type === "KOGO_AUTH" && e.data?.jwt) {
        (window as any).__KOGO_JWT__ = e.data.jwt;
        setReady(true);
      }
    };
    window.addEventListener("message", handler);
    return () => window.removeEventListener("message", handler);
  }, []);

  if (!ready) {
    return (
      <div style={{ height: "100vh", display: "flex", alignItems: "center", justifyContent: "center", color: "#9CA3AF", fontSize: 14 }}>
        Connecting...
      </div>
    );
  }

  return (
    <div style={{ height: "100vh", display: "flex", flexDirection: "column" }}>
      <AgentChat />
    </div>
  );
}
```

---

## Mode 2 — Module Integration Steps

> Follow these steps exactly when integrating chat into an existing project.

---

### ⚠️ Pre-Flight — Read These Files First

1. **`backend/config.py`** — all constants are defined here. Chat module imports from here.
   **MANDATORY config check:** grep `config.py` for each of the 6 imported names: `AGENT_ID`, `DEPLOYMENT_ID`, `USER_ID`, `CHAT_API_PATH`, `API_PATH`, `SWARM_ID`. If ANY one is missing → **STOP and report which name is missing.** NEVER fabricate a value (no placeholder host, no made-up ID, no default token) to satisfy the import.
2. **DESIGN.md** — the AgentChat component below uses fully hardcoded colors and is NOT themed from DESIGN.md. Do NOT attempt to extract or apply color tokens; leave the component's literal style values as written.
3. **`backend/functions.py`** — locate `FUNCTIONS = {` dict. Insert BEFORE it.
4. **`frontend/src/services/api.ts`** — `callApi` returns `{ success, data, message }`.
5. **`frontend/src/App.tsx`** — understand routing pattern (used by Step 4's deterministic integration rule).

---

### Step 1 — Backend (insert BEFORE FUNCTIONS dict)

> **⛔ CRITICAL:** Insert BEFORE `FUNCTIONS = {` — Python must define before reference.

Ensure these imports at top of functions.py (**check first, do NOT duplicate**):
```python
import os
import json
import re
import requests
from typing import Optional
```
> `os` is used to read `USER_JWT_TOKEN` from the environment; `json` is used to parse the SSE stream. Both are required — do not omit them.

Insert this block **right before** `FUNCTIONS = {`:

```python
# ═══════════════════════════════════════════════════════════════════════════
# CHAT MODULE — Kogo Agent Chat Functions
# ═══════════════════════════════════════════════════════════════════════════

# Import config values from config.py. These are the ONLY source for IDs/paths.
# The JWT is NEVER imported here — it is read from the USER_JWT_TOKEN env var at
# runtime inside _chat_headers(). (See Pre-Flight: all 6 names below must exist
# in config.py, or STOP and report — do not fabricate.)
from config import (
    AGENT_ID as CFG_AGENT_ID,
    DEPLOYMENT_ID as CFG_DEPLOYMENT_ID,
    USER_ID as CFG_USER_ID,
    CHAT_API_PATH as CFG_CHAT_API_PATH,
    API_PATH as CFG_API_PATH,
    SWARM_ID as CFG_SWARM_ID,
)

CHAT_MODULE_CHAT_API_PATH = CFG_CHAT_API_PATH  # from env CHAT_API_PATH
CHAT_MODULE_USER_ID = CFG_USER_ID
CHAT_MODULE_DEPLOYMENT_ID = CFG_DEPLOYMENT_ID  # from env DEPLOYMENT_ID (the deployment id)
# SWARM_ID: empty string means "no workspace" (direct agent context).
# Also guard against the legacy "null" string sentinel from old configs.
CHAT_MODULE_SWARM_ID = CFG_SWARM_ID if CFG_SWARM_ID and CFG_SWARM_ID != "null" else None
# AGENT_ID / DEPLOYMENT_ID / SWARM_ID are ALWAYS distinct ids — never equal.
CHAT_MODULE_AGENT_ID = CFG_AGENT_ID  # from env AGENT_ID (the agent's own id)
# API_PATH from env is the GraphQL gateway URL (ends with /gateway).
# Derive base (without /gateway) for api_path response field.
CHAT_MODULE_BASE = CFG_API_PATH[:-len("/gateway")] if CFG_API_PATH.endswith("/gateway") else CFG_API_PATH
CHAT_MODULE_API_PATH = CFG_API_PATH if CFG_API_PATH.endswith("/gateway") else f"{CFG_API_PATH}/gateway"


def _chat_headers() -> dict:
    return {
        "Authorization": os.environ.get("USER_JWT_TOKEN", ""),  # runtime only
        "Content-Type": "application/json",
    }


def clean_boat_reply(raw: str) -> str:
    if not raw: return ""
    text = raw
    for tag in ["starttime", "endtime", "icon", "loader", "summary", "file"]:
        text = re.sub(rf"<{tag}\b[^>]*>.*?</{tag}>", "", text, flags=re.DOTALL)
    text = re.sub(r"\d{13}", "", text)
    text = re.sub(r"fa-(?:regular|solid) fa-[\w-]+", "", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    text = re.sub(r" {3,}", " ", text)
    return text.strip()


def get_chat_config(db: Session) -> dict:
    # All values from config.py. Fail loud if the module is not configured —
    # never hand the frontend an empty chat_api_path (would build a hostless URL).
    if not CHAT_MODULE_CHAT_API_PATH or not CHAT_MODULE_API_PATH:
        return {"error": "chat module not configured: missing CHAT_API_PATH"}
    if not CHAT_MODULE_DEPLOYMENT_ID and not CHAT_MODULE_SWARM_ID:
        return {"error": "chat module not configured: missing DEPLOYMENT_ID and SWARM_ID"}
    return {
        "api_path": CHAT_MODULE_BASE,
        "chat_api_path": CHAT_MODULE_CHAT_API_PATH,
        "user_id": CHAT_MODULE_USER_ID,
        "deployment_id": CHAT_MODULE_DEPLOYMENT_ID,
        "swarm_id": CHAT_MODULE_SWARM_ID,
        "agent_id": CHAT_MODULE_AGENT_ID,
        "token": os.environ.get("USER_JWT_TOKEN", ""),  # runtime only
        "agent_name": "",
        "agent_icon": "",
    }


def create_room(db: Session) -> dict:
    """Create a user room via the Kogo GraphQL gateway. Must be called before any chat interaction."""
    # FIXED CONTRACT: GraphQL operation "register_user_room" — verbatim, never renamed/invented.
    payload = {
        "query": (
            "mutation Register_user_room($sender: ID) {\n"
            "  register_user_room(sender: $sender) {\n"
            "    _id\n"
            "  }\n"
            "}"
        ),
        "variables": {"sender": CHAT_MODULE_USER_ID},
    }
    try:
        resp = requests.post(CHAT_MODULE_API_PATH, json=payload, headers=_chat_headers(), timeout=30)
        resp.raise_for_status()
        data = resp.json()
        room_data = (data.get("data") or {}).get("register_user_room")
        if room_data is None:
            return {"error": "No data returned from register_user_room", "raw": data}
        return {"room_id": room_data["_id"]}
    except requests.exceptions.RequestException as e:
        return {"error": f"Room creation failed: {e}"}
    except (KeyError, TypeError) as e:
        return {"error": f"Unexpected room creation response: {e}"}


def send_message(
    db: Session,
    message: str,
    thread_id: Optional[str] = None,
    deployment_id: str = "",
    swarm_id: Optional[str] = None,
) -> dict:
    """Send a user message to the agent via SSE streaming. Backend accumulates the full stream."""
    dep_id = deployment_id or CHAT_MODULE_DEPLOYMENT_ID
    # swarm_id "null" sentinel (see config import block) is normalized to None.
    swm_id = swarm_id if swarm_id is not None else (CHAT_MODULE_SWARM_ID if CHAT_MODULE_SWARM_ID and CHAT_MODULE_SWARM_ID != "null" else None)

    # Fail loud — never POST a hostless URL or an empty deployment_id.
    if not CHAT_MODULE_CHAT_API_PATH:
        return {"error": "chat module not configured: missing CHAT_API_PATH"}
    if not dep_id and not swm_id:
        return {"error": "chat module not configured: missing DEPLOYMENT_ID and SWARM_ID"}

    # FIXED CONTRACT: endpoint path "deployment_stream_kogo_os_stream" — verbatim,
    # never altered, abbreviated, or invented.
    url = f"{CHAT_MODULE_CHAT_API_PATH}/deployment_stream_kogo_os_stream"
    payload = {
        "sender": CHAT_MODULE_USER_ID,
        "guest_sender": None,
        "guest_name": None,
        "thread_id": thread_id,
        "message": message,
        "deployment_id": dep_id,
        "kogo_swarm_id": swm_id,
    }

    created_thread_id = None
    boatReply = ""
    repliedAgent = None
    chat_id = None
    chat_ref_id = None
    cardContent = None

    try:
        with requests.post(url, json=payload, headers=_chat_headers(), stream=True, timeout=120) as resp:
            resp.raise_for_status()
            buffer = ""
            for chunk in resp.iter_content(chunk_size=None, decode_unicode=True):
                if not chunk:
                    continue
                if isinstance(chunk, bytes):
                    chunk = chunk.decode("utf-8", errors="replace")
                buffer += chunk
                while "\n\n" in buffer:
                    event_raw, buffer = buffer.split("\n\n", 1)
                    data_str = None
                    for line in event_raw.split("\n"):
                        if line.startswith("data:"):
                            data_str = line[len("data:"):].strip()
                            break
                    if not data_str:
                        continue
                    try:
                        event_data = json.loads(data_str)
                    except json.JSONDecodeError:
                        continue
                    event_type = event_data.get("type", "")
                    inner = event_data.get("data", {})
                    if event_type == "streaming":
                        if inner.get("boatReply"):
                            boatReply += inner["boatReply"]
                        if created_thread_id is None and inner.get("created_thread_id"):
                            created_thread_id = inner["created_thread_id"]
                        if repliedAgent is None and inner.get("repliedAgent"):
                            repliedAgent = inner["repliedAgent"]
                        if not cardContent and inner.get("cardContent"):
                            cardContent = inner["cardContent"]
                    elif event_type == "final":
                        if inner.get("boatReply"):
                            boatReply = inner["boatReply"]
                        if inner.get("created_thread_id"):
                            created_thread_id = inner["created_thread_id"]
                        if inner.get("repliedAgent"):
                            repliedAgent = inner["repliedAgent"]
                        if inner.get("chat_id"):
                            chat_id = inner["chat_id"]
                        if inner.get("chat_ref_id"):
                            chat_ref_id = inner["chat_ref_id"]
                        if inner.get("cardContent"):
                            cardContent = inner["cardContent"]

        result = {
            "created_thread_id": created_thread_id,
            "boatReply": boatReply,
            "message": clean_boat_reply(boatReply),
            "repliedAgent": repliedAgent,
            "chat_id": chat_id,
            "cardContent": cardContent if cardContent else None,
        }
        if chat_ref_id:
            result["chat_ref_id"] = chat_ref_id
        return result
    except requests.exceptions.RequestException as e:
        return {"error": f"Message send failed: {e}"}
    except Exception as e:
        return {"error": f"Stream processing error: {e}"}


def fetch_threads(db: Session, room_id: str) -> dict:
    """Fetch the chat thread list for a room.

    ⭐ FIXED CONTRACT — thread scoping has TWO cases. Pick the case by whether a SWARM_ID
    exists, and send EXACTLY the keys listed for that case (nothing more, nothing less):

      • WORKSPACE / SWARM context  (CHAT_MODULE_SWARM_ID is set):
            { "isKogoSwramThread": True,  "roomId": <room_id>, "swarmId": <SWARM_ID> }
        → do NOT send deploymentId.
      • DIRECT AGENT context       (CHAT_MODULE_SWARM_ID is None / empty):
            { "isKogoSwramThread": False, "roomId": <room_id>, "deploymentId": <DEPLOYMENT_ID> }
        → do NOT send swarmId.

    ⚠️ The GraphQL argument is literally spelled `is_kogo_swram_thread` — note "swram", NOT
       "swarm". This is the server's real (misspelled) field name; copy it verbatim and NEVER
       "fix" the spelling, or the query fails. Same for the variable `$isKogoSwramThread`.
    """
    # Branch strictly on SWARM_ID presence — this is what decides swarm vs agent threads.
    if CHAT_MODULE_SWARM_ID:
        variables: dict = {
            "roomId": room_id,
            "isKogoSwramThread": True,
            "swarmId": CHAT_MODULE_SWARM_ID,
        }
    else:
        variables = {
            "roomId": room_id,
            "isKogoSwramThread": False,
            "deploymentId": CHAT_MODULE_DEPLOYMENT_ID or None,
        }
    # FIXED CONTRACT: operation "getChatThreadList_kogoos", the arg name
    # "is_kogo_swram_thread" (real server typo), and the response field names — all verbatim.
    # The query declares all branch variables; the unused one is simply null for that case.
    payload = {
        "query": (
            "query GetChatThreadList_kogoos($roomId: ID!, $isKogoSwramThread: Boolean, $swarmId: ID, $deploymentId: ID) {\n"
            "  getChatThreadList_kogoos(room_id: $roomId, is_kogo_swram_thread: $isKogoSwramThread, swarm_id: $swarmId, deployment_id: $deploymentId) {\n"
            "    _id\n    title\n    summary\n    deployment_id\n    kogo_swarm_id\n"
            "    last_chat_time\n    dateCategory\n    unread_count\n    agent_category_id\n    job_type\n"
            "  }\n}"
        ),
        "variables": variables,
    }
    try:
        resp = requests.post(CHAT_MODULE_API_PATH, json=payload, headers=_chat_headers(), timeout=30)
        resp.raise_for_status()
        data = resp.json()
        threads = (data.get("data") or {}).get("getChatThreadList_kogoos")
        if threads is None:
            return {"threads": [], "error": "No data returned from getChatThreadList_kogoos", "raw": data}
        return {"threads": threads}
    except requests.exceptions.RequestException as e:
        return {"error": f"Fetch threads failed: {e}"}
    except (KeyError, TypeError) as e:
        return {"error": f"Unexpected threads response: {e}"}


def fetch_chat_history(db: Session, thread_id: str) -> dict:
    """Fetch full chat history for a specific thread."""
    # FIXED CONTRACT: GraphQL operation "kogoos_getChatsAndLogs" and its response
    # field names (incl. card_data { card_content { item_info } }) — verbatim, never
    # renamed/invented.
    payload = {
        "query": (
            "query Kogoos_getChatsAndLogs($thread_id: ID!) {\n"
            "  kogoos_getChatsAndLogs(thread_id: $thread_id) {\n"
            "    logs { _id message thread_id timestamp type vendor_id }\n"
            "    schedule_info { first_run last_run runs_at next_run }\n"
            "    thread { _id summary title agent_category_id last_chat_time kogo_swarm_id }\n"
            "    chats { _id sent_at agent { icon name } card_data { _id card_content { item_info } card_description card_icon card_type } message translated_message chat_ref_id isHumanReply user { _id first_name last_name email } file_datas { file_type file_extension file_name file_path } likeStatus likeFeedback is_msg_read }\n"
            "    deployment_details { _id deployment_name icon }\n"
            "    videoChatData { audio_recording_path created_at end_time meeting_url start_time thread_id call_duration }\n"
            "    ticket_ids\n"
            "  }\n}"
        ),
        "variables": {"thread_id": thread_id},
    }
    try:
        resp = requests.post(CHAT_MODULE_API_PATH, json=payload, headers=_chat_headers(), timeout=30)
        resp.raise_for_status()
        data = resp.json()
        result_data = (data.get("data") or {}).get("kogoos_getChatsAndLogs")
        if result_data is None:
            return {"chats": [], "thread": {}, "deployment_details": {}, "logs": [], "error": "No data returned", "raw": data}
        return {
            "chats": result_data.get("chats", []),
            "thread": result_data.get("thread", {}),
            "deployment_details": result_data.get("deployment_details", {}),
            "logs": result_data.get("logs", []),
            "schedule_info": result_data.get("schedule_info"),
            "videoChatData": result_data.get("videoChatData", []),
            "ticket_ids": result_data.get("ticket_ids", []),
        }
    except requests.exceptions.RequestException as e:
        return {"error": f"Fetch chat history failed: {e}"}
    except (KeyError, TypeError) as e:
        return {"error": f"Unexpected chat history response: {e}"}
```

Also register in `FUNCTIONS` dict:

```python
# Add to existing FUNCTIONS dict:
"get_chat_config": get_chat_config,
"create_room": create_room,
"send_message": send_message,
"fetch_threads": fetch_threads,
"fetch_chat_history": fetch_chat_history,
```

---

### Step 2 — Frontend Component

Create `frontend/src/components/AgentChat.tsx`:

```tsx
import { useState, useEffect, useRef, useCallback } from "react";
import { Send, Plus, MessageSquare, Paperclip, ThumbsUp, ThumbsDown, ExternalLink } from "lucide-react";
import { callApi, ChatConfig, streamMessage, cleanBoatReply } from "../services/api";

interface Thread { _id: string; title: string; summary: string; dateCategory: string; unread_count: number; }
// FIXED CONTRACT — canonical card shape used by ALL THREE layers (backend send_message,
// api.ts streamMessage, this component). The agent emits `cardContent` as an object:
//   { card_data: [ { card_content: { item_info: {...} } } ], file_datas: [...] }
// Each rendered CardItem is mapped from one card_data[i].card_content.item_info as:
//   title       <- item_info.title
//   description <- item_info.description
//   url         <- item_info.url
//   image       <- item_info.image
// This mapping (item_info -> CardItem) is performed once, in mapCardContent() below,
// and the component renders CardItem[] only.
interface CardItem { title?: string; description?: string; url?: string; image?: string; [key: string]: any; }
interface FileChip { name: string; url?: string; type?: string; }

// Map the agent's cardContent contract object to the flat CardItem[] the UI renders.
function mapCardContent(cardContent: any): CardItem[] | null {
  const cards = cardContent?.card_data;
  if (!Array.isArray(cards) || cards.length === 0) return null;
  return cards.map((c: any) => {
    const info = c?.card_content?.item_info || {};
    return { title: info.title, description: info.description, url: info.url, image: info.image };
  });
}
function mapFileDatas(cardContent: any): FileChip[] | null {
  const files = cardContent?.file_datas;
  if (!Array.isArray(files) || files.length === 0) return null;
  return files.map((f: any) => ({ name: f.file_name || f.name, url: f.file_path || f.url, type: f.file_type || f.type }));
}
interface Message {
  id: string;
  role: "user" | "agent";
  text: string;
  agentName?: string;
  agentIcon?: string;
  streaming?: boolean;
  cardData?: CardItem[] | null;
  fileDatas?: FileChip[] | null;
  likeStatus?: "liked" | "disliked" | null;
}

export default function AgentChat() {
  const [config, setConfig] = useState<ChatConfig | null>(null);
  const [roomId, setRoomId] = useState<string | null>(null);
  const [threads, setThreads] = useState<Thread[]>([]);
  const [activeThreadId, setActiveThreadId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [streaming, setStreaming] = useState(false);
  const [threadTitle, setThreadTitle] = useState("New Chat");
  const [searchQuery, setSearchQuery] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  useEffect(() => { scrollToBottom(); }, [messages]);

  useEffect(() => {
    (async () => {
      const cfgRes = await callApi("get_chat_config");
      if (!cfgRes.success) return;
      const cfg = cfgRes.data as ChatConfig;
      setConfig(cfg);
      const roomRes = await callApi("create_room");
      if (!roomRes.success) return;
      const rid = roomRes.data.room_id;
      setRoomId(rid);
      const threadsRes = await callApi("fetch_threads", { room_id: rid });
      if (threadsRes.success) setThreads(threadsRes.data.threads || []);
    })();
  }, []);

  const loadThread = useCallback(async (threadId: string, title: string) => {
    setActiveThreadId(threadId);
    setThreadTitle(title);
    const res = await callApi("fetch_chat_history", { thread_id: threadId });
    if (!res.success) return;
    const chats = res.data.chats || [];
    setMessages(chats.map((c: any) => ({
      id: c._id,
      role: c.isHumanReply || !c.agent ? "user" : "agent",
      text: cleanBoatReply(c.message || ""),
      agentName: c.agent?.name,
      agentIcon: c.agent?.icon,
    })));
  }, []);

  const sendMsg = useCallback(async () => {
    if (!input.trim() || streaming || !config) return;
    const userText = input.trim();
    setInput("");
    setMessages(prev => [...prev, { id: Date.now().toString(), role: "user", text: userText }]);
    setStreaming(true);

    const agentMsgId = (Date.now() + 1).toString();
    setMessages(prev => [...prev, { id: agentMsgId, role: "agent", text: "", streaming: true }]);

    let capturedThreadId = activeThreadId;

    await streamMessage(config, userText, activeThreadId, {
      onChunk: (_, fullReply, repliedAgent) => {
        setMessages(prev => prev.map(m =>
          m.id === agentMsgId ? { ...m, text: fullReply, agentName: repliedAgent?.name, agentIcon: repliedAgent?.icon } : m
        ));
      },
      onFinal: (fullReply, repliedAgent, cardContent) => {
        setMessages(prev => prev.map(m =>
          m.id === agentMsgId ? {
            ...m,
            text: fullReply,
            streaming: false,
            agentName: repliedAgent?.name,
            agentIcon: repliedAgent?.icon,
            cardData: mapCardContent(cardContent),
            fileDatas: mapFileDatas(cardContent),
          } : m
        ));
      },
      onThreadId: (tid) => {
        capturedThreadId = tid;
        setActiveThreadId(tid);
        setThreadTitle("New conversation");
      },
      onError: (err) => {
        setMessages(prev => prev.map(m => m.id === agentMsgId ? { ...m, text: `Error: ${err}`, streaming: false } : m));
      },
    });

    setStreaming(false);
    if (roomId) {
      const threadsRes = await callApi("fetch_threads", { room_id: roomId });
      if (threadsRes.success) setThreads(threadsRes.data.threads || []);
    }
  }, [input, streaming, config, activeThreadId, roomId]);

  const filteredThreads = threads.filter(t =>
    (t.title || t.summary || "").toLowerCase().includes(searchQuery.toLowerCase())
  );

  const groupedThreads = filteredThreads.reduce((acc: Record<string, Thread[]>, t) => {
    const cat = t.dateCategory || "Older";
    if (!acc[cat]) acc[cat] = [];
    acc[cat].push(t);
    return acc;
  }, {});

  const categoryOrder = ["Today", "Yesterday", "Previous 7 Days", "Older"];
  // Catch-all: any dateCategory the server returns that is NOT in categoryOrder gets
  // rendered after the known buckets so no thread silently vanishes.
  const extraCategories = Object.keys(groupedThreads).filter(c => !categoryOrder.includes(c));
  const renderOrder = [...categoryOrder, ...extraCategories];

  return (
    <div style={{ display: "flex", height: "100%", background: "#F8F9FA", fontFamily: "'Space Grotesk', sans-serif" }}>
      {/* Sidebar */}
      <div style={{ width: 260, background: "#fff", borderRight: "1px solid #E5E7EB", display: "flex", flexDirection: "column" }}>
        <div style={{ padding: "16px 12px 8px", borderBottom: "1px solid #E5E7EB" }}>
          <div style={{ fontWeight: 600, fontSize: 14, color: "#1F2937", marginBottom: 8 }}>
            {config?.agent_name || "Agent Chat"}
          </div>
          <button
            onClick={() => { setActiveThreadId(null); setMessages([]); setThreadTitle("New Chat"); }}
            style={{ width: "100%", padding: "6px 10px", background: "#3B82F6", color: "#fff", border: "none", borderRadius: 6, cursor: "pointer", fontSize: 13, display: "flex", alignItems: "center", gap: 6 }}
          >
            <Plus size={14} /> New Chat
          </button>
        </div>
        <div style={{ padding: "8px 12px" }}>
          <input
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search threads..."
            style={{ width: "100%", padding: "6px 8px", border: "1px solid #E5E7EB", borderRadius: 6, fontSize: 12, outline: "none", boxSizing: "border-box" }}
          />
        </div>
        <div style={{ flex: 1, overflowY: "auto", padding: "0 8px 8px" }}>
          {renderOrder.map(cat => {
            const group = groupedThreads[cat];
            if (!group?.length) return null;
            return (
              <div key={cat}>
                <div style={{ fontSize: 10, fontWeight: 600, color: "#9CA3AF", textTransform: "uppercase", letterSpacing: "0.05em", padding: "8px 4px 4px" }}>{cat}</div>
                {group.map(t => (
                  <div
                    key={t._id}
                    onClick={() => loadThread(t._id, t.title || t.summary || "Conversation")}
                    style={{
                      padding: "8px 8px", borderRadius: 6, cursor: "pointer", marginBottom: 2,
                      background: activeThreadId === t._id ? "#EFF6FF" : "transparent",
                      borderLeft: activeThreadId === t._id ? "3px solid #3B82F6" : "3px solid transparent",
                    }}
                  >
                    <div style={{ fontSize: 12, color: "#1F2937", fontWeight: activeThreadId === t._id ? 600 : 400, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                      {t.title || t.summary || "Conversation"}
                    </div>
                  </div>
                ))}
              </div>
            );
          })}
          {threads.length === 0 && (
            <div style={{ textAlign: "center", color: "#9CA3AF", fontSize: 12, padding: 16 }}>No conversations yet</div>
          )}
        </div>
      </div>

      {/* Chat Area */}
      <div style={{ flex: 1, display: "flex", flexDirection: "column" }}>
        <div style={{ padding: "12px 20px", borderBottom: "1px solid #E5E7EB", background: "#fff", fontWeight: 600, fontSize: 14, color: "#1F2937" }}>
          {threadTitle}
        </div>
        <div style={{ flex: 1, overflowY: "auto", padding: "16px 20px", display: "flex", flexDirection: "column", gap: 12 }}>
          {messages.length === 0 && (
            <div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", color: "#9CA3AF" }}>
              <MessageSquare size={32} style={{ marginBottom: 8, opacity: 0.4 }} />
              <div style={{ fontSize: 14 }}>Start a conversation</div>
            </div>
          )}
          {messages.map(msg => (
            <div key={msg.id} style={{ display: "flex", justifyContent: msg.role === "user" ? "flex-end" : "flex-start", gap: 8 }}>
              {msg.role === "agent" && (
                <div style={{ width: 28, height: 28, borderRadius: "50%", background: "#E5E7EB", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 12, flexShrink: 0, overflow: "hidden" }}>
                  {msg.agentIcon ? <img src={msg.agentIcon} style={{ width: "100%", height: "100%", objectFit: "cover" }} alt="" /> : "🤖"}
                </div>
              )}
              <div style={{ maxWidth: "70%" }}>
                {msg.role === "agent" && msg.agentName && (
                  <div style={{ fontSize: 10, color: "#6B7280", marginBottom: 3 }}>{msg.agentName}</div>
                )}
                <div style={{
                  padding: "10px 14px", borderRadius: msg.role === "user" ? "16px 16px 4px 16px" : "16px 16px 16px 4px",
                  background: msg.role === "user" ? "#3B82F6" : "#fff",
                  color: msg.role === "user" ? "#fff" : "#1F2937",
                  fontSize: 13, lineHeight: 1.5,
                  borderLeft: msg.role === "agent" ? "3px solid rgba(59,130,246,0.3)" : "none",
                  boxShadow: "0 1px 3px rgba(0,0,0,0.08)",
                  whiteSpace: "pre-wrap",
                }}>
                  {msg.text || (msg.streaming ? <span style={{ opacity: 0.5 }}>●●●</span> : "")}
                </div>

                {/* File chips (file_datas) — shown below message bubble */}
                {msg.fileDatas && msg.fileDatas.length > 0 && (
                  <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginTop: 6 }}>
                    {msg.fileDatas.map((f, i) => (
                      <a
                        key={i}
                        href={f.url || "#"}
                        target="_blank"
                        rel="noopener noreferrer"
                        style={{
                          display: "inline-flex", alignItems: "center", gap: 4,
                          padding: "4px 10px", borderRadius: 6,
                          background: "#F3F4F6", border: "1px solid #E5E7EB",
                          fontSize: 12, color: "#374151", textDecoration: "none",
                        }}
                      >
                        <Paperclip size={11} />
                        {f.name}
                      </a>
                    ))}
                  </div>
                )}

                {/* Card data — rendered as cards below the message */}
                {msg.cardData && msg.cardData.length > 0 && (
                  <div style={{ display: "flex", flexDirection: "column", gap: 8, marginTop: 8 }}>
                    {msg.cardData.map((card, i) => (
                      <div
                        key={i}
                        style={{
                          background: "#fff", border: "1px solid #E5E7EB", borderRadius: 8,
                          padding: "10px 12px", boxShadow: "0 1px 2px rgba(0,0,0,0.05)",
                        }}
                      >
                        {card.image && (
                          <img src={card.image} alt="" style={{ width: "100%", borderRadius: 4, marginBottom: 6, objectFit: "cover", maxHeight: 120 }} />
                        )}
                        {card.title && <div style={{ fontWeight: 600, fontSize: 13, color: "#111827" }}>{card.title}</div>}
                        {card.description && <div style={{ fontSize: 12, color: "#6B7280", marginTop: 2 }}>{card.description}</div>}
                        {card.url && (
                          <a href={card.url} target="_blank" rel="noopener noreferrer"
                            style={{ display: "inline-flex", alignItems: "center", gap: 4, marginTop: 6, fontSize: 12, color: "#3B82F6", textDecoration: "none" }}>
                            Open <ExternalLink size={10} />
                          </a>
                        )}
                      </div>
                    ))}
                  </div>
                )}

                {/* Like/dislike buttons — shown on agent messages only */}
                {msg.role === "agent" && !msg.streaming && (
                  <div style={{ display: "flex", gap: 4, marginTop: 4 }}>
                    <button
                      onClick={() => setMessages(prev => prev.map(m => m.id === msg.id ? { ...m, likeStatus: m.likeStatus === "liked" ? null : "liked" } : m))}
                      style={{
                        background: "none", border: "none", cursor: "pointer", padding: "2px 6px", borderRadius: 4,
                        color: msg.likeStatus === "liked" ? "#16A34A" : "#9CA3AF",
                      }}
                      title="Like"
                    >
                      <ThumbsUp size={13} />
                    </button>
                    <button
                      onClick={() => setMessages(prev => prev.map(m => m.id === msg.id ? { ...m, likeStatus: m.likeStatus === "disliked" ? null : "disliked" } : m))}
                      style={{
                        background: "none", border: "none", cursor: "pointer", padding: "2px 6px", borderRadius: 4,
                        color: msg.likeStatus === "disliked" ? "#DC2626" : "#9CA3AF",
                      }}
                      title="Dislike"
                    >
                      <ThumbsDown size={13} />
                    </button>
                  </div>
                )}
              </div>
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        <div style={{ padding: "12px 20px", borderTop: "1px solid #E5E7EB", background: "#fff", display: "flex", gap: 8 }}>
          <textarea
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMsg(); } }}
            disabled={streaming}
            placeholder="Type a message... (Enter to send, Shift+Enter for newline)"
            style={{ flex: 1, padding: "10px 12px", border: "1px solid #E5E7EB", borderRadius: 8, fontSize: 13, resize: "none", outline: "none", maxHeight: 120, fontFamily: "inherit" }}
            rows={1}
          />
          <button
            onClick={sendMsg}
            disabled={streaming || !input.trim()}
            style={{ padding: "10px 16px", background: streaming || !input.trim() ? "#E5E7EB" : "#3B82F6", color: streaming || !input.trim() ? "#9CA3AF" : "#fff", border: "none", borderRadius: 8, cursor: streaming ? "not-allowed" : "pointer" }}
          >
            <Send size={16} />
          </button>
        </div>
      </div>
    </div>
  );
}
```

---

### Step 3 — API Layer (append to frontend/src/services/api.ts)

```typescript
// ═══════════════════════════════════════════════════════════════════════════
// CHAT MODULE — API additions
// ═══════════════════════════════════════════════════════════════════════════

export interface ChatConfig {
  api_path: string;
  chat_api_path: string;
  user_id: string;
  deployment_id: string;
  swarm_id: string | null;
  agent_id: string;
  token: string;
  agent_name: string;
  agent_icon: string;
}

const ANNOTATION_TAGS = ["starttime", "endtime", "icon", "loader", "summary", "file"];

export function cleanBoatReply(raw: string): string {
  if (!raw) return "";
  let text = raw;
  for (const tag of ANNOTATION_TAGS) {
    text = text.replace(new RegExp(`<${tag}\\b[^>]*>.*?</${tag}>`, "gs"), "");
    text = text.replace(new RegExp(`<${tag}\\b[^>]*>`, "g"), "");
  }
  text = text.replace(/\d{13}/g, "");
  text = text.replace(/fa-(?:regular|solid) fa-[\w-]+/g, "");
  text = text.replace(/\n{3,}/g, "\n\n");
  return text.trim();
}

// FIXED CONTRACT — cardContent is the agent's object shape:
//   { card_data: [ { card_content: { item_info: {...} } } ], file_datas: [...] }
// It is passed through verbatim to onFinal; the component maps it via mapCardContent().
export interface CardContent {
  card_data?: Array<{ card_content?: { item_info?: any } }>;
  file_datas?: any[];
}

export interface SSECallbacks {
  onChunk: (text: string, fullReply: string, repliedAgent: any) => void;
  onFinal: (fullReply: string, repliedAgent: any, cardContent?: CardContent | null) => void;
  onThreadId: (threadId: string) => void;
  onError: (error: string) => void;
}

export async function streamMessage(config: ChatConfig, message: string, threadId: string | null, callbacks: SSECallbacks): Promise<void> {
  // Fail loud — never fetch a hostless URL or POST an empty deployment_id.
  if (!config?.chat_api_path) { callbacks.onError("chat module not configured: missing CHAT_API_PATH"); return; }
  if (!config.deployment_id && !config.swarm_id) { callbacks.onError("chat module not configured: missing DEPLOYMENT_ID and SWARM_ID"); return; }

  const payload = {
    sender: config.user_id, guest_sender: null, guest_name: null,
    thread_id: threadId || null, message,
    deployment_id: config.deployment_id, swarm_id: config.swarm_id,
  };

  let fullReply = "";
  let repliedAgent: any = null;
  let finalCalled = false;

  try {
    // FIXED CONTRACT: endpoint path "deployment_stream_kogo_os_stream" — verbatim.
    const response = await fetch(`${config.chat_api_path}/deployment_stream_kogo_os_stream`, {
      method: "POST",
      headers: { Authorization: config.token, "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    if (!response.ok) { callbacks.onError(`API error: ${response.status}`); return; }

    const reader = response.body?.getReader();
    if (!reader) { callbacks.onError("No response stream"); return; }

    const decoder = new TextDecoder();
    let buffer = "";

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split("\n");
      buffer = lines.pop() || "";

      for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed.startsWith("data:")) continue;
        try {
          const parsed = JSON.parse(trimmed.slice(5).trim());
          const data = parsed.data || {};
          if (data.created_thread_id) callbacks.onThreadId(data.created_thread_id);
          if (data.repliedAgent) repliedAgent = data.repliedAgent;
          if (parsed.type === "streaming" && data.boatReply) {
            fullReply += data.boatReply;
            callbacks.onChunk(data.boatReply, cleanBoatReply(fullReply), repliedAgent);
          } else if (parsed.type === "final") {
            if (data.boatReply) fullReply = data.boatReply;
            finalCalled = true;
            callbacks.onFinal(cleanBoatReply(fullReply), repliedAgent, data.cardContent || null);
          }
        } catch { /* skip unparseable */ }
      }
    }

    if (!finalCalled) callbacks.onFinal(cleanBoatReply(fullReply), repliedAgent, null);
  } catch (err: any) {
    callbacks.onError(err.message || "Connection lost");
  }
}
```

---

### Step 4 — App Integration (deterministic option selection)

**Pick the option by grepping `frontend/src/App.tsx` — do NOT choose by preference:**

- If App.tsx declares an `activeTab` string state (grep: `useState` referencing `activeTab`) → **Option A (Tab / Route replacement)**.
- Else if App.tsx declares a `page` state (grep: `useState` referencing `page`) → **Option C (Full page replacement)**.
- Else (neither found) → **Option B (Side panel)**.

Apply exactly the matched option below.

**Option A — Tab / Route replacement**

App already has tabs or a nav. Replace the chat placeholder with the real component:

```tsx
import AgentChat from "./components/AgentChat";

// Inside your tab rendering, wire up the chat tab:
{activeTab === "chat" && (
  <div style={{ height: "calc(100vh - 60px)" }}>
    <AgentChat />
  </div>
)}
```

**Option B — Side panel (chat alongside main content)**

Chat slides in from the right while main content stays visible:

```tsx
import AgentChat from "./components/AgentChat";

// In App state:
const [chatOpen, setChatOpen] = useState(false);

// In JSX:
<div style={{ display: "flex", height: "100vh" }}>
  {/* Main content */}
  <div style={{ flex: 1, overflow: "auto" }}>
    {/* existing app content */}
    <button onClick={() => setChatOpen(o => !o)} style={{ position: "fixed", bottom: 24, right: chatOpen ? 404 : 24, zIndex: 10 }}>
      💬 Chat
    </button>
  </div>

  {/* Side panel */}
  {chatOpen && (
    <div style={{ width: 380, borderLeft: "1px solid #E5E7EB", flexShrink: 0, display: "flex", flexDirection: "column" }}>
      <div style={{ padding: "10px 16px", borderBottom: "1px solid #E5E7EB", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <span style={{ fontWeight: 600, fontSize: 14 }}>Chat</span>
        <button onClick={() => setChatOpen(false)} style={{ background: "none", border: "none", cursor: "pointer", fontSize: 16 }}>×</button>
      </div>
      <div style={{ flex: 1, overflow: "hidden" }}>
        <AgentChat />
      </div>
    </div>
  )}
</div>
```

**Option C — Full page replacement**

The app has a "Chat" page. Navigate to it and render AgentChat full-screen (state-based routing, no react-router-dom):

```tsx
import AgentChat from "./components/AgentChat";

// In App state:
const [page, setPage] = useState<"home" | "chat">("home");

// Nav link:
<button onClick={() => setPage("chat")}>Chat</button>

// Page render:
{page === "chat" ? (
  <div style={{ height: "100vh" }}>
    <AgentChat />
  </div>
) : (
  <YourMainContent />
)}
```

---

### Step 5 — Document (append to backend/document.md)

```markdown
---

## Chat Module

### `get_chat_config`
Returns config for SSE streaming: api_path, chat_api_path, user_id, deployment_id, swarm_id, agent_id, token, agent_name, agent_icon.
**Params:** none
**Returns:** ChatConfig dict

### `create_room`
Creates a Kogo user room. Call once before first message.
**Params:** none
**Returns:** `{ room_id }`

### `send_message`
Sends a message via SSE streaming (backend accumulates full reply).
**Params:** message (str, required), thread_id (str, optional), deployment_id (str, optional), swarm_id (str, optional)
**Returns:** `{ created_thread_id, message (cleaned), boatReply, repliedAgent, chat_id, cardContent }`

### `fetch_threads`
Fetches thread list for a room, grouped by dateCategory.
**Params:** room_id (str, required)
**Returns:** `{ threads: [{ _id, title, summary, dateCategory, unread_count }] }`

### `fetch_chat_history`
Fetches full message history for a thread.
**Params:** thread_id (str, required)
**Returns:** `{ chats: [...], thread: {...}, deployment_details: {...} }`
```
