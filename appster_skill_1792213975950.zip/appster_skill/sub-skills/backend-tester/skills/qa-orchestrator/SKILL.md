---
name: qa-orchestrator
description: >
  Orchestrates multi-skill testing pipelines. Classifies requests, routes to the right
  sub-skills, sequences execution (parallel or sequential), merges results into one
  unified QA_REPORT.md. This is the brain for complex testing workflows.
  Trigger when user mentions: full QA, test everything, pipeline, complete test,
  comprehensive testing.
---

# QA Orchestrator — Multi-Skill Pipeline Execution

## When to Use

- User says "test everything" or "full QA"
- Multiple sub-skills need to run together
- Results from one skill feed into another
- Need a single unified report from multiple test runs

## References

| File | Load When |
|---|---|
| `../references/decision-logic.md` | **Always** |
| `../references/qa-report-template.md` | **Always** |
| `../SKILL.md` | **Always** (for pipeline definitions and classification) |

## Architecture

```
User Request
  ↓
┌─────────────────────────────────────────────┐
│           QA ORCHESTRATOR                    │
│                                              │
│  1. CLASSIFY  — What kind of testing?        │
│  2. ROUTE     — Which sub-skills to use?     │
│  3. SEQUENCE  — What order? Parallel?        │
│  4. EXECUTE   — Run sub-skills               │
│  5. MERGE     — Combine into one report      │
│  6. REPORT    — Generate final QA_REPORT.md  │
└──────────────────────────────────────────────┘
```

---

## Step 1 — CLASSIFY

Read the user's request and classify into one or more testing categories using the classification table in `../SKILL.md`.

---

## Step 2 — ROUTE

### Single-Skill Requests

Most requests map to one sub-skill. Activate it directly.

| Category | Sub-Skill | Read This File |
|----------|-----------|---------------|
| Project QA, Unit, REST, GraphQL, Express, etc. | `../skills/backend-tester/` | `SKILL.md` |
| Spec-Driven, Spec Validation | `../skills/api-doc-tester/` | `SKILL.md` |
| DB Schema, Integrity, Indexes, Query, Migration | `../skills/db-tester/` | `SKILL.md` |
| Perf Load, Stress, Spike, Benchmark | `../skills/perf-tester/` | `SKILL.md` |
| WS Raw, Socket.IO, SSE | `../skills/websocket-tester/` | `SKILL.md` |

### Multi-Skill Requests

Use the pipeline definitions from `../SKILL.md` to determine which skills to run and in what order.

---

## Step 3 — SEQUENCE

### When to Run Sequential

- Skill B needs Skill A's output
- Later skill may modify code
- Load test only after functional tests pass

### When to Run Parallel

- Skills are independent
- Same target, different angles

### Sequencing Rules

```
RULE 1: Functional tests FIRST → Load/Perf tests SECOND
RULE 2: Backend-tester BEFORE Perf-tester
RULE 3: DB-tester PARALLEL with Backend-tester (same project)
RULE 4: API-doc-tester BEFORE Backend-tester (when spec exists)
RULE 5: Bug fixes → Re-test → THEN move to next skill
RULE 6: ALWAYS end with QA_REPORT.md
```

---

## Step 4 — EXECUTE

For each activated sub-skill:

1. READ the sub-skill's SKILL.md
2. IDENTIFY which sections apply
3. EXECUTE those sections
4. FIX any bugs found (if code is in workspace)
5. RE-TEST fixed areas
6. COLLECT results for the unified report

---

## Step 5 — MERGE

After all sub-skills complete, merge their results into ONE QA_REPORT.md.

### Merging Rules

1. **One executive summary** — aggregated totals from all skills
2. **Per-skill sections** — each skill's findings in its own section
3. **Cross-skill findings** — correlations between skills
4. **Deduplicated bugs** — same bug found by multiple skills appears once
5. **Unified severity scale** — all findings use the same severity levels

---

## Step 6 — REPORT

Generate the final QA_REPORT.md using the template from `../references/qa-report-template.md`.

---

## Error Handling

| Situation | Action |
|-----------|--------|
| Sub-skill SKILL.md not found | Report which skill is missing, proceed with available skills |
| Tests fail with 500 errors | Stop load testing — API is broken, fix first |
| No database file found | Skip db-tester, note in report |
| No WebSocket/SSE endpoints | Skip websocket-tester, note in report |
| No OpenAPI spec provided | Skip api-doc-tester, note in report |
| All tests pass but perf is bad | Mark as READY WITH WARNINGS |
| Critical bugs found | Mark as NOT READY, stop perf testing, report bugs |

---

## Quick Routing Cheat Sheet

```
"test project"         → Pipeline A (Full Project QA)
"test API url"         → Pipeline B (API URL Full Test)
"test from spec"       → Pipeline C (Spec-Driven)
"test GraphQL"         → Pipeline D (GraphQL Full Test)
"test WebSocket"       → Pipeline E (Real-Time Full Test)
"audit database"       → Pipeline F (DB Deep Audit)
"security test"        → Pipeline G (Security-First)
"unit tests only"      → backend-tester Section 2 only
"profile functions"    → backend-tester Section 8 only
"load test"            → perf-tester only
"check indexes"        → db-tester Section 3 only
"validate spec"        → api-doc-tester Step 3 only
"test SSE"             → websocket-tester Section 3 only
"test everything"      → Pipeline A + B + C (everything that applies)
```
