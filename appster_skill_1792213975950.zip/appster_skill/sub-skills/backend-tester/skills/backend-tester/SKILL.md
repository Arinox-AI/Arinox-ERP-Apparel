---
name: backend-tester-core
description: >
  Comprehensive backend testing — unit testing, integration testing, REST API testing,
  GraphQL testing, Express.js endpoint testing, Selenium/browser testing, execution time
  profiling, distributed tracing, security testing, load testing, test data management,
  and full QA reporting. 13 sections covering all backend testing scenarios.
  Trigger when user mentions: test project, pytest, unit test, REST API, GraphQL,
  Express, integration, Selenium, profile, trace, security, load test, test data.
---

# Backend Tester — Core Testing Sub-Skill

Comprehensive backend testing with 13 sections covering all testing scenarios.

## When to Use

- Test a Python/SQLite project in artifacts/
- Test an API by URL
- Test a GraphQL API
- Test an Express.js backend
- Write unit tests or integration tests
- Profile execution time
- Run security checks
- Basic load testing

## References

| File | Load When |
|---|---|
| `../references/decision-logic.md` | **Always** |
| `../references/test-patterns.md` | **Always** |
| `../references/qa-report-template.md` | **Always** |
| `../references/tools-guide.md` | When setting up tools |

## Testing Modes

| Mode | When to Use | Test Type |
|------|-------------|-----------|
| **Project Testing** | User gives a project in `artifacts/` directory | CLI testing of functions.py |
| **API URL Testing** | User gives an HTTP URL to test | requests-based endpoint testing |
| **GraphQL Testing** | User wants to test a GraphQL API | Query/mutation validation |
| **Express.js Testing** | User has a Node/Express backend | Route/middleware testing |
| **Full QA Suite** | User says "test everything" | All applicable modes combined |

---

## Section 1 — Project Testing (Python/SQLite)

Test a project's `functions.py` by calling every function via CLI and validating the results.

### Step 1.1 — Locate Project

```bash
pwd  # → get base path
ls artifacts/  # → list available projects
# PROJECT_DIR = {pwd_output}/artifacts/{project-name}
```

### Step 1.2 — Read document.md

```bash
cat {PROJECT_DIR}/backend/document.md
```

Extract: all function names, parameter signatures, return shapes.

### Step 1.3 — CLI Test Every Function

For each function in document.md:

```bash
cd {PROJECT_DIR}/backend

# Initialize DB
python database.py

# Test each function
python functions.py <function_name> '<json_params>'
```

**Testing strategy per function type:**

| Function Type | Test Approach |
|---------------|---------------|
| `get_*` (list) | Call with empty params, then with search_query, verify pagination (limit/offset) |
| `get_*` (single) | Call with valid ID, then with non-existent ID → expect `{"error": "..."}` |
| `create_*` | Create with all required fields, verify returned dict has `id` and all fields |
| `update_*` | Create first, then update each field individually, verify changes persisted |
| `delete_*` | Create first, delete, then try to get → expect `{"error": "..."}` |
| `*_tool` (proxy) | Call with AGENT_ID + JWT env vars, verify tool response shape |
| `file_*` | Create test file in /tmp/, call with file_path, verify output |

### Step 1.4 — Edge Case Testing

```bash
# Empty string inputs
python functions.py create_item '{"name":""}'

# Missing required fields
python functions.py create_item '{}'

# Very long strings
python functions.py create_item '{"name":"aaaaaaaaaa...500chars..."}'

# Special characters
python functions.py create_item '{"name":"test<>script&\"quotes"}'

# Negative IDs
python functions.py get_item '{"item_id":-1}'

# Zero limit/offset
python functions.py get_items '{"limit":0,"offset":0}'
```

### Step 1.5 — Validate Return Shapes

Every function must return a JSON-serializable dict. Check:

- ✅ No ORM objects leaked (must be dicts via `to_dict()`)
- ✅ No datetime objects (must be `.isoformat()` strings)
- ✅ Error responses follow `{"error": "message"}` format
- ✅ List returns include `total`, `total_count`, `offset`, `limit`
- ✅ `created_at` and `updated_at` are ISO strings

---

## Section 2 — Unit Testing with pytest

For projects that benefit from a proper test suite, generate `test_functions.py` using pytest.

### Template

```python
"""Unit tests for {project_name} backend."""

import pytest
import json
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from database import get_session, init_db
from functions import FUNCTIONS, call_function


@pytest.fixture(scope="session")
def db():
    """Create a fresh test database."""
    init_db()
    session = get_session()
    yield session
    session.close()


@pytest.fixture(autouse=True)
def cleanup(db):
    """Rollback after each test to keep DB clean."""
    yield
    db.rollback()


class TestGetEntities:
    def test_get_all(self, db):
        result = call_function("get_items", db)
        assert "items" in result
        assert isinstance(result["items"], list)

    def test_get_with_search(self, db):
        result = call_function("get_items", db, search_query="test")
        assert "items" in result

    def test_pagination(self, db):
        result = call_function("get_items", db, limit=5, offset=0)
        assert result["limit"] == 5
        assert result["offset"] == 0


class TestCreateEntity:
    def test_create_with_all_fields(self, db):
        result = call_function("create_item", db, name="Test Item")
        assert "id" in result
        assert result["name"] == "Test Item"

    def test_create_missing_required(self, db):
        with pytest.raises(TypeError):
            call_function("create_item", db)


class TestUpdateEntity:
    def test_update_existing(self, db):
        created = call_function("create_item", db, name="Original")
        updated = call_function("update_item", db, item_id=created["id"], name="Updated")
        assert updated["name"] == "Updated"

    def test_update_nonexistent(self, db):
        result = call_function("update_item", db, item_id=99999, name="Ghost")
        assert "error" in result


class TestDeleteEntity:
    def test_delete_existing(self, db):
        created = call_function("create_item", db, name="ToDelete")
        result = call_function("delete_item", db, item_id=created["id"])
        assert result.get("deleted") is True

    def test_delete_nonexistent(self, db):
        result = call_function("delete_item", db, item_id=99999)
        assert "error" in result


class TestEdgeCases:
    def test_empty_string_input(self, db):
        result = call_function("create_item", db, name="")
        assert isinstance(result, dict)

    def test_special_characters(self, db):
        result = call_function("create_item", db, name='<script>alert("xss")</script>')
        assert isinstance(result, dict)

    def test_very_long_input(self, db):
        result = call_function("create_item", db, name="A" * 1000)
        assert isinstance(result, dict)
```

### Running the Suite

```bash
cd {PROJECT_DIR}/backend
pip install pytest -q
python -m pytest test_functions.py -v --tb=short 2>&1
```

---

## Section 3 — REST API Endpoint Testing

Test any REST API by URL — validate HTTP methods, status codes, headers, and response bodies.

### Step 3.1 — Generate API Test Suite

```python
"""REST API tests for {api_name}."""

import requests
import pytest
import json

BASE_URL = "{api_base_url}"
HEADERS = {"Content-Type": "application/json"}
TIMEOUT = 30


class TestHealthCheck:
    def test_health_endpoint(self):
        resp = requests.get(f"{BASE_URL}/health", timeout=TIMEOUT)
        assert resp.status_code == 200

    def test_ping(self):
        resp = requests.get(f"{BASE_URL}/ping", timeout=TIMEOUT)
        assert resp.status_code == 200


class TestCRUDEndpoints:
    RESOURCE = "{resource_path}"
    SAMPLE_CREATE = {"name": "Test Item", "description": "Created by test suite"}
    SAMPLE_UPDATE = {"name": "Updated Item"}

    def test_list_resources(self):
        resp = requests.get(f"{BASE_URL}{self.RESOURCE}", headers=HEADERS, timeout=TIMEOUT)
        assert resp.status_code == 200
        data = resp.json()
        assert isinstance(data, (list, dict))

    def test_create_resource(self):
        resp = requests.post(f"{BASE_URL}{self.RESOURCE}", json=self.SAMPLE_CREATE, headers=HEADERS, timeout=TIMEOUT)
        assert resp.status_code in (200, 201)
        data = resp.json()
        assert "id" in data or "error" not in data
        self.__class__.created_id = data.get("id")

    def test_get_resource(self):
        if not hasattr(self.__class__, "created_id"):
            pytest.skip("No resource created yet")
        resp = requests.get(f"{BASE_URL}{self.RESOURCE}/{self.__class__.created_id}", headers=HEADERS, timeout=TIMEOUT)
        assert resp.status_code == 200

    def test_update_resource(self):
        if not hasattr(self.__class__, "created_id"):
            pytest.skip("No resource created yet")
        resp = requests.put(f"{BASE_URL}{self.RESOURCE}/{self.__class__.created_id}", json=self.SAMPLE_UPDATE, headers=HEADERS, timeout=TIMEOUT)
        assert resp.status_code in (200, 204)

    def test_delete_resource(self):
        if not hasattr(self.__class__, "created_id"):
            pytest.skip("No resource created yet")
        resp = requests.delete(f"{BASE_URL}{self.RESOURCE}/{self.__class__.created_id}", headers=HEADERS, timeout=TIMEOUT)
        assert resp.status_code in (200, 204)

    def test_get_nonexistent(self):
        resp = requests.get(f"{BASE_URL}{self.RESOURCE}/99999", headers=HEADERS, timeout=TIMEOUT)
        assert resp.status_code in (404, 400)

    def test_create_missing_fields(self):
        resp = requests.post(f"{BASE_URL}{self.RESOURCE}", json={}, headers=HEADERS, timeout=TIMEOUT)
        assert resp.status_code in (400, 422)


class TestResponseStatusCodes:
    def test_200_ok(self):
        resp = requests.get(f"{BASE_URL}/", timeout=TIMEOUT)
        assert resp.status_code < 400

    def test_404_not_found(self):
        resp = requests.get(f"{BASE_URL}/nonexistent_route_12345", timeout=TIMEOUT)
        assert resp.status_code == 404


class TestEdgeCases:
    def test_empty_body_post(self):
        resp = requests.post(f"{BASE_URL}/", data="", headers=HEADERS, timeout=TIMEOUT)
        assert resp.status_code in (200, 201, 400, 422)

    def test_invalid_json_post(self):
        resp = requests.post(f"{BASE_URL}/", data="not json{", headers={"Content-Type": "application/json"}, timeout=TIMEOUT)
        assert resp.status_code in (400, 422)

    def test_large_payload(self):
        big_data = {"name": "A" * 10000}
        resp = requests.post(f"{BASE_URL}/", json=big_data, headers=HEADERS, timeout=TIMEOUT)
        assert resp.status_code < 500

    def test_sql_injection(self):
        injection = {"name": "'; DROP TABLE items; --"}
        resp = requests.post(f"{BASE_URL}/", json=injection, headers=HEADERS, timeout=TIMEOUT)
        assert resp.status_code < 500

    def test_xss_payload(self):
        xss = {"name": '<script>alert("xss")</script>'}
        resp = requests.post(f"{BASE_URL}/", json=xss, headers=HEADERS, timeout=TIMEOUT)
        assert resp.status_code < 500

    def test_concurrent_requests(self):
        import concurrent.futures
        results = []
        with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
            futures = [executor.submit(requests.get, f"{BASE_URL}/", timeout=TIMEOUT) for _ in range(20)]
            for f in concurrent.futures.as_completed(futures):
                try:
                    results.append(f.result().status_code)
                except Exception as e:
                    results.append(str(e))
        for r in results:
            if isinstance(r, int):
                assert r < 500
```

---

## Section 4 — GraphQL API Testing

Test GraphQL APIs — introspection, query validation, mutation testing.

### Step 4.1 — Schema Introspection

```python
"""GraphQL API testing utilities."""

import requests
import json

GQL_URL = "{graphql_url}"
HEADERS = {"Content-Type": "application/json"}


def gql_query(query: str, variables: dict = None) -> dict:
    payload = {"query": query}
    if variables:
        payload["variables"] = variables
    resp = requests.post(GQL_URL, json=payload, headers=HEADERS, timeout=30)
    return resp.json()


def introspect_schema() -> dict:
    INTROSPECTION_QUERY = """
    {
      __schema {
        queryType { name }
        mutationType { name }
        types {
          name
          kind
          fields {
            name
            type { name kind ofType { name kind } }
          }
        }
      }
    }
    """
    return gql_query(INTROSPECTION_QUERY)


def list_queries() -> list:
    result = introspect_schema()
    types = result.get("data", {}).get("__schema", {}).get("types", [])
    for t in types:
        if t.get("name") == "Query":
            return [f["name"] for f in (t.get("fields") or [])]
    return []


def list_mutations() -> list:
    result = introspect_schema()
    types = result.get("data", {}).get("__schema", {}).get("types", [])
    for t in types:
        if t.get("name") == "Mutation":
            return [f["name"] for f in (t.get("fields") or [])]
    return []
```

### Step 4.2 — Query Validation Tests

```python
class TestGraphQLBasics:
    def test_introspection(self):
        result = introspect_schema()
        assert "data" in result
        assert "__schema" in result["data"]

    def test_has_query_type(self):
        queries = list_queries()
        assert len(queries) > 0

    def test_invalid_query(self):
        result = gql_query("{ nonExistentField12345 }")
        assert "errors" in result

    def test_empty_query(self):
        result = gql_query("")
        assert "errors" in result

    def test_malformed_query(self):
        result = gql_query("{ broken query }")
        assert "errors" in result
```

### Step 4.3 — KOGO Platform GraphQL Testing

```
Gateway: https://uatos.kogo.ai/api/v1/gateway
Required headers:
  x-introspection-secret: -kogo@2026@123
  Authorization: Bearer <jwt>
```

> ⚠️ **NEVER delete anything on the KOGO API.** Only test read operations (queries).

---

## Section 5 — Express.js / Node.js Backend Testing

```javascript
const request = require('supertest');
const app = require('../app');

describe('Route Tests', () => {
  it('should return 200 on GET /', async () => {
    const res = await request(app).get('/');
    expect(res.status).toBe(200);
  });

  it('should create an item', async () => {
    const res = await request(app).post('/api/items').send({ name: 'Test' });
    expect(res.status).toBe(201);
  });

  it('should return 404 for unknown routes', async () => {
    const res = await request(app).get('/api/nonexistent12345');
    expect(res.status).toBe(404);
  });
});
```

```bash
npm install --save-dev jest supertest && npx jest --verbose
```

---

## Section 6 — Integration Testing

```python
"""Integration tests — DB + Functions together."""

import pytest
from database import get_session, init_db
from functions import call_function

@pytest.fixture(scope="module")
def db():
    init_db()
    session = get_session()
    yield session
    session.close()

class TestDatabaseIntegration:
    def test_create_and_read(self, db):
        result = call_function("create_item", db, name="Integration Test")
        item_id = result["id"]
        item = call_function("get_item", db, item_id=item_id)
        assert item["name"] == "Integration Test"

    def test_transaction_rollback(self, db):
        initial = call_function("get_items", db)["total_count"]
        try:
            call_function("create_item", db)  # Missing required fields
        except:
            pass
        db.rollback()
        final = call_function("get_items", db)["total_count"]
        assert initial == final
```

---

## Section 7 — Selenium / Browser Testing

```python
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from webdriver_manager.chrome import ChromeDriverManager

def get_driver():
    options = Options()
    options.add_argument("--headless")
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    return webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)

class TestBrowserRendering:
    def test_page_loads(self):
        driver = get_driver()
        try:
            driver.get("{url}")
            assert driver.title != ""
        finally:
            driver.quit()
```

---

## Section 8 — Execution Time Profiling

```python
import time, statistics
from database import get_session, init_db
from functions import FUNCTIONS, call_function

def profile_function(name: str, params: dict, runs: int = 10) -> dict:
    init_db()
    times = []
    for _ in range(runs):
        db = get_session()
        try:
            start = time.perf_counter()
            result = call_function(name, db, **params)
            times.append(time.perf_counter() - start)
        finally:
            db.close()
    return {
        "function": name,
        "mean_ms": round(statistics.mean(times) * 1000, 2),
        "p95_ms": round(sorted(times)[int(len(times) * 0.95)] * 1000, 2),
        "min_ms": round(min(times) * 1000, 2),
        "max_ms": round(max(times) * 1000, 2),
    }
```

| Category | Threshold | Action |
|----------|-----------|--------|
| 🟢 Fast | < 100ms | No action |
| 🟡 Moderate | 100–500ms | Note in report |
| 🟠 Slow | 500ms–1s | Recommend optimization |
| 🔴 Very Slow | > 1s | Critical — investigate |

---

## Section 9 — Distributed Tracing

```python
import requests, uuid, time

def trace_request(url: str, method: str = "GET", body: dict = None) -> dict:
    trace_id = str(uuid.uuid4())
    headers = {"X-Trace-ID": trace_id, "X-Request-Source": "backend-tester"}
    start = time.perf_counter()
    resp = requests.request(method, url, json=body, headers=headers, timeout=30)
    elapsed = time.perf_counter() - start
    return {
        "trace_id": trace_id,
        "status_code": resp.status_code,
        "elapsed_ms": round(elapsed * 1000, 2),
        "response_size_bytes": len(resp.content),
    }

def trace_chain(base_url: str, chain: list) -> list:
    results = []
    for i, step in enumerate(chain):
        result = trace_request(f"{base_url}{step['path']}", step.get("method", "GET"), step.get("body"))
        result["step"] = i + 1
        results.append(result)
    return results
```

---

## Section 10 — Security Testing

```python
import requests

BASE_URL = "{api_base_url}"
HEADERS = {"Content-Type": "application/json"}

class TestSecurity:
    def test_sql_injection(self):
        payloads = ["' OR '1'='1", "'; DROP TABLE users; --", "1 UNION SELECT * FROM users--"]
        for p in payloads:
            resp = requests.post(f"{BASE_URL}/api/items", json={"name": p}, headers=HEADERS, timeout=30)
            assert resp.status_code < 500

    def test_auth_required(self):
        resp = requests.get(f"{BASE_URL}/api/protected", timeout=30)
        assert resp.status_code in (401, 403)

    def test_https_enforcement(self):
        if BASE_URL.startswith("https://"):
            http_url = BASE_URL.replace("https://", "http://")
            try:
                resp = requests.get(http_url, timeout=10, allow_redirects=False)
                assert resp.status_code in (301, 302, 308)
            except requests.ConnectionError:
                pass  # Good — HTTP rejected
```

---

## Section 11 — Load Testing

```python
import requests, concurrent.futures, time, statistics
from collections import Counter

def load_test(url: str, concurrency: int = 10, total_requests: int = 100) -> dict:
    results = {"status_codes": Counter(), "response_times": [], "errors": []}
    def make_request(i):
        start = time.perf_counter()
        try:
            resp = requests.get(url, timeout=30)
            return {"status": resp.status_code, "time": time.perf_counter() - start}
        except Exception as e:
            return {"status": 0, "time": time.perf_counter() - start, "error": str(e)}

    start_time = time.perf_counter()
    with concurrent.futures.ThreadPoolExecutor(max_workers=concurrency) as executor:
        for f in concurrent.futures.as_completed([executor.submit(make_request, i) for i in range(total_requests)]):
            r = f.result()
            results["status_codes"][r["status"]] += 1
            results["response_times"].append(r["time"])
            if "error" in r:
                results["errors"].append(r["error"])

    total_time = time.perf_counter() - start_time
    times = results["response_times"]
    return {
        "total_time_s": round(total_time, 2),
        "rps": round(total_requests / total_time, 2),
        "mean_ms": round(statistics.mean(times) * 1000, 2) if times else 0,
        "p95_ms": round(sorted(times)[int(len(times) * 0.95)] * 1000, 2) if times else 0,
        "error_rate": f"{len(results['errors'])}/{total_requests}",
    }
```

---

## Section 12 — Test Data Management

```python
from database import get_session, init_db
from functions import call_function

def seed_test_data() -> dict:
    init_db()
    db = get_session()
    created_ids = []
    test_items = [
        {"name": "Test Item 1", "description": "Standard fixture"},
        {"name": "Test Item 2", "description": "Another fixture"},
        {"name": "", "description": "Empty name fixture"},
        {"name": "A" * 500, "description": "Max length fixture"},
    ]
    for item in test_items:
        try:
            result = call_function("create_item", db, **item)
            if "id" in result:
                created_ids.append(result["id"])
        except:
            db.rollback()
    db.commit()
    db.close()
    return {"created_ids": created_ids, "count": len(created_ids)}

def cleanup_test_data(ids: list):
    db = get_session()
    for item_id in ids:
        try:
            call_function("delete_item", db, item_id=item_id)
        except:
            db.rollback()
    db.commit()
    db.close()
```

---

## Section 13 — QA Report Generation

**Every testing session must end with a QA_REPORT.md.** No exceptions.

Use the unified template from `../references/qa-report-template.md`.

### Minimal Report Structure

```markdown
# QA Report — {project_name}

**Date:** {date}
**Tester:** Backend Tester Agent
**Project:** {project_slug}

---

## Executive Summary

- **Total Functions Tested:** {total}
- **Passed:** {passed} ✅
- **Failed:** {failed} ❌
- **Bugs Found:** {bugs}
- **Bugs Fixed:** {fixed}
- **Overall Status:** {READY|NOT_READY}

---

## Function Test Results

| Function | Status | Response Time | Notes |
|----------|--------|---------------|-------|

---

## Bugs Found & Fixed

(list if any)

---

## Final Status: {READY|NOT_READY}
```

---

## Quick Reference — Decision Table

| User Request | Section | Action |
|--------------|---------|--------|
| "Test my project" | Section 1 | CLI test all functions |
| "Write unit tests" / "pytest" | Section 2 | Generate test_functions.py |
| "Test this API: https://..." | Section 3 | Generate API test suite |
| "Test GraphQL API" | Section 4 | Introspect + query validation |
| "Test Express.js" | Section 5 | Generate supertest suite |
| "Integration test" | Section 6 | DB + API together |
| "Selenium" / "Browser test" | Section 7 | Headless browser tests |
| "Profile" / "How fast?" | Section 8 | Execution time profiling |
| "Trace requests" | Section 9 | Distributed tracing |
| "Security test" | Section 10 | Vulnerability checks |
| "Load test" / "Stress test" | Section 11 | Concurrent requests |
| "Test data" / "Fixtures" | Section 12 | Test data management |
| Any testing task | Section 13 | Full QA report |

---

## Bug Fix Protocol

1. **Read the failing file** — understand the code
2. **Identify root cause** — logic error, missing validation, wrong type?
3. **Make minimal fix** — change only what's needed
4. **Re-test** — verify the fix works
5. **Document** — add to "Bugs Found & Fixed" in QA_REPORT.md

**If code is NOT in your workspace** (external API):
- Report failure with request/response details
- Mark as ❌ FAIL in QA report
- Include reproduction steps
