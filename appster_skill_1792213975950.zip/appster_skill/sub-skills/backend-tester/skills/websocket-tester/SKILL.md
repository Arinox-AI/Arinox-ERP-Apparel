---
name: websocket-tester
description: >
  Tests WebSocket and real-time backends — Socket.IO, SSE (Server-Sent Events), and raw
  WebSocket servers. Validates connection handling, message delivery, reconnection,
  concurrency, and latency. Generates test scripts and produces real-time testing reports.
  Trigger when user mentions: WebSocket, ws://, Socket.IO, SSE, Server-Sent Events,
  real-time, socket.
---

# WebSocket Tester — Real-Time Backend Testing

## When to Use

- Test raw WebSocket connections (ws:// or wss://)
- Test Socket.IO servers
- Test SSE (Server-Sent Events) streams
- Validate real-time message delivery, latency, reconnection

## References

| File | Load When |
|---|---|
| `../references/decision-logic.md` | **Always** |
| `../references/test-patterns.md` | **Always** |
| `../references/qa-report-template.md` | **Always** |
| `../references/tools-guide.md` | When installing websockets/python-socketio |

## Protocol Detection

| URL Pattern | Protocol | Library |
|-------------|----------|---------|
| `ws://...` or `wss://...` | Raw WebSocket | `websockets` (Python) |
| `http://.../socket.io/...` | Socket.IO | `python-socketio` |
| `http://...` with `text/event-stream` | SSE | `requests` |

---

## Section 1 — Raw WebSocket Testing

### Install

```bash
pip install websockets pytest pytest-asyncio -q
```

### WebSocket Test Script

```python
"""WebSocket test suite."""

import pytest
import asyncio
import json
import time
import websockets
from websockets.exceptions import ConnectionClosed


WS_URL = "{ws_url}"
TIMEOUT = 30


class TestWebSocketConnection:
    @pytest.mark.asyncio
    async def test_connect(self):
        async with websockets.connect(WS_URL, close_timeout=TIMEOUT) as ws:
            assert ws.open

    @pytest.mark.asyncio
    async def test_connect_invalid_url(self):
        with pytest.raises(Exception):
            async with websockets.connect("ws://localhost:99999/nonexistent") as ws:
                pass

    @pytest.mark.asyncio
    async def test_send_receive(self):
        async with websockets.connect(WS_URL, close_timeout=TIMEOUT) as ws:
            test_msg = json.dumps({"type": "ping", "data": "hello"})
            await ws.send(test_msg)
            response = await asyncio.wait_for(ws.recv(), timeout=10)
            assert response is not None

    @pytest.mark.asyncio
    async def test_close_connection(self):
        ws = await websockets.connect(WS_URL)
        await ws.close()
        assert ws.closed

    @pytest.mark.asyncio
    async def test_multiple_messages(self):
        async with websockets.connect(WS_URL, close_timeout=TIMEOUT) as ws:
            for i in range(5):
                msg = json.dumps({"type": "echo", "data": f"message_{i}"})
                await ws.send(msg)
                response = await asyncio.wait_for(ws.recv(), timeout=10)
                assert response is not None


class TestWebSocketReliability:
    @pytest.mark.asyncio
    async def test_large_message(self):
        async with websockets.connect(WS_URL, close_timeout=TIMEOUT) as ws:
            large_payload = "A" * 10000
            msg = json.dumps({"type": "echo", "data": large_payload})
            await ws.send(msg)
            response = await asyncio.wait_for(ws.recv(), timeout=15)
            assert response is not None

    @pytest.mark.asyncio
    async def test_rapid_messages(self):
        async with websockets.connect(WS_URL, close_timeout=TIMEOUT) as ws:
            for i in range(20):
                await ws.send(json.dumps({"type": "echo", "data": f"rapid_{i}"}))
            responses = []
            for _ in range(20):
                try:
                    resp = await asyncio.wait_for(ws.recv(), timeout=5)
                    responses.append(resp)
                except asyncio.TimeoutError:
                    break
            assert len(responses) > 0

    @pytest.mark.asyncio
    async def test_invalid_json(self):
        async with websockets.connect(WS_URL, close_timeout=TIMEOUT) as ws:
            await ws.send("not valid json{{{")
            await asyncio.sleep(1)
            assert ws.open, "Connection should still be open after invalid JSON"

    @pytest.mark.asyncio
    async def test_reconnection(self):
        ws = await websockets.connect(WS_URL)
        await ws.close()
        ws2 = await websockets.connect(WS_URL)
        assert ws2.open
        await ws2.send(json.dumps({"type": "ping"}))
        response = await asyncio.wait_for(ws2.recv(), timeout=10)
        assert response is not None
        await ws2.close()


class TestWebSocketConcurrency:
    @pytest.mark.asyncio
    async def test_multiple_concurrent_connections(self):
        num_connections = 10
        connections = []
        for _ in range(num_connections):
            ws = await websockets.connect(WS_URL)
            connections.append(ws)
        for i, ws in enumerate(connections):
            await ws.send(json.dumps({"type": "echo", "data": f"conn_{i}"}))
        for i, ws in enumerate(connections):
            try:
                response = await asyncio.wait_for(ws.recv(), timeout=10)
                assert response is not None
            except (asyncio.TimeoutError, ConnectionClosed):
                pass
        for ws in connections:
            await ws.close()


class TestWebSocketLatency:
    @pytest.mark.asyncio
    async def test_echo_latency(self):
        latencies = []
        async with websockets.connect(WS_URL, close_timeout=TIMEOUT) as ws:
            for i in range(20):
                msg = json.dumps({"type": "echo", "data": f"latency_test_{i}"})
                start = time.perf_counter()
                await ws.send(msg)
                response = await asyncio.wait_for(ws.recv(), timeout=10)
                elapsed = time.perf_counter() - start
                latencies.append(elapsed)
        
        import statistics
        latency_ms = [l * 1000 for l in latencies]
        result = {
            "mean_ms": round(statistics.mean(latency_ms), 2),
            "p95_ms": round(sorted(latency_ms)[int(len(latency_ms) * 0.95)], 2),
            "max_ms": round(max(latency_ms), 2),
            "min_ms": round(min(latency_ms), 2),
        }
        assert result["p95_ms"] < 1000
        return result
```

---

## Section 2 — Socket.IO Testing

### Install

```bash
pip install "python-socketio[client]" pytest -q
```

### Socket.IO Test Script

```python
"""Socket.IO test suite."""

import socketio
import pytest
import time
import json

SIO_URL = "{sio_url}"


class TestSocketIOConnection:
    def test_connect(self):
        sio = socketio.SimpleClient()
        sio.connect(SIO_URL)
        assert sio.connected
        sio.disconnect()

    def test_emit_and_receive(self):
        sio = socketio.SimpleClient()
        sio.connect(SIO_URL)
        received = []
        def on_message(data):
            received.append(data)
        sio.on("message", on_message)
        sio.emit("message", {"text": "hello from test"})
        time.sleep(2)
        assert len(received) > 0
        sio.disconnect()

    def test_join_room(self):
        sio = socketio.SimpleClient()
        sio.connect(SIO_URL)
        sio.emit("join", {"room": "test_room"})
        time.sleep(1)
        sio.emit("room_message", {"room": "test_room", "text": "hello room"})
        time.sleep(2)
        sio.disconnect()


class TestSocketIOReconnection:
    def test_reconnect_after_disconnect(self):
        sio = socketio.SimpleClient()
        sio.connect(SIO_URL)
        sio.disconnect()
        sio.connect(SIO_URL)
        assert sio.connected
        sio.disconnect()
```

---

## Section 3 — SSE Testing

```python
"""SSE test suite."""

import requests
import pytest
import json
import time

SSE_URL = "{sse_url}"


class TestSSEConnection:
    def test_sse_stream_connects(self):
        resp = requests.get(SSE_URL, stream=True, timeout=30,
                          headers={"Accept": "text/event-stream"})
        assert resp.status_code == 200
        assert "text/event-stream" in resp.headers.get("Content-Type", "")
        resp.close()

    def test_receive_events(self):
        resp = requests.get(SSE_URL, stream=True, timeout=30,
                          headers={"Accept": "text/event-stream"})
        events = []
        start = time.time()
        for line in resp.iter_lines(decode_unicode=True):
            if line and line.startswith("data:"):
                data = line[5:].strip()
                events.append(data)
                if len(events) >= 5 or (time.time() - start) > 10:
                    break
        resp.close()
        assert len(events) > 0

    def test_event_format(self):
        resp = requests.get(SSE_URL, stream=True, timeout=30,
                          headers={"Accept": "text/event-stream"})
        valid_lines = 0
        for line in resp.iter_lines(decode_unicode=True):
            if not line: continue
            if any(line.startswith(p) for p in ("data:", "event:", "id:", "retry:", ":")):
                valid_lines += 1
            if valid_lines >= 10: break
        resp.close()
        assert valid_lines > 0

    def test_sse_with_last_event_id(self):
        headers = {"Accept": "text/event-stream", "Last-Event-ID": "1"}
        resp = requests.get(SSE_URL, stream=True, headers=headers, timeout=30)
        assert resp.status_code == 200
        resp.close()
```

---

## Section 4 — WebSocket Test Report

```markdown
# WebSocket/Real-Time Test Report — {target}

**Date:** {date}
**Protocol:** WebSocket / Socket.IO / SSE
**Target:** {url}

---

## Connection Tests

| Test | Status | Notes |
|------|--------|-------|

---

## Reliability Tests

| Test | Status | Notes |
|------|--------|-------|

---

## Latency

| Metric | Value |
|--------|-------|
| Min | {min} ms |
| Mean | {mean} ms |
| P95 | {p95} ms |
| Max | {max} ms |

---

## Overall Status: {PASS|FAIL}
```

---

## Decision Table

| User Request | Section | Action |
|--------------|---------|--------|
| "Test WebSocket" / "ws://..." | Section 1 | Raw WebSocket tests |
| "Test Socket.IO" | Section 2 | Socket.IO client tests |
| "Test SSE" / "Server-Sent Events" | Section 3 | SSE stream tests |
| "Real-time latency test" | Section 1 | Measure round-trip time |
| "Concurrent connections test" | Section 1 | Multiple simultaneous connections |
| "Reconnection test" | Section 1 / 2 | Disconnect + reconnect |
