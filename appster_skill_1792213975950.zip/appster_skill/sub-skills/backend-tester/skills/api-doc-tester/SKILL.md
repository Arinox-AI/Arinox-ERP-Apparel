---
name: api-doc-tester
description: >
  Auto-generates backend tests from OpenAPI/Swagger specs. Reads JSON/YAML API docs,
  extracts endpoints, parameters, schemas, and generates complete pytest + requests
  test suites. Also validates that live API matches its documented spec.
  Trigger when user mentions: OpenAPI, Swagger, spec, generate tests from spec,
  validate API vs docs.
---

# API Doc Tester — OpenAPI/Swagger Test Generation

## When to Use

- User provides an OpenAPI/Swagger spec (file or URL)
- User wants to validate an API against its documentation
- User wants tests auto-generated from an API spec

## References

| File | Load When |
|---|---|
| `../references/decision-logic.md` | **Always** |
| `../references/test-patterns.md` | **Always** |
| `../references/qa-report-template.md` | **Always** |
| `../references/tools-guide.md` | When setting up tools |

## Overview

```
OpenAPI Spec (JSON/YAML) or URL
  ↓
[Step 1] Parse spec → extract endpoints, schemas, params
  ↓
[Step 2] Generate pytest test suite
  ↓
[Step 3] Run tests against live API
  ↓
[Step 4] Generate spec-validation report
  ↓
Return results
```

---

## Step 1 — Parse OpenAPI Spec

```python
"""OpenAPI spec parser and test generator."""

import json
import yaml
import os
from typing import Any


def load_spec(source: str) -> dict:
    """Load OpenAPI spec from file path or URL."""
    if source.startswith("http"):
        import requests
        resp = requests.get(source, timeout=30)
        if source.endswith(".yaml") or source.endswith(".yml"):
            return yaml.safe_load(resp.text)
        return resp.json()
    else:
        with open(source, 'r') as f:
            if source.endswith(".yaml") or source.endswith(".yml"):
                return yaml.safe_load(f)
            return json.load(f)


def extract_endpoints(spec: dict) -> list:
    """Extract all endpoints from OpenAPI spec."""
    endpoints = []
    paths = spec.get("paths", {})
    
    for path, methods in paths.items():
        for method, details in methods.items():
            if method.lower() not in ("get", "post", "put", "patch", "delete"):
                continue
            
            params = []
            for p in details.get("parameters", []):
                params.append({
                    "name": p.get("name"),
                    "in": p.get("in"),
                    "required": p.get("required", False),
                    "schema": p.get("schema", {}),
                    "description": p.get("description", ""),
                })
            
            request_body = None
            rb = details.get("requestBody")
            if rb:
                content = rb.get("content", {})
                for ct, schema_info in content.items():
                    request_body = {
                        "content_type": ct,
                        "schema": schema_info.get("schema", {}),
                        "required": rb.get("required", False),
                    }
            
            responses = {}
            for code, resp_details in details.get("responses", {}).items():
                responses[code] = {
                    "description": resp_details.get("description", ""),
                    "schema": resp_details.get("content", {}).get("application/json", {}).get("schema", {}),
                }
            
            security = details.get("security", [])
            
            endpoints.append({
                "path": path,
                "method": method.upper(),
                "operation_id": details.get("operationId", f"{method}_{path.replace('/', '_').strip('_')}"),
                "summary": details.get("summary", ""),
                "tags": details.get("tags", []),
                "parameters": params,
                "request_body": request_body,
                "responses": responses,
                "security": security,
                "deprecated": details.get("deprecated", False),
            })
    
    return endpoints


def extract_schemas(spec: dict) -> dict:
    """Extract all schema definitions from components."""
    schemas = {}
    components = spec.get("components", {}).get("schemas", {})
    definitions = spec.get("definitions", {})
    
    all_defs = {**components, **definitions}
    
    for name, schema in all_defs.items():
        properties = schema.get("properties", {})
        required = schema.get("required", [])
        
        fields = {}
        for prop_name, prop_schema in properties.items():
            fields[prop_name] = {
                "type": prop_schema.get("type", "any"),
                "format": prop_schema.get("format", ""),
                "required": prop_name in required,
                "default": prop_schema.get("default"),
                "enum": prop_schema.get("enum", []),
                "description": prop_schema.get("description", ""),
                "example": prop_schema.get("example"),
            }
        
        schemas[name] = {"fields": fields, "required": required}
    
    return schemas


def generate_example(schema: dict, schemas: dict = None) -> dict:
    """Generate example data from a schema definition."""
    example = {}
    properties = schema.get("properties", {})
    required = schema.get("required", [])
    
    type_defaults = {
        "string": "test_string", "integer": 1, "number": 1.0,
        "boolean": True, "array": [], "object": {},
    }
    
    for prop_name, prop_schema in properties.items():
        if prop_name not in required:
            continue
        prop_type = prop_schema.get("type", "string")
        if prop_schema.get("enum"):
            example[prop_name] = prop_schema["enum"][0]
        elif prop_schema.get("format") == "email":
            example[prop_name] = "test@example.com"
        elif prop_schema.get("format") == "date":
            example[prop_name] = "2026-01-01"
        elif prop_schema.get("format") == "date-time":
            example[prop_name] = "2026-01-01T00:00:00Z"
        elif prop_schema.get("format") == "uri":
            example[prop_name] = "https://example.com"
        elif prop_schema.get("example"):
            example[prop_name] = prop_schema["example"]
        elif "$ref" in prop_schema:
            ref_name = prop_schema["$ref"].split("/")[-1]
            if schemas and ref_name in schemas:
                example[prop_name] = generate_example(schemas[ref_name], schemas)
            else:
                example[prop_name] = {}
        else:
            example[prop_name] = type_defaults.get(prop_type, "test")
    
    return example
```

---

## Step 2 — Generate Test Suite

```python
def generate_test_suite(spec: dict, base_url: str) -> str:
    """Generate a complete pytest test suite from an OpenAPI spec."""
    
    endpoints = extract_endpoints(spec)
    schemas = extract_schemas(spec)
    spec_info = spec.get("info", {})
    api_title = spec_info.get("title", "API")
    
    lines = [
        f'"""Auto-generated tests from {api_title} OpenAPI spec."""',
        '', 'import pytest', 'import requests', 'import json',
        'from typing import Any', '',
        f'BASE_URL = "{base_url}"',
        'HEADERS = {"Content-Type": "application/json"}',
        'TIMEOUT = 30', '',
    ]
    
    has_security = any(ep["security"] for ep in endpoints)
    if has_security:
        lines.extend([
            '@pytest.fixture(scope="session")',
            'def auth_headers():',
            '    """Provide authenticated headers. Override with real credentials."""',
            '    return {**HEADERS, "Authorization": "Bearer YOUR_TOKEN_HERE"}',
            '',
        ])
    
    for ep in endpoints:
        method = ep["method"]
        path = ep["path"]
        op_id = ep["operation_id"]
        
        lines.append(f'class Test{op_id.capitalize()}:')
        lines.append(f'    """Test {method} {path} — {ep["summary"]}"""')
        lines.append('')
        
        success_code = next((c for c in ep["responses"] if c.startswith("2")), "200")
        lines.append(f'    def test_success(self):')
        
        test_path = path
        path_params = [p for p in ep["parameters"] if p["in"] == "path"]
        for pp in path_params:
            test_path = test_path.replace(f"{{{pp['name']}}}", "1")
        
        url = f"{BASE_URL}{test_path}"
        headers_var = "auth_headers" if ep["security"] else "HEADERS"
        
        query_params = [p for p in ep["parameters"] if p["in"] == "query"]
        if query_params:
            query_str = "&".join(f'{p["name"]}=test' for p in query_params if p["required"])
            lines.append(f'        resp = requests.{method.lower()}(f"{url}?{query_str}", headers={headers_var}, timeout=TIMEOUT)')
        else:
            lines.append(f'        resp = requests.{method.lower()}("{url}", headers={headers_var}, timeout=TIMEOUT)')
        
        lines.append(f'        assert resp.status_code == {success_code}, f"Expected {success_code}, got {{resp.status_code}}"')
        lines.append('')
        
        if method == "GET" and path_params:
            not_found_code = next((c for c in ep["responses"] if c.startswith("4") and c != "422"), "404")
            not_found_path = path
            for pp in path_params:
                not_found_path = not_found_path.replace(f"{{{pp['name']}}}", "99999")
            lines.append(f'    def test_not_found(self):')
            lines.append(f'        resp = requests.{method.lower()}(f"{BASE_URL}{not_found_path}", headers={headers_var}, timeout=TIMEOUT)')
            lines.append(f'        assert resp.status_code == {not_found_code}')
            lines.append('')
        
        if ep["request_body"] and method in ("POST", "PUT", "PATCH"):
            lines.append(f'    def test_validation_error(self):')
            lines.append(f'        resp = requests.{method.lower()}("{url}", json={{}}, headers={headers_var}, timeout=TIMEOUT)')
            lines.append(f'        assert resp.status_code in (400, 422), f"Expected 400/422, got {{resp.status_code}}"')
            lines.append('')
        
        if ep["deprecated"]:
            lines.append(f'    # ⚠️ DEPRECATED endpoint')
            lines.append('')
    
    return '\n'.join(lines)
```

---

## Step 3 — Spec Validation (Live API vs Documentation)

```python
def validate_api_matches_spec(spec: dict, base_url: str) -> list:
    """Compare live API responses against OpenAPI spec. Returns list of discrepancies."""
    
    endpoints = extract_endpoints(spec)
    schemas = extract_schemas(spec)
    discrepancies = []
    
    for ep in endpoints:
        method = ep["method"]
        path = ep["path"]
        
        if method != "GET":
            continue
        
        test_path = path
        for p in ep["parameters"]:
            if p["in"] == "path":
                test_path = test_path.replace(f"{{{p['name']}}}", "1")
        
        try:
            resp = requests.get(f"{BASE_URL}{test_path}", headers=HEADERS, timeout=TIMEOUT)
        except Exception as e:
            discrepancies.append({"endpoint": f"{method} {path}", "issue": "Connection error", "detail": str(e)})
            continue
        
        expected_codes = list(ep["responses"].keys())
        if str(resp.status_code) not in expected_codes:
            discrepancies.append({"endpoint": f"{method} {path}", "issue": "Unexpected status code", "expected": expected_codes, "actual": resp.status_code})
        
        success_schema = None
        for code, resp_info in ep["responses"].items():
            if code.startswith("2") and resp_info.get("schema"):
                success_schema = resp_info["schema"]
                break
        
        if success_schema and 200 <= resp.status_code < 300:
            try:
                body = resp.json()
                schema_issues = validate_response_schema(body, success_schema, schemas)
                for issue in schema_issues:
                    discrepancies.append({"endpoint": f"{method} {path}", "issue": f"Schema mismatch: {issue}"})
            except json.JSONDecodeError:
                if "application/json" in str(ep["responses"].get(str(resp.status_code), {})):
                    discrepancies.append({"endpoint": f"{method} {path}", "issue": "Expected JSON but got non-JSON response"})
    
    return discrepancies


def validate_response_schema(data: Any, schema: dict, schemas: dict) -> list:
    """Validate response data against its schema."""
    issues = []
    
    if "$ref" in schema:
        ref_name = schema["$ref"].split("/")[-1]
        if ref_name in schemas:
            schema = schemas[ref_name]
        else:
            return [f"Unknown schema ref: {ref_name}"]
    
    schema_type = schema.get("type", "object")
    
    if schema_type == "object":
        if not isinstance(data, dict):
            issues.append(f"Expected object, got {type(data).__name__}")
        else:
            properties = schema.get("properties", {})
            required = schema.get("required", [])
            for field in required:
                if field not in data:
                    issues.append(f"Missing required field: {field}")
            for field, field_schema in properties.items():
                if field in data:
                    expected_type = field_schema.get("type")
                    actual_value = data[field]
                    type_map = {"string": str, "integer": int, "number": (int, float), "boolean": bool, "array": list, "object": dict}
                    if expected_type in type_map:
                        if not isinstance(actual_value, type_map[expected_type]):
                            issues.append(f"Field '{field}': expected {expected_type}, got {type(actual_value).__name__}")
    
    elif schema_type == "array":
        if not isinstance(data, list):
            issues.append(f"Expected array, got {type(data).__name__}")
        items_schema = schema.get("items", {})
        if items_schema and data:
            for i, item in enumerate(data[:5]):
                item_issues = validate_response_schema(item, items_schema, schemas)
                for issue in item_issues:
                    issues.append(f"Item [{i}]: {issue}")
    
    return issues
```

---

## Step 4 — Run and Report

```bash
# Generate tests
python -c "
from api_doc_tester import load_spec, generate_test_suite
spec = load_spec('openapi.json')
suite = generate_test_suite(spec, 'https://api.example.com')
with open('test_api_spec.py', 'w') as f:
    f.write(suite)
print(f'Generated {suite.count(\"def test_\")} test functions')
"

# Run
pip install pytest pyyaml -q
python -m pytest test_api_spec.py -v --tb=short 2>&1

# Validate spec vs live
python -c "
from api_doc_tester import load_spec, validate_api_matches_spec
spec = load_spec('openapi.json')
discrepancies = validate_api_matches_spec(spec, 'https://api.example.com')
for d in discrepancies:
    print(f'❌ {d[\"endpoint\"]}: {d[\"issue\"]}')
if not discrepancies:
    print('✅ All endpoints match spec')
"
```

---

## Decision Table

| User Request | Action |
|--------------|--------|
| "Test this API spec" / "OpenAPI test" | Parse spec → generate tests → run |
| "Validate API against its docs" | Parse spec → compare live responses → report discrepancies |
| "Generate tests from Swagger" | Same as OpenAPI — both are supported |
| "Check if API matches spec" | Spec validation (Step 3) |
| "Generate example data from schema" | Use `generate_example()` |
