---
name: db-tester
description: >
  Deep database testing — schema validation, data integrity checks, index analysis,
  query optimization, migration safety testing. For SQLite and SQLAlchemy databases.
  Trigger when user mentions: DB schema, data integrity, orphan records, index analysis,
  slow query, migration safety, database audit.
---

# DB Tester — Deep Database Testing

## When to Use

- Validate a database schema
- Check data integrity (NULLs, orphans, duplicates)
- Analyze index coverage
- Optimize slow queries
- Test migration safety

## References

| File | Load When |
|---|---|
| `../references/decision-logic.md` | **Always** |
| `../references/qa-report-template.md` | **Always** |
| `../references/tools-guide.md` | When using SQLite CLI |

## Overview

```
Database (SQLite file or SQLAlchemy models)
  ↓
[Section 1] Schema validation
  ↓
[Section 2] Data integrity
  ↓
[Section 3] Index analysis
  ↓
[Section 4] Query optimization
  ↓
[Section 5] Migration safety
  ↓
[Section 6] Generate DB_TEST_REPORT.md
```

---

## Section 1 — Schema Validation

```python
"""Database schema inspector and validator."""

import sqlite3
import json
from pathlib import Path
from typing import Optional


def inspect_sqlite_db(db_path: str) -> dict:
    """Full inspection of a SQLite database."""
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")
    tables = [row["name"] for row in cursor.fetchall()]
    
    result = {"database": db_path, "tables": {}}
    
    for table in tables:
        cursor.execute(f"PRAGMA table_info({table})")
        columns = [{"cid": r["cid"], "name": r["name"], "type": r["type"],
                     "notnull": r["notnull"], "default": r["dflt_value"], "pk": r["pk"]} 
                    for r in cursor.fetchall()]
        
        cursor.execute(f"PRAGMA index_list({table})")
        indexes = [{"name": r["name"], "unique": r["unique"], "origin": r["origin"]} 
                   for r in cursor.fetchall()]
        
        cursor.execute(f"PRAGMA foreign_key_list({table})")
        foreign_keys = [{"from": r["from"], "table": r["table"], "to": r["to"]} 
                        for r in cursor.fetchall()]
        
        cursor.execute(f"SELECT COUNT(*) as count FROM {table}")
        row_count = cursor.fetchone()["count"]
        
        cursor.execute(f"SELECT sql FROM sqlite_master WHERE type='table' AND name='{table}'")
        create_sql = cursor.fetchone()["sql"]
        
        result["tables"][table] = {
            "columns": columns, "indexes": indexes, "foreign_keys": foreign_keys,
            "row_count": row_count, "create_sql": create_sql,
        }
    
    conn.close()
    return result


def validate_schema(db_path: str) -> list:
    """Validate schema and return list of issues."""
    inspection = inspect_sqlite_db(db_path)
    issues = []
    
    for table_name, table_info in inspection["tables"].items():
        columns = table_info["columns"]
        fks = table_info["foreign_keys"]
        indexes = table_info["indexes"]
        
        # Check 1: Primary key exists
        pk_columns = [c for c in columns if c["pk"]]
        if not pk_columns:
            issues.append({"table": table_name, "severity": "HIGH", "issue": "No primary key defined"})
        
        # Check 2: Auto-increment on integer PK
        if pk_columns and pk_columns[0]["type"].upper() == "INTEGER" and pk_columns[0]["pk"] == 1:
            create_sql = table_info["create_sql"]
            if "AUTOINCREMENT" not in create_sql.upper():
                issues.append({"table": table_name, "severity": "MEDIUM", "issue": "Integer PK without AUTOINCREMENT"})
        
        # Check 3: Timestamps
        col_names = [c["name"] for c in columns]
        if "created_at" not in col_names:
            issues.append({"table": table_name, "severity": "LOW", "issue": "Missing created_at timestamp"})
        if "updated_at" not in col_names:
            issues.append({"table": table_name, "severity": "LOW", "issue": "Missing updated_at timestamp"})
        
        # Check 4: Foreign keys without indexes
        fk_columns = [fk["from"] for fk in fks]
        indexed_columns = []
        for idx in indexes:
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            cursor.execute(f"PRAGMA index_info({idx['name']})")
            for r in cursor.fetchall():
                indexed_columns.append(r[2])
            conn.close()
        
        for fk_col in fk_columns:
            if fk_col not in indexed_columns:
                issues.append({"table": table_name, "severity": "HIGH",
                              "issue": f"Foreign key column '{fk_col}' has no index — JOIN performance issue"})
        
        # Check 5: No type defined
        for col in columns:
            if col["type"] == "" or col["type"] is None:
                issues.append({"table": table_name, "severity": "MEDIUM",
                              "issue": f"Column '{col['name']}' has no type defined"})
        
        # Check 6: NOT NULL without default
        for col in columns:
            if col["notnull"] and col["pk"] == 0 and col["default"] is None:
                issues.append({"table": table_name, "severity": "LOW",
                              "issue": f"Column '{col['name']}' is NOT NULL with no default"})
    
    return issues
```

---

## Section 2 — Data Integrity Checks

```python
def check_data_integrity(db_path: str) -> list:
    """Check data integrity — NULLs, orphans, duplicates, referential integrity."""
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    issues = []
    
    inspection = inspect_sqlite_db(db_path)
    
    for table_name, table_info in inspection["tables"].items():
        columns = table_info["columns"]
        fks = table_info["foreign_keys"]
        row_count = table_info["row_count"]
        
        if row_count == 0:
            issues.append({"table": table_name, "severity": "INFO", "issue": "Empty table — no data to check"})
            continue
        
        # NULL in NOT NULL columns
        for col in columns:
            if col["notnull"] and col["pk"] == 0:
                cursor.execute(f"SELECT COUNT(*) as cnt FROM {table_name} WHERE {col['name']} IS NULL")
                null_count = cursor.fetchone()["cnt"]
                if null_count > 0:
                    issues.append({"table": table_name, "severity": "HIGH",
                                  "issue": f"NULL values in NOT NULL column '{col['name']}': {null_count} rows"})
        
        # Duplicate values in unique-type columns
        for col in columns:
            col_lower = col["name"].lower()
            if any(kw in col_lower for kw in ["email", "slug", "code", "uuid", "token"]):
                cursor.execute(f"SELECT {col['name']}, COUNT(*) as cnt FROM {table_name} GROUP BY {col['name']} HAVING cnt > 1")
                dupes = cursor.fetchall()
                if dupes:
                    issues.append({"table": table_name, "severity": "HIGH",
                                  "issue": f"Duplicate values in '{col['name']}': {len(dupes)} duplicate groups"})
        
        # Referential integrity (orphan records)
        for fk in fks:
            fk_col = fk["from"]
            ref_table = fk["table"]
            ref_col = fk["to"]
            
            cursor.execute(f"SELECT name FROM sqlite_master WHERE type='table' AND name='{ref_table}'")
            if not cursor.fetchone():
                issues.append({"table": table_name, "severity": "HIGH",
                              "issue": f"Foreign key references non-existent table '{ref_table}'"})
                continue
            
            cursor.execute(f"""
                SELECT COUNT(*) as cnt FROM {table_name} t
                WHERE t.{fk_col} IS NOT NULL
                AND NOT EXISTS (SELECT 1 FROM {ref_table} r WHERE r.{ref_col} = t.{fk_col})
            """)
            orphan_count = cursor.fetchone()["cnt"]
            if orphan_count > 0:
                issues.append({"table": table_name, "severity": "HIGH",
                              "issue": f"Orphan records: {orphan_count} rows in '{fk_col}' reference non-existent {ref_table}.{ref_col}"})
    
    conn.close()
    return issues
```

---

## Section 3 — Index Analysis

```python
def analyze_indexes(db_path: str) -> dict:
    """Analyze index coverage and identify missing/unused indexes."""
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    inspection = inspect_sqlite_db(db_path)
    analysis = {"coverage": [], "missing": [], "recommendations": []}
    
    for table_name, table_info in inspection["tables"].items():
        columns = table_info["columns"]
        fks = table_info["foreign_keys"]
        indexes = table_info["indexes"]
        
        indexed_cols = set()
        for idx in indexes:
            cursor.execute(f"PRAGMA index_info({idx['name']})")
            for r in cursor.fetchall():
                indexed_cols.add(r[2])
        
        # FK coverage
        for fk in fks:
            if fk["from"] not in indexed_cols:
                analysis["missing"].append({
                    "table": table_name, "column": fk["from"],
                    "reason": "Foreign key column needs index for JOIN performance",
                    "sql": f"CREATE INDEX idx_{table_name}_{fk['from']} ON {table_name}({fk['from']});",
                })
        
        # Commonly queried columns
        for col in columns:
            name_lower = col["name"].lower()
            if name_lower.endswith("_id") and col["name"] not in indexed_cols and col["pk"] == 0:
                analysis["missing"].append({
                    "table": table_name, "column": col["name"],
                    "reason": "ID column commonly used in WHERE clauses",
                    "sql": f"CREATE INDEX idx_{table_name}_{col['name']} ON {table_name}({col['name']});",
                })
            if name_lower == "status" and col["name"] not in indexed_cols:
                analysis["missing"].append({
                    "table": table_name, "column": col["name"],
                    "reason": "Status column commonly filtered",
                    "sql": f"CREATE INDEX idx_{table_name}_{col['name']} ON {table_name}({col['name']});",
                })
            if name_lower == "created_at" and col["name"] not in indexed_cols:
                analysis["missing"].append({
                    "table": table_name, "column": col["name"],
                    "reason": "created_at commonly used in ORDER BY",
                    "sql": f"CREATE INDEX idx_{table_name}_{col['name']} ON {table_name}({col['name']});",
                })
    
    conn.close()
    return analysis
```

---

## Section 4 — Query Optimization

```python
def explain_query(db_path: str, query: str) -> dict:
    """Run EXPLAIN QUERY PLAN on a SQL statement."""
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    cursor.execute(f"EXPLAIN QUERY PLAN {query}")
    plan = cursor.fetchall()
    
    result = {"query": query, "plan": [{"selectid": r[0], "order": r[1], "from": r[2], "detail": r[3]} for r in plan]}
    
    for step in result["plan"]:
        detail = step["detail"].upper()
        if "SCAN TABLE" in detail and "USING INDEX" not in detail and "COVERING INDEX" not in detail:
            result["warning"] = f"Full table scan detected: {step['detail']}"
            table_name = step["detail"].split("TABLE")[-1].strip().split(" ")[0] if "TABLE" in step["detail"] else "unknown"
            result["recommendation"] = f"Consider adding an index on the WHERE clause columns for table '{table_name}'"
    
    conn.close()
    return result


def auto_generate_test_queries(inspection: dict) -> list:
    """Generate test queries for all tables based on schema."""
    queries = []
    for table_name, table_info in inspection["tables"].items():
        queries.append(f"SELECT * FROM {table_name} LIMIT 10")
        for fk in table_info["foreign_keys"]:
            queries.append(f"SELECT t.*, r.* FROM {table_name} t LEFT JOIN {fk['table']} r ON t.{fk['from']} = r.{fk['to']} LIMIT 10")
        queries.append(f"SELECT COUNT(*) as cnt FROM {table_name}")
    return queries
```

---

## Section 5 — Migration Safety Testing

```python
def test_migration_safety(db_path: str, old_models_path: str, new_models_path: str) -> dict:
    """Compare two versions of SQLAlchemy models and identify migration risks."""
    import importlib.util
    
    def load_models(path):
        spec = importlib.util.spec_from_file_location("models", path)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        return mod
    
    old_models = load_models(old_models_path)
    new_models = load_models(new_models_path)
    
    old_tables = {}
    for mapper in old_models.Base.registry.mappers:
        cls = mapper.class_
        table = mapper.mapped_table
        old_tables[table.name] = {"columns": {c.name: str(c.type) for c in table.columns}, "class": cls.__name__}
    
    new_tables = {}
    for mapper in new_models.Base.registry.mappers:
        cls = mapper.class_
        table = mapper.mapped_table
        new_tables[table.name] = {"columns": {c.name: str(c.type) for c in table.columns}, "class": cls.__name__}
    
    risks = []
    
    # Removed tables
    for table_name in old_tables:
        if table_name not in new_tables:
            risks.append({"severity": "CRITICAL", "risk": f"Table '{table_name}' removed — DATA LOSS", "action": "Archive data before dropping"})
    
    # Removed columns
    for table_name, table_info in old_tables.items():
        if table_name not in new_tables: continue
        for col_name in table_info["columns"]:
            if col_name not in new_tables[table_name]["columns"]:
                risks.append({"severity": "HIGH", "risk": f"Column '{table_name}.{col_name}' removed — DATA LOSS", "action": "Add migration to drop column after backing up"})
    
    # Type changes
    for table_name, table_info in old_tables.items():
        if table_name not in new_tables: continue
        for col_name, old_type in table_info["columns"].items():
            if col_name in new_tables[table_name]["columns"]:
                new_type = new_tables[table_name]["columns"][col_name]
                if old_type != new_type:
                    risks.append({"severity": "MEDIUM", "risk": f"Type change: '{table_name}.{col_name}' {old_type} → {new_type}", "action": "Verify data compatibility, add conversion migration"})
    
    return {"old_tables": len(old_tables), "new_tables": len(new_tables), "risks": risks, "risk_count": len(risks), "critical_count": len([r for r in risks if r["severity"] == "CRITICAL"])}
```

---

## Section 6 — DB Test Report

```markdown
# Database Test Report — {db_name}

**Date:** {date}
**Database:** {db_path}
**Size:** {size_mb} MB
**Tables:** {table_count}

---

## Schema Validation

| Table | Issue | Severity |
|-------|-------|----------|

**Schema Score:** {pass}/{total} ({pct}%)

---

## Data Integrity

| Table | Check | Result | Details |
|-------|-------|--------|---------|

---

## Index Coverage

| Table | Indexes | Coverage | Missing |
|-------|---------|----------|---------|

**Recommended CREATE INDEX statements:**
```sql
-- Add missing indexes here
```

---

## Query Performance

| Query | Time (ms) | Warning |
|-------|-----------|---------|

---

## Overall Status: {PASS|FAIL}
```

---

## Decision Table

| User Request | Section | Action |
|--------------|---------|--------|
| "Check my DB schema" / "Validate schema" | Section 1 | Schema validation |
| "Data integrity check" / "Find orphan records" | Section 2 | Data integrity |
| "Analyze indexes" / "Missing indexes?" | Section 3 | Index analysis |
| "Slow query" / "Optimize query" | Section 4 | EXPLAIN + profiling |
| "Test migration" / "Is this schema change safe?" | Section 5 | Migration safety |
| "Full DB audit" | All sections | Complete report |
