---
name: perf-tester
description: >
  Professional performance and load testing — generates k6 and Locust test scripts,
  runs benchmarks, analyzes latency percentiles, throughput, error rates under load,
  and produces performance reports with optimization recommendations.
  Trigger when user mentions: k6, Locust, load test, stress test, spike test,
  benchmark, how many users, performance.
---

# Perf Tester — Performance & Load Testing

## When to Use

- Load test an API or backend
- Stress test to find breaking point
- Spike test for traffic surge resilience
- Benchmark function execution time
- Find maximum sustainable concurrent users

## References

| File | Load When |
|---|---|
| `../references/decision-logic.md` | **Always** |
| `../references/test-patterns.md` | **Always** (load/stress/spike stage patterns) |
| `../references/qa-report-template.md` | **Always** |
| `../references/tools-guide.md` | When installing k6/Locust |

## Overview

```
Target URL or Project
  ↓
[Step 1] Choose tool: k6 (standalone) or Locust (Python)
  ↓
[Step 2] Generate test script
  ↓
[Step 3] Run benchmark
  ↓
[Step 4] Analyze results — latency, throughput, error rate, saturation
  ↓
[Step 5] Generate PERF_REPORT.md
```

---

## Section 1 — k6 Performance Testing

### Step 1.1 — Install k6

```bash
which k6 || (curl -s https://run.k6.io -o /tmp/k6_install.sh && bash /tmp/k6_install.sh 2>&1)
k6 version
```

### Step 1.2 — Basic k6 Script Generator

```python
def generate_k6_basic(base_url: str, endpoints: list = None) -> str:
    """Generate a k6 test script."""
    if not endpoints:
        endpoints = [
            {"method": "GET", "path": "/", "name": "root"},
            {"method": "GET", "path": "/health", "name": "health"},
        ]
    
    endpoint_code = []
    trend_decls = []
    
    for ep in endpoints:
        method = ep.get("method", "GET").lower()
        path = ep.get("path", "/")
        name = ep.get("name", path.replace("/", "_").strip("_"))
        body = ep.get("body")
        
        trend_decls.append(f"const {name}Trend = new Trend('{name}_response_time', true);")
        
        if body:
            import json
            body_str = json.dumps(body)
            endpoint_code.append(f"""
    group('{name}', function () {{
        let res = http.{method}(`${{BASE_URL}}{path}`, JSON.parse('{body_str}'), {{
            headers: {{ 'Content-Type': 'application/json' }},
        }});
        check(res, {{ '{name} status 2xx': (r) => r.status >= 200 && r.status < 300 }});
        {name}Trend.add(res.timings.duration);
    }});""")
        else:
            endpoint_code.append(f"""
    group('{name}', function () {{
        let res = http.{method}(`${{BASE_URL}}{path}`);
        check(res, {{ '{name} status 2xx': (r) => r.status >= 200 && r.status < 300 }});
        {name}Trend.add(res.timings.duration);
    }});""")
    
    script = f"""import http from 'k6/http';
import {{ check, group }} from 'k6';
import {{ Rate, Trend, Counter }} from 'k6/metrics';

const BASE_URL = '{base_url}';

{''.join(trend_decl + '\\n' for trend_decl in trend_decls)}
const errorRate = new Rate('errors');

export const options = {{
    stages: [
        {{ duration: '30s', target: 20 }},
        {{ duration: '1m', target: 20 }},
        {{ duration: '30s', target: 50 }},
        {{ duration: '1m', target: 50 }},
        {{ duration: '30s', target: 0 }},
    ],
    thresholds: {{
        http_req_duration: ['p(95)<500'],
        errors: ['rate<0.1'],
    }},
}};

export default function () {{
{''.join(endpoint_code)}
    errorRate.add(0);
}}
"""
    return script
```

### Step 1.3 — k6 Stress Test

```python
def generate_k6_stress(base_url: str) -> str:
    """Generate a stress test — find the breaking point."""
    return f"""import http from 'k6/http';
import {{ check, sleep }} from 'k6';

const BASE_URL = '{base_url}';

export const options = {{
    stages: [
        {{ duration: '2m', target: 100 }},
        {{ duration: '5m', target: 100 }},
        {{ duration: '2m', target: 200 }},
        {{ duration: '5m', target: 200 }},
        {{ duration: '2m', target: 500 }},
        {{ duration: '5m', target: 500 }},
        {{ duration: '3m', target: 0 }},
    ],
    thresholds: {{
        http_req_duration: ['p(95)<1000'],
        http_req_failed: ['rate<0.05'],
    }},
}};

export default function () {{
    const res = http.get(`${{BASE_URL}}/`);
    check(res, {{ 'is status 200': (r) => r.status === 200 }});
    sleep(1);
}}
"""
```

### Step 1.4 — k6 Spike Test

```python
def generate_k6_spike(base_url: str) -> str:
    """Generate a spike test — sudden traffic surge."""
    return f"""import http from 'k6/http';
import {{ check, sleep }} from 'k6';

const BASE_URL = '{base_url}';

export const options = {{
    stages: [
        {{ duration: '10s', target: 10 }},
        {{ duration: '1m', target: 10 }},
        {{ duration: '10s', target: 200 }},
        {{ duration: '1m', target: 200 }},
        {{ duration: '10s', target: 10 }},
        {{ duration: '3m', target: 10 }},
    ],
    thresholds: {{
        http_req_duration: ['p(95)<2000'],
        http_req_failed: ['rate<0.20'],
    }},
}};

export default function () {{
    const res = http.get(`${{BASE_URL}}/`);
    check(res, {{ 'status 2xx': (r) => r.status >= 200 && r.status < 300 }});
    sleep(1);
}}
"""
```

### Step 1.5 — Run k6

```bash
cat > perf-test.js << 'EOF'
  {script_content}
EOF

k6 run perf-test.js 2>&1 | tee k6-output.txt
k6 run --out json=k6-results.json perf-test.js 2>&1
```

---

## Section 2 — Locust Performance Testing

### Step 2.1 — Generate Locust Script

```python
def generate_locust_script(base_url: str, endpoints: list = None) -> str:
    """Generate a Locust load test script."""
    if not endpoints:
        endpoints = [
            {"method": "GET", "path": "/", "name": "root", "weight": 5},
            {"method": "GET", "path": "/health", "name": "health", "weight": 2},
        ]
    
    tasks = []
    for ep in endpoints:
        method = ep.get("method", "GET").lower()
        path = ep.get("path", "/")
        name = ep.get("name", path.replace("/", "_").strip("_"))
        weight = ep.get("weight", 1)
        body = ep.get("body")
        
        if body:
            import json
            body_str = json.dumps(body)
            tasks.append(f"""
    @task({weight})
    def {name}(self):
        self.client.{method}("{path}", json={body_str}, name="{name}")
""")
        else:
            tasks.append(f"""
    @task({weight})
    def {name}(self):
        self.client.{method}("{path}", name="{name}")
""")
    
    script = f"""\"\"\"Locust load test for {base_url}\"\"\"

from locust import HttpUser, task, between


class APIUser(HttpUser):
    host = "{base_url}"
    wait_time = between(1, 3)
    
{''.join(tasks)}
"""
    return script
```

### Step 2.2 — Run Locust

```bash
pip install locust -q
locust -f locustfile.py --headless -u 50 -r 10 -t 2m --host {base_url} 2>&1 | tee locust-output.txt
locust -f locustfile.py --headless -u 50 -r 10 -t 2m --host {base_url} --csv=locust_results 2>&1
```

---

## Section 3 — Python Benchmarking (No External Tools)

```python
"""Pure Python performance benchmark."""

import requests
import concurrent.futures
import time
import statistics
import json
from collections import Counter


def benchmark_endpoint(url: str, method: str = "GET", body: dict = None,
                       concurrency: int = 10, total_requests: int = 200,
                       headers: dict = None) -> dict:
    """Benchmark a single endpoint with detailed metrics."""
    
    results = {"status_codes": Counter(), "latencies": [], "errors": [], "sizes": []}
    
    def make_request():
        start = time.perf_counter()
        try:
            if method == "GET":
                resp = requests.get(url, headers=headers, timeout=30)
            elif method == "POST":
                resp = requests.post(url, json=body, headers=headers, timeout=30)
            else:
                resp = requests.request(method, url, json=body, headers=headers, timeout=30)
            elapsed = time.perf_counter() - start
            return {"status": resp.status_code, "latency_s": elapsed, "size_bytes": len(resp.content), "error": None}
        except Exception as e:
            elapsed = time.perf_counter() - start
            return {"status": 0, "latency_s": elapsed, "size_bytes": 0, "error": str(e)}
    
    wall_start = time.perf_counter()
    with concurrent.futures.ThreadPoolExecutor(max_workers=concurrency) as executor:
        futures = [executor.submit(make_request) for _ in range(total_requests)]
        for f in concurrent.futures.as_completed(futures):
            r = f.result()
            results["status_codes"][r["status"]] += 1
            results["latencies"].append(r["latency_s"])
            results["sizes"].append(r["size_bytes"])
            if r["error"]:
                results["errors"].append(r["error"])
    wall_time = time.perf_counter() - wall_start
    
    latencies = sorted(results["latencies"])
    if not latencies:
        return {"error": "No successful requests"}
    
    success_count = sum(1 for s in results["status_codes"] if 200 <= s < 400)
    error_count = total_requests - success_count
    
    return {
        "url": url, "method": method,
        "concurrency": concurrency, "total_requests": total_requests,
        "wall_time_s": round(wall_time, 2),
        "requests_per_second": round(total_requests / wall_time, 2),
        "success_count": success_count, "error_count": error_count,
        "error_rate_pct": round(error_count / total_requests * 100, 1),
        "latency": {
            "min_ms": round(min(latencies) * 1000, 2),
            "mean_ms": round(statistics.mean(latencies) * 1000, 2),
            "median_ms": round(statistics.median(latencies) * 1000, 2),
            "p90_ms": round(latencies[int(len(latencies) * 0.90)] * 1000, 2),
            "p95_ms": round(latencies[int(len(latencies) * 0.95)] * 1000, 2),
            "p99_ms": round(latencies[int(len(latencies) * 0.99)] * 1000, 2),
            "max_ms": round(max(latencies) * 1000, 2),
            "stddev_ms": round(statistics.stdev(latencies) * 1000, 2) if len(latencies) > 1 else 0,
        },
        "status_codes": dict(results["status_codes"]),
        "errors_sample": results["errors"][:5],
    }
```

---

## Section 4 — Performance Report

```markdown
# Performance Test Report — {target}

**Date:** {date}
**Target:** {url}
**Tool:** k6 / Locust / Python
**Duration:** {duration}

---

## Executive Summary

| Metric | Value | Threshold | Status |
|--------|-------|-----------|--------|
| Throughput | {rps} req/s | — | — |
| P95 Latency | {p95} ms | < 500ms | ✅/❌ |
| P99 Latency | {p99} ms | < 1000ms | ✅/❌ |
| Error Rate | {err_pct}% | < 10% | ✅/❌ |

---

## Endpoint Breakdown

| Endpoint | Mean (ms) | P95 (ms) | Error Rate | Status |
|----------|-----------|----------|------------|--------|

---

## Bottleneck Analysis

| Finding | Severity | Recommendation |
|---------|----------|----------------|

---

## Overall Verdict: {PASS|FAIL}
{Maximum sustainable load: X concurrent users}
```

---

## Decision Table

| User Request | Tool | Action |
|--------------|------|--------|
| "Load test this API" | k6 or Locust | Generate + run load test |
| "Stress test" / "Find breaking point" | k6 stress script | Ramp until failure |
| "Spike test" / "Sudden traffic surge" | k6 spike script | Spike + recovery |
| "Benchmark my functions" | Python benchmark | Per-function timing |
| "How many users can this handle?" | k6 ramping | Find max sustainable load |
| "Compare before/after performance" | k6 + Locust | Baseline then compare |
