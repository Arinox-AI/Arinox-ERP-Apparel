# Learned API Quirks

API-specific quirks, headers, auth patterns learned from user interactions.

---

## How This File Works

When agent discovers API-specific behavior (custom headers, auth requirements, rate limits), it's stored here.

---

## Learned API Details

_(No API quirks learned yet. This section will be populated as agent encounters APIs.)_
