# Learned Test Patterns

Company/project-specific test patterns learned from user interactions.

---

## How This File Works

When agent learns a new test pattern not in `test-patterns.md`, it's added here.
Agent checks this file after checking core patterns.

---

## Learned Patterns

_(No patterns learned yet. This section will be populated as agent learns from user.)_
