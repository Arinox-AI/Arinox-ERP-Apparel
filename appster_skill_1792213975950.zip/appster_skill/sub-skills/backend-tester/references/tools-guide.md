# Tools Guide — Installation and Setup

How to install and set up testing tools used across all sub-skills.

---

## Python Testing Tools

### pytest

```bash
pip install pytest pytest-asyncio -q
python -m pytest test_file.py -v --tb=short 2>&1
```

### requests (API testing)

```bash
pip install requests -q
```

### Selenium (browser testing)

```bash
pip install selenium webdriver-manager -q
```

### websockets (WebSocket testing)

```bash
pip install websockets pytest-asyncio -q
```

### python-socketio (Socket.IO testing)

```bash
pip install "python-socketio[client]" -q
```

---

## Performance Testing Tools

### k6 (preferred for load testing)

```bash
# Install k6
which k6 || (curl -s https://run.k6.io -o /tmp/k6_install.sh && bash /tmp/k6_install.sh 2>&1)
k6 version

# Run a k6 script
k6 run perf-test.js 2>&1 | tee k6-output.txt

# Run with JSON output for analysis
k6 run --out json=k6-results.json perf-test.js 2>&1
```

### Locust (Python-based load testing)

```bash
pip install locust -q

# Run headless (no web UI)
locust -f locustfile.py --headless -u 50 -r 10 -t 2m --host {base_url} 2>&1 | tee locust-output.txt

# Run with CSV output
locust -f locustfile.py --headless -u 50 -r 10 -t 2m --host {base_url} --csv=locust_results 2>&1
```

### PyYAML (for OpenAPI spec parsing)

```bash
pip install pyyaml -q
```

---

## JavaScript Testing Tools

### Jest + Supertest (Express.js testing)

```bash
npm install --save-dev jest supertest && npx jest --verbose
```

---

## Database Inspection Tools

### SQLite CLI

```bash
sqlite3 {db_path} ".tables"
sqlite3 {db_path} ".schema {table}"
sqlite3 {db_path} "PRAGMA table_info({table})"
sqlite3 {db_path} "PRAGMA index_list({table})"
sqlite3 {db_path} "PRAGMA foreign_key_list({table})"
sqlite3 {db_path} "EXPLAIN QUERY PLAN SELECT * FROM {table}"
```

---

## Tool Selection Guide

| What You Need | Tool | Install |
|---------------|------|---------|
| Unit test framework | pytest | `pip install pytest` |
| REST API testing | requests | `pip install requests` |
| GraphQL testing | requests + gql | `pip install requests` |
| Browser testing | Selenium | `pip install selenium webdriver-manager` |
| WebSocket testing | websockets | `pip install websockets` |
| Socket.IO testing | python-socketio | `pip install "python-socketio[client]"` |
| Load testing (standalone) | k6 | `curl https://run.k6.io | bash` |
| Load testing (Python) | Locust | `pip install locust` |
| Express.js testing | Jest + Supertest | `npm install --save-dev jest supertest` |
| OpenAPI spec parsing | PyYAML | `pip install pyyaml` |
