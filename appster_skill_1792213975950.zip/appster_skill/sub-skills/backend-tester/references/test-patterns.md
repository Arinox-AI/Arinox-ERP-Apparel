# Test Patterns — Common Patterns, Edge Cases, Fixtures

Reusable test patterns, edge case payloads, and fixture templates for all testing modes.

---

## Standard Edge Case Payloads

### For All Input Fields

| Test | Payload | Expected |
|------|---------|----------|
| Empty string | `""` | Should not crash |
| Very long string | `"A" * 10000` | Should not crash |
| Special characters | `'<script>alert("xss")</script>'` | Should be sanitized |
| SQL injection | `"'; DROP TABLE items; --"` | Should not execute |
| Unicode | `"日本語 ñ é ü"` | Should handle correctly |
| Null/None | `null` / omitted | Should handle or default |
| Negative number | `-1` | Should validate or reject |
| Zero | `0` | Should handle correctly |
| Boolean where string expected | `true` | Should type-check |

### SQL Injection Payloads

```python
SQL_INJECTION_PAYLOADS = [
    "' OR '1'='1",
    "'; DROP TABLE users; --",
    "1 UNION SELECT * FROM users--",
    "' OR 1=1 --",
    "admin'--",
    "1; DELETE FROM items WHERE 1=1",
    "' UNION SELECT password FROM users WHERE '1'='1",
]
```

### XSS Payloads

```python
XSS_PAYLOADS = [
    '<script>alert("xss")</script>',
    '<img src=x onerror=alert(1)>',
    '"><script>alert(document.cookie)</script>',
    "<svg/onload=alert('xss')>",
    'javascript:alert(1)',
    '<iframe src="javascript:alert(1)">',
]
```

---

## Common Test Patterns

### CRUD Function Testing

```python
# Standard CRUD test sequence
CRUD_TEST_SEQUENCE = [
    # 1. List (should be empty or have seed data)
    ("get_{entities}", {}, "list_all"),
    # 2. Create
    ("create_{entity}", {"name": "Test Item"}, "create"),
    # 3. Get single (by ID from create result)
    ("get_{entity}", {"{entity}_id": "{created_id}"}, "get_by_id"),
    # 4. Update
    ("update_{entity}", {"{entity}_id": "{created_id}", "name": "Updated"}, "update"),
    # 5. Delete
    ("delete_{entity}", {"{entity}_id": "{created_id}"}, "delete"),
    # 6. Get deleted (should 404)
    ("get_{entity}", {"{entity}_id": "{created_id}"}, "get_deleted"),
]
```

### REST API CRUD Test Pattern

```python
REST_CRUD_PATTERN = [
    ("GET", "/api/{resource}", None, 200, "List all"),
    ("POST", "/api/{resource}", {"name": "Test"}, 201, "Create"),
    ("GET", "/api/{resource}/{id}", None, 200, "Get by ID"),
    ("PUT", "/api/{resource}/{id}", {"name": "Updated"}, 200, "Update"),
    ("DELETE", "/api/{resource}/{id}", None, 204, "Delete"),
    ("GET", "/api/{resource}/99999", None, 404, "Not found"),
]
```

### GraphQL Test Pattern

```python
GQL_TEST_PATTERN = [
    ("Introspection", "{ __schema { queryType { name } } }"),
    ("Invalid query", "{ nonExistentField12345 }"),
    ("Empty query", ""),
    ("Malformed query", "{ broken query }"),
]
```

---

## Fixture Templates

### Pytest Fixtures

```python
import pytest
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from database import get_session, init_db


@pytest.fixture(scope="session")
def db():
    """Create a fresh test database."""
    init_db()
    session = get_session()
    yield session
    session.close()


@pytest.fixture(autouse=True)
def cleanup(db):
    """Rollback after each test to keep DB clean."""
    yield
    db.rollback()
```

### Test Data Seeds

```python
STANDARD_TEST_ITEMS = [
    {"name": "Test Item 1", "description": "Standard fixture"},
    {"name": "Test Item 2", "description": "Another fixture"},
    {"name": "", "description": "Empty name fixture"},
    {"name": "A" * 500, "description": "Max length fixture"},
    {"name": "Special <>&\"'", "description": "Special characters fixture"},
]
```

---

## Performance Test Patterns

### Load Test Stages (k6)

```javascript
// Standard ramp-up → sustain → ramp-down
stages: [
    { duration: '30s', target: 20 },   // Ramp up
    { duration: '1m', target: 20 },     // Sustain
    { duration: '30s', target: 50 },     // Ramp up more
    { duration: '1m', target: 50 },     // Sustain
    { duration: '30s', target: 0 },     // Ramp down
],
thresholds: {
    http_req_duration: ['p(95)<500'],
    errors: ['rate<0.1'],
},
```

### Stress Test Stages

```javascript
// Progressive ramp to find breaking point
stages: [
    { duration: '2m', target: 100 },
    { duration: '5m', target: 100 },
    { duration: '2m', target: 200 },
    { duration: '5m', target: 200 },
    { duration: '2m', target: 500 },
    { duration: '5m', target: 500 },
    { duration: '3m', target: 0 },
],
```

### Spike Test Stages

```javascript
// Sudden surge → recovery
stages: [
    { duration: '10s', target: 10 },
    { duration: '1m', target: 10 },
    { duration: '10s', target: 200 },    // SPIKE!
    { duration: '1m', target: 200 },
    { duration: '10s', target: 10 },     // Recovery
    { duration: '3m', target: 10 },
],
```

---

## Concurrency Test Pattern

```python
import concurrent.futures

def test_concurrent(url, num_requests=20, max_workers=10):
    results = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = [executor.submit(requests.get, url, timeout=30) for _ in range(num_requests)]
        for f in concurrent.futures.as_completed(futures):
            try:
                results.append(f.result().status_code)
            except Exception as e:
                results.append(str(e))
    return results
```

---

## Return Shape Validation

Every function must return a JSON-serializable dict. Check:

- ✅ No ORM objects leaked (must be dicts via `to_dict()`)
- ✅ No datetime objects (must be `.isoformat()` strings)
- ✅ Error responses follow `{"error": "message"}` format
- ✅ List returns include `total`, `total_count`, `offset`, `limit`
- ✅ `created_at` and `updated_at` are ISO strings
