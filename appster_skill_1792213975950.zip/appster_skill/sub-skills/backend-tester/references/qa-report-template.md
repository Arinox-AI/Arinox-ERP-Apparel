# QA Report Template — Unified

Standard template for ALL testing reports. Every testing session produces one QA_REPORT.md.

---

## Unified Severity Scale

| Level | Icon | Meaning | Action Required |
|-------|------|---------|-----------------|
| CRITICAL | 🔴 | System is broken or data loss possible | Must fix before release |
| HIGH | 🟠 | Major functionality broken or security risk | Should fix before release |
| MEDIUM | 🟡 | Degraded performance or minor bugs | Fix in next sprint |
| LOW | 🔵 | Cosmetic or edge case issues | Backlog |
| INFO | ℹ️ | Observation, no action needed | Note only |

---

## Final Status Values

| Status | Meaning |
|--------|---------|
| **READY** | All tests pass, no critical/high issues |
| **READY WITH WARNINGS** | Functional tests pass, but medium/info findings exist |
| **NOT READY** | Critical or high severity issues found — must fix before release |

---

## Report Template

```markdown
# QA Report — {target_name}

**Date:** {date}
**Tester:** Backend Tester Agent
**Scope:** {scope_description}
**Skills Used:** {comma-separated list of sub-skills}

---

## Executive Summary

| Metric | Value |
|--------|-------|
| Total Tests Run | {total_tests} |
| Passed | {passed} ✅ |
| Failed | {failed} ❌ |
| Warnings | {warnings} ⚠️ |
| Bugs Found | {bugs_found} |
| Bugs Fixed | {bugs_fixed} |
| Critical Issues | {critical} |
| **Overall Status** | **{READY / NOT READY / READY WITH WARNINGS}** |

---

## 1. Functional Testing (`backend-tester`)

### Function Test Results

| Function | Status | Time | Notes |
|----------|--------|------|-------|
| get_items | ✅ PASS | 12ms | |
| create_item | ✅ PASS | 18ms | |
| delete_item (nonexistent) | ✅ PASS | 3ms | Returns proper error |

### Edge Cases

| Test | Result | Notes |
|------|--------|-------|
| Empty string inputs | ✅ | Handled |
| SQL injection | ✅ | Not vulnerable |
| XSS payloads | ✅ | Sanitized |
| Concurrent access | ✅ | No corruption |

### Security Findings

| Finding | Severity | Status |
|---------|----------|--------|
| No rate limiting | ℹ️ INFO | Noted |
| Auth on protected routes | ✅ | Confirmed |

---

## 2. API Spec Validation (`api-doc-tester`)

*Only present if OpenAPI/Swagger spec was provided*

### Spec Coverage

| Endpoint | Documented | Live Match | Status |
|----------|-----------|------------|--------|
| GET /api/items | ✅ | ✅ | ✅ PASS |
| POST /api/items | ✅ | ❌ (extra field) | ⚠️ WARN |

### Discrepancies

| Endpoint | Issue | Severity |
|----------|-------|----------|
| POST /api/items | Response has undocumented field `metadata` | 🟡 MEDIUM |

---

## 3. Database Testing (`db-tester`)

### Schema Validation

| Table | Issue | Severity |
|-------|-------|----------|
| orders | FK 'user_id' has no index | 🟠 HIGH |
| items | Missing updated_at | 🔵 LOW |

### Data Integrity

| Check | Result | Details |
|-------|--------|---------|
| NULL violations | ✅ | None found |
| Orphan records | ❌ | 3 orders reference deleted users |
| Duplicate emails | ✅ | None found |

### Index Coverage

| Table | Coverage | Missing Indexes |
|-------|----------|-----------------|
| items | 80% | created_at |
| orders | 50% | user_id, status |

### Recommended SQL

```sql
CREATE INDEX idx_orders_user_id ON orders(user_id);
CREATE INDEX idx_items_created_at ON items(created_at);
```

---

## 4. Performance Testing (`perf-tester`)

### Load Test Summary

| Metric | Value | Threshold | Status |
|--------|-------|-----------|--------|
| Throughput | {rps} req/s | — | — |
| P95 Latency | {p95} ms | < 500ms | ✅/❌ |
| P99 Latency | {p99} ms | < 1000ms | ✅/❌ |
| Error Rate | {err}% | < 10% | ✅/❌ |

### Endpoint Breakdown

| Endpoint | Mean (ms) | P95 (ms) | Error Rate | Status |
|----------|-----------|----------|------------|--------|
| GET / | 45 | 120 | 0% | 🟢 |
| GET /api/items | 89 | 230 | 0% | 🟢 |
| POST /api/items | 156 | 450 | 2% | 🟡 |

---

## 5. WebSocket/Real-Time Testing (`websocket-tester`)

*Only present if real-time endpoints were tested*

### Connection Tests

| Test | Status | Notes |
|------|--------|-------|
| Connect | ✅ | |
| Send/Receive | ✅ | Echo working |
| Reconnect | ✅ | |
| Concurrent (10 clients) | ✅ | |

---

## Cross-Skill Findings

| Finding | Skills Involved | Root Cause | Recommendation |
|---------|----------------|------------|----------------|
| P99 > 1s under load + full table scan | perf-tester + db-tester | Missing index | Add index → re-test |

---

## Bugs Found & Fixed

| # | Bug | Severity | Skill Found By | Fix | Status |
|---|-----|----------|---------------|-----|--------|
| 1 | create_item crashes on empty name | 🟠 HIGH | backend-tester | Added validation | ✅ Fixed |

---

## Recommendations

1. **CRITICAL:** {Most important finding}
2. **HIGH:** {Second priority}
3. **MEDIUM:** {Third priority}

---

## Final Status: {READY / NOT READY / READY WITH WARNINGS}
```

---

## Merging Rules

When combining results from multiple sub-skills into one report:

1. **One executive summary** — aggregated totals from all skills
2. **Per-skill sections** — each skill's findings in its own section
3. **Cross-skill findings** — correlations between skills
4. **Deduplicated bugs** — same bug found by multiple skills appears once
5. **Unified severity scale** — all findings use the same severity levels above
