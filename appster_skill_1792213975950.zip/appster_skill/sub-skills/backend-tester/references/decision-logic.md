# Decision Logic — Testing

Rules for when to ask vs auto-decide, test sequencing, pass/fail criteria, and output format.

---

## Core Principle

**Never ask the user for something you can determine yourself.**

---

## Decision Hierarchy

### LEVEL 1 — Can be determined from the project/code (NEVER ask)

| What | How to Determine |
|------|-----------------|
| What functions exist | Read document.md |
| What endpoints exist | Read code or introspect API |
| What DB schema looks like | Read models.py or inspect SQLite |
| Test type needed | Derive from user request keywords |
| Edge cases to test | Standard set (empty, SQL injection, XSS, concurrent) |
| Project directory | From `pwd` + `ls artifacts/` |

### LEVEL 2 — Can be determined from standard practice (NEVER ask)

| What | Rule |
|------|------|
| Edge case testing | Always test empty strings, SQL injection, XSS, concurrent access |
| Performance testing | Always run after functional tests pass |
| Security checks | Always run on API endpoints |
| Bug fixing | Always fix before moving to next phase |
| Report generation | Always produce QA_REPORT.md at the end |

### LEVEL 3 — Only ask the user for these (genuinely unknown)

| What | When to Ask |
|------|------------|
| Which project to test | If multiple exist and not specified |
| Target URL | If not provided and not discoverable |
| Destructive test confirmation | Before running destructive tests |
| Custom test parameters | When user wants something non-standard |

---

## Pass/Fail Criteria

### Function Tests

| Result | Meaning |
|--------|---------|
| ✅ PASS | Function returns expected shape, no errors |
| ❌ FAIL | Function crashes, returns wrong shape, or error |
| ⚠️ WARN | Function works but has performance concern or minor issue |
| ⏭️ SKIP | Function not testable (e.g., requires external service not available) |

### API Endpoint Tests

| HTTP Status | Meaning |
|-------------|---------|
| 2xx | ✅ PASS |
| 4xx (expected, e.g., 404 for nonexistent) | ✅ PASS (correct error handling) |
| 4xx (unexpected, e.g., 400 for valid input) | ❌ FAIL |
| 5xx | ❌ FAIL (server error) |
| Timeout | ❌ FAIL (no response) |

### Performance Thresholds

| Category | Threshold | Action |
|----------|-----------|--------|
| 🟢 Fast | < 100ms | No action |
| 🟡 Moderate | 100-500ms | Note in report |
| 🟠 Slow | 500ms-1s | Recommend optimization |
| 🔴 Very Slow | > 1s | Critical — investigate |

### Severity Assignment

| Finding | Severity |
|---------|----------|
| System crash / data loss | CRITICAL 🔴 |
| Major feature broken / security vulnerability | HIGH 🟠 |
| Degraded performance / minor bug | MEDIUM 🟡 |
| Cosmetic issue / edge case | LOW 🔵 |
| Observation only | INFO ℹ️ |

---

## Test Sequencing Rules

```
RULE 1: Functional tests FIRST → Load/Perf tests SECOND
RULE 2: Backend-tester BEFORE Perf-tester
RULE 3: DB-tester PARALLEL with Backend-tester (same project)
RULE 4: API-doc-tester BEFORE Backend-tester (when spec exists)
RULE 5: Bug fixes → Re-test → THEN move to next skill
RULE 6: ALWAYS end with QA_REPORT.md
```

---

## When to Stop Testing

| Situation | Action |
|-----------|--------|
| All tests pass | Continue to next phase (perf, security, etc.) |
| Critical bug found | Stop, fix, re-test before continuing |
| API returns 500 consistently | Stop load testing — API is broken |
| >50% tests failing | Stop, report, let user decide |
| External service down | Skip related tests, note in report |

---

## Auto-Decisions (Never Ask User)

| Question | Auto-Decision |
|----------|--------------|
| "Should I test edge cases?" | Always yes |
| "Should I fix bugs I find?" | Always yes (if code is in workspace) |
| "Should I profile?" | Yes, after functional tests pass |
| "Should I run security checks?" | Always yes on API endpoints |
| "Should I generate a report?" | Always yes — QA_REPORT.md mandatory |
| "Should I test concurrent access?" | Always yes for APIs |

---

## Response Format

### During Testing
Show concise progress — what's being tested, what passed/failed.

### After Testing
Full QA_REPORT.md with executive summary, detailed results, bugs, recommendations.

### Error Messages
Never show internal tool errors to user. Translate to plain language:
- "Connection refused" → "The API at {url} is not responding"
- "401 Unauthorized" → "The endpoint requires authentication"
- "pytest exit code 1" → "N test(s) failed — see details below"
