---
name: backend-tester
description: "Phase 6 QA — enhanced backend testing pipeline: functional CLI tests, DB integrity, performance profiling, and security checks. Produces a comprehensive QA_REPORT.md."
keyword_triggers: [test, qa, quality, verify, validate, backend test, full qa, test project, test functions, unit test, integration test]
provides:
  backend_functions: []
  frontend_components: []
  npm_deps: []
---

# Backend Tester (sub-skill)

This sub-skill handles **Phase 6 QA** for appster. It replaces the basic inline CLI tests with a full testing pipeline.

All sub-skills and references live inside this folder — no external paths needed.

```
sub-skills/backend-tester/
├── SKILL.md                   ← This file (master router)
├── skills/
│   ├── backend-tester/        ← Functional + unit + GraphQL + security tests
│   ├── db-tester/             ← Schema, integrity, indexes, slow queries
│   ├── perf-tester/           ← k6, Locust, benchmark
│   ├── api-doc-tester/        ← OpenAPI/Swagger spec-driven tests
│   ├── websocket-tester/      ← SSE/WebSocket/Socket.IO tests
│   └── qa-orchestrator/       ← Merge reports into one QA_REPORT.md
└── references/
    ├── qa-report-template.md  ← Unified QA report template — load always
    ├── decision-logic.md      ← When to ask vs auto-decide — load always
    ├── test-patterns.md       ← Common patterns, edge case payloads — load always
    ├── tools-guide.md         ← k6, Locust, pytest setup — load when needed
    └── learned/               ← Self-teaching storage
```

---

## Routing Decision Tree

```
User Request / Phase 6 trigger
     ↓
┌─ "Test my project" / "Full QA" / "Test everything"
│    → Pipeline A (Full Project QA)
│
├─ "Test this API: https://..."
│    → Pipeline B (API URL Full Test)
│
├─ "Test from this OpenAPI/Swagger spec"
│    → Pipeline C (Spec-Driven Full Test)
│
├─ "Test GraphQL" / "Test KOGO API"
│    → Pipeline D (GraphQL Full Test)
│
├─ "Test WebSocket" / "Test my real-time backend"
│    → Pipeline E (Real-Time Full Test)
│
├─ "Audit database" / "Full DB check"
│    → Pipeline F (DB Deep Audit)
│
├─ "Security test" / "Pen test"
│    → Pipeline G (Security-First Test)
│
└─ Phase 6 default (no user QA request) → Pipeline A
```

---

## Sub-skill paths (relative to this folder)

| Sub-skill | Trigger | Path |
|---|---|---|
| **backend-tester** | CLI tests, pytest, unit, REST, GraphQL, security, load | `skills/backend-tester/SKILL.md` |
| **api-doc-tester** | OpenAPI, Swagger, spec, generate tests from spec | `skills/api-doc-tester/SKILL.md` |
| **db-tester** | DB schema, integrity, orphan records, indexes, slow queries | `skills/db-tester/SKILL.md` |
| **perf-tester** | k6, Locust, load test, stress test, benchmark | `skills/perf-tester/SKILL.md` |
| **websocket-tester** | WebSocket, SSE, Socket.IO, real-time | `skills/websocket-tester/SKILL.md` |
| **qa-orchestrator** | Full QA, pipeline, merge reports | `skills/qa-orchestrator/SKILL.md` |

**Always load these references first:**
- `references/qa-report-template.md`
- `references/decision-logic.md`
- `references/test-patterns.md`

---

## Pipeline A — Full Project QA (default for Phase 6)

```
Phase 1 — PARALLEL: Functional + Database
  ├── skills/backend-tester/SKILL.md (Sections 1, 2, 4, 6, 10) — CLI, pytest, integration, security
  └── skills/db-tester/SKILL.md (Sections 1, 2, 3, 4) — Schema, integrity, indexes, queries

Phase 2 — SEQUENTIAL: Fix bugs found in Phase 1
  └── Fix all critical/high issues → re-test

Phase 3 — SEQUENTIAL: Performance (only after functional passes)
  └── skills/perf-tester/SKILL.md (Sections 1 or 3) — k6 load test or Python benchmark

Phase 4 — MERGE: Generate unified QA_REPORT.md
  └── skills/qa-orchestrator/SKILL.md
```

---

## Context available during Phase 6

```
PROJECT_DIR   = {PROJECT_DIR}
BACKEND_DIR   = {PROJECT_DIR}/backend
document.md   = {PROJECT_DIR}/backend/document.md
functions.py  = {PROJECT_DIR}/backend/functions.py
AGENT_ID      = {agentId}
USER_JWT      = ${USER_JWT_TOKEN}
KOGO_API_BASE = ${KOGO_API_BASE}
```

---

## Output

Write the consolidated report to `{PROJECT_DIR}/QA_REPORT.md`.

---

## Sequencing rules

```
RULE 1: Functional tests FIRST → Load/Perf tests SECOND
RULE 2: DB-tester PARALLEL with backend-tester (same project, no conflict)
RULE 3: API-doc-tester BEFORE backend-tester (when spec exists)
RULE 4: Bug fixes → Re-test → THEN move to next sub-skill
RULE 5: ALWAYS end with QA_REPORT.md via qa-orchestrator
```

## Agent decides, does not ask

- What functions exist → read `document.md`
- What DB schema looks like → read `models.py` or inspect SQLite
- Test type → derive from keywords + project structure
- Only ask: which project (if multiple), target URL (if not discoverable), destructive test consent
