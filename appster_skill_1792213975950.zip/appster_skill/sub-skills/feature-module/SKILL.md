---
name: feature-module
description: "Adds 5 agentic analytics features: Answer from Agent, Query Generator (SQL via agent + DB persist), Graph (chart type selection), Report (markdown analysis), Summary (dashboard widget). All backed by the Kogo Chat API."
keyword_triggers: [analytics, graph, chart, report, summary, dashboard, query, data, visualization, insights, sql, metrics]
provides:
  backend_functions: [get_feature_config, get_db_structure, get_query_history, answer_from_agent, query_generator, generate_graph, generate_report, generate_summary, handle_widget_request]
  frontend_components: [AnalyticsDashboard]
  npm_deps: ["react-plotly.js", "plotly.js-basic-dist-min"]
---

# Feature Module

---

## HARD RULES — never override, even if the user explicitly asks

These are FIXED. Do not relax them for any request, convenience, or "just this once."

1. **Credentials and hosts come ONLY from config/env** (`API_PATH`, `CHAT_API_PATH`, `USER_JWT_TOKEN`, `USER_ID`, `DEPLOYMENT_ID`, `SWARM_ID`). NEVER hardcode a host, port, URL, ID, or token. NEVER substitute a default host (especially not `uatos.kogo.ai`) and NEVER build a hostless URL. If a required value is empty/missing → fail loud (`{"error": ...}`), never fabricate.
2. **`check_env` / `_feat_guard_env` must not be bypassed.** Every agent-calling function guards env first and returns the error dict on failure.
3. **Endpoint paths, GraphQL mutations/input types, and SSE field/event names are FIXED CONTRACT** — verbatim from a verified source, never invented. Specifically: endpoint paths `deployment_stream_kogo_os` and `deployment_stream_kogo_os_stream`; GraphQL `register_user_room`, `saveAgentQueryResult`, input type `AgentQueryResultInput`; SSE `type` values `"streaming"`/`"final"` and field `boatReply`. If you cannot verify one of these from the actual backend, STOP and ask — do not guess.
4. **History is ALWAYS saved** for every attempt (success, error, partial). Save failures must be observable (logged/flagged), never silently swallowed.
5. **Never swallow errors silently.** SQL/save/parse failures surface as `{"error": ...}` or a logged flag — never as fabricated success data.

---

## Feature Decision Table

Use this table to route user intent to the right backend function:

| User says / intent | Primary function | Secondary function |
|---|---|---|
| "Ask agent X" / "What is X" / direct question | `answer_from_agent` (DEFAULT, non-streaming). Use `answer_from_agent_stream` ONLY when the frontend explicitly passes a streaming flag. | — |
| "Query data / show me data" | `query_generator` | — |
| "Chart / graph / visualize X" | `query_generator` | `generate_graph` |
| "Report on X" / "Analyze X" | `query_generator` | `generate_report` |
| "Summarize X" / "Summary of X" | `query_generator` | `generate_summary` |
| Full widget: auto-detect + render | `handle_widget_request` | (handles routing internally) |

---

## Endpoint Decision Table

| Function | Endpoint | Streaming? |
|---|---|---|
| `answer_from_agent` | `deployment_stream_kogo_os` | No — returns full response at once |
| `answer_from_agent_stream` | `deployment_stream_kogo_os_stream` | **Yes — SSE stream** |
| `query_generator` | `deployment_stream_kogo_os_stream` | Yes — SSE stream |
| `generate_graph` | `deployment_stream_kogo_os` | No |
| `generate_report` | `deployment_stream_kogo_os` | No |
| `generate_summary` | `deployment_stream_kogo_os` | No |
| `handle_widget_request` | (calls above functions internally) | Depends on feature |

---

## Module Integration Steps

> Follow these steps exactly when integrating analytics/widget features into an existing project.

---

### Module Integration Steps

### Step 0 — Add Analytics History Model (append to existing models.py)

Analytics history is **always saved to the project's local SQLite DB** — every query attempt, whether it succeeds, fails, or returns partial results. This is non-negotiable default behavior.

Append to `backend/models.py`:

```python
# ─── Analytics History ────────────────────────────────────────────────────────
import json as _json
from datetime import datetime

class AnalyticsHistoryModel(Base):
    __tablename__ = "analytics_history"

    id         = mapped_column(Integer, primary_key=True, autoincrement=True)
    question   = mapped_column(String, nullable=False)
    feature_type = mapped_column(String, default="query")   # answer/query/graph/report/summary
    sql_query  = mapped_column(String, nullable=True)
    query_output_json = mapped_column(String, nullable=True)  # JSON-stringified list
    result     = mapped_column(String, nullable=True)         # chart_type / report text / summary text
    status     = mapped_column(String, default="success")     # success / error / partial
    error_msg  = mapped_column(String, nullable=True)
    created_at = mapped_column(DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            "id": self.id,
            "question": self.question,
            "feature_type": self.feature_type,
            "sql_query": self.sql_query,
            "query_output": _json.loads(self.query_output_json) if self.query_output_json else [],
            "result": self.result,
            "status": self.status,
            "error_msg": self.error_msg,
            "created_at": str(self.created_at),
        }
```

After adding the model, ensure `init_db()` in `database.py` runs `Base.metadata.create_all(bind=engine)` — the `analytics_history` table will be created automatically on next startup.

---

### Step 1 — Backend (append to existing functions.py)

Add `import requests`, `import re`, `import json`, and `from typing import Optional` to imports if not already present.

**Install npm dependencies** (add to `frontend/package.json` and run during build):

DETERMINISTIC: detect the package manager from the lockfile present in `frontend/` — do NOT assume `pnpm`. Apply this rule in order:
- `pnpm-lock.yaml` present → use `pnpm add` / `pnpm add -D`
- `yarn.lock` present → use `yarn add` / `yarn add -D`
- `package-lock.json` (or no lockfile) present → use `npm install` / `npm install -D`

Then install the deps (example shown for npm; substitute the matching command):
```bash
# npm:        npm install react-plotly.js plotly.js-basic-dist-min && npm install -D @types/react-plotly.js
# yarn:       yarn add react-plotly.js plotly.js-basic-dist-min && yarn add -D @types/react-plotly.js
# pnpm:       pnpm add react-plotly.js plotly.js-basic-dist-min && pnpm add -D @types/react-plotly.js
npm install react-plotly.js plotly.js-basic-dist-min
npm install -D @types/react-plotly.js
```

Append the following block at the end of `functions.py`, before the `if __name__ == "__main__":` block:

```python
# ═══════════════════════════════════════════════════════════════════════════
# FEATURE MODULE — Agentic Analytics Functions
# ═══════════════════════════════════════════════════════════════════════════

# NOTHING HARDCODED: API_PATH and CHAT_API_PATH are REQUIRED from config/env.
# No host literal anywhere. If empty/missing, every function fails loud via _feat_guard_env.
_feat_raw_api = os.environ.get("API_PATH", "").rstrip("/")
FEAT_GATEWAY_URL = (
    "" if not _feat_raw_api
    else (_feat_raw_api if _feat_raw_api.endswith("/gateway") else f"{_feat_raw_api}/gateway")
)
FEAT_CHAT_API_URL = os.environ.get("CHAT_API_PATH", "").rstrip("/")
FEAT_USER_JWT = os.environ.get("USER_JWT_TOKEN", "")
FEAT_USER_ID = os.environ.get("USER_ID", "")
FEAT_DEPLOYMENT_ID = os.environ.get("DEPLOYMENT_ID", "")
FEAT_SWARM_ID = os.environ.get("SWARM_ID", "")


def _feat_headers() -> dict:
    return {"Authorization": FEAT_USER_JWT, "Content-Type": "application/json"}


def _feat_create_room() -> str:
    """Create a user room and return room_id. Required before every agent call.
    Uses $sender: String as per agentic-feature original.

    FIXED CONTRACT — never invent: GraphQL mutation name `register_user_room` and its
    `$sender: String` variable are verbatim backend contract values. Do not rename or guess.
    """
    payload = {
        "query": (
            "mutation Register_user_room($sender: String) {\n"
            "  register_user_room(sender: $sender) {\n"
            "    _id\n"
            "    members { _id first_name }\n"
            "  }\n"
            "}"
        ),
        "variables": {"sender": FEAT_USER_ID},
    }
    resp = requests.post(FEAT_GATEWAY_URL, json=payload, headers=_feat_headers(), timeout=30)
    resp.raise_for_status()
    data = resp.json()
    return data["data"]["register_user_room"]["_id"]


def _feat_base_payload(message: str, thread_id: Optional[str] = None) -> dict:
    swm = FEAT_SWARM_ID if FEAT_SWARM_ID and FEAT_SWARM_ID != "null" else None
    return {
        "sender": FEAT_USER_ID,
        "guest_sender": None,
        "guest_name": None,
        "thread_id": thread_id,
        "message": message,
        "deployment_id": FEAT_DEPLOYMENT_ID,
        "swarm_id": swm,
    }


def _feat_parse_query_response(raw: str) -> tuple:
    """Extract (sql_query, query_output) from the agent response — DETERMINISTIC, strict.

    The agent MUST return a STRICT JSON envelope (no prose, no markdown fences):
        {"sql_query": "<SELECT ...>", "query_output": [ {..row..}, ... ]}
    We parse exactly that schema. We do NOT scrape prose with regex (non-deterministic),
    and we do NOT fabricate a result on failure. On any parse/schema violation we raise
    ValueError so the caller fails loud with {"error": ...} (NO FABRICATION).

    The chart prompt / query prompt MUST instruct the agent to emit ONLY this JSON object.
    Note: `query_output` here is the agent's claimed data; the caller MUST still execute
    `sql_query` against the real SQLite DB before trusting/persisting it (see query_generator).
    """
    candidate = raw.strip()
    # If the agent wrapped JSON in a ```json fence, strip exactly that fence (no prose scraping).
    if candidate.startswith("```"):
        first_nl = candidate.find("\n")
        if first_nl != -1:
            candidate = candidate[first_nl + 1:]
        if candidate.rstrip().endswith("```"):
            candidate = candidate.rstrip()[:-3]
        candidate = candidate.strip()
    try:
        parsed = json.loads(candidate)
    except (json.JSONDecodeError, ValueError) as e:
        raise ValueError(f"Agent did not return the strict JSON envelope: {e}")
    if not isinstance(parsed, dict):
        raise ValueError("Agent response envelope must be a JSON object with keys 'sql_query' and 'query_output'.")
    if "sql_query" not in parsed or "query_output" not in parsed:
        raise ValueError("Agent response missing required keys 'sql_query' and/or 'query_output'.")
    sql_query = parsed["sql_query"]
    query_output = parsed["query_output"]
    if not isinstance(sql_query, str) or not sql_query.strip():
        raise ValueError("Envelope 'sql_query' must be a non-empty string.")
    if not isinstance(query_output, list):
        raise ValueError("Envelope 'query_output' must be a JSON array.")
    return sql_query.strip(), query_output


def check_env() -> dict:
    """Verify that required environment variables are set.
    API_PATH and CHAT_API_PATH are REQUIRED (no defaults, no host literals) — if either
    is missing the feature fails loud. USER_JWT_TOKEN, USER_ID, DEPLOYMENT_ID are also
    required for agent API calls.
    """
    missing = []
    for var in ["API_PATH", "CHAT_API_PATH", "USER_JWT_TOKEN", "USER_ID", "DEPLOYMENT_ID"]:
        if not os.environ.get(var):
            missing.append(var)
    return {"ok": len(missing) == 0, "missing": missing}


def _feat_guard_env() -> dict | None:
    """Return error dict if required env vars are missing, else None."""
    env = check_env()
    if not env["ok"]:
        return {"error": f"Analytics not configured. Missing env vars: {', '.join(env['missing'])}. Ensure USER_JWT_TOKEN, USER_ID, DEPLOYMENT_ID, API_PATH, CHAT_API_PATH are set."}
    return None


def get_db_structure(db: Session) -> dict:
    """Introspect the project SQLite database and return its schema.
    Use this to get db_structure before calling query_generator or handle_widget_request.
    """
    try:
        from sqlalchemy import inspect as sa_inspect
        inspector = sa_inspect(db.get_bind())
        structure = []
        for table_name in inspector.get_table_names():
            columns = inspector.get_columns(table_name)
            structure.append({
                "tableName": table_name,
                "table_description": f"Table: {table_name}",
                "tableColumns": [{"name": col["name"], "type": str(col["type"])} for col in columns],
            })
        return {"db_structure": structure}
    except Exception as e:
        return {"error": str(e), "db_structure": []}


def _feat_save_history(
    db: Session,
    question: str,
    feature_type: str,
    status: str,
    sql_query: str = None,
    query_output: list = None,
    result: str = None,
    error_msg: str = None,
) -> int:
    """Save an analytics query attempt to the local SQLite DB. Always called — success, error, or partial."""
    import json as _j
    try:
        from models import AnalyticsHistoryModel
        record = AnalyticsHistoryModel(
            question=question,
            feature_type=feature_type,
            sql_query=sql_query,
            query_output_json=_j.dumps(query_output) if query_output else None,
            result=result,
            status=status,
            error_msg=error_msg,
        )
        db.add(record)
        db.commit()
        db.refresh(record)
        return record.id
    except Exception as e:
        # History saving is non-negotiable — a failure must be OBSERVABLE, never silent.
        # Return -1 to signal failure AND log it so the guarantee is real.
        db.rollback()
        import logging as _logging
        _logging.getLogger(__name__).error(
            "ANALYTICS HISTORY SAVE FAILED (question=%r, feature=%r, status=%r): %s",
            question, feature_type, status, e,
        )
        return -1


def get_analytics_history(db: Session, limit: int = 50) -> dict:
    """Fetch analytics query history from the local DB, newest first."""
    try:
        from models import AnalyticsHistoryModel
        from sqlalchemy import desc
        records = db.query(AnalyticsHistoryModel).order_by(desc(AnalyticsHistoryModel.created_at)).limit(limit).all()
        return {"history": [r.to_dict() for r in records]}
    except Exception as e:
        return {"history": [], "error": str(e)}


def delete_analytics_history(db: Session, history_id: int) -> dict:
    """Delete a single analytics history record by id."""
    try:
        from models import AnalyticsHistoryModel
        record = db.query(AnalyticsHistoryModel).filter(AnalyticsHistoryModel.id == history_id).first()
        if not record:
            return {"error": f"History record {history_id} not found"}
        db.delete(record)
        db.commit()
        return {"deleted": True, "id": history_id}
    except Exception as e:
        db.rollback()
        return {"error": str(e)}


def get_query_history(db: Session, limit: int = 20) -> dict:
    """Alias for get_analytics_history — kept for backwards compatibility."""
    return get_analytics_history(db, limit=limit)


def get_feature_config(db: Session) -> dict:
    """Return analytics feature configuration from environment."""
    env_check = check_env()
    return {
        "deployment_id": FEAT_DEPLOYMENT_ID,
        "swarm_id": FEAT_SWARM_ID if FEAT_SWARM_ID and FEAT_SWARM_ID != "null" else None,
        "user_id": FEAT_USER_ID,
        "ready": bool(FEAT_DEPLOYMENT_ID and FEAT_USER_ID),
        "env_ok": env_check["ok"],
        "env_missing": env_check.get("missing", []),
    }


def answer_from_agent(db: Session, message: str) -> dict:
    """Get a direct answer from the agent (non-streaming)."""
    err = _feat_guard_env()
    if err: return err
    try:
        _feat_create_room()
        # FIXED CONTRACT endpoint path — verbatim, never invented.
        url = f"{FEAT_CHAT_API_URL}/deployment_stream_kogo_os"
        resp = requests.post(url, json=_feat_base_payload(message), headers=_feat_headers(), timeout=60)
        resp.raise_for_status()
        return {"response": resp.json()}
    except Exception as e:
        return {"error": str(e)}


def answer_from_agent_stream(db: Session, message: str) -> dict:
    """Get a direct answer from the agent via SSE streaming (accumulates full reply)."""
    err = _feat_guard_env()
    if err: return err
    try:
        _feat_create_room()
        # FIXED CONTRACT endpoint path — verbatim, never invented.
        url = f"{FEAT_CHAT_API_URL}/deployment_stream_kogo_os_stream"
        full_response = ""
        with requests.post(url, json=_feat_base_payload(message), headers=_feat_headers(), stream=True, timeout=90) as resp:
            resp.raise_for_status()
            for chunk in resp.iter_content(chunk_size=None, decode_unicode=True):
                if chunk:
                    raw = chunk if isinstance(chunk, str) else chunk.decode("utf-8", errors="replace")
                    for line in raw.splitlines():
                        if not line.strip().startswith("data:"):
                            continue
                        try:
                            parsed = json.loads(line.strip()[5:].strip())
                            data = parsed.get("data") or {}
                            # FIXED CONTRACT SSE fields — verbatim, never invented:
                            # type == "streaming" | "final"; field == "boatReply".
                            if parsed.get("type") == "streaming" and data.get("boatReply"):
                                full_response += data["boatReply"]
                            elif parsed.get("type") == "final" and data.get("boatReply"):
                                full_response = data["boatReply"]
                        except (json.JSONDecodeError, KeyError):
                            pass
        return {"response": full_response}
    except Exception as e:
        return {"error": str(e)}


def _feat_run_sql(db: Session, sql_query: str) -> list:
    """Execute a read-only SELECT against the project's real SQLite DB and return rows
    as a list of dicts. DETERMINISTIC source of truth for query_output.

    Guards (fail loud, never fabricate):
    - Only a single SELECT is allowed; any other statement (INSERT/UPDATE/DELETE/DROP/
      multiple statements) raises ValueError.
    """
    stripped = sql_query.strip().rstrip(";").strip()
    if ";" in stripped:
        raise ValueError("Only a single SQL statement is allowed.")
    if not stripped.lower().startswith("select"):
        raise ValueError("Only read-only SELECT queries may be executed.")
    from sqlalchemy import text as _sa_text
    rows = db.execute(_sa_text(stripped)).mappings().all()
    return [dict(r) for r in rows]


def query_generator(db: Session, user_question: str, db_structure: list = None) -> dict:
    """Generate SQL via streaming agent, EXECUTE it against the real SQLite DB, persist, and
    return record_id + the actually-executed data.

    DETERMINISTIC / NO FABRICATION: query_output ALWAYS comes from running sql_query against
    the project DB — never from the agent's claimed result. On parse or execution failure we
    return {"error": ...}; we never return fabricated query_output.
    """
    err = _feat_guard_env()
    if err: return err
    if not db_structure:
        db_structure = get_db_structure(db).get("db_structure", [])
    try:
        _feat_create_room()

        # Build message for agent. Require a STRICT JSON envelope back (see _feat_parse_query_response).
        user_question_obj = {
            "credentials": {"ref_database_type": "SQLite"},
            "input": (
                f"User question is: {user_question}. Write a single read-only SQLite SELECT "
                f"query based ONLY on these tables/columns: {json.dumps(db_structure)}. "
                "Respond with ONLY a JSON object (no prose, no markdown) of the exact form: "
                '{"sql_query": "<SELECT ...>", "query_output": []}.'
            ),
        }
        message = json.dumps(user_question_obj)

        # FIXED CONTRACT endpoint path — verbatim, never invented.
        url = f"{FEAT_CHAT_API_URL}/deployment_stream_kogo_os_stream"
        full_response = ""
        with requests.post(url, json=_feat_base_payload(message), headers=_feat_headers(), stream=True, timeout=120) as resp:
            resp.raise_for_status()
            for chunk in resp.iter_content(chunk_size=None, decode_unicode=True):
                if chunk:
                    raw_chunk = chunk if isinstance(chunk, str) else chunk.decode("utf-8", errors="replace")
                    for line in raw_chunk.splitlines():
                        if not line.strip().startswith("data:"):
                            continue
                        try:
                            sse_parsed = json.loads(line.strip()[5:].strip())
                            sse_data = sse_parsed.get("data") or {}
                            # FIXED CONTRACT SSE fields: type "streaming"/"final", field "boatReply"
                            if sse_parsed.get("type") == "streaming" and sse_data.get("boatReply"):
                                full_response += sse_data["boatReply"]
                            elif sse_parsed.get("type") == "final" and sse_data.get("boatReply"):
                                full_response = sse_data["boatReply"]
                        except (json.JSONDecodeError, KeyError):
                            pass

        # Strict parse — raises ValueError on any schema violation (fail loud).
        sql_query, _agent_claimed_output = _feat_parse_query_response(full_response)

        # Execute the generated SQL against the REAL DB — this is the only trusted source of data.
        # If the agent hallucinated a column/table, this raises and we return {"error": ...}.
        query_output = _feat_run_sql(db, sql_query)

        # Persist via gateway. FIXED CONTRACT — verbatim, never invented: GraphQL mutation
        # `saveAgentQueryResult` and input type `AgentQueryResultInput`. Surface save errors
        # (do NOT swallow silently) so the history guarantee stays observable.
        record_id = None
        save_error = None
        try:
            save_payload = {
                "query": "mutation SaveAgentQueryResult($fields: AgentQueryResultInput) {\n  saveAgentQueryResult(fields: $fields) {\n    _id\n  }\n}",
                "variables": {
                    "fields": {
                        "user_id": FEAT_USER_ID,
                        "deployment_id": FEAT_DEPLOYMENT_ID,
                        "swarm_id": FEAT_SWARM_ID or None,
                        "user_question": user_question,
                        "sql_query": sql_query,
                        "query_output": query_output,
                    }
                }
            }
            save_resp = requests.post(FEAT_GATEWAY_URL, json=save_payload, headers=_feat_headers(), timeout=30)
            save_resp.raise_for_status()
            record_id = save_resp.json()["data"]["saveAgentQueryResult"]["_id"]
        except Exception as save_exc:
            # Surface, never swallow. The result is still returned, but the failure is observable.
            save_error = str(save_exc)
            import logging as _logging
            _logging.getLogger(__name__).error("saveAgentQueryResult failed: %s", save_error)

        result = {
            "record_id": record_id,
            "sql_query": sql_query,
            "query_output": query_output,
        }
        if save_error:
            result["save_error"] = save_error
        return result
    except Exception as e:
        return {"error": str(e)}


def _feat_extract_text(raw) -> str:
    """Extract plain text from deployment_stream_kogo_os response.
    The endpoint returns a dict like {"boatReply": "...", "chat_id": "...", ...}
    Always extract boatReply — never return the raw dict to the frontend.
    """
    if isinstance(raw, dict):
        return (raw.get("boatReply") or raw.get("message") or raw.get("response") or "").strip()
    return str(raw).strip()


# Fixed allowed chart enum — the ONLY values generate_graph may ever return.
_FEAT_CHART_ENUM = (
    "bar", "grouped_bar", "stacked_bar", "line", "area", "scatter", "bubble",
    "pie", "donut", "sunburst", "treemap", "histogram", "box", "violin", "strip",
    "heatmap", "density_heatmap", "contour", "candlestick", "choropleth",
    "scatter_geo", "mapbox", "funnel", "indicator", "table", "timeline", "icicle",
    "parcats", "parcoords",
)
_FEAT_CHART_DEFAULT = "bar"  # the ONE deterministic fallback


def _feat_classify_columns(query_output: list) -> dict:
    """Classify each column by role from the actual data: 'date', 'numeric', or 'categorical'.
    DETERMINISTIC: same rows → same classification."""
    import re as _re
    cols = list(query_output[0].keys())
    roles = {}
    date_re = _re.compile(r"^\d{4}-\d{2}(-\d{2})?([ T].*)?$")
    for c in cols:
        vals = [r.get(c) for r in query_output if r.get(c) is not None]
        if not vals:
            roles[c] = "categorical"
            continue
        is_num = all(isinstance(v, (int, float)) and not isinstance(v, bool) for v in vals)
        is_date = all(isinstance(v, str) and date_re.match(v.strip()) for v in vals)
        roles[c] = "date" if is_date else ("numeric" if is_num else "categorical")
    return roles


def _feat_chart_from_shape(query_output: list) -> str:
    """DETERMINISTIC data-shape → chart rule table. Returns a value from _FEAT_CHART_ENUM.

    Rules (first match wins):
    - single scalar (1 row, 1 numeric column)            → indicator
    - exactly 1 date/time column + >=1 numeric column    → line
    - exactly 2 numeric columns, no categorical/date     → scatter
    - exactly 1 categorical + exactly 1 numeric column   → bar  (pie if it reads as a share)
    - anything else                                       → bar (the single default)
    """
    if not query_output:
        return _FEAT_CHART_DEFAULT
    roles = _feat_classify_columns(query_output)
    n_date = sum(1 for r in roles.values() if r == "date")
    n_num = sum(1 for r in roles.values() if r == "numeric")
    n_cat = sum(1 for r in roles.values() if r == "categorical")
    if len(roles) == 1 and n_num == 1 and len(query_output) == 1:
        return "indicator"
    if n_date == 1 and n_num >= 1:
        return "line"
    if n_num == 2 and n_cat == 0 and n_date == 0:
        return "scatter"
    if n_cat == 1 and n_num == 1:
        return "bar"
    return _FEAT_CHART_DEFAULT


def generate_graph(db: Session, query_output: list, user_question: str) -> dict:
    """Determine the chart type for the given query output — DETERMINISTIC.

    The chart type is decided by a data-shape rule table (_feat_chart_from_shape). The agent
    is only consulted as a SUGGESTION; its reply is validated against the fixed allowed enum
    (_FEAT_CHART_ENUM). Any invalid/unparseable suggestion is discarded in favour of the
    shape-derived type, with a single defined default ("bar"). The returned chart_type is
    ALWAYS a valid enum member, so the label can never mismatch the rendered chart.
    """
    err = _feat_guard_env()
    if err: return err
    if not query_output:
        return {"error": "query_output is empty — run query_generator first to get data, then pass query_output here"}

    # Deterministic baseline from the data shape — this is the source of truth.
    shape_chart = _feat_chart_from_shape(query_output)
    try:
        _feat_create_room()
        chart_prompt = (
            "Based on user input select 1 chart we have these options: "
            + ", ".join(f"'{c}'" for c in _FEAT_CHART_ENUM) + "; "
            "In return give ONLY the single selected chart type token, no other words."
        )
        message = json.dumps({"input": json.dumps(query_output), "user_question": user_question, "prompt": chart_prompt})
        # FIXED CONTRACT endpoint path — verbatim, never invented.
        url = f"{FEAT_CHAT_API_URL}/deployment_stream_kogo_os"
        resp = requests.post(url, json=_feat_base_payload(message), headers=_feat_headers(), timeout=60)
        resp.raise_for_status()
        raw = _feat_extract_text(resp.json())
    except Exception:
        # Agent unavailable — fall back to the deterministic shape-derived chart, never error here.
        return {"chart_type": shape_chart}

    # Validate the suggestion against the fixed enum. Accept ONLY an exact token match.
    suggestion = (raw or "").strip().lower()
    chart_type = suggestion if suggestion in _FEAT_CHART_ENUM else shape_chart
    return {"chart_type": chart_type}


_REPORT_PROMPT = """<div>You are a Data Analyst agent. Your primary role is to review the user query and the tables involved, and the results returned by the SQL query. From these elements, you will produce a comprehensive, elaborate structured report containing both an in-depth analysis and a direct answer to the user's question.</div><div>Steps</div><div>1. Interpret the User Query</div><div>Identify the user's main objective or question (e.g., comparing pass vs. fail counts for a given agent).</div><div>2. Review Table References and Columns</div><div>Note the table name(s) and relevant columns so you understand the context of the returned data.</div><div>3. Examine Query Results</div><div>Carefully read and interpret the actual data produced by the backend query. Focus on key metrics, patterns, anomalies, or other pertinent observations.</div><div>4. Generate Report</div><div>&nbsp; &nbsp; * Analysis Section: Provide a detailed explanation of the data, highlighting important findings, potential reasons behind trends, and any implications for performance or decision-making.</div><div>&nbsp; &nbsp; * Answer Section: Directly address the user's question or request using data-backed conclusions.</div><div>Output Format</div><div>Your final response should be a written report in markdown format that includes:</div><div>* Short Answer: Concise conclusion or result that specifically resolves the user's query.</div><div>* Detailed Analysis: Thorough breakdown of the data and any insights drawn from it.</div><div>* Deeper Analysis : Based on the data and the query suggest 4 follow up questions you can ask for further analysis on the data</div><div>Notes</div><div>* You do not need to generate the SQL query; it is already created in the backend. Focus solely on interpreting the table schema, query results, and user query to produce your analysis.</div><div>* Keep your explanations clear, data-driven, and aligned with the user's needs.</div>

Query Result Data:
{query_result_data}

User Question: {user_question}"""


def generate_report(db: Session, query_output: list, user_question: str) -> dict:
    """Generate a detailed markdown report from query output."""
    err = _feat_guard_env()
    if err: return err
    if not query_output:
        return {"error": "query_output is empty — run query_generator first to get data, then pass query_output here"}
    try:
        _feat_create_room()
        message = _REPORT_PROMPT.format(
            query_result_data=json.dumps(query_output),
            user_question=user_question
        )
        # FIXED CONTRACT endpoint path — verbatim, never invented.
        url = f"{FEAT_CHAT_API_URL}/deployment_stream_kogo_os"
        resp = requests.post(url, json=_feat_base_payload(message), headers=_feat_headers(), timeout=90)
        resp.raise_for_status()
        return {"report": _feat_extract_text(resp.json())}
    except Exception as e:
        return {"error": str(e)}


_SUMMARY_PROMPT = """You are an AI assistant that writes an ultra-concise summary for a dashboard widget from the TABULAR result of a SQL query. Your output must include exactly these three sections:
Title: One short, specific title naming the metric/dimension shown by the data.
Key Bullet Points: Provide EXACTLY 3 bullet points. Each bullet is one concise sentence stating a concrete, data-backed observation drawn from the rows below (e.g. the largest value, a notable comparison, or a clear trend). Do not invent data not present in the rows.
Conclusion: One sentence stating the single most important takeaway that answers the user's question.
Keep the language clear, precise, and instantly readable on a dashboard. Use only the data provided; do not fabricate figures.

Query Result Data (rows from the executed SQL):
{query_result_data}

User Question: {user_question}"""


def generate_summary(db: Session, query_output: list, user_question: str) -> dict:
    """Generate a concise dashboard summary from query output."""
    err = _feat_guard_env()
    if err: return err
    if not query_output:
        return {"error": "query_output is empty — run query_generator first to get data, then pass query_output here"}
    try:
        _feat_create_room()
        message = _SUMMARY_PROMPT.format(
            query_result_data=json.dumps(query_output),
            user_question=user_question
        )
        # FIXED CONTRACT endpoint path — verbatim, never invented.
        url = f"{FEAT_CHAT_API_URL}/deployment_stream_kogo_os"
        resp = requests.post(url, json=_feat_base_payload(message), headers=_feat_headers(), timeout=60)
        resp.raise_for_status()
        return {"summary": _feat_extract_text(resp.json())}
    except Exception as e:
        return {"error": str(e)}


def handle_widget_request(db: Session, user_question: str, feature_type: str, db_structure: list = None) -> dict:
    """End-to-end orchestrator: routes user question to the correct feature pipeline.

    feature_type: "answer" | "answer_stream" | "query" | "graph" | "report" | "summary"

    ALWAYS saves the attempt to analytics_history (local SQLite) regardless of outcome.
    This ensures the user can always review past queries — even failed or partial ones.
    The save result is OBSERVABLE: every returned dict carries `history_saved` (True if the
    row persisted, False if _feat_save_history failed — which is also logged). The save
    guarantee is never silently dropped.
    """
    err = _feat_guard_env()
    if err:
        hid = _feat_save_history(db, user_question, feature_type or "unknown", "error", error_msg=err["error"])
        return {**err, "history_saved": hid != -1}

    feature_type = (feature_type or "").lower().strip()

    # Answer features — save response, no SQL/query_output
    if feature_type in ("answer", "answer_stream"):
        if feature_type == "answer":
            result = answer_from_agent(db, user_question)
        else:
            result = answer_from_agent_stream(db, user_question)
        status = "error" if "error" in result else "success"
        hid = _feat_save_history(db, user_question, feature_type, status,
                                 result=str(result.get("response", "")), error_msg=result.get("error"))
        result["history_saved"] = hid != -1
        return result

    # Auto-fetch db_structure
    if not db_structure:
        db_structure = get_db_structure(db).get("db_structure", [])

    if feature_type == "query":
        result = query_generator(db, user_question, db_structure)
        status = "error" if "error" in result else ("partial" if not result.get("query_output") else "success")
        hid = _feat_save_history(db, user_question, feature_type, status,
                                 sql_query=result.get("sql_query"),
                                 query_output=result.get("query_output"),
                                 error_msg=result.get("error"))
        result["history_saved"] = hid != -1
        return result

    if feature_type in ("graph", "report", "summary"):
        query_res = query_generator(db, user_question, db_structure)
        q_out = query_res.get("query_output", [])

        if "error" in query_res:
            # Query step failed — save as error, still return
            hid = _feat_save_history(db, user_question, feature_type, "error",
                                     sql_query=query_res.get("sql_query"),
                                     error_msg=query_res.get("error"))
            query_res["history_saved"] = hid != -1
            return query_res

        # Query succeeded — now run widget step
        if feature_type == "graph":
            widget_res = generate_graph(db, q_out, user_question)
        elif feature_type == "report":
            widget_res = generate_report(db, q_out, user_question)
        else:
            widget_res = generate_summary(db, q_out, user_question)

        merged = {**query_res, **widget_res}
        status = "error" if "error" in widget_res else ("partial" if not q_out else "success")
        result_text = (widget_res.get("chart_type") or widget_res.get("report") or
                       widget_res.get("summary") or widget_res.get("error", ""))
        hid = _feat_save_history(db, user_question, feature_type, status,
                                 sql_query=query_res.get("sql_query"),
                                 query_output=q_out,
                                 result=str(result_text)[:2000],  # cap at 2000 chars
                                 error_msg=widget_res.get("error"))
        merged["history_saved"] = hid != -1
        return merged

    unknown_err = {"error": f"Unknown feature_type: '{feature_type}'. Use: answer, answer_stream, query, graph, report, summary"}
    hid = _feat_save_history(db, user_question, feature_type, "error", error_msg=unknown_err["error"])
    return {**unknown_err, "history_saved": hid != -1}
```

Also register in `FUNCTIONS` dict:

```python
# Add to existing FUNCTIONS dict:
"check_env": check_env,
"get_feature_config": get_feature_config,
"get_db_structure": get_db_structure,
"get_analytics_history": get_analytics_history,
"delete_analytics_history": delete_analytics_history,
"get_query_history": get_query_history,
"answer_from_agent": answer_from_agent,
"answer_from_agent_stream": answer_from_agent_stream,
"handle_widget_request": handle_widget_request,
"query_generator": query_generator,
"generate_graph": generate_graph,
"generate_report": generate_report,
"generate_summary": generate_summary,
```

---

### Step 2 — Frontend Component

Create `frontend/src/components/AnalyticsDashboard.tsx`:

```tsx
import { useState, useCallback, useEffect } from "react";
import { BarChart2, FileText, Layers, MessageCircle, Send, Loader, Clock, Trash2, RotateCcw } from "lucide-react";
import { callApi } from "../services/api";
// @ts-ignore
import Plot from "react-plotly.js";

type FeatureType = "answer" | "query" | "graph" | "report" | "summary";

interface HistoryItem {
  id: number;
  question: string;
  feature_type: string;
  sql_query?: string;
  query_output?: any[];
  result?: string;
  status: "success" | "error" | "partial";
  error_msg?: string;
  created_at?: string;
}

// Build Plotly traces from query_output array + chart type string.
// DETERMINISTIC: x/y are chosen by column ROLE (categorical/date → x; numeric → y series),
// NOT by positional column order (SQL column order is unstable).
function classifyColumns(data: any[]): { dateCols: string[]; numCols: string[]; catCols: string[] } {
  const keys = Object.keys(data[0]);
  const dateRe = /^\d{4}-\d{2}(-\d{2})?([ T].*)?$/;
  const dateCols: string[] = [], numCols: string[] = [], catCols: string[] = [];
  for (const k of keys) {
    const vals = data.map(r => r[k]).filter(v => v !== null && v !== undefined);
    if (!vals.length) { catCols.push(k); continue; }
    const isNum = vals.every(v => typeof v === "number" || (typeof v === "string" && v.trim() !== "" && !isNaN(Number(v))));
    const isDate = vals.every(v => typeof v === "string" && dateRe.test(v.trim()));
    if (isDate) dateCols.push(k);
    else if (isNum) numCols.push(k);
    else catCols.push(k);
  }
  return { dateCols, numCols, catCols };
}

function buildPlotlyData(data: any[], chartType: string): { traces: any[]; layout: any } {
  if (!data?.length) return { traces: [], layout: {} };
  const { dateCols, numCols, catCols } = classifyColumns(data);
  // x-axis: prefer a date column, then a categorical column (deterministic, by role not index).
  const xKey = dateCols[0] ?? catCols[0] ?? numCols[0];
  // y series: all numeric columns except whichever one was used as x.
  const yKeys = numCols.filter(k => k !== xKey);
  if (!yKeys.length || !xKey) return { traces: [], layout: {} };

  const ct = chartType.toLowerCase();
  const xVals = data.map(r => r[xKey]);

  let traces: any[] = [];
  if (["pie", "donut"].includes(ct)) {
    traces = [{ type: "pie", labels: xVals, values: data.map(r => Number(r[yKeys[0]])), hole: ct === "donut" ? 0.45 : 0 }];
  } else if (ct === "scatter") {
    traces = yKeys.map(yk => ({ type: "scatter", mode: "markers", x: xVals, y: data.map(r => Number(r[yk])), name: yk }));
  } else if (ct === "line" || ct === "area") {
    traces = yKeys.map(yk => ({ type: "scatter", mode: "lines+markers", fill: ct === "area" ? "tozeroy" : "none", x: xVals, y: data.map(r => Number(r[yk])), name: yk }));
  } else if (ct === "histogram") {
    traces = yKeys.map(yk => ({ type: "histogram", x: data.map(r => Number(r[yk])), name: yk }));
  } else {
    // default bar (grouped_bar, stacked_bar, bar)
    const barmode = ct === "stacked_bar" ? "stack" : ct === "grouped_bar" ? "group" : "group";
    traces = yKeys.map(yk => ({ type: "bar", x: xVals, y: data.map(r => Number(r[yk])), name: yk }));
    return { traces, layout: { barmode, xaxis: { title: xKey }, yaxis: { title: yKeys[0] } } };
  }
  return { traces, layout: { xaxis: { title: xKey }, yaxis: { title: yKeys[0] } } };
}

export default function AnalyticsDashboard() {
  const [activeFeature, setActiveFeature] = useState<FeatureType>("query");
  const [question, setQuestion] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [widgetResult, setWidgetResult] = useState<any>(null);
  const [answerResult, setAnswerResult] = useState<string | null>(null);
  const [history, setHistory] = useState<HistoryItem[]>([]);

  const loadHistory = useCallback(() => {
    callApi("get_analytics_history", { limit: 50 }).then(res => {
      if (res.success && res.data?.history) setHistory(res.data.history);
    });
  }, []);

  // Load history on mount
  useEffect(() => { loadHistory(); }, [loadHistory]);

  const deleteHistory = useCallback(async (id: number) => {
    const res = await callApi("delete_analytics_history", { history_id: id });
    if (res.success) setHistory(prev => prev.filter(h => h.id !== id));
  }, []);

  const features = [
    { id: "answer" as FeatureType, label: "Ask Agent", icon: <MessageCircle size={15} /> },
    { id: "query" as FeatureType, label: "Query Data", icon: <Layers size={15} /> },
    { id: "graph" as FeatureType, label: "Visualize", icon: <BarChart2 size={15} /> },
    { id: "report" as FeatureType, label: "Report", icon: <FileText size={15} /> },
    { id: "summary" as FeatureType, label: "Summary", icon: <FileText size={15} /> },
  ];

  const run = useCallback(async () => {
    if (!question.trim()) return;
    setLoading(true);
    setError(null);
    setWidgetResult(null);
    setAnswerResult(null);

    try {
      const res = await callApi("handle_widget_request", {
        user_question: question,
        feature_type: activeFeature,
        // db_structure omitted — backend auto-fetches from the project DB
      });

      if (!res.success) {
        setError(res.data?.error || res.message || "Request failed");
        loadHistory(); // even failed attempts are saved
        return;
      }

      const d = res.data;

      if (activeFeature === "answer") {
        setAnswerResult(typeof d?.response === "string" ? d.response : JSON.stringify(d?.response ?? "", null, 2));
        return;
      }
      if (activeFeature === "query") {
        setWidgetResult({ type: "table", data: d?.query_output || [], sql: d?.sql_query || "" });
        loadHistory();
        return;
      }
      if (activeFeature === "graph") {
        setWidgetResult({ type: "graph", chart_type: d?.chart_type || "bar", data: d?.query_output || [], sql: d?.sql_query || "" });
        loadHistory();
        return;
      }
      if (activeFeature === "report") {
        setWidgetResult({ type: "report", content: typeof d?.report === "string" ? d.report : JSON.stringify(d?.report ?? "", null, 2) });
        return;
      }
      if (activeFeature === "summary") {
        setWidgetResult({ type: "summary", content: typeof d?.summary === "string" ? d.summary : JSON.stringify(d?.summary ?? "", null, 2) });
        return;
      }
    } finally {
      setLoading(false);
    }
  }, [question, activeFeature]);

  const card = { background: "#fff", border: "1px solid #E5E7EB", borderRadius: 8, padding: 20, marginBottom: 16 };
  const label = { fontSize: 11, fontWeight: 600, color: "#6B7280", textTransform: "uppercase" as const, letterSpacing: "0.05em", marginBottom: 10 };

  return (
    <div style={{ padding: 24, maxWidth: 960, fontFamily: "inherit" }}>
      <div style={{ marginBottom: 20 }}>
        <h2 style={{ fontSize: 18, fontWeight: 700, margin: "0 0 4px" }}>Analytics</h2>
        <p style={{ fontSize: 13, color: "#6B7280", margin: 0 }}>Ask questions about your data</p>
      </div>

      {/* Feature tabs */}
      <div style={{ display: "flex", gap: 6, marginBottom: 16, flexWrap: "wrap" }}>
        {features.map(f => (
          <button key={f.id} onClick={() => { setActiveFeature(f.id); setWidgetResult(null); setAnswerResult(null); }}
            style={{ display: "flex", alignItems: "center", gap: 5, padding: "7px 14px", border: `1px solid ${activeFeature === f.id ? "#3B82F6" : "#E5E7EB"}`, borderRadius: 8, background: activeFeature === f.id ? "#EFF6FF" : "#fff", color: activeFeature === f.id ? "#3B82F6" : "#6B7280", fontSize: 13, cursor: "pointer", fontWeight: activeFeature === f.id ? 600 : 400 }}>
            {f.icon} {f.label}
          </button>
        ))}
      </div>

      {/* Input */}
      <div style={{ display: "flex", gap: 8, marginBottom: 20 }}>
        <input value={question} onChange={e => setQuestion(e.target.value)} onKeyDown={e => { if (e.key === "Enter") run(); }}
          placeholder={activeFeature === "answer" ? "Ask the agent anything..." : "Ask a data question..."}
          style={{ flex: 1, padding: "10px 14px", border: "1px solid #E5E7EB", borderRadius: 8, fontSize: 13, outline: "none", fontFamily: "inherit" }} />
        <button onClick={run} disabled={loading || !question.trim()}
          style={{ padding: "10px 18px", background: loading || !question.trim() ? "#E5E7EB" : "#3B82F6", color: loading || !question.trim() ? "#9CA3AF" : "#fff", border: "none", borderRadius: 8, cursor: loading ? "not-allowed" : "pointer", display: "flex", alignItems: "center", gap: 6, fontSize: 13 }}>
          {loading ? <Loader size={14} /> : <Send size={14} />}
          {loading ? "Running..." : "Run"}
        </button>
      </div>

      {/* Error */}
      {error && <div style={{ padding: 12, background: "#FEF2F2", border: "1px solid #FECACA", borderRadius: 8, color: "#DC2626", fontSize: 13, marginBottom: 16 }}>{error}</div>}

      {/* Answer */}
      {answerResult && (
        <div style={card}>
          <div style={label}>Agent Response</div>
          <p style={{ margin: 0, fontSize: 14, color: "#1F2937", lineHeight: 1.7, whiteSpace: "pre-wrap" }}>{answerResult}</p>
        </div>
      )}

      {/* Table */}
      {widgetResult?.type === "table" && (
        <div style={card}>
          {widgetResult.sql && (
            <div style={{ marginBottom: 12, padding: "8px 12px", background: "#F9FAFB", borderRadius: 6, border: "1px solid #E5E7EB" }}>
              <div style={label}>SQL Query</div>
              <code style={{ fontSize: 12, color: "#374151", wordBreak: "break-all" }}>{widgetResult.sql}</code>
            </div>
          )}
          {widgetResult.data?.length > 0 ? (
            <div style={{ overflowX: "auto" }}>
              <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
                <thead>
                  <tr>{Object.keys(widgetResult.data[0]).map((k: string) => (
                    <th key={k} style={{ padding: "8px 12px", background: "#F9FAFB", border: "1px solid #E5E7EB", textAlign: "left", fontWeight: 600, color: "#374151" }}>{k}</th>
                  ))}</tr>
                </thead>
                <tbody>
                  {widgetResult.data.map((row: any, i: number) => (
                    <tr key={i} style={{ background: i % 2 === 0 ? "#fff" : "#F9FAFB" }}>
                      {Object.values(row).map((v: any, j: number) => (
                        <td key={j} style={{ padding: "8px 12px", border: "1px solid #E5E7EB", color: "#374151" }}>{String(v ?? "")}</td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : <p style={{ color: "#9CA3AF", fontSize: 13, margin: 0 }}>No data returned.</p>}
        </div>
      )}

      {/* Graph — actual Plotly chart */}
      {widgetResult?.type === "graph" && (
        <div style={card}>
          <div style={label}>Chart — {widgetResult.chart_type}</div>
          {widgetResult.data?.length > 0 ? (() => {
            const { traces, layout } = buildPlotlyData(widgetResult.data, widgetResult.chart_type);
            return traces.length > 0 ? (
              <Plot
                data={traces}
                layout={{ ...layout, autosize: true, margin: { l: 40, r: 20, t: 30, b: 40 }, paper_bgcolor: "transparent", plot_bgcolor: "transparent", font: { size: 12 } }}
                useResizeHandler
                style={{ width: "100%", height: 360 }}
                config={{ displayModeBar: false, responsive: true }}
              />
            ) : <p style={{ color: "#9CA3AF", fontSize: 13 }}>Could not build chart from data shape.</p>;
          })() : <p style={{ color: "#9CA3AF", fontSize: 13, margin: 0 }}>No data to visualize.</p>}
          {widgetResult.sql && (
            <div style={{ marginTop: 12, padding: "6px 10px", background: "#F9FAFB", borderRadius: 6, border: "1px solid #E5E7EB" }}>
              <code style={{ fontSize: 11, color: "#6B7280" }}>{widgetResult.sql}</code>
            </div>
          )}
        </div>
      )}

      {/* Report / Summary */}
      {(widgetResult?.type === "report" || widgetResult?.type === "summary") && (
        <div style={card}>
          <div style={label}>{widgetResult.type === "report" ? "Analysis Report" : "Summary"}</div>
          <div style={{ fontSize: 14, color: "#1F2937", lineHeight: 1.8, whiteSpace: "pre-wrap" }}>{widgetResult.content}</div>
        </div>
      )}

      {/* Analytics History — always visible when history exists */}
      {history.length > 0 && (
        <div style={{ ...card, marginTop: 24 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 14 }}>
            <Clock size={13} style={{ color: "#6B7280" }} />
            <span style={label}>History ({history.length})</span>
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
            {history.map(h => {
              const statusColor = h.status === "success" ? "#16A34A" : h.status === "partial" ? "#D97706" : "#DC2626";
              const statusBg = h.status === "success" ? "#DCFCE7" : h.status === "partial" ? "#FEF3C7" : "#FEE2E2";
              return (
                <div key={h.id} style={{ display: "flex", alignItems: "flex-start", gap: 8, padding: "10px 12px", background: "#F9FAFB", border: "1px solid #E5E7EB", borderRadius: 8 }}>
                  {/* Status badge */}
                  <span style={{ flexShrink: 0, fontSize: 10, fontWeight: 600, padding: "2px 7px", borderRadius: 999, background: statusBg, color: statusColor, marginTop: 2 }}>
                    {h.status}
                  </span>
                  {/* Question + meta */}
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 13, color: "#1F2937", fontWeight: 500, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{h.question}</div>
                    <div style={{ display: "flex", gap: 8, marginTop: 3, flexWrap: "wrap" }}>
                      <span style={{ fontSize: 11, color: "#6B7280" }}>{h.feature_type}</span>
                      {h.created_at && <span style={{ fontSize: 11, color: "#9CA3AF" }}>{new Date(h.created_at).toLocaleString()}</span>}
                      {h.result && <span style={{ fontSize: 11, color: "#6B7280", maxWidth: 200, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>→ {h.result}</span>}
                      {h.error_msg && <span style={{ fontSize: 11, color: "#DC2626", maxWidth: 200, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{h.error_msg}</span>}
                    </div>
                  </div>
                  {/* Actions */}
                  <div style={{ display: "flex", gap: 4, flexShrink: 0 }}>
                    <button
                      onClick={() => { setQuestion(h.question); setActiveFeature((h.feature_type as FeatureType) || "query"); }}
                      title="Edit and re-run"
                      style={{ padding: "4px 8px", background: "#EFF6FF", border: "1px solid #BFDBFE", borderRadius: 6, cursor: "pointer", color: "#3B82F6" }}>
                      <RotateCcw size={12} />
                    </button>
                    <button
                      onClick={() => deleteHistory(h.id)}
                      title="Delete"
                      style={{ padding: "4px 8px", background: "#FEF2F2", border: "1px solid #FECACA", borderRadius: 6, cursor: "pointer", color: "#DC2626" }}>
                      <Trash2 size={12} />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
```

---

### Step 3 — API Layer

No new exports needed in `api.ts` for feature-module — all calls go through the existing `callApi()` function.

BEFORE generating `AnalyticsDashboard.tsx`, VERIFY the contract: read `frontend/src/services/api.ts`
and confirm it exports `callApi` and that `callApi(fn, params)` resolves to an object shaped
`{ success: boolean, data: any, message?: string }` (the component reads `res.success`, `res.data`,
`res.message`). If the actual export name or return shape differs (e.g. it throws on error, returns
`{ ok, result }`, or uses a different function name), ADAPT the component's calls and destructuring to
the real signature instead of assuming this shape.

---

### Step 4 — App Integration

FIRST READ `frontend/src/App.tsx` and adapt to its ACTUAL routing/tab pattern. Do NOT assume an
`activeTab === "analytics"` placeholder exists — the project may use React Router, a `page`/`view`
state variable, a different tab identifier, or a sidebar. Identify how existing views are mounted,
then wire `AnalyticsDashboard` into that same pattern (matching the real state variable name and the
real route/tab value). The snippet below is ONLY illustrative of one common pattern:

```tsx
import AnalyticsDashboard from "./components/AnalyticsDashboard";

// EXAMPLE ONLY — replace `activeTab`/`"analytics"` with the identifiers actually used in App.tsx:
{activeTab === "analytics" && <AnalyticsDashboard />}
```

---

### Step 5 — Document (append to backend/document.md)

```markdown
---

## Feature Module — Analytics Functions

### `get_feature_config`
Returns analytics config: deployment_id, swarm_id, user_id, ready (bool).
**Params:** none

### `check_env`
Verifies all required env vars are set. Returns `{ ok: bool, missing: [...] }`.
**Params:** none

### `answer_from_agent`
Gets a direct non-streaming answer from the agent.
**Params:** message (str, required)
**Returns:** `{ response: <agent_response> }`

### `answer_from_agent_stream`
Gets an answer via SSE streaming (accumulates full reply server-side).
**Params:** message (str, required)
**Returns:** `{ response: <full_reply_string> }`

### `handle_widget_request`
End-to-end orchestrator — routes question to the right pipeline based on feature_type.
**Params:** user_question (str), feature_type (str: answer|answer_stream|query|graph|report|summary), db_structure (list)
**Returns:** merged result from the pipeline (includes query_output for graph/report/summary)

### `query_generator`
Streams a SQL query via agent, saves result to DB.
**Params:** user_question (str, required), db_structure (list, required — list of {tableName, table_description, tableColumns})
**Returns:** `{ record_id, sql_query, query_output: [...] }`

### `generate_graph`
Determines best chart type for given data.
**Params:** query_output (list, required), user_question (str, required)
**Returns:** `{ chart_type: "bar"|"line"|"pie"|... }`

### `generate_report`
Generates detailed markdown report from query output.
**Params:** query_output (list, required), user_question (str, required)
**Returns:** `{ report: <markdown_string> }`

### `generate_summary`
Generates concise dashboard summary (title + bullets + conclusion).
**Params:** query_output (list, required), user_question (str, required)
**Returns:** `{ summary: <text> }`

### `get_analytics_history`
Fetches all analytics query history from local SQLite DB (newest first).
**Params:** limit (int, optional, default 50)
**Returns:** `{ history: [{ id, question, feature_type, sql_query, query_output, result, status, error_msg, created_at }] }`

### `delete_analytics_history`
Deletes a single history record by id.
**Params:** history_id (int, required)
**Returns:** `{ deleted: true, id: <int> }`

### Feature Decision
| User says | Function |
|---|---|
| "Ask agent X" / "What is X" | answer_from_agent |
| "Query data for X" / "Show me X data" | query_generator |
| "Chart / graph of X" | query_generator → generate_graph |
| "Report on X" | query_generator → generate_report |
| "Summarize X" | query_generator → generate_summary |
```

---

## End-to-End Widget Flow

**Option 1 — Use `handle_widget_request` (recommended)**

Single call routes everything:

```python
result = handle_widget_request(db, user_question="Show sales by region", feature_type="graph", db_structure=[...])
# Returns: { record_id, sql_query, query_output, chart_type, history_saved }
```

**Option 2 — Manual pipeline**

```
User question
  ↓
query_generator(user_question, db_structure)
  → streams SQL via agent → strict-JSON parse → EXECUTES SQL on the real SQLite DB → saves to DB
  → returns { record_id, sql_query, query_output: [...] }  (query_output is the EXECUTED result)
  ↓
generate_graph / generate_report / generate_summary (query_output, user_question)
  → calls agent with data + prompt → returns result
```

**Option 3 — Direct agent answer (no DB/SQL)**

```
answer_from_agent(db, message)          # non-streaming — the DEFAULT
answer_from_agent_stream(db, message)   # SSE stream — ONLY when the frontend explicitly requests streaming
```

Always run `query_generator` first for graph/report/summary — they need `query_output`.
DETERMINISTIC default: use `answer_from_agent` (non-streaming) unless the frontend explicitly passes a streaming flag — do not switch to streaming on your own judgement.
