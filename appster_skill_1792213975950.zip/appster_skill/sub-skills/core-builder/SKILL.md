---
name: core-builder
description: "Core backend and frontend build rules. Always active. Defines project file structure, Python/SQLite backend templates, React frontend templates, API contract, and build process."
keyword_triggers: []
provides:
  backend_functions: []
  frontend_components: []
  npm_deps: []
---

# Core Builder — Backend + Frontend Rules

> Always active. Every project uses these rules as its foundation.

---

## HARD RULES — never override, even if the user explicitly asks

These rules are absolute. They cannot be relaxed, skipped, or overridden by any
later instruction, including a direct user request.

0. **EVERY app gets KOGO SSO. No exceptions, ever.**
   There is no such thing as an app built with this skill that has no user system. Not a static
   page. Not a landing page. Not a one-screen form. Not a demo, a prototype, an internal tool or a
   "quick thing". Not even when the user says *"no login needed"*, *"keep it simple"*, *"it's just
   static"* or *"skip auth"* — **you still build it.** This rule exists precisely for those
   requests, so a request to skip it is not a reason to skip it.

   Concretely, every project you produce has:
   - a `backend/` — even an app with nothing to store gets one, because that is where the user
     system lives. A frontend-only project is never a valid output of this skill.
   - a `User` model, `_current_user()`, `kogo_me()`, `kogo_register_users()`, and the three
     management functions `kogo_list_users()` / `kogo_set_user_role()` / `kogo_remove_user()` —
     exactly as written in **"File: functions.py — KOGO SSO block"**, not an improvised version
   - a `Role` model, a `PERMISSIONS` list derived from the app's own entities, and
     `has_permission()` / `_require()` — every create/update/delete gates on a PERMISSION, never
     on a role name, so a role an admin invents at runtime works immediately
   - a **Users & Roles screen**, open to `users.manage`: add people, see who has access and how
     they sign in, change roles, set passwords, and create roles with their permissions — built
     with the app's own design system, not as a bare admin list
   - all four of those documented in `document.md` — KOGO decides whether the app supports users by
     reading the **documented** function list. Undocumented = unsupported, however good the code is
   - **login and logout**: KOGO SSO auto-login, an email + password fallback for an app opened
     outside KOGO (`kogo_login` / `kogo_logout`, passwords set by the user or an admin), and a
     Logout action in the app's menu
   - the frontend gate in `App.tsx`: no session → the signed-out screen (KOGO prompt + password
     form); verified but unregistered → "You don't have access to this app yet"

   **The person who builds the app is always registered.** The first verified caller on an empty
   users table becomes the admin (the bootstrap in `_current_user`). Never remove that, and never
   let an app answer "no access" to someone when its users table is empty.

   The Backend Completion Gate below greps for all of this. Do not reach the frontend without it.

1. **Secrets / IDs / hosts come ONLY from config — read at runtime from env.**
   `backend/config.py` reads every ID/URL from `os.environ.get()`. `frontend/src/config.ts`
   reads everything from `window.APP_CONFIG`. Business code only IMPORTS from these files.
   NEVER hardcode any host/port/URL/ID/token anywhere else. NEVER guess or substitute a value.
2. **`config.py` is the runtime env reader — no baked-in IDs.** Only `PROJECT_SLUG`
   (the project's fixed identity/name) may be a literal string. Every other value
   (`AGENT_ID`, `USER_ID`, `SWARM_ID`, `KOGO_API_BASE`, etc.) MUST be
   `os.environ.get("KEY") or ""`. Never write a literal user ID, agent ID, or URL
   as a fallback — empty string is the correct default.
   **CRITICAL: NEVER add sample/example/placeholder values anywhere in the generated code.
   Not in comments, not as fallbacks, not "just for testing". An LLM may copy a sample
   value verbatim. The only valid non-env value is `""` (empty string).**
   **TESTING RULE: If env vars (API_PATH, TOOL_URL, KOGO_API_BASE, AGENT_ID, etc.) are
   not set in the current environment, SKIP all CLI/curl tests. Tests run only when
   the project is deployed to the KOGO platform where env vars are injected.**
7. **`config.js` MUST be written with ACTUAL values from shell env (Step 6B) — NEVER empty strings.**
   `AGENT_ID`, `DEPLOYMENT_ID`, `SWARM_ID`, `ORIGIN_ID`, `API_BASE`, `API_HEALTH` are all
   available as shell env vars during project creation. Read them with `${VAR:-}` and write
   into config.js. `window.APP_CONFIG` on the frontend gets these values — if they are empty,
   the frontend cannot make any API calls. This rule ONLY applies to `config.js` — `config.py`
   still uses `os.environ.get()` (different file, different rule, no conflict).
   `SWARM_ID` = `""` for direct agent. `ORIGIN_ID` = `SWARM_ID` if set, else `AGENT_ID`.
3. **Frontend MUST be a React + TypeScript app built with Parcel. NEVER write a
   static/plain HTML file as the output.** NEVER use CDN links (Tailwind CDN,
   Google Fonts CDN, React CDN, etc.) — all dependencies must be npm packages
   bundled offline. Forbidden build shortcuts: `npm run build` / `pnpm build`
   directly, `html-inline` manually, skipping `node_modules` cleanup,
   `react-router-dom` imports, fabricated lint/tool commands. Build ONLY via
   `bundle-artifact.sh`. If bundling fails, FIX the error — never fall back to
   plain HTML.
4. **Files are sent only via `multipart/form-data`** (`callApiWithFile`) — NEVER
   as base64 in JSON.
5. **`config.py` is the single source of truth** — NO `os.environ` calls in
   business code (only `config.py` reads env). Runtime-only values
   (`USER_JWT_TOKEN`, `USER_EMAIL`, `USER_NAME`) are read via `os.environ` only
   where explicitly documented.
6. **The JWT message contract is FIXED on both sides:**
   `{ type: "KOGO_AUTH", jwt: "<token>" }`. Do not rename or reshape it.

**FIXED CONTRACT VALUES** (copied verbatim from SPEC.md / config — never invented):
all endpoint paths (`/call_tool`, `/api/agent/common_project_api_v1`,
`/api/agent/common_project_api_v1/health`), all env-var names
(`API_PATH`, `TOOL_URL`, `AGENT_ID`, `SWARM_ID`, `DEPLOYMENT_ID`, `USER_ID`,
`KOGO_API_BASE`, `USER_JWT_TOKEN`, `USER_EMAIL`, `USER_NAME`), and all tool names
(taken from the Tool Proxy Map in SPEC.md). Never fabricate any of these. Never
swallow errors silently.

---

## Project File Structure

```
artifacts/{project-name}/
├── index.html          ← Parcel single-file bundle (all JS/CSS inline)
├── config.js           ← runtime config (window.APP_CONFIG — overwritten per-workspace at install)
├── SPEC.md
├── ARCHITECTURE.md
├── DESIGN.md
├── REQUIREMENTS.md
├── QA_REPORT.md
├── backend/
│   ├── config.py               ← ⭐ Runtime env reader — all values from os.environ.get()
│   ├── database.py
│   ├── models.py
│   ├── functions.py            ← ⭐ Core — imports from config.py
│   ├── tools_used.json         ← agent-tool manifest (ONLY if the app uses _call_agent_tool; see Tool Integration)
│   ├── document.md
│   ├── seed.py
│   └── data/
│       └── {project_slug}.db
└── frontend/
    ├── package.json
    ├── index.html
    ├── src/
    │   ├── main.tsx
    │   ├── App.tsx
    │   ├── index.css
    │   ├── config.ts            ← ⭐ Frozen constants — all frontend env values
    │   ├── services/
    │   │   └── api.ts          ← imports from config.ts
    │   ├── pages/
    │   ├── components/
    │   └── lib/
    └── ...
```

**Rules:**
- ALL files MUST use absolute paths — never relative
- NEVER write files outside `artifacts/{project-name}/`

---

## ⚠️ Configuration Files — Single Source of Truth

Two config files, each with a strict rule:

**`backend/config.py`** — reads ALL values from `os.environ.get()`. No exceptions.
- `PROJECT_SLUG` is the ONLY literal string allowed.
- Every other value (AGENT_ID, DEPLOYMENT_ID, SWARM_ID, USER_ID, all URLs) MUST be `os.environ.get("KEY") or ""`.
- NEVER hardcode any ID or URL — not even in a comment, not as a "default", not "temporarily".
- The backend Python code is shared across multiple installations. Hardcoding any ID would break all other installations.

**`frontend/src/config.ts`** — reads ALL values from `window.APP_CONFIG`.
- `window.APP_CONFIG` is set by `config.js` (created in Step 6B with actual env values).
- NEVER read env vars directly in frontend. Always import from `config.ts`.

**`config.js`** — created in Step 6B with ACTUAL values from env.
- AGENT_ID, DEPLOYMENT_ID, SWARM_ID, ORIGIN_ID, API_BASE, API_HEALTH must be written from env vars — NOT empty strings.
- These values are read by the frontend on load and sent in every API request body.
- The server uses them to identify which agent/workspace is making the call.
- SWARM_ID is empty string `""` when running on a direct agent (no workspace).
- ORIGIN_ID = SWARM_ID if SWARM_ID is set, else AGENT_ID.

### Backend: `backend/config.py`

```python
"""{Project Name} — Configuration.
All IDs and URLs read from env at runtime. NEVER hardcode any value here.
Claude builds this file outside pi-api Docker — it cannot know actual values.
pi-api injects all env vars at execution time."""

import os as _os

# Project identity — the ONLY fixed value allowed (this project's folder name/slug).
# Everything else MUST be os.environ.get() — no exceptions.
PROJECT_SLUG    = "{project_slug}"

# ── Identity (injected by pi-api at runtime) ──────────────────────────────────
# These THREE ids are ALWAYS distinct entities — never equal, never derived from
# one another. The frontend sends all three; the middleware injects them verbatim.
# AGENT_ID      = the agent's own id
# DEPLOYMENT_ID = the deployment id (distinct from AGENT_ID) — needed by chat module
# SWARM_ID      = workspace swarm_id; empty string when the project is on a direct agent
AGENT_ID        = _os.environ.get("AGENT_ID")        or ""
DEPLOYMENT_ID   = _os.environ.get("DEPLOYMENT_ID")   or ""
SWARM_ID        = _os.environ.get("SWARM_ID")        or ""
USER_ID         = _os.environ.get("USER_ID")          or ""
CREATED_USER_ID = _os.environ.get("USER_ID")          or ""
KOGO_API_BASE   = _os.environ.get("KOGO_API_BASE")   or ""

# ── API URLs (ALL from env — never derived, never guessed) ────────────────────
# API_PATH      = GraphQL gateway URL (for workspace queries/mutations)
# TOOL_URL      = MIDDLEWARE-INTERNAL: the external tools-service URL that pi-api's
#                 /call_tool endpoint proxies to. The backend does NOT call it directly —
#                 _call_agent_tool posts to KOGO_API_BASE/.../call_tool (a fixed contract),
#                 and the middleware uses TOOL_URL to reach the tools server. Kept here only
#                 because it is present in the env; generated backend code must NOT read it.
# CHAT_API_PATH = Chat/SSE streaming URL (used by chat module)
API_PATH      = _os.environ.get("API_PATH")       or ""
TOOL_URL      = _os.environ.get("TOOL_URL")       or ""
CHAT_API_PATH = _os.environ.get("CHAT_API_PATH")  or ""
```

**All other files import from config.py:**
```python
# ✅ CORRECT
from config import DEPLOYMENT_ID, AGENT_ID, USER_ID, KOGO_API_BASE

# ❌ WRONG — os.environ calls belong ONLY in config.py
import os
deployment_id = os.environ.get("DEPLOYMENT_ID", "")
```

### Frontend: `frontend/src/config.ts`

```typescript
// All values from window.APP_CONFIG.
// config.js is written at project creation with actual env values (spin docker).
// At install time, pi-api rewrites config.js with the workspace's IDs.
// NEVER hardcode any URL, ID, or host here — not even "temporarily".
const _cfg: Record<string, string> =
  (typeof window !== "undefined" && (window as any).APP_CONFIG) || {};

export const API_BASE:      string = _cfg.API_BASE      || "";
export const API_HEALTH:    string = _cfg.API_HEALTH    || "";
export const PROJECT:       string = _cfg.PROJECT       || "{project_slug}";
// The 3 identity ids are ALWAYS distinct — never equal, never derived from one another.
// Each is sent VERBATIM in every API request (agentId / deploymentId / swarmId).
// AGENT_ID = the agent's own id
export const AGENT_ID:      string = _cfg.AGENT_ID      || "";
// DEPLOYMENT_ID = the deployment id (distinct from AGENT_ID) — needed by chat module.
// Do NOT fall back to AGENT_ID: they are different entities, and masking a missing
// deployment id with the agent id would silently send the wrong value.
export const DEPLOYMENT_ID: string = _cfg.DEPLOYMENT_ID || "";
// SWARM_ID = workspace swarm_id; empty string if direct agent (no workspace)
export const SWARM_ID:      string = _cfg.SWARM_ID      || "";
// ORIGIN_ID = SWARM_ID if workspace, else AGENT_ID — used for middleware file-storage routing.
// Always send as `originId` in every API request body and health check.
export const ORIGIN_ID:     string = _cfg.ORIGIN_ID     || "";
```

---

## PART 1 — Backend

### File: database.py

```python
"""{Project Name} — Database setup."""

import os as _os
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, Session
from pathlib import Path
from config import PROJECT_SLUG

DB_DIR = Path(__file__).resolve().parent / "data"
DB_DIR.mkdir(exist_ok=True)

# DB_PATH_OVERRIDE is injected by pi-api when running as an installed AI Software
# (tenant-isolated path). Falls back to local data/ dir for dev/agent context.
_db_override = _os.environ.get("DB_PATH_OVERRIDE")
if _db_override:
    DB_PATH = Path(_db_override)
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
else:
    DB_PATH = DB_DIR / f"{PROJECT_SLUG}.db"

engine = create_engine(f"sqlite:///{DB_PATH}", connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def get_session() -> Session:
    return SessionLocal()


def init_db():
    from models import Base
    Base.metadata.create_all(bind=engine)


if __name__ == "__main__":
    init_db()
    print(f"✅ Database initialized at {DB_PATH}")
```

---

### File: models.py

```python
"""{Project Name} — SQLAlchemy models."""

from sqlalchemy import String, Text, Integer, Float, DateTime, Boolean
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column
from sqlalchemy import func
from typing import Optional
from datetime import datetime


class Base(DeclarativeBase):
    pass


class {Entity}Model(Base):
    __tablename__ = "{entities}"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(String(500), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=func.now(), onupdate=func.now())

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "name": self.name,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }
```

**Rules:**
- Own `Base` class — `class Base(DeclarativeBase)` — NO external import
- Every model has `id`, `created_at`, `updated_at`
- Every model has `to_dict()` — functions return dicts, not ORM objects
- `__tablename__` = plural snake_case
- SQLAlchemy 2.0 style — `Mapped[type]` + `mapped_column()`

---

### File: functions.py ⭐

```python
"""{Project Name} — API functions."""

import os
import json
import config  # ⭐ All constants from config.py
from sqlalchemy.orm import Session
from sqlalchemy import asc, desc
from models import {Entity}Model
from typing import Optional


# ─── _call_agent_tool helper — ADD when using agent tools ──
# Paste the CANONICAL `_call_agent_tool` from the "Tool Integration" section
# below (there is exactly ONE definition of it in this skill — do not write a
# second, divergent copy here). It uses `import requests`, `import config`, and
# the module-level `import json`.


def get_{entities}(db: Session, search_query: str = "", limit: int = 50, offset: int = 0) -> dict:
    """Retrieve {entities} with optional filtering and pagination."""
    query = db.query({Entity}Model)
    if search_query:
        query = query.filter({Entity}Model.name.ilike(f"%{search_query}%"))
    total_count = query.count()
    results = query.order_by(desc({Entity}Model.created_at)).offset(offset).limit(limit).all()
    return {"{entities}": [r.to_dict() for r in results], "total": len(results), "total_count": total_count, "offset": offset, "limit": limit}


def get_{entity}(db: Session, {entity}_id: int) -> dict:
    """Retrieve a single {entity} by ID."""
    item = db.query({Entity}Model).filter({Entity}Model.id == {entity}_id).first()
    if not item:
        return {"error": f"{Entity} with id {{{entity}_id}} not found"}
    return item.to_dict()


def create_{entity}(db: Session, name: str, **kwargs) -> dict:
    """Create a new {entity}."""
    item = {Entity}Model(name=name, **kwargs)
    db.add(item)
    db.commit()
    db.refresh(item)
    return item.to_dict()


def update_{entity}(db: Session, {entity}_id: int, **kwargs) -> dict:
    """Update an existing {entity} by ID."""
    item = db.query({Entity}Model).filter({Entity}Model.id == {entity}_id).first()
    if not item:
        return {"error": f"{Entity} with id {{{entity}_id}} not found"}
    for key, value in kwargs.items():
        if hasattr(item, key) and value is not None:
            setattr(item, key, value)
    db.commit()
    db.refresh(item)
    return item.to_dict()


def delete_{entity}(db: Session, {entity}_id: int) -> dict:
    """Delete a {entity} by ID."""
    item = db.query({Entity}Model).filter({Entity}Model.id == {entity}_id).first()
    if not item:
        return {"error": f"{Entity} with id {{{entity}_id}} not found"}
    db.delete(item)
    db.commit()
    return {"deleted": True, "{entity}_id": {entity}_id}


# ─── Function Registry ────────────────────────────────────────────────────────
FUNCTIONS = {
    "get_{entities}": get_{entities},
    "get_{entity}": get_{entity},
    "create_{entity}": create_{entity},
    "update_{entity}": update_{entity},
    "delete_{entity}": delete_{entity},
}


def call_function(name: str, db: Session, **kwargs) -> dict:
    func = FUNCTIONS.get(name)
    if not func:
        raise ValueError(f"Function '{name}' not found. Available: {list(FUNCTIONS.keys())}")
    return func(db=db, **kwargs)


# ─── CLI mode ─────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import sys
    from database import get_session, init_db

    init_db()

    if len(sys.argv) < 2:
        print(json.dumps({"error": "Usage: python functions.py <function_name> [json_params]"}))
        sys.exit(1)

    func_name = sys.argv[1]
    params = {}
    if len(sys.argv) > 2:
        try:
            params = json.loads(sys.argv[2])
        except json.JSONDecodeError as e:
            print(json.dumps({"error": f"Invalid JSON params: {e}"}))
            sys.exit(1)

    db = get_session()
    try:
        func = FUNCTIONS.get(func_name)
        if not func:
            print(json.dumps({"error": f"Function '{func_name}' not found. Available: {list(FUNCTIONS.keys())}"}))
            sys.exit(1)
        result = func(db=db, **params)
        print(json.dumps(result, default=str))
    except Exception as e:
        db.rollback()
        print(json.dumps({"error": str(e), "function": func_name, "params": params}))
        sys.exit(1)
    finally:
        db.close()
```

**Rules:**
1. Every function takes `db: Session` as FIRST arg — including file-processing functions
2. Every function returns a dict — always JSON serializable
3. `FUNCTIONS` dict maps names → callables
4. CLI mode: `python functions.py get_items '{"limit":10}'`
5. Error returns: `{"error": "message"}` — never raise from functions
6. `get_` list functions must have `search_query`, `limit`, `offset` params + return `total_count`

#### Multi-user pattern

**Trigger (deterministic):** Include this ONLY when SPEC.md lists a `userId` (or
`user_id`) field on at least one entity. Otherwise omit it entirely.

`USER_EMAIL` and `USER_NAME` are FIXED CONTRACT, runtime-only env-var names read
via `os.environ` (the documented exception to the no-`os.environ` rule). Fallback
for each when unset is the empty string `''`.

```python
import os
from config import USER_ID

def get_current_user() -> dict:
    return {
        "user_id":    USER_ID,  # from config.py (frozen at init)
        "user_email": os.environ.get('USER_EMAIL', ''),  # runtime, fallback ''
        "user_name":  os.environ.get('USER_NAME', ''),   # runtime, fallback ''
    }
```

#### File-accepting functions

```python
def process_file(db: Session, file_name: str, file_path: str) -> dict:
    """file_path is injected by server — never passed by frontend manually."""
    with open(file_path, "rb") as f:
        data = f.read()
    return {"file_name": file_name, "result": {}}
```

---

### File: document.md ⭐ Single Source of Truth

```markdown
# {Project Name} — Backend API Reference

**Project:** {project_slug}
**Backend entry point:** `backend/functions.py`
**Database:** SQLite at `backend/data/{project_slug}.db`

---

## Database Schema

### `{entities}` table
| Column | Type | Required | Default | Description |
|--------|------|----------|---------|-------------|
| id | integer | auto | — | Primary key |
| name | string(500) | yes | — | Name |
| created_at | datetime | auto | now() | Creation timestamp |
| updated_at | datetime | auto | now() | Last updated |

---

## Functions

### `get_{entities}`
| Parameter | Type | Required | Default |
|-----------|------|----------|---------|
| search_query | string | no | "" |
| limit | integer | no | 50 |
| offset | integer | no | 0 |
**Returns:** `{"{entities}": [...], "total": N, "total_count": N}`

### `get_{entity}`
| Parameter | Type | Required |
|-----------|------|----------|
| {entity}_id | integer | yes |
**Returns:** Single dict or `{"error": "Not found"}`

### `create_{entity}`
| Parameter | Type | Required |
|-----------|------|----------|
| name | string | yes |
**Returns:** Created entity dict

### `update_{entity}`
| Parameter | Type | Required |
|-----------|------|----------|
| {entity}_id | integer | yes |
| name | string | no |
**Returns:** Updated entity dict or `{"error": "Not found"}`

### `delete_{entity}`
| Parameter | Type | Required |
|-----------|------|----------|
| {entity}_id | integer | yes |
**Returns:** `{"deleted": true}`

### `kogo_me`
| Parameter | Type | Required |
|-----------|------|----------|
**Returns:** `{"authenticated": bool, "registered": bool, "email": "...", "role": "...", "is_admin": bool}`

### `kogo_register_users`
| Parameter | Type | Required |
|-----------|------|----------|
| users | list | yes |
**Returns:** `{"ok": true, "count": N, "default_role": "member"}`

### `kogo_list_users`
| Parameter | Type | Required |
|-----------|------|----------|
**Returns:** `{"users": [{"id": N, "email": "...", "name": "...", "role": "...", "is_admin": bool, "is_you": bool}], "roles": [...], "total": N}` — admins only

### `kogo_add_user`
| Parameter | Type | Required |
|-----------|------|----------|
| email | string | yes |
| name | string | no |
| role | string | no |
| password | string | no |
**Returns:** `{"ok": true, "id": N, "email": "...", "role": "...", "can_login_directly": bool}` — needs `users.manage`

### `kogo_set_user_role`
| Parameter | Type | Required |
|-----------|------|----------|
| user_id | integer | yes |
| role | string | yes |
**Returns:** `{"ok": true, "id": N, "role": "...", "is_admin": bool}` — admins only

### `kogo_remove_user`
| Parameter | Type | Required |
|-----------|------|----------|
| user_id | integer | yes |
**Returns:** `{"ok": true, "removed": "email"}` — needs `users.manage`

### `kogo_login`
| Parameter | Type | Required |
|-----------|------|----------|
| email | string | yes |
| password | string | yes |
**Returns:** `{"ok": true, "token": "...", "name": "...", "role": "...", "is_admin": bool}` or `{"error": "Incorrect email or password"}`

### `kogo_logout`
| Parameter | Type | Required |
|-----------|------|----------|
**Returns:** `{"ok": true}` — ends the app session carried in `_app_token`

### `kogo_set_password`
| Parameter | Type | Required |
|-----------|------|----------|
| password | string | yes |
**Returns:** `{"ok": true}` — the signed-in user enables direct login for themselves

### `kogo_admin_set_password`
| Parameter | Type | Required |
|-----------|------|----------|
| user_id | integer | yes |
| password | string | yes |
**Returns:** `{"ok": true, "email": "..."}` — needs `users.manage`; drops that user's open sessions

### `kogo_list_roles`
| Parameter | Type | Required |
|-----------|------|----------|
**Returns:** `{"roles": [{"id": N, "name": "...", "is_system": bool, "permissions": [...], "users": N}], "all_permissions": [...]}` — needs `users.manage`

### `kogo_create_role`
| Parameter | Type | Required |
|-----------|------|----------|
| name | string | yes |
| permissions | list | yes |
**Returns:** `{"ok": true, "name": "...", "permissions": [...]}` — needs `users.manage`

### `kogo_update_role`
| Parameter | Type | Required |
|-----------|------|----------|
| name | string | yes |
| permissions | list | yes |
**Returns:** `{"ok": true, "name": "...", "permissions": [...]}` — built-in roles cannot be changed

### `kogo_delete_role`
| Parameter | Type | Required |
|-----------|------|----------|
| name | string | yes |
**Returns:** `{"ok": true, "deleted": "name"}` — built-in or in-use roles cannot be deleted

---

## How to Call

### CLI
```bash
cd artifacts/{project-name}/backend
python functions.py get_{entities} '{"limit": 10}'
```

### Middleware API v1
```json
POST {API_BASE}/api/agent/common_project_api_v1
{
  "project": "{project_slug}",
  "function": "get_{entities}",
  "params": {"limit": 10},
  "agentId": "{agentId}",
  "deploymentId": "{deploymentId}",
  "swarmId": "{swarmId}",
  "originId": "{originId}"
}
```
Send all 3 identity ids (they are ALWAYS distinct): `agentId` = AGENT_ID, `deploymentId` = DEPLOYMENT_ID, `swarmId` = SWARM_ID (`""` on a direct agent). `originId` = SWARM_ID if workspace, else AGENT_ID (this is `ORIGIN_ID` from `config.ts`, used only for file-storage routing). All come straight from `config.ts`.
```

---

### File: functions.py — KOGO SSO block ⭐ MANDATORY in every new app

**This section is HARD RULE 0.** It applies to every single app — including one the user described
as static, simple, or not needing login. Build it anyway; a static page with a user system still
renders as a static page, while a missing user system cannot be added back once the app is published.

Every app you build gets a user system wired to KOGO. The user never configures anything: KOGO
detects support by looking for `kogo_register_users` in the app's own `document.md`. Ship these and
the app gets auto-login, roles and access control for free. Omit them and the app still runs — it
just has no idea who is using it.

**Where identity comes from.** On every backend call the runtime puts the *verified* caller in the
environment. Verified means KOGO checked the token's signature — do not re-check it, and do not
read anything else as identity:

```
USER_EMAIL          the caller's email — THE key to match a user row on
USER_NAME           display name
USER_ID             KOGO user id
USER_IS_ADMIN       "1" / "0" — their role in KOGO, not in this app
KOGO_AUTH_VERIFIED  "1" when the above can be trusted. ABSENT = anonymous caller.
```

**`KOGO_AUTH_VERIFIED` is the whole gate.** If it is not `"1"`, treat the caller as a stranger no
matter what else is set.

**1. Add a `users` table** in `models.py` (and `database.py`):

```python
class User(Base):
    __tablename__ = "users"
    id         = Column(Integer, primary_key=True)
    email      = Column(String(255), unique=True, nullable=False, index=True)
    name       = Column(String(255), default="")
    role       = Column(String(50), default="member")   # your own vocabulary
    is_admin   = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)
```

**2. Add these three functions** to `functions.py` and the `FUNCTIONS` dict:

```python
def _current_user(db, **kwargs):
    """The caller, as a row in THIS app. None = not signed in or not registered.
    Every function that touches user data starts here.

    TWO ways in, checked in this order:
      1. KOGO SSO  — the verified identity the platform put in the environment
      2. app login — an `_app_token` the frontend got from kogo_login(), for someone opening the
                     app outside KOGO. Only ever consulted when there is no KOGO identity.
    """
    if os.environ.get("KOGO_AUTH_VERIFIED") == "1":
        email = (os.environ.get("USER_EMAIL") or "").strip().lower()
        if email:
            return _resolve_or_bootstrap(db, email, os.environ.get("USER_NAME") or email)
        return None
    return _session_user(db, kwargs.get("_app_token"))   # no KOGO identity → try the app session


def _resolve_or_bootstrap(db, email, name):
    """A verified email → its row, creating it only on a completely empty app (see below)."""
    user = db.query(User).filter(User.email == email).first()
    if user:
        return user
    # FIRST-USER BOOTSTRAP. KOGO fills this table at install and at share — but an app the agent
    # just built has had neither, so the table is empty and even the person who built it would be
    # locked out of their own app. So: an empty table + a verified caller = that caller owns it.
    # Fires at most once, and never for an installed app (install registered someone first).
    if db.query(User).count() == 0:
        user = User(email=email, name=name, role="admin", is_admin=True)
        db.add(user)
        db.commit()
        return user
    return None                          # registered users exist, this one is not among them

def kogo_me(**kwargs):
    """Who am I? The frontend calls this first and renders from the answer."""
    db = SessionLocal()
    try:
        # A password session counts as authenticated too — only a caller with neither is anonymous.
        if os.environ.get("KOGO_AUTH_VERIFIED") != "1" and not _session_user(db, kwargs.get("_app_token")):
            return {"authenticated": False, "registered": False, "reason": "no_session"}
        user = _current_user(db, **kwargs)
        if not user:
            return {"authenticated": True, "registered": False, "reason": "not_registered",
                    "email": os.environ.get("USER_EMAIL", "")}
        return {"authenticated": True, "registered": True,
                "email": user.email, "name": user.name, "role": user.role, "is_admin": user.is_admin,
                "via": "kogo" if os.environ.get("KOGO_AUTH_VERIFIED") == "1" else "password",
                "can_login_directly": bool(user.password_hash)}
    finally:
        db.close()

def kogo_register_users(users=None, **kwargs):
    """KOGO calls this at install and when the app is shared. Never called by the frontend.

    Idempotent: the same user twice is an update, not an error. Per-user try/except, because one
    bad entry must never stop the rest — a half-registered workspace is worse than a logged error.
    """
    db = SessionLocal()
    count = 0
    try:
        for u in (users or []):
            try:
                email = (u.get("email") or "").strip().lower()
                if not email:
                    continue
                row = db.query(User).filter(User.email == email).first()
                if row:
                    row.name = u.get("name") or row.name
                    if u.get("is_admin"):          # never demote someone silently
                        row.is_admin, row.role = True, u.get("role") or "admin"
                else:
                    db.add(User(email=email, name=u.get("name") or email,
                                role=u.get("role") or ("admin" if u.get("is_admin") else "member"),
                                is_admin=bool(u.get("is_admin"))))
                db.commit()
                count += 1
            except Exception:
                db.rollback()
                continue
        return {"ok": True, "count": count, "default_role": "member"}
    finally:
        db.close()

FUNCTIONS = { ..., "kogo_me": kogo_me, "kogo_register_users": kogo_register_users }
```

**2b. Manual login + logout — MANDATORY.** KOGO SSO is how people normally get in. But an app
opened outside a KOGO workspace has no token, and must still be usable by someone who has been
given a password. So every app also has its own login.

**Where a password comes from.** KOGO creates users WITHOUT one — there is nothing to log in with
until somebody sets it. Two ways, both in the app:
- a signed-in user sets their own (`kogo_set_password`) — "let me get in without KOGO next time"
- an admin sets one for someone (`kogo_admin_set_password`)

A user who has never done either simply cannot log in manually. That is correct: they were never
given direct access.

Add to `models.py`:

Add ONE column to the `User` model you already have — do not declare a second `User` class:

```python
    password_hash = Column(String(255), default="")   # on User. empty = manual login not enabled
```

And one new model:

```python
class Session(Base):
    __tablename__ = "sessions"
    id         = Column(Integer, primary_key=True)
    token_hash = Column(String(64), unique=True, index=True, nullable=False)
    user_id    = Column(Integer, nullable=False, index=True)
    expires_at = Column(DateTime, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
```

In `functions.py` — stdlib only, no new dependency:

```python
import hashlib, secrets
from datetime import timedelta

SESSION_DAYS = 7

def _hash_password(password, salt=None):
    salt = salt or secrets.token_hex(16)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), 200_000)
    return f"{salt}${dk.hex()}"

def _check_password(password, stored):
    if not stored or "$" not in stored:
        return False
    salt, _ = stored.split("$", 1)
    return secrets.compare_digest(_hash_password(password, salt), stored)   # constant time

def _session_user(db, token):
    """Resolve an app session token to its user, or None. Expired sessions are deleted on sight."""
    if not token:
        return None
    th = hashlib.sha256(token.encode()).hexdigest()
    row = db.query(Session).filter(Session.token_hash == th).first()
    if not row:
        return None
    if row.expires_at < datetime.utcnow():
        db.delete(row)
        db.commit()
        return None
    return db.query(User).filter(User.id == row.user_id).first()

def kogo_login(email=None, password=None, **kwargs):
    """Manual login, for someone opening the app outside KOGO."""
    db = SessionLocal()
    try:
        user = db.query(User).filter(User.email == (email or "").strip().lower()).first()
        # One message for "no such user" and "wrong password" — a different message for each tells
        # a stranger which emails are registered.
        if not user or not _check_password(password or "", user.password_hash):
            return {"error": "Incorrect email or password"}
        token = secrets.token_urlsafe(32)
        db.add(Session(token_hash=hashlib.sha256(token.encode()).hexdigest(), user_id=user.id,
                       expires_at=datetime.utcnow() + timedelta(days=SESSION_DAYS)))
        db.commit()
        return {"ok": True, "token": token, "name": user.name, "role": user.role,
                "is_admin": user.is_admin}
    finally:
        db.close()

def kogo_logout(**kwargs):
    """Ends the app session. A KOGO SSO user has no app session — for them this is a no-op on the
    backend, and the frontend simply returns them to the signed-out screen."""
    db = SessionLocal()
    try:
        token = kwargs.get("_app_token")
        if token:
            th = hashlib.sha256(token.encode()).hexdigest()
            row = db.query(Session).filter(Session.token_hash == th).first()
            if row:
                db.delete(row)
                db.commit()
        return {"ok": True}
    finally:
        db.close()

def kogo_set_password(password=None, **kwargs):
    """The signed-in user enables direct login for themselves."""
    db = SessionLocal()
    try:
        user = _current_user(db, **kwargs)
        if not user:
            return {"error": "Not authorised"}
        if not password or len(password) < 8:
            return {"error": "Password must be at least 8 characters"}
        user.password_hash = _hash_password(password)
        db.commit()
        return {"ok": True}
    finally:
        db.close()

def kogo_admin_set_password(user_id=None, password=None, **kwargs):
    """An admin sets or resets someone's password. Every existing session of that user is dropped,
    so a reset actually locks out whoever was using the old one."""
    db = SessionLocal()
    try:
        me, err = _require(db, "users.manage", **kwargs)
        if err:
            return err
        target = db.query(User).filter(User.id == user_id).first()
        if not target:
            return {"error": "User not found"}
        if not password or len(password) < 8:
            return {"error": "Password must be at least 8 characters"}
        target.password_hash = _hash_password(password)
        db.query(Session).filter(Session.user_id == target.id).delete()
        db.commit()
        return {"ok": True, "email": target.email}
    finally:
        db.close()
```

**`kogo_me` must report both paths** so the frontend knows which screen to show — add
`"via": "kogo" if os.environ.get("KOGO_AUTH_VERIFIED") == "1" else "password"` and
`"can_login_directly": bool(user.password_hash)` to its registered-user reply, and accept
`**kwargs` so the session token reaches `_current_user`.

**Every function takes `**kwargs` and forwards it.** `_current_user(db, **kwargs)` and
`_require(db, perm, **kwargs)` — that is how `_app_token` travels. A function that forgets to
forward it works under KOGO and mysteriously returns "Not authorised" for a password-logged-in
user; forward it everywhere, with no exceptions.

**Frontend:**
- `src/services/api.ts` keeps the app token in `localStorage` and puts it into `params._app_token`
  on EVERY call, alongside the existing KOGO JWT header
- The signed-out screen offers both: *"Open from your KOGO workspace"* and an email + password form
- A **Logout** item in the app's menu → `kogo_logout()` → clear `localStorage` → signed-out screen.
  Show it for both kinds of session; for a KOGO user it just returns them to the signed-out screen.
- Account screen: "Set a password for direct access" → `kogo_set_password`
- Users screen gets a per-user "Set password" action → `kogo_admin_set_password`

**3. Roles & permissions — also MANDATORY in every app.** Registration decides WHO is in; roles
decide WHAT they may do, and the admin must be able to change both without a developer.

**Permissions, not role names, are what the code checks.** A role is just a named bundle of
permissions. That is the whole reason an admin can invent a role at runtime and have it mean
something immediately — if functions tested `role == "editor"`, a new role would be a label that
does nothing.

**Derive the permission list mechanically from the app's own entities** — do not invent a scheme:

```python
# One line per entity the app has. For a notes app with notes + folders:
PERMISSIONS = [
    "notes.create", "notes.read", "notes.update", "notes.delete",
    "folders.create", "folders.read", "folders.update", "folders.delete",
    "users.manage",      # always present — see and manage users and roles
]
```

**Two tables.** `users.role` holds a role NAME; `roles` holds what that name can do:

```python
class Role(Base):
    __tablename__ = "roles"
    id          = Column(Integer, primary_key=True)
    name        = Column(String(50), unique=True, nullable=False)
    permissions = Column(Text, default="[]")     # JSON list of permission strings
    is_system   = Column(Boolean, default=False) # built-in: cannot be edited or deleted
    created_at  = Column(DateTime, default=datetime.utcnow)
```

**Seed two roles** in `database.py` (idempotent — it runs on every DB init):

```python
def _seed_roles(db):
    if not db.query(Role).filter(Role.name == "admin").first():
        db.add(Role(name="admin", permissions="[]", is_system=True))   # see _role_permissions
    if not db.query(Role).filter(Role.name == "member").first():
        db.add(Role(name="member", is_system=True,
                    permissions=json.dumps([p for p in PERMISSIONS if p.endswith(".read")])))
    db.commit()
```

**The permission check** — every gate goes through this, nothing else:

```python
def _role_permissions(db, role_name):
    """What this role may do. `admin` always gets EVERYTHING — computed, never stored, so a
    permission added later is covered without a migration or a re-seed."""
    if role_name == "admin":
        return set(PERMISSIONS)
    row = db.query(Role).filter(Role.name == role_name).first()
    if not row:
        return set()
    try:
        return set(json.loads(row.permissions or "[]"))
    except Exception:
        return set()

def has_permission(db, user, perm):
    if not user:
        return False
    if user.is_admin:            # the superuser flag always wins
        return True
    return perm in _role_permissions(db, user.role)

def _require(db, perm, **kwargs):
    """Returns (user, None) when allowed, or (None, error_dict) to return straight to the caller.
    EVERY function that creates, changes or deletes anything starts with this.
    `**kwargs` is forwarded so a password-logged-in caller's _app_token reaches _current_user."""
    user = _current_user(db, **kwargs)
    if not user:
        return None, {"error": "Not authorised"}
    if not has_permission(db, user, perm):
        return None, {"error": "You don't have permission to do that"}
    return user, None
```

Use it in the app's own functions — this is what makes a custom role real:

```python
def delete_note(note_id=None, **kwargs):
    db = SessionLocal()
    try:
        user, err = _require(db, "notes.delete", **kwargs)
        if err:
            return err
        ...
```

**User management** (admins, or anyone with `users.manage`):

```python
def kogo_list_users(**kwargs):
    db = SessionLocal()
    try:
        me, err = _require(db, "users.manage", **kwargs)
        if err:
            return err
        rows = db.query(User).order_by(User.created_at.asc()).all()
        roles = [r.name for r in db.query(Role).order_by(Role.name.asc()).all()]
        return {"users": [{"id": u.id, "email": u.email, "name": u.name, "role": u.role,
                           "is_admin": u.is_admin, "is_you": u.id == me.id} for u in rows],
                "roles": roles, "total": len(rows)}
    finally:
        db.close()

def kogo_set_user_role(user_id=None, role=None, **kwargs):
    db = SessionLocal()
    try:
        me, err = _require(db, "users.manage", **kwargs)
        if err:
            return err
        if not db.query(Role).filter(Role.name == role).first():
            return {"error": f"No such role: {role}"}
        target = db.query(User).filter(User.id == user_id).first()
        if not target:
            return {"error": "User not found"}
        # Demoting the last admin leaves an app nobody can administer, and the Manage Users screen
        # itself needs users.manage — so there would be no way back. Refuse.
        if target.is_admin and role != "admin" and db.query(User).filter(User.is_admin == True).count() <= 1:
            return {"error": "This is the only admin — make someone else an admin first"}
        target.role = role
        target.is_admin = (role == "admin")
        db.commit()
        return {"ok": True, "id": target.id, "role": target.role, "is_admin": target.is_admin}
    finally:
        db.close()

def kogo_add_user(email=None, name=None, role="member", password=None, **kwargs):
    """An admin adds someone directly.

    This grants access to THIS APP only — it cannot give anyone a KOGO account or put them in the
    workspace. So it is useful in exactly one way: pair it with a password and the person can sign
    in through the app's own login form without going through KOGO at all. Added without a
    password, the row sits waiting until they arrive via KOGO (install/share) or an admin sets one.
    """
    db = SessionLocal()
    try:
        me, err = _require(db, "users.manage", **kwargs)
        if err:
            return err
        email = (email or "").strip().lower()
        if "@" not in email:
            return {"error": "A valid email is required"}
        if db.query(User).filter(User.email == email).first():
            return {"error": "That person already has access"}
        if not db.query(Role).filter(Role.name == role).first():
            return {"error": f"No such role: {role}"}
        if password and len(password) < 8:
            return {"error": "Password must be at least 8 characters"}
        user = User(email=email, name=(name or "").strip() or email, role=role,
                    is_admin=(role == "admin"),
                    password_hash=_hash_password(password) if password else "")
        db.add(user)
        db.commit()
        return {"ok": True, "id": user.id, "email": user.email, "role": user.role,
                "can_login_directly": bool(password)}
    finally:
        db.close()

def kogo_remove_user(user_id=None, **kwargs):
    db = SessionLocal()
    try:
        me, err = _require(db, "users.manage", **kwargs)
        if err:
            return err
        target = db.query(User).filter(User.id == user_id).first()
        if not target:
            return {"error": "User not found"}
        if target.id == me.id:
            return {"error": "You cannot remove yourself"}
        if target.is_admin and db.query(User).filter(User.is_admin == True).count() <= 1:
            return {"error": "This is the only admin — make someone else an admin first"}
        db.delete(target)
        db.commit()
        return {"ok": True, "removed": target.email}
    finally:
        db.close()
```

**Role management** — this is the part that lets an admin shape access without a developer:

```python
def kogo_list_roles(**kwargs):
    """Roles + the full permission catalogue, so the UI can render tick-boxes from one call."""
    db = SessionLocal()
    try:
        me, err = _require(db, "users.manage", **kwargs)
        if err:
            return err
        out = []
        for r in db.query(Role).order_by(Role.name.asc()).all():
            out.append({"id": r.id, "name": r.name, "is_system": r.is_system,
                        "permissions": sorted(_role_permissions(db, r.name)),
                        "users": db.query(User).filter(User.role == r.name).count()})
        return {"roles": out, "all_permissions": PERMISSIONS}
    finally:
        db.close()

def kogo_create_role(name=None, permissions=None, **kwargs):
    db = SessionLocal()
    try:
        me, err = _require(db, "users.manage", **kwargs)
        if err:
            return err
        name = (name or "").strip().lower()
        if not name:
            return {"error": "Role name is required"}
        if db.query(Role).filter(Role.name == name).first():
            return {"error": f"A role called '{name}' already exists"}
        bad = [p for p in (permissions or []) if p not in PERMISSIONS]
        if bad:
            return {"error": f"Unknown permission(s): {', '.join(bad)}"}
        db.add(Role(name=name, permissions=json.dumps(sorted(set(permissions or []))), is_system=False))
        db.commit()
        return {"ok": True, "name": name, "permissions": sorted(set(permissions or []))}
    finally:
        db.close()

def kogo_update_role(name=None, permissions=None, **kwargs):
    db = SessionLocal()
    try:
        me, err = _require(db, "users.manage", **kwargs)
        if err:
            return err
        row = db.query(Role).filter(Role.name == (name or "").strip().lower()).first()
        if not row:
            return {"error": "Role not found"}
        if row.is_system:
            return {"error": f"'{row.name}' is a built-in role and cannot be changed"}
        bad = [p for p in (permissions or []) if p not in PERMISSIONS]
        if bad:
            return {"error": f"Unknown permission(s): {', '.join(bad)}"}
        row.permissions = json.dumps(sorted(set(permissions or [])))
        db.commit()
        return {"ok": True, "name": row.name, "permissions": sorted(set(permissions or []))}
    finally:
        db.close()

def kogo_delete_role(name=None, **kwargs):
    db = SessionLocal()
    try:
        me, err = _require(db, "users.manage", **kwargs)
        if err:
            return err
        row = db.query(Role).filter(Role.name == (name or "").strip().lower()).first()
        if not row:
            return {"error": "Role not found"}
        if row.is_system:
            return {"error": f"'{row.name}' is a built-in role and cannot be deleted"}
        in_use = db.query(User).filter(User.role == row.name).count()
        if in_use:
            # Deleting it would leave those users with a role that grants nothing, and no obvious
            # sign why they suddenly cannot do anything.
            return {"error": f"{in_use} user(s) still have this role — move them first"}
        db.delete(row)
        db.commit()
        return {"ok": True, "deleted": row.name}
    finally:
        db.close()

FUNCTIONS = { ..., "kogo_list_users": kogo_list_users, "kogo_add_user": kogo_add_user,
              "kogo_set_user_role": kogo_set_user_role,
              "kogo_remove_user": kogo_remove_user, "kogo_list_roles": kogo_list_roles,
              "kogo_create_role": kogo_create_role, "kogo_update_role": kogo_update_role,
              "kogo_delete_role": kogo_delete_role }
```

> All of these ARE callable from the frontend (unlike `kogo_register_users`, which KOGO blocks on
> the public route). The `_require` check inside each one is the only thing protecting them — never
> move that check into the UI, and never skip it "because the button is hidden".

**3. Gate the functions that matter.** A read everyone may do needs no gate; anything user-owned or
destructive does:

```python
def delete_item(item_id=None, **kwargs):
    db = SessionLocal()
    try:
        user = _current_user(db)
        if not user:
            return {"error": "Not authorised"}
        if not user.is_admin:
            return {"error": "Admins only"}
        ...
```

Never gate on `USER_IS_ADMIN` alone — that is the user's role in KOGO, not in this app. The app's
own `users.is_admin` is what decides here.

**4. `document.md` — APPEND these, never replace what is already there.** 🛑

The block below is an **addition to** the `## Functions` section you already wrote for the app's
own CRUD. It is NOT a template for the whole file. Writing only these entries leaves the app's real
functions undocumented — and the middleware refuses any function that is not in `document.md`, so
`get_notebooks` comes back as *"Function 'get_notebooks' not found. Available: kogo_list_users, …"*
and the app is dead while looking perfectly built. **This has actually happened.**

Rule: **every function in the `FUNCTIONS` dict has a `### \`name\`` entry in `document.md`.** The
app's own functions first, these after. You do not have to keep that in your head — the Backend
Completion Gate runs `scripts/sync-document.py`, which appends anything you missed.

`kogo_register_users` matters doubly: KOGO reads the parsed list to decide whether this app supports
registration at all. Undocumented means unsupported, however good the Python is.

```
### `kogo_me`
| Parameter | Type | Required |
|-----------|------|----------|
**Returns:** `{"authenticated": bool, "registered": bool, "email": "...", "role": "...", "is_admin": bool}`

### `kogo_register_users`
| Parameter | Type | Required |
|-----------|------|----------|
| users | list | yes |
**Returns:** `{"ok": true, "count": N, "default_role": "member"}`

### `kogo_list_users`
| Parameter | Type | Required |
|-----------|------|----------|
**Returns:** `{"users": [{"id": N, "email": "...", "name": "...", "role": "...", "is_admin": bool, "is_you": bool}], "roles": [...], "total": N}` — admins only

### `kogo_add_user`
| Parameter | Type | Required |
|-----------|------|----------|
| email | string | yes |
| name | string | no |
| role | string | no |
| password | string | no |
**Returns:** `{"ok": true, "id": N, "email": "...", "role": "...", "can_login_directly": bool}` — needs `users.manage`

### `kogo_set_user_role`
| Parameter | Type | Required |
|-----------|------|----------|
| user_id | integer | yes |
| role | string | yes |
**Returns:** `{"ok": true, "id": N, "role": "...", "is_admin": bool}` — admins only

### `kogo_remove_user`
| Parameter | Type | Required |
|-----------|------|----------|
| user_id | integer | yes |
**Returns:** `{"ok": true, "removed": "email"}` — needs `users.manage`

### `kogo_login`
| Parameter | Type | Required |
|-----------|------|----------|
| email | string | yes |
| password | string | yes |
**Returns:** `{"ok": true, "token": "...", "name": "...", "role": "...", "is_admin": bool}` or `{"error": "Incorrect email or password"}`

### `kogo_logout`
| Parameter | Type | Required |
|-----------|------|----------|
**Returns:** `{"ok": true}` — ends the app session carried in `_app_token`

### `kogo_set_password`
| Parameter | Type | Required |
|-----------|------|----------|
| password | string | yes |
**Returns:** `{"ok": true}` — the signed-in user enables direct login for themselves

### `kogo_admin_set_password`
| Parameter | Type | Required |
|-----------|------|----------|
| user_id | integer | yes |
| password | string | yes |
**Returns:** `{"ok": true, "email": "..."}` — needs `users.manage`; drops that user's open sessions

### `kogo_list_roles`
| Parameter | Type | Required |
|-----------|------|----------|
**Returns:** `{"roles": [{"id": N, "name": "...", "is_system": bool, "permissions": [...], "users": N}], "all_permissions": [...]}` — needs `users.manage`

### `kogo_create_role`
| Parameter | Type | Required |
|-----------|------|----------|
| name | string | yes |
| permissions | list | yes |
**Returns:** `{"ok": true, "name": "...", "permissions": [...]}` — needs `users.manage`

### `kogo_update_role`
| Parameter | Type | Required |
|-----------|------|----------|
| name | string | yes |
| permissions | list | yes |
**Returns:** `{"ok": true, "name": "...", "permissions": [...]}` — built-in roles cannot be changed

### `kogo_delete_role`
| Parameter | Type | Required |
|-----------|------|----------|
| name | string | yes |
**Returns:** `{"ok": true, "deleted": "name"}` — built-in or in-use roles cannot be deleted
```

**5. Frontend: one gate, before anything else.** `src/App.tsx` calls `kogo_me` on mount:

(The bootstrap is why "I built an app and can't get into it" never happens, while an installed
app still refuses anyone KOGO did not register.)

| `kogo_me` says | Show |
|---|---|
| `authenticated: false` | the signed-out screen: "Open this app from your KOGO workspace" **plus** the email + password form |
| `registered: false` | "You don't have access to this app yet. Ask your workspace admin." |
| `registered: true` | the app, with `role` / `is_admin` driving what is visible, and **Logout** in the menu |

**Two ways in, one screen.** KOGO is the primary identity provider, so inside a workspace nobody
ever types anything. The email + password form is the fallback for an app opened outside KOGO, and
it only works for someone who has set a password (§2b) — never as a way to self-register. Never let
the app treat an unknown caller as an admin, and never show a "Sign up" option: accounts come from
KOGO, not from this form.

**6. Frontend: a Users & Roles screen — MANDATORY, admins only.** An app with roles and no way to
see or change them is an app whose roles nobody can administer.

> ⚠️ **Build it with the SAME design system as the rest of the app.** This screen is the one most
> likely to come out looking like a debug page — a bare list, raw chips, a lone trash icon. It is
> part of the product and gets the same care as the main screens: the same DESIGN.md tokens, the
> same table/card/button/dialog components, the same spacing scale. Never hand-roll one-off styles
> here.

**Layout — follow this, do not improvise:**

- A **page header**: title "Users & Roles", a one-line subtitle, and the primary action
  (**+ Add person**) right-aligned in the header, not floating in the body.
- Two **tabs**: *People* and *Roles*, in the app's own tab component.
- **People tab** — a proper table, not a list of divs:
  | Person | Role | Access | |
  |---|---|---|---|
  | avatar initials + name, email underneath | role dropdown | "KOGO" or "Password" | ⋯ menu |
  - the current user's row carries a subtle **You** badge, and its remove action is disabled
  - the ⋯ menu holds *Set password* and *Remove*, so destructive actions are not one stray click
  - **empty state** never happens here (there is always at least one admin), so don't build one
- **Roles tab** — one **card per role**, not a table:
  - header: role name, a `built-in` badge where `is_system`, and "N people"
  - body: permissions as chips, **grouped by their prefix** (`notes.*`, `tasks.*`, `users.*`) with
    a small group label — a flat wall of 13 chips is unreadable, which is exactly what happens if
    you skip this
  - built-in roles show their chips read-only, with no Edit/Delete
  - **+ New role** opens a dialog: name field, then the permission tick-boxes **grouped the same
    way**, with a "select all" per group
- **Dialogs, not inline forms**, for Add person / New role / Set password.
- Destructive actions (Remove person, Delete role) confirm first, and name what is being removed.
- Every backend `error` string is shown in the dialog or as a toast, **verbatim** — they are
  written to be read ("3 user(s) still have this role — move them first").
- Loading and saving states on every action; never leave a button looking idle mid-request.

- A **"Users"** entry in the app's own navigation, rendered **only** when `kogo_me().is_admin`
- The screen calls `kogo_list_users()` and shows a table: name, email, role, and "you" on your row
- Role is a dropdown built from the `roles` array the same call returns — never a hardcoded list,
  so adding a role in `ROLES` is the only change needed
- Changing it calls `kogo_set_user_role(user_id, role)`; a Remove action calls
  `kogo_remove_user(user_id)` behind a confirm
- Show the `error` string the backend returns, verbatim — "This is the only admin…" is written to
  be read by a person
- **"Add person"** button → a dialog with email, name, role, and an optional password. Calls
  `kogo_add_user`. Make the password field's purpose explicit in the UI — *"Set a password so they
  can sign in without KOGO"* — because that is the only thing it adds: this cannot grant anyone a
  KOGO account or workspace access, only access to this app.

**A second tab on the same screen: Roles.** This is what lets an admin shape access without a
developer.

- `kogo_list_roles()` returns every role, its permissions, how many users hold it, and
  `all_permissions` — the app's full catalogue. Render the tick-boxes from `all_permissions`;
  never hardcode the list, or adding an entity will silently leave its permissions unreachable.
- "New role" → a name + tick-boxes → `kogo_create_role(name, permissions)`
- Editing an existing one → `kogo_update_role(name, permissions)`
- Delete → `kogo_delete_role(name)`
- Built-in roles (`is_system`) render read-only: show their permissions, hide Edit and Delete.
  `admin` shows every permission ticked, because it always has them all.
- Surface the backend's `error` text as-is. "3 user(s) still have this role — move them first" and
  "This is the only admin…" are written for a person to read and act on.

Hiding the nav entry is presentation only. The backend is what enforces it — every one of these
functions checks `_require_admin` itself.

> **This is also why the app works in the dashboard but not in a plain browser tab.** The token
> arrives by `postMessage` from the KOGO dashboard; opened directly there is no parent, so
> `kogo_me` returns `authenticated: false`. That is correct behaviour — say so on screen rather
> than rendering a UI whose every call will fail.

### File: seed.py

```python
"""{Project Name} — Demo data."""
from models import {Entity}Model

def seed(db):
    count = db.query({Entity}Model).count()
    if count == 0:
        demo = [
            {Entity}Model(name="Demo 1"),
            {Entity}Model(name="Demo 2"),
        ]
        db.add_all(demo)
        print(f"  🌱 Seeded {len(demo)} items")

if __name__ == "__main__":
    from database import get_session, init_db
    init_db()
    db = get_session()
    try:
        seed(db)
        db.commit()
    finally:
        db.close()
```

---

## ⛔ Backend Completion Gate — MUST pass before ANY frontend work

After writing all backend files, verify this checklist BEFORE moving to Phase 4B or bundling:

```bash
# All 3 must exist — if ANY is missing, create it NOW before continuing
ls {PROJECT_DIR}/backend/functions.py   # ← middleware executes this directly
ls {PROJECT_DIR}/backend/document.md    # ← required for middleware to find the project
ls {PROJECT_DIR}/backend/database.py    # ← required for DB init
```

**KOGO SSO check — all four lines must print a number greater than 0:**

```bash
grep -c "def kogo_register_users" {PROJECT_DIR}/backend/functions.py
grep -c "def kogo_me"             {PROJECT_DIR}/backend/functions.py
grep -c "kogo_register_users"     {PROJECT_DIR}/backend/document.md
grep -c "kogo_me"                 {PROJECT_DIR}/backend/document.md

# user + role management — all four must be > 0 too
grep -c "def kogo_list_users"     {PROJECT_DIR}/backend/functions.py
grep -c "def kogo_add_user"       {PROJECT_DIR}/backend/functions.py
grep -c "def kogo_set_user_role"  {PROJECT_DIR}/backend/functions.py
grep -c "def kogo_remove_user"    {PROJECT_DIR}/backend/functions.py
grep -c "kogo_list_users"         {PROJECT_DIR}/backend/document.md

# login / logout / passwords — all must be > 0
grep -c "def kogo_login"          {PROJECT_DIR}/backend/functions.py
grep -c "def kogo_logout"         {PROJECT_DIR}/backend/functions.py
grep -c "def kogo_set_password"   {PROJECT_DIR}/backend/functions.py
grep -c "class Session"           {PROJECT_DIR}/backend/models.py
grep -c "password_hash"           {PROJECT_DIR}/backend/models.py
grep -c "kogo_login"              {PROJECT_DIR}/backend/document.md

# roles + permissions — all must be > 0
grep -c "PERMISSIONS = \["         {PROJECT_DIR}/backend/functions.py
grep -c "class Role"              {PROJECT_DIR}/backend/models.py
grep -c "def has_permission"      {PROJECT_DIR}/backend/functions.py
grep -c "def kogo_create_role"    {PROJECT_DIR}/backend/functions.py
grep -c "kogo_create_role"        {PROJECT_DIR}/backend/document.md
```

**Sync `document.md` with the script — do not audit it by eye:**

```bash
python3 '{SCRIPTS_DIR}/sync-document.py' \
  {PROJECT_DIR}/backend/functions.py {PROJECT_DIR}/backend/document.md
```

It must print **`document.md is in sync`**. If it instead lists functions it ADDED, open the file
and fill in each new entry's `Required` column and `Returns:` line, then run it again.

The script never edits an entry you already wrote and never deletes anything — it only appends what
is missing, with parameters read from the function signature. So running it is always safe, and
running it twice is a no-op.

**This is the single most common way a finished-looking app ships broken.** An undocumented
function cannot be called: the middleware answers *"Function 'get_notebooks' not found. Available:
…"* and every feature fails while the UI looks complete. Do not rely on having remembered — run
the script.

And check the gating actually happened — every function that creates, updates or deletes should
start with `_require(db, "<entity>.<action>")`. A business function with no `_require` line is a
hole: the role system exists but that operation is open to everyone.

A `0` on either of the **document.md** lines is the dangerous one: the Python works, the app looks
finished, and KOGO silently treats it as having no user system — because support is detected by
reading the documented function list, not the code. Nobody gets registered at install, and every
user is locked out with "you don't have access". Fix it here; it is invisible later.

Also confirm `models.py` has the `User` model and `_current_user()` is used by every function that
touches user-owned or destructive data.

**CLI/curl tests (KOGO platform only):**
These tests require env vars injected by pi-api at runtime (`KOGO_API_BASE`, `AGENT_ID`, `API_PATH`, etc.).
- **On KOGO platform (env vars available):** run the health check and CLI tests below.
- **On any other platform (env vars not available):** SKIP all tests. The project will be tested when deployed to KOGO.
- NEVER substitute, guess, or hardcode any env var value to make tests pass.

```bash
# KOGO platform only — skip if env vars not set
curl "${API_HEALTH}?userId=${USER_ID}&originId=${ORIGIN_ID}&project=${project_slug}"
# → projects array must contain the project_slug
# → If slug is missing: functions.py or document.md does not exist — fix it
```

**Why this matters:** The frontend's `checkApiHealth()` runs on startup and shows "Backend offline" if the project slug is absent from the health list. This happens when `functions.py` is missing. The middleware finds projects ONLY by scanning for `functions.py` — if you skip it or write it after bundling, the app appears broken even though the code is complete.

**NEVER create `server.py`, `backend_api.py`, or any FastAPI/Flask file.** The middleware IS the server. See the "Backend offline" diagnosis block in the main SKILL.md for details.

**CRITICAL — when you see "Backend offline", you have exactly 2 allowed responses:**
1. "I see `functions.py` is missing — creating it now." → create the file
2. "I see `document.md` is missing — creating it now." → create the file

**You are NEVER allowed to say:**
- "Deploy this backend to your server"
- "Test locally via localhost" / "rebundle to call localhost:XXXX"
- "Option A / Option B" involving a server or local port
- Anything about running uvicorn, Flask, or any HTTP server

The user does NOT need to deploy, run, or expose anything. The fix is always: create the missing file.

---

## PART 2 — Frontend

### File: src/services/api.ts (MANDATORY template)

```typescript
import { API_BASE, API_HEALTH, PROJECT, USER_ID, AGENT_ID, DEPLOYMENT_ID, SWARM_ID, ORIGIN_ID } from "../config";

let _jwt: string | null = null;
// _jwtReady resolves as soon as the parent posts the JWT (or after a short timeout).
// The FIRST api call awaits it — WITHOUT this, the call fires on mount BEFORE the
// KOGO_AUTH postMessage arrives, the middleware falls back to a default user, and the
// project is looked up in the WRONG workspace → "Project 'x' not found. Available: []".
let _resolveJwtReady: (() => void) | null = null;
const _jwtReady: Promise<void> = new Promise((resolve) => { _resolveJwtReady = resolve; });
if (typeof window !== "undefined") {
  window.addEventListener("message", (event) => {
    // Only the embedding dashboard may hand us a token. Any page can postMessage into an iframe,
    // so ignore anything that did not come from our parent. (A forged token would be rejected
    // server-side anyway — KOGO verifies the signature — but there is no reason to accept it.)
    if (event.source !== window.parent) return;
    if (event.data?.type === "KOGO_AUTH" && event.data?.jwt) {
      _jwt = event.data.jwt;
      _resolveJwtReady?.();
    }
  });
  // Safety net: never block longer than 4s waiting for the token.
  setTimeout(() => _resolveJwtReady?.(), 4000);
}

export function getJwt(): string | null { return _jwt; }
// Await before the first authenticated request so the JWT (→ correct user) is present.
async function ensureJwt(): Promise<void> { if (!_jwt) await _jwtReady; }

export interface ApiResponse {
  success: boolean;
  project: string | null;
  function_called: string | null;
  data: any;
  message: string | null;
  diagnosis: any | null;
}

export async function callApi(functionName: string, params: Record<string, any> = {}): Promise<ApiResponse> {
  await ensureJwt();  // wait for the JWT so the very first call hits the correct user's workspace
  const response = await fetch(API_BASE, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${_jwt ?? "null"}`,
    },
    // Send all 3 identity ids VERBATIM — middleware injects them into the backend env as-is.
    body: JSON.stringify({ project: PROJECT, function: functionName, params, agentId: AGENT_ID, deploymentId: DEPLOYMENT_ID, swarmId: SWARM_ID, originId: ORIGIN_ID }),
    signal: AbortSignal.timeout(30000),
  });
  if (!response.ok) throw new Error(`API error: ${response.status}`);
  return response.json();
}

export async function callApiWithFile(functionName: string, file: File, params: Record<string, any> = {}): Promise<ApiResponse> {
  await ensureJwt();  // wait for the JWT so the call hits the correct user's workspace
  const formData = new FormData();
  formData.append("file", file);
  formData.append("project", PROJECT);
  formData.append("function", functionName);
  formData.append("params", JSON.stringify(params));
  formData.append("agentId", AGENT_ID);
  formData.append("deploymentId", DEPLOYMENT_ID);
  formData.append("swarmId", SWARM_ID);
  formData.append("originId", ORIGIN_ID);
  const response = await fetch(API_BASE, {
    method: "POST",
    headers: { "Authorization": `Bearer ${_jwt ?? "null"}` },
    body: formData,
    signal: AbortSignal.timeout(120000),
  });
  if (!response.ok) throw new Error(`API error: ${response.status}`);
  return response.json();
}

export async function checkApiHealth(): Promise<boolean> {
  try {
    await ensureJwt();  // wait for the JWT so the health check resolves the correct user's workspace
    // Include project= so installed AI Software apps (UUID project IDs) are
    // recognised by the health endpoint's SQLite installation lookup.
    const r = await fetch(`${API_HEALTH}?userId=${USER_ID}&originId=${ORIGIN_ID}&project=${PROJECT}`, {
      signal: AbortSignal.timeout(5000),
      headers: { "Authorization": `Bearer ${_jwt ?? "null"}` },
    });
    if (!r.ok) return false;
    const data = await r.json();
    return Array.isArray(data.projects) && data.projects.includes(PROJECT);
  } catch { return false; }
}
```

### File Upload — Using callApiWithFile (NEVER base64)

**⛔ NEVER send files as base64 in JSON** — use `callApiWithFile` which sends as `multipart/form-data`.

**Frontend usage:**

```typescript
async function handleFileSubmit(file: File, extraParams: Record<string, any> = {}) {
  setUploading(true);
  setUploadError(null);
  try {
    const result = await callApiWithFile("process_{entity}_file", file, extraParams);
    if (result.success) {
      // use result.data
    } else {
      setUploadError(result.message || "Processing failed");
    }
  } catch (err: any) {
    setUploadError(err.message);
  } finally {
    setUploading(false);
  }
}
```

**Python backend pattern:**

```python
def process_{entity}_file(db: Session, file_name: str, file_path: str) -> dict:
    """Process an uploaded file. file_path is injected by the server — never base64."""
    with open(file_path, "rb") as f:
        file_bytes = f.read()
    # process file_bytes — use PyMuPDF, pdfplumber, pandas, openpyxl, etc.
    return {"file_name": file_name, "result": {...}}
```

**Rules:**
- `file_path` is a real filesystem path — the server saves the upload and passes the path to the function
- `file_name` is the original filename from the upload
- Never pass `file_path` as a param from the frontend — the server injects it automatically
- Document `file_path` in document.md as "injected by server (never send from frontend)"

### Dashboard Integration — How to Pass JWT to index.html

Give this snippet to the frontend team. Use it whenever the dashboard opens or embeds a project's `index.html`:

```js
// Option A — iframe (recommended)
// After the iframe loads, send the JWT once.
const iframe = document.getElementById("project-iframe"); // your iframe element
const userJwt = "..."; // JWT token from your dashboard auth state

iframe.addEventListener("load", () => {
  iframe.contentWindow.postMessage(
    { type: "KOGO_AUTH", jwt: userJwt },
    "*"
  );
});

// Option B — new tab / window
const win = window.open(projectUrl, "_blank");
win.addEventListener("load", () => {
  win.postMessage({ type: "KOGO_AUTH", jwt: userJwt }, "*");
});
```

**Rules:**
- Message shape MUST be exactly `{ type: "KOGO_AUTH", jwt: "<token>" }` — index.html listens for this
- Send once after the iframe/window loads — token is stored in memory for the session
- If the user's JWT refreshes, send another `postMessage` with the new token
- If index.html is opened locally (not via dashboard) → no postMessage → `Authorization` header is not set → API rejects
- JWT is sent as `Authorization: Bearer <token>` for both JSON and file upload calls

---

### LIVE/OFFLINE Status (every data page)

```tsx
import { Wifi, WifiOff } from "lucide-react";
const [apiStatus, setApiStatus] = useState<"checking" | "connected" | "offline">("checking");

useEffect(() => {
  const check = async () => setApiStatus((await checkApiHealth()) ? "connected" : "offline");
  check();
  const interval = setInterval(check, 30000);
  return () => clearInterval(interval);
}, []);
```

### Routing — state-based ONLY (no react-router-dom)

```tsx
type Page = "list" | "add" | "detail";
export default function App() {
  const [page, setPage] = useState<Page>("list");
  return (
    <>
      {page === "list" && <ListPage onNavigate={setPage} />}
      {page === "add" && <AddPage onNavigate={setPage} />}
    </>
  );
}
```

### Data Fetching Pattern

```typescript
const fetchData = useCallback(async () => {
  if (apiStatus !== "connected") { setItems([]); return; }
  try {
    const result = await callApi("get_items", { limit, offset });
    if (result.success && result.data?.items) setItems(result.data.items);
    else setItems([]);
  } catch { setItems([]); }
}, [apiStatus, limit, offset]);
```

**Rule:** Offline → show empty state + message. NEVER hardcode fake data.

---

## Build & Bundle Process

```bash
# All commands from inside {PROJECT_DIR}
SCRIPTS_DIR="{PWD}/skills/appster_skill/scripts"

# 1. Init React workspace
cd {PROJECT_DIR}
bash "$SCRIPTS_DIR/init-artifact.sh" frontend

# 2. Enter workspace, write src/ files
cd frontend
# ... write all files ...

# 3. Fix resizable.tsx
cat > src/components/ui/resizable.tsx << 'FIX'
import { Group, Panel, Separator } from "react-resizable-panels"
const ResizablePanelGroup = Group
const ResizablePanel = Panel
const ResizableHandle = Separator
export { ResizablePanelGroup, ResizablePanel, ResizableHandle }
FIX

# 4. Remove favicon reference (Parcel fails if missing)
sed -i '/favicon.svg/d' index.html

# 5. Fix tsconfig deprecation
node -e "const fs=require('fs');const f='tsconfig.app.json';const c=JSON.parse(fs.readFileSync(f,'utf8'));c.compilerOptions.ignoreDeprecations='6.0';fs.writeFileSync(f,JSON.stringify(c,null,2))"

# 6. Build — ONLY this command, never npm run build or pnpm build directly
bash "$SCRIPTS_DIR/bundle-artifact.sh" && cp bundle.html ../index.html

# 6B. Create config.js at project root — MANDATORY for all builds.
#
# This runs inside spin docker where ALL env vars are available.
# AGENT_ID, DEPLOYMENT_ID, SWARM_ID are baked in from env — they identify
# the creating agent/workspace. At install time, pi-api REWRITES this file
# with the installing workspace's IDs. Backend NEVER reads from this file —
# it reads from env (middleware sets env from request body at runtime).
#
# ORIGIN_ID = SWARM_ID if workspace, else AGENT_ID (for middleware routing).
# API_BASE  = KOGO_API_BASE + /api/agent/common_project_api_v1
# API_HEALTH = KOGO_API_BASE + /api/agent/common_project_api_v1/health
#
_AGENT_ID="${AGENT_ID:-}"
_DEPLOYMENT_ID="${DEPLOYMENT_ID:-}"
_SWARM_ID="${SWARM_ID:-}"
# Normalize the literal string "null" → "" so it never leaks into config / origin routing.
[ "$_SWARM_ID" = "null" ] && _SWARM_ID=""
# ORIGIN_ID = SWARM_ID when workspace, else AGENT_ID.
_ORIGIN_ID="${_SWARM_ID:-${_AGENT_ID}}"
_API_BASE="${KOGO_API_BASE:-}/api/agent/common_project_api_v1"
_API_HEALTH="${KOGO_API_BASE:-}/api/agent/common_project_api_v1/health"

cat > ../config.js << CONFIG
(function(){window.APP_CONFIG={API_BASE:'${_API_BASE}',API_HEALTH:'${_API_HEALTH}',PROJECT:'{project_slug}',AGENT_ID:'${_AGENT_ID}',DEPLOYMENT_ID:'${_DEPLOYMENT_ID}',SWARM_ID:'${_SWARM_ID}',ORIGIN_ID:'${_ORIGIN_ID}'};})();
CONFIG

# 6C. Inject <script src="./config.js"> as FIRST script in index.html.
# pi-api detects this tag and replaces it with a full-URL inline APP_CONFIG at serve
# time — it never actually loads as a separate file (srcdoc iframes have no base URL).
# NOTE: Parcel+html-inline output has no <head> tag — inject after <html ...> instead.
node -e "
const fs=require('fs');
const f='../index.html';
let h=fs.readFileSync(f,'utf8');
const tag='<script src=\"./config.js\"></script>';
if(!h.includes(tag)){
  if(h.includes('<head>'))h=h.replace('<head>','<head>'+tag);
  else{const m=h.match(/<html[^>]*>/i);if(m)h=h.replace(m[0],m[0]+tag);else h=tag+h;}
  fs.writeFileSync(f,h);
}
console.log('config.js injected into index.html');
"

# 7. Cleanup — MANDATORY always, success OR failure
rm -rf node_modules dist bundle.html .parcel-cache

# 8. Remove template artifacts
rm -f src/assets/react.svg src/assets/vite.svg vite.config.ts README.md
find . -maxdepth 1 -name "index.html*" ! -name "index.html" -delete 2>/dev/null || true

# 9. Verify
ls {PROJECT_DIR}
# Must show: backend/ frontend/ index.html config.js
```

**⛔ FORBIDDEN:**
- `npm run build` or `pnpm build` directly
- `html-inline` manually
- Skipping node_modules cleanup
- react-router-dom imports

---

## Tool Integration

Projects can call agent tools (web search, PDF OCR, weather, etc.) from Python functions via the tool proxy. Auth, billing, and config are all handled server-side — Python only needs to pass the tool name and params.

### `_call_agent_tool` Helper — CANONICAL (the ONLY definition)

This is the single canonical `_call_agent_tool`. Add it at the top of
functions.py when tools are used. `/call_tool` is a FIXED CONTRACT path and
`USER_JWT_TOKEN` is a FIXED CONTRACT env-var name (a runtime-only secret, the one
allowed `os.environ` read) — copy both verbatim, never invent.

```python
import json       # module-level (already imported at top of functions.py)
import os         # only for the runtime-only USER_JWT_TOKEN read below
import requests
import config

def _call_agent_tool(tool_name: str, params: dict) -> dict:
    resp = requests.post(
        f"{config.KOGO_API_BASE}/api/agent/common_project_api_v1/call_tool",  # always derived from KOGO_API_BASE
        # swarm_id is REQUIRED for portability: when this app is installed in a workspace, the tool it
        # needs lives in that workspace's swarm_capability. The proxy uses swarm_id to load workspace
        # tools (not just the agent's own). Omitting it makes workspace-provisioned tools invisible.
        json={"agentId": config.AGENT_ID, "userId": config.USER_ID, "swarm_id": config.SWARM_ID,
              "tool_name": tool_name, "params": params},
        headers={"Authorization": f"Bearer {os.environ.get('USER_JWT_TOKEN', '')}"},
        timeout=60,
    )
    data = resp.json()
    if not data.get("success"):
        msg = data.get("message", "Tool call failed")
        # Tool not enabled in THIS workspace (e.g. an installed app whose workspace lacks the
        # capability). Return a structured, detectable error so tool-backed UIs can show a clean
        # "capability needed" state instead of a raw failure. (Portability across workspaces.)
        if "not found" in msg.lower():
            return {"error": "tool_unavailable", "tool": tool_name,
                    "message": f"The '{tool_name}' capability isn't enabled in this workspace."}
        return {"error": msg}
    result = data.get("result", {})
    if isinstance(result, dict) and "content" in result:
        content = result["content"]
        if isinstance(content, list) and content:
            text = content[0].get("text", "")
            try:
                return json.loads(text)
            except Exception:
                return {"message": text}
    return result
```

### Tool-Backed Function Pattern

Each tool-backed function is simply a wrapper around `_call_agent_tool`. The tool name and param names come **exactly** from the Tool Proxy Map in SPEC.md:

```python
def get_weather(db: Session, city: str) -> dict:
    return _call_agent_tool("GetWeatherInfo", {"city": city})

def search_web(db: Session, query: str) -> dict:
    return _call_agent_tool("PerplexitySearch", {"query": query})

def extract_pdf(db: Session, file_name: str, file_path: str) -> dict:
    return _call_agent_tool("MistralOCR", {"file_path": file_path})
```

Register in FUNCTIONS dict like any other function. Document in document.md like any other function.

**🔧 MANDATORY — keep `backend/tools_used.json` in sync with the code.** This manifest is the app's
single source of truth for which agent tools it uses. The rule (applies to fresh builds, incremental
"add a tab" edits, AND when touching an OLDER project that predates this file):
- **Whenever you add/edit ANY `_call_agent_tool("X", …)` function → ensure `"X"` has an entry here.**
- **If the project already contains `_call_agent_tool` calls but `tools_used.json` is missing or
  out of date → create/reconcile it now** so it lists every tool name currently used in `functions.py`.
  Do this even if your edit is unrelated to tools — a project that uses tools must always ship this file.

Publish reads this file to snapshot exactly those capabilities, and install auto-provisions them into the
installing workspace — so a research/weather/OCR feature keeps working after the app is installed
elsewhere. Do NOT rely on the SPEC Tool Proxy Map for this (it isn't updated on incremental adds).
(If this file is ever missing, publish falls back to grepping `functions.py` — but always ship the file.)

```jsonc
// backend/tools_used.json  — create if missing; append (never drop existing) on each tool added.
{
  "tools": [
    { "name": "Perplexity", "used_by": ["do_research"], "note": "web research" }
    // { "name": "MistralOCR", "used_by": ["extract_pdf"] }, ...
  ]
}
```
`name` (required) = the EXACT tool name passed to `_call_agent_tool(...)`. `used_by`/`note` are for humans.
If the project has no tool-backed functions, this file may be omitted (or `{ "tools": [] }`).

**⚠️ Portability — a tool-backed function may run in a workspace that lacks the tool.** The same app
can be published and installed into another workspace whose agent doesn't have this capability enabled.
In that case `_call_agent_tool` returns `{"error": "tool_unavailable", "tool": "<name>", "message": "..."}`.
This is NOT a bug — the function must pass that through as-is (it already does), and **every tool-backed
UI (Pattern B) MUST detect `error === "tool_unavailable"` and render a clean "capability needed" state**
(see Pattern B). Never let a missing tool crash the tab or show a raw error — chat/DB features keep working.

CLI testing for tool-backed functions (KOGO platform only — skip if env vars unavailable):
```bash
# Only run if KOGO_API_BASE, AGENT_ID, USER_JWT_TOKEN are already set in your environment.
# NEVER hardcode or substitute a value for any of these.
python functions.py {function_name} '{json_params}'
```
If any env var is unset → SKIP this test. It will run on the KOGO platform.

---

### Pattern A — Agent calls tool directly (no Python code change needed)

Use when the **user asks the agent in chat** to do something with a tool result.

```
User: "Research kubernetes best practices and save it as a task"

Agent:
  1. Call PerplexitySearch tool → result
  2. python functions.py create_task '{"title":"Kubernetes Best Practices","description":"<result>"}'
```

Zero Python changes. Works for any tool. Use this for chat-driven, one-off requests.

---

### Pattern B — UI button/form calls a tool at runtime

Use when a **project page needs to call a tool** (Weather tab, Research tab, PDF import feature, etc.).

```python
# Python function calls _call_agent_tool — proxy handles everything
def get_weather_data(db: Session, city: str) -> dict:
    return _call_agent_tool("GetWeatherInfo", {"city": city})
```

```typescript
// Frontend calls it like any other function — BUT must handle the "tool not enabled here" case,
// because an installed app may run in a workspace that doesn't have this capability.
const res = await callApi("get_weather_data", { city: "Delhi" });
if (res.data?.error === "tool_unavailable") {
  // Show a clean, non-blocking state — do NOT crash the tab or surface a raw error.
  setToolMissing({ tool: res.data.tool, message: res.data.message });
  return;
}
if (res.data?.error) { setError(res.data.message || res.data.error); return; }
// ...use res.data as the tool result
```

**Mandatory UI for a tool-backed tab (e.g. Research):** when `error === "tool_unavailable"`, render a
friendly panel instead of results, e.g.:
```tsx
// 🔌 icon + heading + message
<div style={{ padding: 40, textAlign: "center", color: "var(--text-muted,#6B7280)" }}>
  <div style={{ fontSize: 30, marginBottom: 8 }}>🔌</div>
  <div style={{ fontWeight: 600 }}>This feature needs the “{toolMissing.tool}” capability</div>
  <div style={{ fontSize: 13, marginTop: 6 }}>{toolMissing.message} Ask a workspace admin to enable it.</div>
</div>
```
The rest of the dashboard (chat, tasks, DB features) keeps working normally.

---

### When to use which pattern

| User wants | Pattern |
|---|---|
| "Research X and create a task" (agent chat) | A — agent calls tool, no Python changes |
| "Add a Research tab to the app" | B — Python wraps `_call_agent_tool` |
| "Add weather widget to dashboard" | B — Python wraps `_call_agent_tool` |
| "Import PDF feature" | B — Python wraps `_call_agent_tool` |

---

## Design System

### Step 1 — Select a Template

Template selection is deterministic: SPEC.md MUST carry a `design_template:`
field naming the chosen template folder. Use it verbatim — do not re-judge
"closest aesthetic".

```bash
# List all available templates
ls {DESIGNS_DIR}/

# The chosen folder is the verbatim value of SPEC.md's `design_template:` field.
CHOSEN="$(grep -E '^design_template:' {PROJECT_DIR}/SPEC.md | sed -E 's/^design_template:[[:space:]]*//')"

# Validate against the fixed allowed-set (the folders that exist). If the named
# folder does NOT exist → STOP and report. Never silently substitute another.
test -f "{DESIGNS_DIR}/$CHOSEN/DESIGN.md" \
  || { echo "FAIL: design_template '$CHOSEN' not found under {DESIGNS_DIR}"; exit 1; }

# Copy ONLY the DESIGN.md file — never create a design from scratch.
cp "{DESIGNS_DIR}/$CHOSEN/DESIGN.md" {PROJECT_DIR}/DESIGN.md

# Update ONLY the name: field to match the project — do NOT change anything else
```

**Rule:** Always use the template named in SPEC.md `design_template:`. Never
create a design from scratch. If the field is missing or names a non-existent
folder → STOP and report (do not guess a substitute).

---

### Step 2 — Apply DESIGN.md Tokens

DESIGN.md contains structured tokens. Use them as the source of truth for every visual decision.

**Colors — set CSS variables to the EXACT hex values from DESIGN.md (no mental
math):**

Do NOT convert hex → HSL in your head — LLM color math is non-deterministic.
Write the exact hex strings from DESIGN.md directly:

```css
/* src/index.css */
:root {
  --background:  {DESIGN.md colors.background hex};  /* e.g. #ffffff */
  --foreground:  {DESIGN.md colors.text hex};
  --primary:     {DESIGN.md colors.accent hex};
  --card:        {DESIGN.md colors.surface hex};
  --border:      {DESIGN.md colors.border hex};
  --radius:      {DESIGN.md rounded.md value};
}
```

If a specific library genuinely requires HSL channel values (e.g. a shadcn theme
that expects `H S% L%`), do NOT compute them mentally — run this deterministic
node snippet once per color and paste its output verbatim:

```bash
# Usage: node hex2hsl.js '#3B82F6'  →  prints: 217 91% 60%
node -e '
const h=process.argv[1].replace("#","");
const r=parseInt(h.slice(0,2),16)/255,g=parseInt(h.slice(2,4),16)/255,b=parseInt(h.slice(4,6),16)/255;
const mx=Math.max(r,g,b),mn=Math.min(r,g,b),l=(mx+mn)/2;let hue=0,s=0;
if(mx!==mn){const d=mx-mn;s=l>0.5?d/(2-mx-mn):d/(mx+mn);
hue=mx===r?(g-b)/d+(g<b?6:0):mx===g?(b-r)/d+2:(r-g)/d+4;hue/=6;}
console.log(Math.round(hue*360)+" "+Math.round(s*100)+"% "+Math.round(l*100)+"%");
' "$1"
```

**Typography — load via the bundled `@fontsource` package in main.tsx (NOT CSS
@import, NEVER a CDN link):**

Fonts MUST be bundled into the offline single-file build. NEVER load a font from
a CDN / Google Fonts URL — the bundle must work fully offline.

Take `DESIGN.md typography.fontFamily`, kebab-case it, and import the matching
`@fontsource` package. Example for a DESIGN.md fontFamily of `Plus Jakarta Sans`
→ package `@fontsource/plus-jakarta-sans`:

```typescript
// src/main.tsx
// Replace the package name with @fontsource/<DESIGN.md typography.fontFamily kebab-cased>.
// Import only the weights the design uses.
import "@fontsource/plus-jakarta-sans/400.css";
import "@fontsource/plus-jakarta-sans/500.css";
import "@fontsource/plus-jakarta-sans/600.css";
import "@fontsource/plus-jakarta-sans/700.css";
```

Add the same `@fontsource/<kebab-cased-family>` package to package.json
dependencies so it bundles. No `document.createElement("link")`, no
`fonts.googleapis.com` URL.

**Component tokens from DESIGN.md:**
- `components.button` → apply to button className / style
- `components.card` → apply to card className / style
- `components.input` → apply to input className / style

**Typography sizing — apply from DESIGN.md tokens:**

| Role | Token | Apply to |
|---|---|---|
| Page title / hero | `typography.display` or `typography.heading-1` | `<h1>` |
| Section heading | `typography.heading-2` | `<h2>` |
| Card heading | `typography.heading-3` | `<h3>` |
| Sub-label / group header | `typography.heading-4` | `<h4>` |
| Body copy | `typography.body` | `<p>`, default text |
| Small body / captions | `typography.body-sm` or `typography.caption` | Subtitles, helper text |
| Metric values | `typography.metric-hero` / `typography.metric-lg` | KPI numbers — apply ONLY if `grep -q 'metric-hero\|metric-lg' DESIGN.md` succeeds; else fall back to `typography.heading-1` |
| Form labels | `typography.label` | `<label>` elements |
| Buttons | `typography.button` | Button text |
| Legal / fine print | `typography.legal` | Footer disclaimers — apply ONLY if `grep -q 'legal' DESIGN.md` succeeds; else fall back to `typography.caption` |

**Grid layout rules:**
- Sidebar + content: `display: flex; height: 100vh` — sidebar fixed width, content `flex: 1`
- Card grid: `display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: {spacing.xxl}`
- Form layout: single column on mobile, two-column on wide: `display: grid; grid-template-columns: repeat(2, 1fr); gap: {spacing.lg}`
- Dashboard metric row: `display: grid; grid-template-columns: repeat(4, 1fr); gap: {spacing.lg}` (wrap at smaller widths)
- Never use position: absolute for layout — use flexbox/grid
- Never use margin: auto centering for page layout — use flex justify/align

**Rules:**
- Fonts: use exactly what DESIGN.md specifies — NOT Inter/Arial unless DESIGN.md says so
- Load font via bundled `@fontsource/<family-kebab-cased>` import in `main.tsx` — NEVER CSS `@import` (Parcel can't resolve), NEVER a CDN/Google-Fonts link (offline build)
- No AI slop: no purple gradients, no uniform rounded corners, no generic card-grid-everywhere layouts
- Do NOT change DESIGN.md colors/tokens — use them as-is after copying
- Match rounded values exactly: use `{rounded.md}` not arbitrary px values
- spacing.xs = tightest (4px), spacing.section = widest (56px+) — match to context

---

### Step 3 — Design/Wiring Static Checks (run before bundling)

There is NO render/screenshot step, so "visual verification" is impossible and
forbidden as a gate. Instead run these DETERMINISTIC static checks against the
source files. Each is a grep/file-existence check with a pass/fail answer — if
ANY check fails, fix the source and re-run before bundling.

Run from `{PROJECT_DIR}/frontend`:

```bash
# 1. Every page component file is imported in App.tsx.
for f in src/pages/*.tsx; do
  comp="$(basename "$f" .tsx)"
  grep -q "$comp" src/App.tsx || echo "FAIL: $comp not referenced in App.tsx"
done

# 2. Every callApi("name", ...) call in pages/components refers to a function
#    that the backend exposes (name must appear in backend FUNCTIONS registry).
grep -rhoE 'callApi(WithFile)?\("([a-zA-Z0-9_]+)"' src \
  | sed -E 's/.*"([a-zA-Z0-9_]+)"/\1/' | sort -u | while read -r fn; do
    grep -q "\"$fn\"" ../backend/functions.py || echo "FAIL: callApi('$fn') has no backend FUNCTIONS entry"
  done

# 3. DESIGN.md color tokens are wired into index.css as CSS variables.
grep -q -- '--background' src/index.css || echo "FAIL: --background not set in index.css"
grep -q -- '--primary'    src/index.css || echo "FAIL: --primary not set in index.css"
grep -q -- '--radius'     src/index.css || echo "FAIL: --radius not set in index.css"

# 4. Font is bundled via @fontsource (no CDN), matching DESIGN.md fontFamily.
grep -q '@fontsource/' src/main.tsx || echo "FAIL: no @fontsource import in main.tsx"
grep -qE 'fonts\.googleapis\.com|createElement\("link"\)' src/main.tsx \
  && echo "FAIL: CDN/link-tag font loading present — must be bundled @fontsource"

# 5. No forbidden patterns.
grep -rq 'react-router-dom' src && echo "FAIL: react-router-dom import present"
grep -rqiE 'base64' src && echo "WARN: base64 reference in src — files must use callApiWithFile (multipart)"
```

Each `FAIL:` line printed = a blocking defect. Zero `FAIL:` lines = checks pass.

---

## API Request / Response Format

### Request
```json
POST {API_BASE}/api/agent/common_project_api_v1
{
  "project": "item_catalog",
  "function": "get_items",
  "params": {"category": "Electronics"},
  "agentId": "{agentId}",
  "deploymentId": "{deploymentId}",
  "swarmId": "{swarmId}",
  "originId": "{originId}"
}
```

### Success Response
```json
{
  "success": true,
  "project": "item_catalog",
  "function_called": "get_items",
  "data": {"items": [...], "total": 5},
  "message": null,
  "diagnosis": null
}
```

### Error Response
```json
{
  "success": false,
  "data": null,
  "message": "Error in get_items: ...",
  "diagnosis": {
    "error_type": "AttributeError",
    "fix_needed": true,
    "suggested_fix": "...",
    "file": "artifacts/item-catalog/backend/functions.py"
  }
}
```
