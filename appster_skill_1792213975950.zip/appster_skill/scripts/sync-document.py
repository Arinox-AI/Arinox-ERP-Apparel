#!/usr/bin/env python3
"""
sync-document.py — make document.md agree with functions.py, mechanically.

Why this exists: document.md is the contract the middleware enforces. A function that is not
documented cannot be called, and the app fails at runtime with
"Function 'get_notebooks' not found" while looking perfectly built. Hand-writing that list next
to a 50-function functions.py drifts every single time — so don't hand-write it.

What it does:
  • reads every public function in functions.py (and the FUNCTIONS dict, when present)
  • keeps every entry document.md already has, exactly as written — your param tables, your
    Returns lines, your wording are never touched
  • appends a generated entry for anything missing, with parameters read from the signature
  • never removes anything, so a function documented but not yet written stays visible

Run it from the project root after editing functions.py:
    python3 scripts/sync-document.py backend/functions.py backend/document.md
Exit code 1 means it changed the file — re-read it and fix the `Required` column where the
signature could not tell (a param with no default is marked yes, one with a default is marked no).
"""
import ast
import re
import sys


def exposed_functions(src):
    """Public top-level functions, in source order. If a FUNCTIONS dict exists, it wins."""
    tree = ast.parse(src)
    defs = {}
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and not node.name.startswith("_"):
            params = []
            args = node.args
            defaults = [None] * (len(args.args) - len(args.defaults)) + list(args.defaults)
            for arg, default in zip(args.args, defaults):
                # Plumbing, never an API parameter. Some apps take the session as a first arg;
                # documenting it would tell every caller to pass a database handle over HTTP.
                if arg.arg in ("self", "cls", "kwargs", "db", "session", "conn", "cursor"):
                    continue
                params.append({"name": arg.arg, "required": default is None})
            defs[node.name] = params

    # FUNCTIONS = {"name": fn, ...} is the real public surface when it is there.
    for node in ast.walk(tree):
        if isinstance(node, ast.Assign) and any(
            isinstance(t, ast.Name) and t.id == "FUNCTIONS" for t in node.targets
        ):
            if isinstance(node.value, ast.Dict):
                names = [k.value for k in node.value.keys
                         if isinstance(k, ast.Constant) and isinstance(k.value, str)]
                if names:
                    return {n: defs.get(n, []) for n in names}
    defs.pop("call_function", None)   # the CLI dispatcher is not an API function
    return defs


def documented(doc):
    return set(re.findall(r"^### `(\w+)`", doc, re.M))


def entry_for(name, params):
    rows = "\n".join(
        f"| {p['name']} | string | {'yes' if p['required'] else 'no'} |" for p in params
    ) or "| — | — | — |"
    return (f"### `{name}`\n"
            f"| Parameter | Type | Required |\n"
            f"|-----------|------|----------|\n"
            f"{rows}\n"
            f"**Returns:** TODO — describe the shape this returns\n")


def main(fn_path, doc_path):
    src = open(fn_path).read()
    doc = open(doc_path).read()

    want = exposed_functions(src)
    have = documented(doc)
    missing = [n for n in want if n not in have]

    if not missing:
        print(f"document.md is in sync — {len(want)} function(s), nothing missing")
        return 0

    block = "\n".join(entry_for(n, want[n]) for n in missing)
    if re.search(r"^## Functions\s*$", doc, re.M):
        # append at the end of the Functions section (before the next ## heading, if any)
        m = re.search(r"^## Functions\s*$", doc, re.M)
        rest = doc[m.end():]
        nxt = re.search(r"^## ", rest, re.M)
        cut = m.end() + (nxt.start() if nxt else len(rest))
        doc = doc[:cut].rstrip() + "\n\n" + block + "\n" + doc[cut:]
    else:
        doc = doc.rstrip() + "\n\n## Functions\n\n" + block

    open(doc_path, "w").write(doc)
    print(f"ADDED {len(missing)} missing function(s) to document.md:")
    for n in missing:
        print(f"  - {n}")
    print("\nNow open document.md and fix the Required column + the Returns line for each.")
    return 1


if __name__ == "__main__":
    if len(sys.argv) != 3:
        print(__doc__)
        sys.exit(2)
    sys.exit(main(sys.argv[1], sys.argv[2]))
