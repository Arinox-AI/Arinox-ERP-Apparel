#!/bin/bash
set -e

echo "📦 Bundling React app to single HTML artifact..."

# Check if we're in a project directory
if [ ! -f "package.json" ]; then
  echo "❌ Error: No package.json found. Run this script from your project root."
  exit 1
fi

# Check if index.html exists
if [ ! -f "index.html" ]; then
  echo "❌ Error: No index.html found in project root."
  echo "   This script requires an index.html entry point."
  exit 1
fi

# Install bundling dependencies
echo "📦 Installing bundling dependencies..."
pnpm add -D parcel @parcel/config-default parcel-resolver-tspaths html-inline

# Create Parcel config with tspaths resolver
if [ ! -f ".parcelrc" ]; then
  echo "🔧 Creating Parcel configuration with path alias support..."
  cat > .parcelrc << 'EOF'
{
  "extends": "@parcel/config-default",
  "resolvers": ["parcel-resolver-tspaths", "..."]
}
EOF
fi

# Clean previous build artifacts and cache
echo "🧹 Cleaning previous build..."
rm -rf dist bundle.html .parcel-cache

# Build with Parcel
echo "🔨 Building with Parcel..."
pnpm exec parcel build index.html --dist-dir dist --no-source-maps

# Inline everything into single HTML
echo "🎯 Inlining all assets into single HTML file..."
pnpm exec html-inline dist/index.html > bundle.html

# Inline fonts as base64 data URIs into bundle.html
# Must run AFTER html-inline because html-inline copies CSS as-is (no url() processing).
# At this point CSS is in <style> blocks so url() font refs are present in the HTML.
echo "🔤 Inlining fonts as base64..."
node - << 'NODE_SCRIPT'
const fs = require('fs');
const path = require('path');
let html = fs.readFileSync('bundle.html', 'utf8');
// Find all font url() references and replace with base64
html = html.replace(/url\(([^)]+\.(woff2?|ttf|eot|otf))\)/g, (match, fontPath) => {
  const clean = fontPath.replace(/['"]/g, '');
  const abs = path.resolve('dist', clean);
  if (fs.existsSync(abs)) {
    const ext = path.extname(clean).slice(1);
    const mime = ext === 'woff2' ? 'font/woff2' : ext === 'woff' ? 'font/woff' : `font/${ext}`;
    const b64 = fs.readFileSync(abs).toString('base64');
    return `url(data:${mime};base64,${b64})`;
  }
  return match;
});
fs.writeFileSync('bundle.html', html);
NODE_SCRIPT

# Move inline <script> blocks from <head> to before </body>
# Prevents React createRoot error when script runs before <body> is parsed (srcdoc iframes)
echo "📦 Moving bundle scripts to end of body..."
node - << 'MOVE_SCRIPT'
const fs = require('fs');
let html = fs.readFileSync('bundle.html', 'utf8');
const scripts = [];
// Extract all <script>...</script> blocks from inside <head>
html = html.replace(/(<head[\s\S]*?>)([\s\S]*?)(<\/head>)/i, (_, open, content, close) => {
  const cleaned = content.replace(/<script\b[^>]*>([\s\S]*?)<\/script>/gi, (tag) => {
    // Keep <script src="..."> in head; move only inline scripts (the bundle)
    if (/<script\s[^>]*src=/i.test(tag)) return tag;
    scripts.push(tag);
    return '';
  });
  return open + cleaned + close;
});
if (scripts.length) {
  html = html.replace(/<\/body>/i, scripts.join('') + '</body>');
}
fs.writeFileSync('bundle.html', html);
console.log(`Moved ${scripts.length} script block(s) to end of body`);
MOVE_SCRIPT

# Get file size
FILE_SIZE=$(du -h bundle.html | cut -f1)

echo ""
echo "✅ Bundle complete!"
echo "📄 Output: bundle.html ($FILE_SIZE)"
echo ""
echo "🧹 Cleaning build cache..."
rm -rf .parcel-cache
echo "You can now use this single HTML file as an artifact in Claude conversations."
echo "To test locally: open bundle.html in your browser"