# Plotly Scripts & React Embedding

## React Embedding Snippet (Standard)
```tsx
import Plot from "react-plotly.js";

export function PlotlyChart({ data, layout }: { data: any[]; layout: any }) {
  return (
    <Plot
      data={data}
      layout={{
        ...layout,
        autosize: true,
        margin: { l: 30, r: 20, t: 40, b: 30 },
        paper_bgcolor: "transparent",
        plot_bgcolor: "transparent",
      }}
      useResizeHandler
      style={{ width: "100%", height: "100%" }}
      config={{ displayModeBar: false, responsive: true }}
    />
  );
}
```

## React Embedding (from Plotly JSON)
```tsx
import Plot from "react-plotly.js";
import chartJson from "@/data/chart.json";

export function PlotlyFromJson() {
  return (
    <Plot
      data={chartJson.data}
      layout={{
        ...chartJson.layout,
        autosize: true,
        margin: { l: 30, r: 20, t: 40, b: 30 },
        paper_bgcolor: "transparent",
        plot_bgcolor: "transparent",
      }}
      useResizeHandler
      style={{ width: "100%", height: "100%" }}
      config={{ displayModeBar: false, responsive: true }}
    />
  );
}
```

## Python Scripts (Interactive)

### 1) Line Chart (Trend)
```python
import plotly.express as px
import pandas as pd

df = pd.DataFrame({
    "month": ["Jan", "Feb", "Mar", "Apr", "May", "Jun"],
    "value": [32, 40, 38, 52, 61, 59]
})

fig = px.line(df, x="month", y="value", markers=True, title="Revenue Trend")
fig.update_layout(template="plotly_white", height=360)
print(fig.to_json())
```

### 2) Bar Chart (Category)
```python
import plotly.express as px
import pandas as pd

df = pd.DataFrame({
    "segment": ["Enterprise", "Mid-Market", "Self-Serve"],
    "value": [5.8, 3.1, 1.4]
})

fig = px.bar(df, x="segment", y="value", title="ARR by Segment", text="value")
fig.update_layout(template="plotly_white", height=360)
print(fig.to_json())
```

### 3) Area Chart (Cumulative)
```python
import plotly.express as px
import pandas as pd

df = pd.DataFrame({
    "week": [1, 2, 3, 4, 5, 6],
    "value": [120, 180, 240, 300, 360, 420]
})

fig = px.area(df, x="week", y="value", title="Cumulative Pipeline")
fig.update_layout(template="plotly_white", height=360)
print(fig.to_json())
```

### 4) Multi‑Series Line
```python
import plotly.express as px
import pandas as pd

df = pd.DataFrame({
    "month": ["Jan", "Feb", "Mar", "Apr", "May", "Jun"],
    "Enterprise": [12, 14, 16, 18, 20, 22],
    "MidMarket": [8, 9, 9, 10, 11, 12]
})

fig = px.line(df, x="month", y=["Enterprise", "MidMarket"], title="Pipeline by Segment")
fig.update_layout(template="plotly_white", height=360)
print(fig.to_json())
```

### 5) Waterfall
```python
import plotly.graph_objects as go

fig = go.Figure(go.Waterfall(
    name="Revenue", orientation="v",
    measure=["relative", "relative", "relative", "total"],
    x=["New", "Expansion", "Churn", "Net"],
    y=[2.4, 1.2, -0.6, 0],
))
fig.update_layout(title="Revenue Waterfall", template="plotly_white", height=360)
print(fig.to_json())
```

### 6) Sankey (Flow)
```python
import plotly.graph_objects as go

fig = go.Figure(go.Sankey(
    node=dict(label=["Inbound", "Qualified", "Closed", "Lost"]),
    link=dict(source=[0, 1, 1], target=[1, 2, 3], value=[100, 45, 55])
))
fig.update_layout(title="Pipeline Flow", template="plotly_white", height=360)
print(fig.to_json())
```

### 7) Heatmap
```python
import plotly.express as px

z = [[1, 20, 30], [20, 1, 60], [30, 60, 1]]
fig = px.imshow(z, text_auto=True, title="Correlation Heatmap")
fig.update_layout(template="plotly_white", height=360)
print(fig.to_json())
```

### 8) KPI Gauge
```python
import plotly.graph_objects as go

fig = go.Figure(go.Indicator(
    mode="gauge+number+delta",
    value=72,
    delta={"reference": 65},
    gauge={"axis": {"range": [0, 100]}}
))
fig.update_layout(title="Health Score", template="plotly_white", height=300)
print(fig.to_json())
```

### 9) Pie / Donut
```python
import plotly.express as px
import pandas as pd

df = pd.DataFrame({
    "segment": ["Enterprise", "Mid-Market", "Self-Serve"],
    "value": [58, 31, 11]
})

fig = px.pie(df, values="value", names="segment", hole=0.5, title="Revenue Mix")
fig.update_layout(template="plotly_white", height=360)
print(fig.to_json())
```

### 10) Scatter (Correlation)
```python
import plotly.express as px
import pandas as pd

_df = pd.DataFrame({
    "cac": [120, 180, 240, 300, 360],
    "ltv": [900, 1100, 1400, 1550, 1700],
    "segment": ["SMB", "SMB", "MM", "ENT", "ENT"]
})

fig = px.scatter(_df, x="cac", y="ltv", color="segment", title="CAC vs LTV")
fig.update_layout(template="plotly_white", height=360)
print(fig.to_json())
```
